#version 150

// Экранная обводка руки/предметов/блоков в руке.
// Sampler0 = копия глубины основного кадра после отрисовки руки (глубина < 1.0 => пиксель руки/предмета).
// Обводка = пиксели вне маски, у которых в радиусе uWidth есть пиксель маски (дилатация силуэта).

uniform sampler2D Sampler0;
uniform vec2 uSize;
uniform float uWidth;
uniform float uTime;
uniform float uTheme;
uniform float uAlpha;
uniform vec3 uBase;
uniform vec3 uC1;
uniform vec3 uC2;

out vec4 fragColor;

float hit(vec2 p) {
    vec2 uv = p / uSize;
    if (uv.x <= 0.0 || uv.y <= 0.0 || uv.x >= 1.0 || uv.y >= 1.0) return 0.0;
    return texture(Sampler0, uv).r < 0.99999 ? 1.0 : 0.0;
}

vec3 hsv(float h, float s, float v) {
    vec3 k = clamp(abs(fract(vec3(h) + vec3(0.0, 0.6666667, 0.3333333)) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
    return v * mix(vec3(1.0), k, s);
}

vec3 lineColor(vec2 q) {
    float x = (q.x - 0.5) * 1.2;
    float y = (q.y - 0.5) * 0.7;
    float t = uTime;
    int th = int(uTheme + 0.5);
    if (th == 1 || th == 2 || th == 3) {
        return mix(uBase, vec3(1.0), 0.55 + 0.35 * sin(t * 2.2 + x * 8.0 + y * 5.0));
    }
    if (th == 4) {
        return mix(uBase, vec3(1.0), 0.25 + 0.5 * (0.5 + 0.5 * sin(t * 3.0 + x * 10.0 + y * 6.0)));
    }
    if (th == 5) {
        return hsv(t * 0.15 + x * 2.2 + y * 1.6 + 0.5, 0.9, 1.0);
    }
    if (th == 6) {
        return mix(uBase, vec3(1.0), 0.45 + 0.45 * sin(t * 2.0 + y * 8.0));
    }
    if (th == 7) {
        return mix(hsv(t * 0.12 + x * 2.0 + y * 1.4, 0.5, 1.0), vec3(1.0), 0.5 + 0.2 * sin(t * 2.0 + x * 6.0));
    }
    float w = 0.5 + 0.5 * sin(t * 2.2 + (x * 6.0 + y * 9.0));
    return mix(uC1, uC2, w);
}

void main() {
    vec2 p = gl_FragCoord.xy;

    // внутри руки/предмета обводки нет
    if (hit(p) > 0.5) discard;

    float w = max(uWidth, 1.0);
    float reach = w + 1.0;

    // дешёвый ранний выход: 16 проб вокруг, большинство пикселей экрана отсекаются здесь
    float nbr = 0.0;
    for (int k = 0; k < 8; k++) {
        float a = 0.7853982 * float(k);
        vec2 d = vec2(cos(a), sin(a));
        nbr += hit(p + d * reach) + hit(p + d * reach * 0.5);
    }
    if (nbr < 0.5) discard;

    // точное расстояние до силуэта: 8 колец x 16 направлений
    float best = reach + 2.0;
    for (int i = 1; i <= 8; i++) {
        float r = reach * float(i) / 8.0;
        for (int k = 0; k < 16; k++) {
            float a = 0.3926991 * float(k);
            vec2 d = vec2(cos(a), sin(a));
            if (hit(p + d * r) > 0.5) best = min(best, r);
        }
        if (best <= reach) break;
    }

    float cover = 1.0 - smoothstep(w - 0.6, w + 0.6, best);
    if (cover <= 0.01) discard;

    fragColor = vec4(lineColor(p / uSize), cover * uAlpha);
}
