#version 150

in vec2 vNdc;
out vec4 fragColor;

uniform float uTime;
uniform vec2 uResolution;
uniform vec3 uColor;
uniform float uAlpha;
uniform float uSpeed;
uniform float uScale;
uniform float uIntensity;
uniform float uFov;
uniform float uMode;
uniform float uIter;
uniform vec3 uCameraDir;
uniform vec3 uCamRight;
uniform vec3 uCamUp;

float caustic(vec2 p, float t) {
    vec2 i = p;
    float c = 1.0;
    float inten = 0.005;
    for (int n = 0; n < 5; n++) {
        if (float(n) >= uIter) break;
        float tt = t * (1.0 - (3.5 / float(n + 1)));
        i = p + vec2(cos(tt - i.x) + sin(tt + i.y), sin(tt - i.y) + cos(tt + i.x));
        c += 1.0 / length(vec2(p.x / (sin(i.x + tt) / inten), p.y / (cos(i.y + tt) / inten)));
    }
    c /= max(uIter, 1.0);
    c = 1.17 - pow(abs(c), 1.4);
    return pow(abs(c), 8.0);
}

void main() {
    float aspect = uResolution.x / max(uResolution.y, 1.0);
    float th = tan(uFov * 0.5);
    vec3 rd = normalize(uCameraDir + uCamRight * (vNdc.x * th * aspect) + uCamUp * (vNdc.y * th));

    float mask = smoothstep(-0.02, 0.2, rd.y);
    if (mask <= 0.0) discard;

    vec2 p = rd.xz / (rd.y + 0.45) * uScale;
    float t = uTime * uSpeed;

    if (uMode < 0.5) {
        float w = sin(p.x * 1.7 + t) + sin(p.y * 2.3 - t * 1.3) + sin((p.x + p.y) * 1.1 + t * 0.7);
        float v = 0.5 + w * (1.0 / 6.0);
        fragColor = vec4(uColor * (0.55 + 0.45 * v) * uIntensity, uAlpha * mask * (0.35 + 0.65 * v));
    } else {
        vec2 q = mod(p * 6.28318, 6.28318) - 250.0;
        float c = caustic(q, t * 0.5 + 23.0);
        fragColor = vec4(uColor * c * uIntensity, uAlpha * mask * clamp(c, 0.0, 1.0));
    }
}
