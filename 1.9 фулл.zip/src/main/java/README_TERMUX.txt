BaTVisuals — патч (все правки из чата одним архивом)
======================================================

Что внутри (6 файлов, полные версии — просто заменить целиком):

  dev/batvisuals/modules/impl/render/Wings.java
      - крылья ближе к спине, чуть крупнее, плавнее анимация (2 слоя: взмах + лёгкий sway)

  dev/batvisuals/modules/impl/render/Pets.java
      - добавлены питомцы: Cat, Fox, Parrot (плюс старые Bat/Allay/Wolf)
      - фикс Wolf: не проваливается под землю (snap to ground), убран рывок
        при обычном прыжке (grace-период), анимация ходьбы лап
      - Bat/Allay/Parrot теперь летают с плавным hover + взмахом крыльев

  dev/batvisuals/mixin/HeldItemRendererMixin.java
      - фикс HandShader: цвет шейдера больше не "залипает" при вкл/выкл модуля

  dev/batvisuals/mixin/MixinCapeFeatureRenderer.java
      - фикс Cape: убран огромный плащ (был баг с квадратной текстурой logo.png
        вместо нормальной cape-текстуры 2:1)

  dev/batvisuals/client/ui/hud/impl/DynamicIsland.java
      - фикс "айфоновской" HUD-панели: убрано пустое место, ширина плавно
        анимируется и расширяется симметрично от центра (50/50 в обе стороны)
      - новые статусы: AFK, Combat, Low FPS (кроме старых Online/Menu/PvP)

  dev/batvisuals/client/managers/ModuleManager.java
      - ВАЖНО: тут добавлена регистрация `new Wings()` и `new Cape()` — без
        этого файла крылья и плащ не появятся в списке модулей вообще, даже
        если заменить их файлы по отдельности. Обязательно заменяй и этот
        файл тоже.


КАК ПРИМЕНИТЬ ЧЕРЕЗ TERMUX
---------------------------

1. Разархивируй этот патч рядом с исходником мода (src.zip), например:

     cd ~/storage/downloads
     unzip -o batvisuals_patch.zip -d patch

2. Найди корень исходников мода (внутри твоей папки BaTVisuals — путь обычно
   заканчивается на .../src/main/java/dev/batvisuals/). Дальше команды
   считают, что исходник лежит в ~/storage/downloads/BaTVisuals/src/main/java

   Подставь свой реальный путь вместо SRC ниже:

     SRC=~/storage/downloads/BaTVisuals/src/main/java

3. Скопируй все файлы патча поверх, сохраняя структуру:

     cp -rv ~/storage/downloads/patch/dev/* "$SRC/dev/"

   Это перезапишет ровно те 6 файлов, ничего больше не тронет.

4. Пересобери мод как обычно (gradlew build) там, где у тебя обычно
   происходит сборка (Termux сам Gradle-сборку Minecraft-мода не потянет
   без полноценного JDK+Android/Java toolchain и сетевого доступа к
   Maven-репозиториям Fabric/Minecraft — собирай на ПК/ноутбуке, если
   сборка через Termux у тебя раньше не работала).

Если структура папок у тебя отличается (не .../src/main/java/dev/batvisuals/...),
просто вручную положи каждый .java-файл на то же место, где лежит его
одноимённый "старый" файл — imports/package в каждом файле уже верные.
