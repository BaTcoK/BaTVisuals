package dev.batvisuals;

import dev.batvisuals.client.managers.GraffitiManager;


import dev.batvisuals.client.managers.*;
import dev.batvisuals.client.managers.FavoritesManager;
import dev.batvisuals.client.ui.mainmenu.MainMenu;
import dev.batvisuals.client.util.Wrapper;
import meteordevelopment.orbit.EventBus;
import meteordevelopment.orbit.IEventBus;
import dev.batvisuals.client.ui.clickgui.ClickGui;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.util.Identifier;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import lombok.*;

import java.io.File;
import java.lang.invoke.MethodHandles;

@Getter
public class  batvisuals implements ModInitializer, Wrapper {

    @Getter private static batvisuals instance;

    private IEventBus eventHandler;
    private long initTime;
    private ModuleManager moduleManager;
    private CommandManager commandManager;
    private ConfigManager configManager;
    private AutoSaveManager autoSaveManager;
    private NotifyManager notifyManager;
    private PerformanceManager performanceManager;
    private ClickGui clickGui;
    private HudManager hudManager;
    private dev.batvisuals.client.managers.AltManager altManager;
    private MainMenu mainmenu;
    private dev.batvisuals.client.ui.hud.impl.WaypointOverlay waypointOverlay;
    private dev.batvisuals.client.managers.AutoEventManager autoEventManager;
    // private dev.batvisuals.client.ui.hud.impl.MusicKaraokeOverlay musicKaraokeOverlay;
    private FirebaseManager firebaseManager;
    private GraffitiManager graffitiManager;

    public static Logger LOGGER = LogManager.getLogger(batvisuals.class);
    private final File globalsDir = new File(mc.runDirectory, "batvisuals");
    private final File configsDir = new File(globalsDir, "configs");

    @Override
    public void onInitialize() {
        LOGGER.info("[batvisuals] Starting initialization.");
        initTime = System.currentTimeMillis();
        instance = this;

        createDirs(globalsDir, configsDir);
        eventHandler = new EventBus();

        eventHandler.registerLambdaFactory("dev.batvisuals",
                (lookupInMethod, klass) -> (MethodHandles.Lookup) lookupInMethod.invoke(null, klass, MethodHandles.lookup())
        );

        FriendsManager.init(globalsDir);
        dev.batvisuals.client.managers.CrosshairPresetManager.init(globalsDir);
        WaypointManager.init(globalsDir);
        dev.batvisuals.client.managers.MusicManager.init(globalsDir);
        FavoritesManager.init(globalsDir);
        AltManager.init(globalsDir);
        String lastAlt = AltManager.getLastUsedNickname();
        if (lastAlt != null && !lastAlt.isEmpty()) {
            AltManager.applyNickname(lastAlt);
        }

        notifyManager = new NotifyManager();
        performanceManager = new PerformanceManager();
        moduleManager = new ModuleManager();
        commandManager = new CommandManager();
        configManager = new ConfigManager();
        autoSaveManager = new AutoSaveManager();
        clickGui = new ClickGui();
        hudManager = new HudManager();
        mainmenu = new MainMenu();

        // Always-on waypoint overlay
        waypointOverlay = new dev.batvisuals.client.ui.hud.impl.WaypointOverlay();
        eventHandler.subscribe(waypointOverlay);

        autoEventManager = new dev.batvisuals.client.managers.AutoEventManager();
        // Караоке временно отключено
        // musicKaraokeOverlay = new dev.batvisuals.client.ui.hud.impl.MusicKaraokeOverlay();
        // eventHandler.subscribe(musicKaraokeOverlay);

        firebaseManager = new FirebaseManager();
        graffitiManager = new GraffitiManager();
        graffitiManager.setBaseUrl("https://batvisuals-e047c-default-rtdb.firebaseio.com");
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            if (client.player != null) {
                firebaseManager.markOnline(client.player.getGameProfile().getId(), client.player.getGameProfile().getName());
            }
            dev.batvisuals.client.managers.WaypointManager.refreshContext();
        });
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.DISCONNECT.register((handler, client) ->
                firebaseManager.markOffline());

        // Загружаем автоматически сохраненную конфигурацию
        autoSaveManager.loadAutoSave();
        try {
            var gr = moduleManager.getModule(dev.batvisuals.modules.impl.render.Graffiti.class);
            if (gr != null) gr.ensureAlwaysOn();
        } catch (Throwable ignored) {}

        
        net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK.register(client -> {
            try {
                var vm = moduleManager.getModule(dev.batvisuals.modules.impl.render.ViewModel.class);
                if (vm != null) vm.pollOpenEditor();
            } catch (Throwable ignored) {}
            try {
                var ch = moduleManager.getModule(dev.batvisuals.modules.impl.render.Crosshair.class);
                // Crosshair opens editor itself when enabled; no-op
            } catch (Throwable ignored) {}
        });

        // Регистрация события для замены TitleScreen на MainMenu
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (dev.batvisuals.client.ui.mainmenu.MenuStyle.isCustom()
                    && client.currentScreen instanceof TitleScreen
                    && !(client.currentScreen instanceof MainMenu)) {
                client.setScreen(mainmenu);
            }
            if (autoEventManager != null) {
                try { autoEventManager.tick(); } catch (Throwable ignored) {}
            }
        });

        LOGGER.info("[batvisuals] Successfully initialized for {} ms.", System.currentTimeMillis() - initTime);
    }

    private void createDirs(File... file) {
        for (File f : file) f.mkdirs();
    }

    public static Identifier id(String texture) {
        return Identifier.of("batvisuals", texture);
    }
}