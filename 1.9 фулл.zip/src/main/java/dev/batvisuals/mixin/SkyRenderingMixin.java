package dev.batvisuals.mixin;

import dev.batvisuals.batvisuals;
import dev.batvisuals.modules.impl.render.SkyFX;
import net.minecraft.client.render.SkyRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.awt.Color;

/**
 * Colors the actual sky disc in 1.21.4 (SkyRendering.renderSky(R,G,B)).
 */
@Mixin(SkyRendering.class)
public class SkyRenderingMixin {

    @ModifyVariable(method = "renderSky", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private float batvisuals$skyR(float red) {
        Color c = sky();
        return c == null ? red : c.getRed() / 255f;
    }

    @ModifyVariable(method = "renderSky", at = @At("HEAD"), argsOnly = true, ordinal = 1, require = 0)
    private float batvisuals$skyG(float green) {
        Color c = sky();
        return c == null ? green : c.getGreen() / 255f;
    }

    @ModifyVariable(method = "renderSky", at = @At("HEAD"), argsOnly = true, ordinal = 2, require = 0)
    private float batvisuals$skyB(float blue) {
        Color c = sky();
        return c == null ? blue : c.getBlue() / 255f;
    }

    private static Color sky() {
        try {
            SkyFX mod = batvisuals.getInstance().getModuleManager().getModule(SkyFX.class);
            if (mod != null && mod.isToggled() && mod.getSkyBlend() > 0.05f) {
                return mod.getSkyColor();
            }
        } catch (Throwable ignored) {}
        return null;
    }
}
