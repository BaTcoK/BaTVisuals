package dev.batvisuals.mixin;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.events.impl.EventHandledScreen;
import dev.batvisuals.modules.impl.utility.Collector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.slot.Slot;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(HandledScreen.class)
public abstract class HandledScreenMixin {
	@Shadow protected int backgroundWidth;
	@Shadow protected int backgroundHeight;
	@Shadow protected int x;
	@Shadow protected int y;
	@Shadow @Nullable protected Slot focusedSlot;

	@Inject(method = "render", at = @At("RETURN"))
	private void batvisuals$afterRender(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
		batvisuals.getInstance().getEventHandler().post(
				new EventHandledScreen(context, focusedSlot, backgroundWidth, backgroundHeight, x, y, mouseX, mouseY)
		);
	}

	private static boolean collectorBlocksInput() {
		try {
			Collector c = batvisuals.getInstance().getModuleManager().getModule(Collector.class);
			return c != null && c.isToggled() && c.isOverlayOpen();
		} catch (Throwable t) {
			return false;
		}
	}

	@Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true, require = 0)
	private void batvisuals$mouseClicked(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
		try {
			Collector collector = batvisuals.getInstance().getModuleManager().getModule(Collector.class);
			if (collector != null && collector.isToggled()
					&& collector.onInventoryMouseClicked(mouseX, mouseY, button, x, y, backgroundWidth, backgroundHeight)) {
				cir.setReturnValue(true);
			}
		} catch (Throwable ignored) {}
	}

	@Inject(method = "mouseReleased", at = @At("HEAD"), cancellable = true, require = 0)
	private void batvisuals$mouseReleased(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
		if (collectorBlocksInput()) {
			cir.setReturnValue(true);
		}
	}

	@Inject(method = "mouseDragged", at = @At("HEAD"), cancellable = true, require = 0)
	private void batvisuals$mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY, CallbackInfoReturnable<Boolean> cir) {
		if (collectorBlocksInput()) {
			cir.setReturnValue(true);
		}
	}

	@Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true, require = 0)
	private void batvisuals$keyPressed(int keyCode, int scanCode, int modifiers, CallbackInfoReturnable<Boolean> cir) {
		try {
			Collector collector = batvisuals.getInstance().getModuleManager().getModule(Collector.class);
			if (collector != null && collector.isToggled() && collector.onInventoryKeyPressed(keyCode)) {
				cir.setReturnValue(true);
			}
		} catch (Throwable ignored) {}
	}
}
