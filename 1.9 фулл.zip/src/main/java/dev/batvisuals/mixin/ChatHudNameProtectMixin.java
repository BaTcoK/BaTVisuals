package dev.batvisuals.mixin;

import dev.batvisuals.modules.impl.utility.NameProtect;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(ChatHud.class)
public class ChatHudNameProtectMixin {

    @ModifyVariable(method = "addMessage(Lnet/minecraft/text/Text;)V", at = @At("HEAD"), argsOnly = true)
    private Text batvisuals$chat(Text message) {
        NameProtect np = NameProtect.getInstance();
        if (np == null || !np.isToggled() || message == null) return message;
        return np.protectText(message);
    }

    // 1.21.4 may use addMessage(Text, MessageSignatureData, MessageIndicator)
    @ModifyVariable(
            method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
            at = @At("HEAD"),
            argsOnly = true,
            require = 0
    )
    private Text batvisuals$chatSigned(Text message) {
        NameProtect np = NameProtect.getInstance();
        if (np == null || !np.isToggled() || message == null) return message;
        return np.protectText(message);
    }
}
