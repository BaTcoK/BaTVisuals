package dev.batvisuals.mixin;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.util.render.HandItemOutline;
import dev.batvisuals.modules.impl.render.HandShader;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ModelTransformationMode;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemRenderer.class)
public abstract class ItemRenderProviderMixin {

    @Unique
    private static HandShader batvisuals$handShader() {
        try {
            return batvisuals.getInstance().getModuleManager().getModule(HandShader.class);
        } catch (Throwable ignored) {
            return null;
        }
    }

    @ModifyVariable(
            method = "renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/world/World;III)V",
            at = @At("HEAD"),
            argsOnly = true,
            require = 0
    )
    private VertexConsumerProvider batvisuals$wrapProvider(VertexConsumerProvider provider) {
        if (!HandItemOutline.isFirstPerson() || provider == null) return provider;
        try {
            HandShader hs = batvisuals$handShader();
            if (hs == null || !hs.isToggled() || !hs.itemsActive()) return provider;
            HandItemOutline wrapper = hs.wrapItem(provider);
            HandItemOutline.pushActive(wrapper);
            return wrapper;
        } catch (Throwable ignored) {
            return provider;
        }
    }

    @Inject(
            method = "renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/world/World;III)V",
            at = @At("RETURN"),
            require = 0
    )
    private void batvisuals$flushProvider(
            LivingEntity entity, ItemStack stack, ModelTransformationMode transformationMode, boolean leftHanded,
            MatrixStack matrices, VertexConsumerProvider vertexConsumers, net.minecraft.world.World world,
            int light, int overlay, int seed, CallbackInfo ci) {
        HandItemOutline wrapper = HandItemOutline.popActive();
        if (wrapper != null) {
            try { wrapper.flush(); } catch (Throwable ignored) {}
        }
    }
}
