package dev.batvisuals.mixin;

import dev.batvisuals.batvisuals;
import dev.batvisuals.modules.impl.utility.HitSound;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntity.class)
public abstract class HitSoundMixin {

	@Inject(method = "attack", at = @At("HEAD"))
	private void onAttack(Entity target, CallbackInfo ci) {
		PlayerEntity self = (PlayerEntity) (Object) this;
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc == null || mc.player == null) return;
		// only local client player
		if (self != mc.player || !self.getWorld().isClient) return;

		HitSound module = batvisuals.getInstance().getModuleManager().getModule(HitSound.class);
		if (module == null || !module.isToggled()) return;

		if (!(target instanceof LivingEntity le) || !le.isAlive() || !target.isAttackable()) return;

		if (module.isOnlyCrits() && !isLocalCriticalHit(self, target)) return;

		float volume = module.getVolume().getValue() != null ? module.getVolume().getValue() : 1f;
		String soundId = module.getSelectedSound();
		mc.getSoundManager().play(
				PositionedSoundInstance.master(
						SoundEvent.of(Identifier.of(soundId)),
						1.0f,
						volume
				)
		);
	}

	/**
	 * Vanilla-like critical conditions at HEAD of attack (cooldown not reset yet).
	 * Sprint blocks crit in vanilla — included.
	 */
	private static boolean isLocalCriticalHit(PlayerEntity self, Entity target) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc == null || self != mc.player) return false;
		if (!(target instanceof LivingEntity le) || !le.isAlive()) return false;

		return self.getAttackCooldownProgress(0.5f) > 0.9f
				&& self.fallDistance > 0.0f
				&& !self.isOnGround()
				&& !self.isClimbing()
				&& !self.isTouchingWater()
				&& !self.hasStatusEffect(StatusEffects.BLINDNESS)
				&& !self.hasVehicle()
				&& !self.isSprinting();
	}
}
