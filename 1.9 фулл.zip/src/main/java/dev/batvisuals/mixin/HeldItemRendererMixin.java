package dev.batvisuals.mixin;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.util.render.Wrapper;
import dev.batvisuals.modules.impl.render.HandShader;
import dev.batvisuals.modules.impl.render.SwingAnimation;
import dev.batvisuals.modules.impl.render.ViewModel;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PotionItem;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin implements Wrapper {

    @Shadow @Final private MinecraftClient client;

    @Shadow
    protected abstract void renderFirstPersonItem(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand, float swingProgress, ItemStack item, float equipProgress, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light);

    @Shadow
    protected abstract void swingArm(float swingProgress, float equipProgress, MatrixStack matrices, int armX, Arm arm);
    // ---------- HandShader: flat fill + outline on the ARM only (items untouched) ----------


    @Unique
    private VertexConsumerProvider batvisuals$wrapArm(VertexConsumerProvider provider) {
        HandShader hs = getHandShader();
        if (hs == null || !hs.isToggled() || provider == null) return provider;
        return hs.wrapArm(provider);
    }

    /** empty hand */
    @ModifyVariable(method = "renderArmHoldingItem", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private VertexConsumerProvider batvisuals$fillArmHolding(VertexConsumerProvider provider) {
        return batvisuals$wrapArm(provider);
    }

    /** hands holding a map */
    @ModifyVariable(method = "renderArm", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private VertexConsumerProvider batvisuals$fillArm(VertexConsumerProvider provider) {
        return batvisuals$wrapArm(provider);
    }

    private HandShader getHandShader() {
        try {
            return batvisuals.getInstance().getModuleManager().getModule(HandShader.class);
        } catch (Throwable t) {
            return null;
        }
    }

    // ---------- ViewModel / SwingAnimation (unchanged) ----------

    @Inject(
            method = "renderFirstPersonItem",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/util/math/MatrixStack;push()V",
                    shift = At.Shift.AFTER,
                    ordinal = 0
            ),
            require = 0
    )
    public void injectAfterMatrixPushHandPosition(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand, float swingProgress, ItemStack item, float equipProgress, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        try {
            ViewModel viewModel = batvisuals.getInstance().getModuleManager().getModule(ViewModel.class);
            if (viewModel == null || !viewModel.isToggled()) return;
            if (item.isEmpty() || item.contains(DataComponentTypes.MAP_ID)) return;

            boolean isMainHand = hand == Hand.MAIN_HAND;
            float x = isMainHand ? viewModel.mainX.getValue() : viewModel.offX.getValue();
            float y = isMainHand ? viewModel.mainY.getValue() : viewModel.offY.getValue();
            float z = isMainHand ? viewModel.mainZ.getValue() : viewModel.offZ.getValue();

            boolean isActiveItem = client.player != null && client.player.getActiveItem().getItem() == item.getItem();
            boolean isFoodOrPotion = item.contains(DataComponentTypes.FOOD) || item.getItem() instanceof PotionItem;

            if (isFoodOrPotion && isActiveItem) {
                matrices.translate(x * 0.5f, y * 0.5f, z * 0.5f);
            } else {
                matrices.translate(x, y, z);
            }
            float sc = isMainHand
                    ? (viewModel.mainScale != null ? viewModel.mainScale.getValue() : 1f)
                    : (viewModel.offScale != null ? viewModel.offScale.getValue() : 1f);
            if (sc != 1f && sc > 0.01f) matrices.scale(sc, sc, sc);
        } catch (Throwable ignored) {}
    }

    /**
     * Inject into swingArm itself instead of Redirecting the call-site.
     * Avoids @Redirect conflict with ZenithDLC (same priority, same target).
     */
    @Inject(method = "swingArm", at = @At("HEAD"), cancellable = true, require = 0)
    private void batvisuals$swingArm(float swingProgress, float equipProgress, MatrixStack matrices, int armX, Arm arm, CallbackInfo ci) {
        try {
            SwingAnimation swingAnimation = batvisuals.getInstance().getModuleManager().getModule(SwingAnimation.class);
            if (swingAnimation != null && swingAnimation.isToggled()) {
                swingAnimation.renderSwordAnimation(matrices, swingProgress, equipProgress, arm);
                ci.cancel();
            }
        } catch (Throwable ignored) {}
    }
}
