package dev.batvisuals.mixin;

import dev.batvisuals.client.ui.BetaNotice;
import dev.batvisuals.client.ui.mainmenu.MainMenu;
import dev.batvisuals.client.ui.mainmenu.MenuStyle;
import dev.batvisuals.client.util.Wrapper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.SplashOverlay;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(TitleScreen.class)
public abstract class MixinTitleScreen extends Screen implements Wrapper {

    @Unique private static final int BAT_BTN_W = 120;
    @Unique private static final int BAT_BTN_H = 20;

    protected MixinTitleScreen(Text title) {
        super(title);
    }

    /** If custom menu is preferred (default), jump to BaTVisuals MainMenu. */
    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
    private void batvisuals$useCustomMenu(CallbackInfo ci) {
        if (!MenuStyle.isCustom()) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) return;
        if (client.currentScreen instanceof MainMenu) return;
        client.setScreen(new MainMenu());
        ci.cancel();
    }

    @Unique
    private int batvisuals$btnX() {
        return this.width - BAT_BTN_W - 10;
    }

    @Unique
    private int batvisuals$btnY() {
        return 10; // top-right, not bottom center
    }

    /** Draw every frame so the button never disappears after widget rebuilds. */
    @Inject(method = "render", at = @At("RETURN"))
    private void batvisuals$renderCustomBtn(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (MenuStyle.isCustom()) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.getOverlay() instanceof SplashOverlay) return;
        int bx = batvisuals$btnX();
        int by = batvisuals$btnY();
        boolean hov = mouseX >= bx && mouseX <= bx + BAT_BTN_W && mouseY >= by && mouseY <= by + BAT_BTN_H;
        int bg = hov ? 0xE0505468 : 0xC0282A32;
        context.fill(bx, by, bx + BAT_BTN_W, by + BAT_BTN_H, bg);
        // border
        context.fill(bx, by, bx + BAT_BTN_W, by + 1, 0xFF6A6E80);
        context.fill(bx, by + BAT_BTN_H - 1, bx + BAT_BTN_W, by + BAT_BTN_H, 0xFF6A6E80);
        context.fill(bx, by, bx + 1, by + BAT_BTN_H, 0xFF6A6E80);
        context.fill(bx + BAT_BTN_W - 1, by, bx + BAT_BTN_W, by + BAT_BTN_H, 0xFF6A6E80);
        String label = "BaTVisuals меню";
        int tw = this.textRenderer.getWidth(label);
        context.drawText(this.textRenderer, label, bx + (BAT_BTN_W - tw) / 2, by + 6, 0xFFFFFFFF, true);
        BetaNotice.render(context, this.width, this.height);
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void batvisuals$clickCustomBtn(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        if (MenuStyle.isCustom()) return;
        if (button != 0) return;
        int bx = batvisuals$btnX();
        int by = batvisuals$btnY();
        if (mouseX >= bx && mouseX <= bx + BAT_BTN_W && mouseY >= by && mouseY <= by + BAT_BTN_H) {
            MenuStyle.setCustom(true);
            MinecraftClient client = MinecraftClient.getInstance();
            if (client != null) client.setScreen(new MainMenu());
            cir.setReturnValue(true);
        }
    }
}
