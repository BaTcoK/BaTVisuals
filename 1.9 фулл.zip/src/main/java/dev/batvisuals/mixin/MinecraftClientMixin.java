package dev.batvisuals.mixin;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.events.impl.EventTick;
import dev.batvisuals.client.events.impl.EventGameShutdown;
import dev.batvisuals.client.util.math.Counter;
import dev.batvisuals.client.managers.HitDetectionManager;
import dev.batvisuals.client.util.Wrapper;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import dev.batvisuals.modules.impl.utility.FakeFPS;

@Mixin(value = MinecraftClient.class, priority = 2500)
public abstract class MinecraftClientMixin implements Wrapper {
    
    private static int tickCounter = 0;

    @Inject(method = "tick", at = @At("HEAD"))
    public void tick(CallbackInfo ci) {
        EventTick event = new EventTick();
        batvisuals.getInstance().getEventHandler().post(event);
        Counter.updateFPS();
        
        // Периодическая очистка HitDetectionManager (каждые 20 тиков = 1 секунда)
        tickCounter++;
        if (tickCounter >= 20) {
            HitDetectionManager.getInstance().cleanup();
            tickCounter = 0;
        }
    }

    @Inject(method = "getWindowTitle", at = @At("HEAD"), cancellable = true)
    public void updateWindowTitle(CallbackInfoReturnable<String> cir) {
        cir.setReturnValue("BaTVisuals");
    }

    @Inject(method = "stop", at = @At("HEAD"))
    private void onStop(CallbackInfo ci) {
        // Публикуем событие выключения игры для автосохранения конфигурации
        batvisuals.getInstance().getEventHandler().post(new EventGameShutdown());
        if (batvisuals.getInstance().getFirebaseManager() != null) {
            batvisuals.getInstance().getFirebaseManager().shutdown();
        }
    }

    @Inject(method = "getCurrentFps", at = @At("RETURN"), cancellable = true)
    private void batvisuals$fakeFps(CallbackInfoReturnable<Integer> cir) {
        if (FakeFPS.isActive()) {
            cir.setReturnValue(FakeFPS.getDisplayFps(cir.getReturnValue()));
        }
    }

}
