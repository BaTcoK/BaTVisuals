package dev.batvisuals.mixin;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.ui.hud.impl.DynamicIsland;
import dev.batvisuals.modules.impl.render.NoRender;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.BossBarHud;
import net.minecraft.client.gui.hud.ClientBossBar;
import net.minecraft.entity.boss.BossBar;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Locale;
import java.util.Map;
import java.util.UUID;

@Mixin(BossBarHud.class)
public abstract class BossBarHudMixin {

    @Shadow @Final private Map<UUID, ClientBossBar> bossBars;

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    public void render(DrawContext context, CallbackInfo ci) {
        try {
            NoRender nr = batvisuals.getInstance().getModuleManager().getModule(NoRender.class);
            if (nr != null && nr.isToggled() && nr.bossBar.getValue()) {
                ci.cancel();
                return;
            }
        } catch (Throwable ignored) {}

        // Hide entire boss bar layer when DynamicIsland shows PvP (cleaner UI)
        if (DynamicIsland.hidePvpBossBars && hasPvpBar()) {
            ci.cancel();
        }
    }

    private boolean hasPvpBar() {
        try {
            if (bossBars == null || bossBars.isEmpty()) return false;
            for (ClientBossBar bar : bossBars.values()) {
                String title = bar.getName() != null ? bar.getName().getString() : "";
                if (title == null) continue;
                String low = title.toLowerCase(Locale.ROOT);
                if (low.contains("пвп") || low.contains("pvp") || low.contains("режим") || low.contains("вы в")) {
                    return true;
                }
            }
        } catch (Throwable ignored) {}
        return false;
    }
}
