package dev.batvisuals.mixin;

import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Fullbright module removed — mixin kept empty so old mixin config entries stay valid.
 */
@Mixin(LightmapTextureManager.class)
public abstract class LightmapTextureManagerMixin {
}
