package dev.batvisuals.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.batvisuals.batvisuals;
import dev.batvisuals.client.events.impl.EventRender3D;
import dev.batvisuals.client.util.world.WorldUtils;
import dev.batvisuals.modules.impl.utility.Optimization;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.ObjectAllocator;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {
    @Inject(method = "renderWeather", at = @At("HEAD"), cancellable = true, require = 0)
    private void batvisuals$disableWeather(CallbackInfo ci) {
        Optimization optimization = Optimization.get();
        if (optimization != null && optimization.isToggled() && Boolean.TRUE.equals(optimization.disableWeather.getValue())) ci.cancel();
    }

    @Inject(method = "renderClouds", at = @At("HEAD"), cancellable = true, require = 0)
    private void batvisuals$disableClouds(CallbackInfo ci) {
        Optimization optimization = Optimization.get();
        if (optimization != null && optimization.isToggled() && Boolean.TRUE.equals(optimization.disableClouds.getValue())) ci.cancel();
    }


    @Inject(method = "render", at = @At("HEAD"))
    public void render(ObjectAllocator allocator, RenderTickCounter tickCounter, boolean renderBlockOutline, Camera camera, GameRenderer gameRenderer, Matrix4f positionMatrix, Matrix4f projectionMatrix, CallbackInfo ci) {
        EventRender3D.World event = new EventRender3D.World(camera, positionMatrix, tickCounter);
        batvisuals.getInstance().getEventHandler().post(event);
        WorldUtils.lastWorld.set(positionMatrix);
        WorldUtils.lastProj.set(RenderSystem.getProjectionMatrix());
        WorldUtils.lastModelView.set(RenderSystem.getModelViewMatrix());
    }
}