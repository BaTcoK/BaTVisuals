package dev.batvisuals.mixin;

import dev.batvisuals.modules.impl.utility.NameProtect;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value = EntityRenderer.class, priority = 2000)
public class EntityRendererNameProtectMixin {

    @ModifyVariable(method = "renderLabelIfPresent", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private Text batvisuals$nametag(Text text) {
        NameProtect np = NameProtect.getInstance();
        if (np == null || !np.isToggled() || text == null) return text;
        return np.protectText(text);
    }
}
