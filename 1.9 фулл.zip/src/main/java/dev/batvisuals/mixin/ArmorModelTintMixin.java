package dev.batvisuals.mixin;

import dev.batvisuals.modules.impl.render.ShowArmor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.Model;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Model.class)
public class ArmorModelTintMixin {

    private static final float ORANGE_BELOW = 0.50f;
    private static final float RED_BELOW = 0.25f;
    private static final int GREEN = 0xFF55FF55;
    private static final int ORANGE = 0xFFFFAA00;
    private static final int RED = 0xFFFF3030;

    @ModifyVariable(
        method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;III)V",
        at = @At("HEAD"),
        argsOnly = true,
        ordinal = 2,
        require = 0
    )
    private int batvisuals$tintColor(int color) {
        if (!ShowArmor.ENABLED) return color;
        ItemStack stack = ShowArmor.CURRENT_STACK.get();
        if (stack == null || !isArmor(stack)) return color;
        if (!ShowArmor.TINT_SELF && isMine(stack)) return color;
        float left = 1f - (float) stack.getDamage() / (float) stack.getMaxDamage();
        if (left > ORANGE_BELOW) return GREEN;
        if (left > RED_BELOW) return ORANGE;
        return RED;
    }

    private static boolean isArmor(ItemStack stack) {
        if (stack.isEmpty() || !stack.isDamageable() || stack.isOf(Items.ELYTRA)) return false;
        EquippableComponent eq = stack.get(DataComponentTypes.EQUIPPABLE);
        if (eq == null) return false;
        EquipmentSlot s = eq.slot();
        return s == EquipmentSlot.HEAD || s == EquipmentSlot.CHEST
                || s == EquipmentSlot.LEGS || s == EquipmentSlot.FEET;
    }

    private static boolean isMine(ItemStack stack) {
        PlayerEntity self = MinecraftClient.getInstance().player;
        if (self == null) return false;
        for (EquipmentSlot s : new EquipmentSlot[]{
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
        }) {
            if (ItemStack.areEqual(self.getEquippedStack(s), stack)) return true;
        }
        return false;
    }
}
