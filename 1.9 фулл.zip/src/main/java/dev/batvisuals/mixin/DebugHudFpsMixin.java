package dev.batvisuals.mixin;

import dev.batvisuals.modules.impl.utility.FakeFPS;
import net.minecraft.client.gui.hud.DebugHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Soft FakeFPS for F3 left text. require=0 friendly; won't crash if method shape differs (f3better etc).
 */
@Mixin(value = DebugHud.class, priority = 500)
public class DebugHudFpsMixin {

    private static final Pattern FPS_LINE = Pattern.compile("(?i)(\\d+)(\\s*fps)");

    @Inject(method = "getLeftText", at = @At("RETURN"), cancellable = true, require = 0)
    private void batvisuals$fakeFpsLeft(CallbackInfoReturnable<List<String>> cir) {
        if (!FakeFPS.isActive()) return;
        List<String> original = cir.getReturnValue();
        if (original == null || original.isEmpty()) return;
        try {
            int fake = FakeFPS.getDisplayFps(0);
            List<String> out = new ArrayList<>(original.size());
            boolean changed = false;
            for (String line : original) {
                if (line == null) { out.add(null); continue; }
                Matcher m = FPS_LINE.matcher(line);
                if (m.find()) {
                    out.add(m.replaceAll(fake + "$2"));
                    changed = true;
                } else {
                    out.add(line);
                }
            }
            if (changed) cir.setReturnValue(out);
        } catch (Throwable ignored) {}
    }
}
