package dev.batvisuals.mixin;

import dev.batvisuals.client.events.impl.EventRender2D;
import dev.batvisuals.modules.impl.render.Crosshair;
import dev.batvisuals.modules.impl.render.NoRender;
import dev.batvisuals.batvisuals;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PotionItem;
import net.minecraft.scoreboard.ScoreboardObjective;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.client.ui.hud.impl.HotbarHUD;
import dev.batvisuals.client.ui.hud.impl.DynamicIsland;
import net.minecraft.text.Text;

@Mixin(InGameHud.class)
public abstract class InGameHudMixin {

    @Inject(method = "render", at = @At("HEAD"))
    public void render(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        EventRender2D event = new EventRender2D(context, tickCounter);
        batvisuals.getInstance().getEventHandler().post(event);
    }

    @Inject(method = "renderHotbar", at = @At("HEAD"), cancellable = true)
    public void renderHotbar(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        try {
            var setting = batvisuals.getInstance().getHudManager().getElements().getName("Hotbar");
            if (setting instanceof BooleanSetting bs && bs.getValue()) {
                ci.cancel();
            }
        } catch (Throwable ignored) {}
    }

    // Cancel vanilla status bars when custom Hotbar HUD is enabled
    @Inject(method = "renderStatusBars", at = @At("HEAD"), cancellable = true)
    public void cancelStatusBars(DrawContext context, CallbackInfo ci) {
        // Keep vanilla hearts/hunger — custom Hotbar only replaces item bar
    }

    // Cancel vanilla XP bar when custom Hotbar HUD is enabled
    @Inject(method = "renderExperienceBar", at = @At("HEAD"), cancellable = true)
    public void cancelXpBar(DrawContext context, int i, CallbackInfo ci) {
        // Keep vanilla XP bar
    }

    // Cancel vanilla XP level text when custom Hotbar HUD is enabled
    @Inject(method = "renderExperienceLevel", at = @At("HEAD"), cancellable = true)
    public void cancelXpLevel(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        // Keep vanilla XP level text
    }

    @Unique
    private boolean isHudHotbarEnabled() {
        var setting = batvisuals.getInstance().getHudManager().getElements().getName("Hotbar");
        return setting instanceof BooleanSetting bs && bs.getValue();
    }

    // No translation needed anymore since we cancel vanilla bars entirely when Hotbar HUD is on

    @Inject(method = "renderStatusEffectOverlay", at = @At("HEAD"), cancellable = true)
    public void renderStatusEffectOverlay(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (batvisuals.getInstance().getModuleManager().getModule(NoRender.class).isToggled() && batvisuals.getInstance().getModuleManager().getModule(NoRender.class).potions.getValue()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V", at = @At("HEAD"), cancellable = true)
    public void renderScoreboardSidebar(DrawContext drawContext, ScoreboardObjective objective, CallbackInfo ci) {
        if (batvisuals.getInstance().getModuleManager().getModule(NoRender.class).isToggled() && batvisuals.getInstance().getModuleManager().getModule(NoRender.class).scoreboard.getValue()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    public void renderCrosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        try {
            Crosshair ch = batvisuals.getInstance().getModuleManager().getModule(Crosshair.class);
            if (ch != null && ch.isToggled() && !dev.batvisuals.client.managers.CrosshairPresetManager.isVanilla()) {
                ci.cancel(); // custom preset — hide vanilla
            }
        } catch (Throwable ignored) {}
    }

    @Unique
    private boolean isPotion(ItemStack stack, StatusEffect status) {
        if (!(stack.getItem() instanceof PotionItem)) return false;
        PotionContentsComponent component = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (component == null) return false;
        if (component.potion().isEmpty()) return false;
        for (StatusEffectInstance effect : component.potion().get().value().getEffects()) {
            if (effect.getEffectType().value() == status) return true;
        }
        return false;
    }

    @Inject(method = "setOverlayMessage", at = @At("HEAD"), cancellable = true)
    private void batvisuals$pvpOverlay(Text message, boolean tinted, CallbackInfo ci) {
        try {
            if (message == null) return;
            String plain = message.getString();
            if (plain == null || plain.isBlank()) return;
            DynamicIsland.onOverlayMessage(plain);
            if (DynamicIsland.hidePvpActionBar) {
                String low = plain.toLowerCase(java.util.Locale.ROOT);
                boolean looks = low.contains("пвп") || low.contains("pvp")
                        || low.contains("режим") || low.contains("вы в");
                if (looks) ci.cancel();
            }
        } catch (Throwable ignored) {}
    }

    @Inject(method = "renderOverlayMessage", at = @At("HEAD"), cancellable = true, require = 0)
    private void batvisuals$hideOverlayRender(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        try {
            if (DynamicIsland.hidePvpActionBar) {
                // soft hide: if last overlay was pvp, skip draw
                if (DynamicIsland.isRecentOverlayPvp()) {
                    ci.cancel();
                }
            }
        } catch (Throwable ignored) {}
    }

}
