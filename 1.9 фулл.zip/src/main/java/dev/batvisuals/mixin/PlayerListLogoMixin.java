package dev.batvisuals.mixin;

import dev.batvisuals.batvisuals;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Добавляет символ-лого перед ником в табе (Tab list, клавиша Tab) для игроков, которые сейчас
 * играют с BaTVisuals согласно Firebase. В отличие от PlayerLogoMixin (nametag над головой),
 * здесь доступен PlayerListEntry с точным UUID — сопоставление надёжнее, чем по подстроке ника.
 * Скорборд (боковая панель очков) сознательно не трогается.
 */
@Mixin(PlayerListHud.class)
public class PlayerListLogoMixin {

    private static final String LOGO_CHAR = "\uE100";

    @Inject(method = "getPlayerName", at = @At("RETURN"), cancellable = true)
    private void prependModLogo(PlayerListEntry entry, CallbackInfoReturnable<Text> cir) {
        if (entry == null || entry.getProfile() == null) return;

        batvisuals instance = batvisuals.getInstance();
        if (instance == null || instance.getFirebaseManager() == null) return;

        if (!instance.getFirebaseManager().isOnline(entry.getProfile().getId())) return;

        Text original = cir.getReturnValue();
        if (original == null) return;

        MutableText prefixed = Text.literal(LOGO_CHAR + " ").append(original);
        cir.setReturnValue(prefixed);
    }
}
