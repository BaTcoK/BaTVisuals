package dev.batvisuals.mixin;

import com.mojang.authlib.GameProfile;
import dev.batvisuals.modules.impl.render.Cape;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import dev.batvisuals.batvisuals;

@Mixin(value = PlayerListEntry.class, priority = 2000)
public class MixinCapeFeatureRenderer {

    // BaTVisuals branding cape texture.
    // IMPORTANT: this must be a proper 64x32-ratio cape UV texture (2048x1024
    // here), NOT the square logo.png (1254x1254). CapeFeatureRenderer maps
    // vanilla cape UVs assuming a 2:1 texture; feeding it a square image
    // stretches the cape geometry into a huge, distorted shape.
    private static final Identifier CUSTOM_CAPE = Identifier.of("batvisuals", "textures/newcape.png");

    @Shadow @Final private GameProfile profile;

    @Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true)
    public void onGetSkinTextures(CallbackInfoReturnable<SkinTextures> cir) {
        Cape cape = batvisuals.getInstance().getModuleManager().getModule(Cape.class);
        if (cape == null || !cape.isToggled()) {
            return;
        }
        SkinTextures original = cir.getReturnValue();
        if (original == null) return;
        cir.setReturnValue(new SkinTextures(
                original.texture(),
                original.textureUrl(),
                CUSTOM_CAPE,
                original.elytraTexture(),
                original.model(),
                original.secure()
        ));
    }
}
