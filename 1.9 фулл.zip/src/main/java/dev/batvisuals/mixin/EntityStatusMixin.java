package dev.batvisuals.mixin;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.events.impl.EventEntityDeath;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Перехватывает сетевой пакет статуса сущности напрямую - работает одинаково
 * что на одиночной игре, что на удалённом сервере, в отличие от LivingEntity.onDeath(),
 * который для чужих (не локально просчитываемых) сущностей может не вызываться в MP.
 */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class EntityStatusMixin {

    @Shadow
    private ClientWorld world;

    // Ванильный код смерти сущности - универсальный статус-код, используемый LivingEntity во всех версиях
    private static final byte DEATH_STATUS = 3;

    @Inject(method = "onEntityStatus", at = @At("HEAD"))
    private void batvisuals$onEntityStatus(EntityStatusS2CPacket packet, CallbackInfo ci) {
        if (packet.getStatus() != DEATH_STATUS) return;
        if (world == null) return;

        Entity entity = packet.getEntity(world);
        if (!(entity instanceof LivingEntity living)) return;

        batvisuals.getInstance().getEventHandler().post(new EventEntityDeath(living));
    }
}
