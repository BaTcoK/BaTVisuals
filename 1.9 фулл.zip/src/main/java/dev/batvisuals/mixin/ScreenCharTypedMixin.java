package dev.batvisuals.mixin;

import dev.batvisuals.batvisuals;
import dev.batvisuals.modules.impl.utility.Collector;
import net.minecraft.client.gui.ParentElement;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ParentElement.class)
public interface ScreenCharTypedMixin {

    @Inject(method = "charTyped", at = @At("HEAD"), cancellable = true, require = 0)
    private void batvisuals$charTyped(char chr, int modifiers, CallbackInfoReturnable<Boolean> cir) {
        try {
            Collector collector = batvisuals.getInstance().getModuleManager().getModule(Collector.class);
            if (collector != null && collector.isToggled() && collector.onCharTyped(chr)) {
                cir.setReturnValue(true);
            }
        } catch (Throwable ignored) {}
    }
}
