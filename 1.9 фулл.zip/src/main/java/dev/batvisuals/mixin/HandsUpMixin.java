package dev.batvisuals.mixin;

import dev.batvisuals.modules.impl.render.HandUP;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.UUID;

@Environment(EnvType.CLIENT)
@Mixin(PlayerEntityModel.class)
public abstract class HandsUpMixin {

    private static final float PITCH_UP = -2.65f;
    private static final float ROLL_SPREAD = 0.12f;

    @Inject(
        method = "setAngles(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;)V",
        at = @At("TAIL")
    )
    private void batvisuals$handsUp(PlayerEntityRenderState state, CallbackInfo ci) {
        if (!HandUP.ENABLED) return;
        HandUP mod = HandUP.get();
        if (mod == null || !mod.isToggled()) return;

        UUID uuid = HandUP.uuidOf(state);
        if (uuid == null) return;
        HandUP.Pose pose = HandUP.resolvePose(uuid);
        if (pose == HandUP.Pose.NONE) return;

        BipedEntityModel<?> model = (BipedEntityModel<?>) (Object) this;

        switch (pose) {
            case HANDS_UP -> {
                model.rightArm.pitch = PITCH_UP;
                model.rightArm.roll = -ROLL_SPREAD;
                model.rightArm.yaw = 0f;
                model.leftArm.pitch = PITCH_UP;
                model.leftArm.roll = ROLL_SPREAD;
                model.leftArm.yaw = 0f;
            }
            case SWING -> {
                // удар: правая рука вперёд, левая чуть назад
                float t = state.handSwingProgress;
                float swing = MathHelper.sin(t * (float) Math.PI);
                model.rightArm.pitch = -1.2f - swing * 1.4f;
                model.rightArm.yaw = -0.2f;
                model.rightArm.roll = 0.1f;
                model.leftArm.pitch = -0.3f + swing * 0.2f;
                model.leftArm.roll = -0.1f;
            }
            case EAT -> {
                // еда: обе руки к лицу
                model.rightArm.pitch = -1.35f;
                model.rightArm.yaw = -0.35f;
                model.rightArm.roll = 0.25f;
                model.leftArm.pitch = -1.35f;
                model.leftArm.yaw = 0.35f;
                model.leftArm.roll = -0.25f;
            }
            default -> {}
        }
    }
}
