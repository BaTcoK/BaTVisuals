package dev.batvisuals.mixin;

import dev.batvisuals.modules.impl.render.ShowArmor;
import net.minecraft.client.model.Model;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.equipment.EquipmentModel;
import net.minecraft.client.render.entity.equipment.EquipmentRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Tracks ItemStack while EquipmentRenderer draws armor.
 * Exact method descriptors required — ambiguous "render" crashes.
 */
@Mixin(EquipmentRenderer.class)
public class ArmorTintMixin {

    private static final String RENDER7 =
            "render(Lnet/minecraft/client/render/entity/equipment/EquipmentModel$LayerType;"
                    + "Lnet/minecraft/registry/RegistryKey;"
                    + "Lnet/minecraft/client/model/Model;"
                    + "Lnet/minecraft/item/ItemStack;"
                    + "Lnet/minecraft/client/util/math/MatrixStack;"
                    + "Lnet/minecraft/client/render/VertexConsumerProvider;"
                    + "I)V";

    private static final String RENDER8 =
            "render(Lnet/minecraft/client/render/entity/equipment/EquipmentModel$LayerType;"
                    + "Lnet/minecraft/registry/RegistryKey;"
                    + "Lnet/minecraft/client/model/Model;"
                    + "Lnet/minecraft/item/ItemStack;"
                    + "Lnet/minecraft/client/util/math/MatrixStack;"
                    + "Lnet/minecraft/client/render/VertexConsumerProvider;"
                    + "ILnet/minecraft/util/Identifier;)V";

    @Inject(method = RENDER7, at = @At("HEAD"), require = 0)
    private void batvisuals$track7(
            EquipmentModel.LayerType layerType,
            RegistryKey<?> assetKey,
            Model model,
            ItemStack stack,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            CallbackInfo ci
    ) {
        ShowArmor.CURRENT_STACK.set(stack);
    }

    @Inject(method = RENDER7, at = @At("RETURN"), require = 0)
    private void batvisuals$clear7(CallbackInfo ci) {
        ShowArmor.CURRENT_STACK.remove();
    }

    @Inject(method = RENDER8, at = @At("HEAD"), require = 0)
    private void batvisuals$track8(
            EquipmentModel.LayerType layerType,
            RegistryKey<?> assetKey,
            Model model,
            ItemStack stack,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            Identifier texture,
            CallbackInfo ci
    ) {
        ShowArmor.CURRENT_STACK.set(stack);
    }

    @Inject(method = RENDER8, at = @At("RETURN"), require = 0)
    private void batvisuals$clear8(CallbackInfo ci) {
        ShowArmor.CURRENT_STACK.remove();
    }
}
