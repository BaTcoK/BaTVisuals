package dev.batvisuals.mixin;

import dev.batvisuals.batvisuals;
import dev.batvisuals.modules.impl.render.HitColor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** HitColor: включаем ванильный entity-outline для только что ударенного игрока (цвет задаёт EntityGlowMixin). */
@Mixin(MinecraftClient.class)
public abstract class HitOutlineMixin {
    @Inject(method = "hasOutline", at = @At("RETURN"), cancellable = true, require = 0)
    private void batvisuals$hitOutline(Entity entity, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValueZ()) return;
        try {
            HitColor m = batvisuals.getInstance().getModuleManager().getModule(HitColor.class);
            if (m != null && m.shouldOutline(entity)) cir.setReturnValue(true);
        } catch (Throwable ignored) {}
    }
}
