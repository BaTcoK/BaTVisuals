package dev.batvisuals.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.SplashOverlay;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SplashOverlay.class)
public abstract class SplashOverlayMixin {
    @Unique private static final Identifier LOGO = Identifier.of("batvisuals", "logo_splash.png");
    @Unique private static final int PARTICLES = 34;
    @Unique private long batvisuals$startMs = -1L;
    @Shadow private float progress;

    @Inject(method = "render", at = @At("RETURN"))
    private void batvisuals$render(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null) return;
        if (batvisuals$startMs < 0L) batvisuals$startMs = System.currentTimeMillis();

        long elapsed = System.currentTimeMillis() - batvisuals$startMs;
        int w = context.getScaledWindowWidth();
        int h = context.getScaledWindowHeight();
        float p = MathHelper.clamp(progress, 0f, 1f);
        float intro = Math.min(1f, elapsed / 450f);
        int alpha = MathHelper.clamp((int) (255f * (intro * intro * (3f - 2f * intro))), 0, 255);

        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        context.fill(0, 0, w, h, 0xFF000000);

        for (int i = 0; i < PARTICLES; i++) {
            long seed = 0x9E3779B97F4A7C15L * (i + 1L);
            float x = (float) ((seed ^ (seed >>> 29)) & 0x7FFFFFFFL) / 2147483647f * w;
            float speed = 0.010f + (((seed >>> 11) & 255L) / 255f) * 0.018f;
            float size = 1f + ((seed >>> 20) & 3L);
            float phase = ((seed >>> 32) & 1023L) / 1023f;
            float y = h - ((phase * h + elapsed * speed) % (h + 40f));
            int a = MathHelper.clamp((int) (90f + 120f * (1f - y / Math.max(1f, h))), 45, 210);
            context.fill((int) x, (int) y, (int) (x + size), (int) (y + size), (a << 24) | 0xFFFFFF);
        }

        int logoSize = MathHelper.clamp(Math.round(h * 0.167f), 68, 82);
        int logoX = (w - logoSize) / 2;
        int logoY = h / 2 - logoSize - Math.round(h * 0.153f);
        context.drawTexture(RenderLayer::getGuiTextured, LOGO, logoX, logoY, 0f, 0f,
                logoSize, logoSize, logoSize, logoSize, (alpha << 24) | 0xFFFFFF);

        int barW = Math.min(430, Math.max(220, (int) (w * 0.52f)));
        int barH = 4;
        int barX = (w - barW) / 2;
        int barY = logoY + logoSize + Math.round(h * 0.18f);
        context.fill(barX, barY, barX + barW, barY + barH, (100 << 24) | 0xFFFFFF);
        int fillW = (int) (barW * p);
        if (fillW > 0) context.fill(barX, barY, barX + fillW, barY + barH, (alpha << 24) | 0xFFFFFF);

        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }
}
