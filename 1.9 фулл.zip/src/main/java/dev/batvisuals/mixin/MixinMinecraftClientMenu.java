package dev.batvisuals.mixin;

import dev.batvisuals.client.ui.mainmenu.MainMenu;
import dev.batvisuals.client.ui.mainmenu.MenuStyle;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * When user chose vanilla menu, block any forced open of custom MainMenu
 * (e.g. ClientTickEvents that always replaces TitleScreen).
 */
@Mixin(MinecraftClient.class)
public class MixinMinecraftClientMenu {

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void batvisuals$blockForcedCustomMenu(Screen screen, CallbackInfo ci) {
        if (screen instanceof MainMenu && !MenuStyle.isCustom()) {
            ci.cancel();
        }
    }
}
