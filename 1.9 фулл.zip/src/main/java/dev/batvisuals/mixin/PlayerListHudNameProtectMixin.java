package dev.batvisuals.mixin;

import dev.batvisuals.modules.impl.utility.NameProtect;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * NameProtect for TAB: player names, header ("Привет Name!"), footer.
 */
@Mixin(value = PlayerListHud.class, priority = 2000)
public class PlayerListHudNameProtectMixin {

    @Inject(method = "getPlayerName", at = @At("RETURN"), cancellable = true)
    private void batvisuals$tabName(PlayerListEntry entry, CallbackInfoReturnable<Text> cir) {
        NameProtect np = NameProtect.getInstance();
        if (np == null || !np.isToggled() || entry == null) return;
        Text original = cir.getReturnValue();
        if (original == null) {
            String name = entry.getProfile().getName();
            String prot = np.getProtectedName(name);
            if (!name.equals(prot)) cir.setReturnValue(Text.literal(prot));
            return;
        }
        Text protectedText = np.protectText(original);
        if (protectedText != original) cir.setReturnValue(protectedText);
    }

    // Header / footer / any Text drawn in tab list
    @ModifyArg(
            method = "render",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawText(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;III)I"),
            index = 1,
            require = 0
    )
    private Text batvisuals$tabDrawText(Text text) {
        return protect(text);
    }

    @ModifyArg(
            method = "render",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawText(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;IIIZ)I"),
            index = 1,
            require = 0
    )
    private Text batvisuals$tabDrawTextZ(Text text) {
        return protect(text);
    }

    @ModifyArg(
            method = "render",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;III)I"),
            index = 1,
            require = 0
    )
    private Text batvisuals$tabDrawShadow(Text text) {
        return protect(text);
    }

    @ModifyArg(
            method = "render",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawText(Lnet/minecraft/client/font/TextRenderer;Ljava/lang/String;IIIZ)I"),
            index = 1,
            require = 0
    )
    private String batvisuals$tabDrawString(String text) {
        NameProtect np = NameProtect.getInstance();
        if (np == null || !np.isToggled() || text == null) return text;
        return np.replaceNames(text);
    }

    @ModifyVariable(method = "render", at = @At("STORE"), ordinal = 0, require = 0)
    private Text batvisuals$tabHeaderStore(Text header) {
        return protect(header);
    }

    private static Text protect(Text text) {
        NameProtect np = NameProtect.getInstance();
        if (np == null || !np.isToggled() || text == null) return text;
        return np.protectText(text);
    }
}
