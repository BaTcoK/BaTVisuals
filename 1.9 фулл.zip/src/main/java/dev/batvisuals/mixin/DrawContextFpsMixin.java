package dev.batvisuals.mixin;

import dev.batvisuals.modules.impl.utility.FakeFPS;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Mixin(value = DrawContext.class, priority = 2000)
public class DrawContextFpsMixin {

    private static final Pattern FPS = Pattern.compile("(?i)((?:fps\\s*[:=]?\\s*))(\\d+)|(\\d+)(\\s*fps)");

    private static String rewrite(String s) {
        if (s == null || !FakeFPS.isActive()) return s;
        if (s.length() > 64) return s; // don't touch long chat lines
        Matcher m = FPS.matcher(s);
        if (!m.find()) return s;
        int fake = FakeFPS.getDisplayFps(0);
        StringBuffer sb = new StringBuffer();
        m.reset();
        while (m.find()) {
            if (m.group(2) != null) {
                m.appendReplacement(sb, Matcher.quoteReplacement(m.group(1) + fake));
            } else {
                m.appendReplacement(sb, Matcher.quoteReplacement(fake + m.group(4)));
            }
        }
        m.appendTail(sb);
        return sb.toString();
    }

    @ModifyVariable(method = "drawText(Lnet/minecraft/client/font/TextRenderer;Ljava/lang/String;IIIZ)I", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private String batvisuals$fpsString(String text) {
        return rewrite(text);
    }

    @ModifyVariable(method = "drawTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Ljava/lang/String;III)I", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private String batvisuals$fpsStringShadow(String text) {
        return rewrite(text);
    }

    @ModifyVariable(method = "drawText(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;IIIZ)I", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private Text batvisuals$fpsText(Text text) {
        if (text == null || !FakeFPS.isActive()) return text;
        String s = text.getString();
        String n = rewrite(s);
        if (s == null || s.equals(n)) return text;
        return Text.literal(n).setStyle(text.getStyle());
    }
}
