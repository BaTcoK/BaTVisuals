package dev.batvisuals.mixin;

import dev.batvisuals.batvisuals;
import dev.batvisuals.modules.impl.render.SkyFX;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.awt.Color;

/**
 * 1.21.4: ClientWorld.getSkyColor / getCloudsColor return packed int RGB, not Vec3d.
 * Without this fix only fog (BackgroundRenderer) was colored.
 */
@Mixin(ClientWorld.class)
public class ClientWorldMixin {

    @Inject(method = "getSkyColor", at = @At("RETURN"), cancellable = true)
    private void batvisuals$skyColor(Vec3d cameraPos, float tickDelta, CallbackInfoReturnable<Integer> cir) {
        try {
            SkyFX sky = batvisuals.getInstance().getModuleManager().getModule(SkyFX.class);
            if (sky == null || !sky.isToggled()) return;
            Color c = sky.getSkyColor();
            float blend = sky.getSkyBlend();
            int orig = cir.getReturnValue() != null ? cir.getReturnValue() : 0x87CEEB;
            int or = ColorHelper.getRed(orig);
            int og = ColorHelper.getGreen(orig);
            int ob = ColorHelper.getBlue(orig);
            int nr = c.getRed();
            int ng = c.getGreen();
            int nb = c.getBlue();
            if (blend < 1f) {
                nr = (int) (or * (1f - blend) + nr * blend);
                ng = (int) (og * (1f - blend) + ng * blend);
                nb = (int) (ob * (1f - blend) + nb * blend);
            }
            nr = MathHelper.clamp(nr, 0, 255);
            ng = MathHelper.clamp(ng, 0, 255);
            nb = MathHelper.clamp(nb, 0, 255);
            cir.setReturnValue(ColorHelper.getArgb(255, nr, ng, nb));
        } catch (Throwable ignored) {}
    }

    @Inject(method = "getCloudsColor", at = @At("RETURN"), cancellable = true)
    private void batvisuals$cloudsColor(float tickDelta, CallbackInfoReturnable<Integer> cir) {
        try {
            SkyFX sky = batvisuals.getInstance().getModuleManager().getModule(SkyFX.class);
            if (sky == null || !sky.isToggled() || !sky.colorClouds()) return;
            Color c = sky.getSkyColor();
            float blend = Math.min(1f, sky.getSkyBlend() * 0.9f);
            int orig = cir.getReturnValue() != null ? cir.getReturnValue() : 0xFFFFFF;
            int or = ColorHelper.getRed(orig);
            int og = ColorHelper.getGreen(orig);
            int ob = ColorHelper.getBlue(orig);
            int nr = c.getRed();
            int ng = c.getGreen();
            int nb = c.getBlue();
            if (blend < 1f) {
                nr = (int) (or * (1f - blend) + nr * blend);
                ng = (int) (og * (1f - blend) + ng * blend);
                nb = (int) (ob * (1f - blend) + nb * blend);
            }
            nr = MathHelper.clamp(nr, 0, 255);
            ng = MathHelper.clamp(ng, 0, 255);
            nb = MathHelper.clamp(nb, 0, 255);
            cir.setReturnValue(ColorHelper.getArgb(255, nr, ng, nb));
        } catch (Throwable ignored) {}
    }
}
