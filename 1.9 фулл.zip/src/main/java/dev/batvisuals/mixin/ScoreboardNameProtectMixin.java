package dev.batvisuals.mixin;

import dev.batvisuals.modules.impl.utility.NameProtect;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/**
 * NameProtect for scoreboard sidebar — all drawText variants, all ordinals (require=0).
 */
@Mixin(InGameHud.class)
public class ScoreboardNameProtectMixin {

    @ModifyArg(
            method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawText(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;III)I"),
            index = 1,
            require = 0
    )
    private Text batvisuals$sb1(Text text) { return protect(text); }

    @ModifyArg(
            method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawText(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;IIIZ)I"),
            index = 1,
            require = 0
    )
    private Text batvisuals$sb2(Text text) { return protect(text); }

    @ModifyArg(
            method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;III)I"),
            index = 1,
            require = 0
    )
    private Text batvisuals$sb3(Text text) { return protect(text); }

    @ModifyArg(
            method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawText(Lnet/minecraft/client/font/TextRenderer;Ljava/lang/String;IIIZ)I"),
            index = 1,
            require = 0
    )
    private String batvisuals$sbStr(String text) {
        NameProtect np = NameProtect.getInstance();
        if (np == null || !np.isToggled() || text == null) return text;
        return np.replaceNames(text);
    }

    private static Text protect(Text text) {
        NameProtect np = NameProtect.getInstance();
        if (np == null || !np.isToggled() || text == null) return text;
        return np.protectText(text);
    }
}
