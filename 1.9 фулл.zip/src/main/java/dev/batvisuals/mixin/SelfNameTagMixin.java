package dev.batvisuals.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * По умолчанию Minecraft не отображает никнейм над головой собственного игрока (нет смысла
 * смотреть на свой же ник) — эта проверка происходит внутри hasLabel. Форсируем true для
 * собственного игрока, когда камера не в первом лице (иначе лейбл рисовался бы прямо перед
 * объективом камеры в first person, что не нужно и не было бы видно физически осмысленно).
 */
@Mixin(LivingEntityRenderer.class)
public class SelfNameTagMixin<T extends LivingEntity> {

    @Inject(method = "hasLabel", at = @At("HEAD"), cancellable = true)
    private void forceOwnNameTag(T entity, double distanceSquared, CallbackInfoReturnable<Boolean> cir) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options == null) return;
        if (entity != mc.player) return;
        if (mc.options.getPerspective().isFirstPerson()) return; // в первом лице свой ник рисовать негде/незачем

        cir.setReturnValue(true);
    }
}
