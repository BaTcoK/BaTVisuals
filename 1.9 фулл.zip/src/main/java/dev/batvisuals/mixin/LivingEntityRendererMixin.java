package dev.batvisuals.mixin;

import dev.batvisuals.client.util.other.FriendRenderContext;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.modules.impl.render.HitColor;
import dev.batvisuals.batvisuals;
import dev.batvisuals.util.HitColorTintState;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin<S extends LivingEntityRenderState, M extends EntityModel<S>> {

    private static final ThreadLocal<Boolean> SV_SHOULD_TINT = HitColorTintState.SHOULD_TINT;
    private static final Identifier SV_WHITE = Identifier.of("minecraft", "textures/misc/white.png");

    @Shadow
    protected abstract Identifier getTexture(S state);

    @Inject(method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At("RETURN"))
    private void batvisuals$clearOwner(S state, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        FriendRenderContext.CURRENT.remove();
        SV_SHOULD_TINT.set(false);
    }

    @Inject(method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At("HEAD"))
    private void batvisuals$prepareTint(S state, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        HitColor module = batvisuals.getInstance().getModuleManager().getModule(HitColor.class);
        if (module != null && module.shouldTintModel() && state.hurt) {
            SV_SHOULD_TINT.set(true);
            state.hurt = false; // suppress vanilla red flash
        }
    }

    /**
     * @author BaTVisuals
     * @reason Theme-coloured model fill on hurt instead of vanilla red.
     */
    @Overwrite
    public int getMixColor(S state) {
        HitColor module = batvisuals.getInstance().getModuleManager().getModule(HitColor.class);
        if (module != null && module.shouldTintModel() && Boolean.TRUE.equals(SV_SHOULD_TINT.get())) {
            java.awt.Color theme;
            try {
                theme = ThemeManager.getInstance().getCurrentTheme().getAccentColor();
            } catch (Throwable t) {
                theme = new java.awt.Color(120, 90, 255);
            }
            if (theme == null) theme = new java.awt.Color(120, 90, 255);
            int a = (int) (255 * module.getFillAlpha());
            return new java.awt.Color(theme.getRed(), theme.getGreen(), theme.getBlue(), Math.max(0, Math.min(255, a))).getRGB();
        }
        return -1;
    }

    @Inject(method = "getRenderLayer(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;ZZZ)Lnet/minecraft/client/render/RenderLayer;",
            at = @At("HEAD"), cancellable = true)
    private void batvisuals$forceTranslucentLayer(S state, boolean showBody, boolean translucent, boolean showOutline, CallbackInfoReturnable<RenderLayer> cir) {
        HitColor module = batvisuals.getInstance().getModuleManager().getModule(HitColor.class);
        if (module != null && module.shouldTintModel() && Boolean.TRUE.equals(SV_SHOULD_TINT.get())) {
            cir.setReturnValue(RenderLayer.getEntityTranslucent(SV_WHITE));
        }
    }
}
