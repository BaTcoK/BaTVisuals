package dev.batvisuals.mixin;

import dev.batvisuals.batvisuals;
import dev.batvisuals.modules.impl.utility.NameProtect;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Префикс лого перед ником (1.21.4: renderLabelIfPresent uses EntityRenderState, not Entity).
 * После NameProtect сверяем и заменённый ник (Protected), и реальные online-ники.
 */
@Mixin(PlayerEntityRenderer.class)
public class PlayerLogoMixin {

    private static final String LOGO_CHAR = "\uE100";

    @ModifyVariable(
            method = "renderLabelIfPresent",
            at = @At("HEAD"),
            argsOnly = true,
            ordinal = 0
    )
    private Text prependModLogo(Text text) {
        if (text == null) return null;

        batvisuals instance = batvisuals.getInstance();
        if (instance == null || instance.getFirebaseManager() == null) return text;

        String plain = text.getString();
        if (plain == null || plain.isEmpty()) return text;
        if (plain.startsWith(LOGO_CHAR)) return text;

        boolean match = false;
        try {
            match = instance.getFirebaseManager().containsAnyOnlineNick(plain);
        } catch (Throwable ignored) {}

        // NameProtect may have replaced the nick — still show logo for self / friends online
        if (!match) {
            try {
                NameProtect np = NameProtect.getInstance();
                if (np != null && np.isToggled()) {
                    for (String self : np.selfNames()) {
                        if (self == null) continue;
                        String prot = np.getProtectedName(self);
                        if (plainEqualsOrContains(plain, self) || plainEqualsOrContains(plain, prot)) {
                            if (instance.getFirebaseManager().containsAnyOnlineNick(self)) {
                                match = true;
                                break;
                            }
                        }
                    }
                    if (!match && np.getProtectFriends().getValue()) {
                        for (String friend : dev.batvisuals.client.managers.FriendsManager.getFriends()) {
                            if (friend == null) continue;
                            String prot = np.getProtectedName(friend);
                            if (plainEqualsOrContains(plain, friend) || plainEqualsOrContains(plain, prot)) {
                                if (instance.getFirebaseManager().containsAnyOnlineNick(friend)) {
                                    match = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            } catch (Throwable ignored) {}
        }

        if (!match) return text;

        MutableText prefixed = Text.literal(LOGO_CHAR + " ").append(text);
        return prefixed;
    }

    private static boolean plainEqualsOrContains(String plain, String name) {
        if (plain == null || name == null || name.isEmpty()) return false;
        if (plain.equalsIgnoreCase(name)) return true;
        // nametag may include rank prefixes
        return plain.toLowerCase().contains(name.toLowerCase());
    }
}
