package dev.batvisuals.mixin;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.events.impl.EventMouse;
import dev.batvisuals.modules.impl.render.SmoothCamera;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public abstract class MouseMixin {

    @Shadow private double cursorDeltaX;
    @Shadow private double cursorDeltaY;

    @Unique private double batvisuals$smoothDX;
    @Unique private double batvisuals$smoothDY;

    @Inject(method = "onMouseButton", at = @At("HEAD"))
    public void onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
        EventMouse event = new EventMouse(button, action);
        batvisuals.getInstance().getEventHandler().post(event);
    }

    /**
     * Exponential smoothing of raw cursor deltas (works both directions, no FOV coupling).
     */
    @Inject(method = "updateMouse", at = @At("HEAD"))
    private void batvisuals$smoothCamera(CallbackInfo ci) {
        SmoothCamera mod = batvisuals.getInstance().getModuleManager().getModule(SmoothCamera.class);
        if (mod == null || !mod.isToggled()) {
            batvisuals$smoothDX = 0;
            batvisuals$smoothDY = 0;
            return;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.currentScreen != null) return;

        batvisuals$smoothDX += cursorDeltaX;
        batvisuals$smoothDY += cursorDeltaY;

        // delay 5..50 → factor ~0.35..0.06
        float delay = Math.max(5f, mod.delay.getValue());
        float factor = Math.max(0.05f, Math.min(0.4f, 2.2f / delay));

        double outX = batvisuals$smoothDX * factor;
        double outY = batvisuals$smoothDY * factor;
        batvisuals$smoothDX -= outX;
        batvisuals$smoothDY -= outY;
        cursorDeltaX = outX;
        cursorDeltaY = outY;
    }
}
