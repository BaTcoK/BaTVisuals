package dev.batvisuals.mixin;

import dev.batvisuals.batvisuals;
import dev.batvisuals.modules.impl.render.HitColor;
import dev.batvisuals.modules.impl.render.NoGlow;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityGlowMixin {
    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true)
    private void batvisuals$noGlow(CallbackInfoReturnable<Boolean> cir) {
        if (NoGlow.isActive()) {
            cir.setReturnValue(false);
        }
    }

    /** Цвет обводки удара = акцент темы (только пока shouldOutline). */
    @Inject(method = "getTeamColorValue", at = @At("HEAD"), cancellable = true, require = 0)
    private void batvisuals$hitOutlineColor(CallbackInfoReturnable<Integer> cir) {
        try {
            HitColor m = batvisuals.getInstance().getModuleManager().getModule(HitColor.class);
            if (m != null && m.shouldOutline((Entity) (Object) this)) cir.setReturnValue(m.getOutlineRgb());
        } catch (Throwable ignored) {}
    }
}
