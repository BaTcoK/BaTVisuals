package dev.batvisuals.mixin;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.events.impl.EventEntityDeath;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Резервный (fallback) детектор смерти для случаев, когда сервер НЕ шлёт
 * стандартный EntityStatusS2CPacket со статусом 3 (см. EntityStatusMixin).
 * Это происходит на многих серверах с кастомной respawn/PvP-логикой:
 * плагин доводит health до 0 и сразу телепортирует/ресетает игрока без
 * ванильного статус-пакета смерти, из-за чего EntityStatusMixin молчит.
 *
 * Ловим падение health до <= 0 напрямую на LivingEntity#setHealth - этот путь
 * почти всегда синхронизируется с сервером (иначе не будет работать health bar),
 * так что он не зависит от конкретной реализации смерти на сервере.
 *
 * Дедупликация от EntityStatusMixin: используем Unique-флаг на инстансе сущности,
 * чтобы не отправить EventEntityDeath дважды, если оба пути сработают на одну смерть.
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityHealthDeathMixin {

    @Unique
    private boolean batvisuals$deathEventFired = false;

    @Unique
    private float batvisuals$lastHealth = -1f;

    @Inject(method = "setHealth", at = @At("HEAD"))
    private void batvisuals$onSetHealth(float health, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;

        // Если health вернулся выше 0 (например, сущность заспавнилась заново
        // под тем же ID или воскресла) - сбрасываем флаг, чтобы ловить следующую смерть.
        if (health > 0f) {
            batvisuals$deathEventFired = false;
            batvisuals$lastHealth = health;
            return;
        }

        // health <= 0 и мы ещё не постили ивент для этой "жизни" сущности
        if (!batvisuals$deathEventFired && batvisuals$lastHealth != 0f) {
            batvisuals$deathEventFired = true;
            batvisuals$lastHealth = health;
            batvisuals.getInstance().getEventHandler().post(new EventEntityDeath(self));
        }
    }
}
