package dev.batvisuals.client.ui.hud.impl;

/** Караоке временно отключено — заглушка. */
public class MusicKaraokeOverlay {
}
