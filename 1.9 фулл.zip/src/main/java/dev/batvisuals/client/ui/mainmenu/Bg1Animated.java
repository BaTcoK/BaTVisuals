package dev.batvisuals.client.ui.mainmenu;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.*;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import org.joml.Matrix4f;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import dev.batvisuals.client.render.RenderState;
import dev.batvisuals.client.render.RenderTheme;
/**
 * bg-1: procedural animated backdrop. 3 draw calls total:
 * gradient (POSITION_COLOR) -> additive batch (aurora + orbs + lightning, one soft texture) -> vignette.
 * No GL_LINES, no shader assets, no ResourceManager access; any failure -> static gradient fallback.
 */
public final class Bg1Animated {
    // ================= TUNING =================
    public static final float SPEED = 1.0f;            // global motion speed
    public static final float INTENSITY = 1.0f;        // aurora / orb / bolt brightness
    public static final boolean LIGHTNING = true;
    public static final float LIGHTNING_MIN_S = 2.0f;  // pause between flashes
    public static final float LIGHTNING_MAX_S = 4.0f;
    public static final float BOLT_LIFE_MIN_S = 0.3f;  // fade duration
    public static final float BOLT_LIFE_MAX_S = 0.8f;
    public static final float PARALLAX_PX = 16f;       // physical px (layers use 0.5 / 0.75 / 1.0 of it)
    public static final float VIGNETTE_ALPHA = 0.35f;
    // ==========================================

    static final boolean MOBILE = System.getenv("POJAV_RENDERER") != null
            || Boolean.getBoolean("batvisuals.mobile");
    static final int ORBS = MOBILE ? 12 : 28;
    static final int AURORAS = MOBILE ? 3 : 4;
    static final int MAX_BOLTS = MOBILE ? 2 : 3;
    static final int BOLT_LEVELS = MOBILE ? 3 : 4;

    private static final Logger LOG = LoggerFactory.getLogger("BaTVisuals/bg1");
    private static final Identifier SOFT = Identifier.of("batvisuals", "dyn/bg1_soft");

    private boolean texReady, failed, inited;
    private long t0, prev;
    private double nextBolt;
    private float pax, pay, fw, fh, fz, parPx;
    private final Random rnd = new Random();

    private final float[] ox = new float[ORBS], oy = new float[ORBS], ovy = new float[ORBS],
            osz = new float[ORBS], oage = new float[ORBS], olife = new float[ORBS],
            osw = new float[ORBS], oph = new float[ORBS];
    private final boolean[] olight = new boolean[ORBS];

    private static final class Bolt {
        final List<float[]> seg = new ArrayList<>();
        double born; float life; float ex, ey;
    }
    private final List<Bolt> bolts = new ArrayList<>();

    // ---------------- public API ----------------
    /** call from MainMenu.render() BEFORE buttons, only when bg-1 is selected. w/h = scaled gui size. */
    public void render(DrawContext ctx, int w, int h, float mouseX, float mouseY, float zoom) {
        if (failed) { fallback(ctx, w, h); return; }
        try {
            draw(ctx, w, h, mouseX, mouseY, Math.max(1.0f, Math.min(1.5f, zoom)));
        } catch (Throwable e) {
            failed = true;
            LOG.warn("bg-1 animated failed, using static fallback", e);
            fallback(ctx, w, h);
        }
    }

    /** call from MainMenu.init() when bg-1 becomes active (resets timers/bolts, keeps texture). */
    public void reset() { inited = false; bolts.clear(); t0 = 0; }

    /** optional retry after a failure (e.g. on bg switch). */
    public void retry() { failed = false; }

    // ---------------- impl ----------------
    private static int accent() {
        try {
            return RenderTheme.argb(RenderTheme.primary()) & 0xFFFFFF;
        } catch (Throwable t) {
            return 0x8A5CFF;
        }
    }

    private void fallback(DrawContext ctx, int w, int h) {
        int a = accent();
        ctx.fillGradient(0, 0, w, h, 0xFF05060B, 0xFF000000 | mix(0x0B0D16, a, 0.15f));
    }

    private void initTex() {
        if (texReady) return;
        var tm = MinecraftClient.getInstance().getTextureManager();
        int n = 64;
        NativeImage img = new NativeImage(n, n, false);
        for (int y = 0; y < n; y++) for (int x = 0; x < n; x++) {
            float dx = (x + .5f) / n * 2 - 1, dy = (y + .5f) / n * 2 - 1;
            float a = Math.max(0f, 1f - (float) Math.sqrt(dx * dx + dy * dy));
            a = a * a * (3 - 2 * a);
            img.setColorArgb(x, y, ((int) (a * 255) << 24) | 0xFFFFFF);
        }
        NativeImageBackedTexture tex = new NativeImageBackedTexture(img);
        tex.setFilter(true, false);
        tm.registerTexture(SOFT, tex);
        texReady = true;
    }

    private void draw(DrawContext ctx, int w, int h, float mx, float my, float zoom) {
        MinecraftClient mc = MinecraftClient.getInstance();
        initTex();

        long now = Util.getMeasuringTimeNano();
        if (t0 == 0) { t0 = now; prev = now; }
        double real = (now - t0) / 1e9;
        float dt = (float) Math.min(0.05, (now - prev) / 1e9);
        prev = now;
        float t = (float) ((real * SPEED) % 6283.0);

        if (!inited) {
            inited = true;
            for (int i = 0; i < ORBS; i++) spawnOrb(i, true);
            nextBolt = real + 1.0;
        }

        // parallax (smoothed), zoom is separate
        float sf = Math.max(1f, (float) mc.getWindow().getScaleFactor());
        float tx = clamp((mx / Math.max(1, w) - .5f) * 2f), ty = clamp((my / Math.max(1, h) - .5f) * 2f);
        float k = 1f - (float) Math.exp(-dt * 3.0);
        pax += (tx - pax) * k; pay += (ty - pay) * k;
        parPx = PARALLAX_PX / sf;
        fw = w; fh = h; fz = zoom;
        float pxGui = 1f / sf; // 1 physical px in gui units

        int rgb = accent();
        int light = mix(rgb, 0xFFFFFF, 0.35f);
        int deep = mix(rgb, 0x000000, 0.45f);

        ctx.draw(); // flush pending vanilla gui geometry so ordering stays correct
        Matrix4f mat = ctx.getMatrices().peek().getPositionMatrix();

        RenderState.push();
        try {
            RenderSystem.disableCull();

            // 1) dark base gradient
            RenderState.apply(RenderState.Preset.ALPHA);
            RenderSystem.disableDepthTest();
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            BufferBuilder g = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            int top = 0xFF000000 | mix(0x05060B, rgb, 0.03f);
            int bot = 0xFF000000 | mix(0x0A0C15, rgb, 0.12f);
            g.vertex(mat, 0, 0, 0).color(top);
            g.vertex(mat, 0, h, 0).color(bot);
            g.vertex(mat, w, h, 0).color(bot);
            g.vertex(mat, w, 0, 0).color(top);
            dev.batvisuals.client.util.render.SafeDraw.draw(g);

            // 2-4) additive batch
            RenderState.apply(RenderState.Preset.GLOW);
            RenderSystem.disableDepthTest();
            RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
            RenderSystem.setShaderTexture(0, SOFT);
            BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

            // aurora: big slow soft blobs, accent -> transparent via texture falloff
            for (int i = 0; i < AURORAS; i++) {
                float ph = i * 1.7f;
                float cx = w * (0.5f + 0.30f * (float) Math.sin(t * 0.09f + ph));
                float cy = h * (0.22f + 0.18f * i) + h * 0.05f * (float) Math.sin(t * 0.13f + ph * 2f);
                float hw = w * (0.55f + 0.10f * (float) Math.sin(t * 0.07f + ph));
                float hh = h * (0.16f + 0.04f * (float) Math.sin(t * 0.11f + ph));
                float rot = 0.25f * (float) Math.sin(t * 0.05f + ph) - 0.12f;
                int c = (i % 3 == 0) ? rgb : (i % 3 == 1) ? light : deep;
                float a = (0.20f + 0.06f * (float) Math.sin(t * 0.2f + ph)) * INTENSITY;
                blob(b, mat, X(cx, 0.5f), Y(cy, 0.5f), hw * fz, hh * fz, rot, col(c, a));
            }
            blob(b, mat, X(w * .5f, 0.5f), Y(h * 1.05f, 0.5f), w * .8f * fz, h * .35f * fz, 0f, col(deep, 0.20f * INTENSITY));

            // orbs: slow, smooth life cycle (no flicker)
            for (int i = 0; i < ORBS; i++) {
                oage[i] += dt * SPEED;
                if (oage[i] >= olife[i]) spawnOrb(i, false);
                float fr = oage[i] / olife[i];
                float s = (float) Math.sin(Math.PI * fr);
                float a = s * s * 0.55f * INTENSITY * (0.85f + 0.15f * (float) Math.sin(t * 1.3f + oph[i]));
                float x = (ox[i] + osw[i] * (float) Math.sin(oage[i] * 0.6f + oph[i])) * w;
                float y = (oy[i] - ovy[i] * oage[i]) * h;
                float r = osz[i] * h * fz;
                blob(b, mat, X(x, 1f), Y(y, 1f), r * 2f, r * 2f, 0f, col(olight[i] ? light : rgb, Math.min(0.6f, a)));
            }

            // lightning arcs: quad ribbons, smooth attack + ease-out fade
            if (LIGHTNING) {
                if (real >= nextBolt) {
                    if (bolts.size() < MAX_BOLTS) spawnBolt(real);
                    nextBolt = real + LIGHTNING_MIN_S + rnd.nextFloat() * (LIGHTNING_MAX_S - LIGHTNING_MIN_S);
                }
                int coreC = mix(rgb, 0xFFFFFF, 0.6f);
                for (int i = bolts.size() - 1; i >= 0; i--) {
                    Bolt bo = bolts.get(i);
                    float u = (float) ((real - bo.born) / bo.life);
                    if (u >= 1f) { bolts.remove(i); continue; }
                    float env = u < 0.12f ? smooth(u / 0.12f) : sq(1f - (u - 0.12f) / 0.88f);
                    blob(b, mat, X(bo.ex * w, .75f), Y(bo.ey * h, .75f), w * .25f * fz, h * .22f * fz, 0f,
                            col(rgb, 0.22f * env * INTENSITY));
                    for (float[] sg : bo.seg) {
                        float x0 = X(sg[0] * w, .75f), y0 = Y(sg[1] * h, .75f), x1 = X(sg[2] * w, .75f), y1 = Y(sg[3] * h, .75f);
                        ribbon(b, mat, x0, y0, x1, y1, 7f * pxGui * fz, col(rgb, 0.35f * env * INTENSITY));
                        ribbon(b, mat, x0, y0, x1, y1, 1.1f * pxGui * fz, col(coreC, 0.95f * env));
                    }
                }
            }
            dev.batvisuals.client.util.render.SafeDraw.draw(b);

            // 5) vignette (edge darkening so buttons stay readable)
            RenderState.apply(RenderState.Preset.ALPHA);
            RenderSystem.disableDepthTest();
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            BufferBuilder v = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            int e = (int) (VIGNETTE_ALPHA * 255) << 24, z = 0;
            float vw = w * 0.25f, vh = h * 0.28f;
            strip(v, mat, 0, 0, vw, h, e, z, e, z);             // left
            strip(v, mat, w - vw, 0, w, h, z, e, z, e);         // right
            strip(v, mat, 0, 0, w, vh, e, e, z, z);             // top
            strip(v, mat, 0, h - vh, w, h, z, z, e, e);         // bottom
            dev.batvisuals.client.util.render.SafeDraw.draw(v);
        } finally {
            RenderState.pop();
        }
    }

    // ---------------- helpers ----------------
    private float X(float x, float par) { return (x - fw * .5f) * fz + fw * .5f + pax * parPx * par; }
    private float Y(float y, float par) { return (y - fh * .5f) * fz + fh * .5f + pay * parPx * par; }

    private static void blob(BufferBuilder b, Matrix4f m, float cx, float cy, float hw, float hh, float rot, int c) {
        float cs = (float) Math.cos(rot), sn = (float) Math.sin(rot);
        float ax = -hw * cs + hh * sn, ay = -hw * sn - hh * cs; // (-hw,-hh)
        float bx = hw * cs + hh * sn, by = hw * sn - hh * cs;   // (+hw,-hh)
        b.vertex(m, cx + ax, cy + ay, 0).texture(0, 0).color(c);
        b.vertex(m, cx - bx, cy - by, 0).texture(0, 1).color(c); // (-hw,+hh)
        b.vertex(m, cx - ax, cy - ay, 0).texture(1, 1).color(c); // (+hw,+hh)
        b.vertex(m, cx + bx, cy + by, 0).texture(1, 0).color(c);
    }

    private static void ribbon(BufferBuilder b, Matrix4f m, float x0, float y0, float x1, float y1, float hw, int c) {
        float dx = x1 - x0, dy = y1 - y0, len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1e-3f) return;
        float ux = dx / len, uy = dy / len, nx = -uy * hw, ny = ux * hw;
        x0 -= ux * hw * .8f; y0 -= uy * hw * .8f; x1 += ux * hw * .8f; y1 += uy * hw * .8f; // close joint gaps
        b.vertex(m, x0 + nx, y0 + ny, 0).texture(.5f, 0).color(c);
        b.vertex(m, x0 - nx, y0 - ny, 0).texture(.5f, 1).color(c);
        b.vertex(m, x1 - nx, y1 - ny, 0).texture(.5f, 1).color(c);
        b.vertex(m, x1 + nx, y1 + ny, 0).texture(.5f, 0).color(c);
    }

    // corner alphas: tl, tr, br, bl
    private static void strip(BufferBuilder v, Matrix4f m, float x0, float y0, float x1, float y1,
                              int tl, int tr, int br, int bl) {
        v.vertex(m, x0, y0, 0).color(tl);
        v.vertex(m, x0, y1, 0).color(bl);
        v.vertex(m, x1, y1, 0).color(br);
        v.vertex(m, x1, y0, 0).color(tr);
    }

    private void spawnOrb(int i, boolean scatter) {
        ox[i] = rnd.nextFloat();
        oy[i] = 0.5f + rnd.nextFloat() * 0.6f;
        ovy[i] = 0.015f + rnd.nextFloat() * 0.03f;
        osz[i] = 0.010f + rnd.nextFloat() * 0.03f;
        olife[i] = 8f + rnd.nextFloat() * 8f;
        oage[i] = scatter ? rnd.nextFloat() * olife[i] : 0f;
        osw[i] = 0.01f + rnd.nextFloat() * 0.03f;
        oph[i] = rnd.nextFloat() * 6.283f;
        olight[i] = rnd.nextFloat() < 0.4f;
    }

    private void spawnBolt(double real) {
        Bolt bo = new Bolt();
        bo.born = real;
        bo.life = BOLT_LIFE_MIN_S + rnd.nextFloat() * (BOLT_LIFE_MAX_S - BOLT_LIFE_MIN_S);
        float x0 = 0.1f + rnd.nextFloat() * 0.8f, y0 = -0.05f;
        float x1 = x0 + (rnd.nextFloat() - .5f) * 0.3f, y1 = 0.45f + rnd.nextFloat() * 0.4f;
        bo.ex = x1; bo.ey = y1;
        jag(bo.seg, x0, y0, x1, y1, 0.12f, BOLT_LEVELS);
        if (bo.seg.size() > 6) { // one short branch
            float[] s = bo.seg.get(bo.seg.size() / 2);
            jag(bo.seg, s[2], s[3], s[2] + (rnd.nextFloat() - .5f) * 0.25f, s[3] + 0.12f + rnd.nextFloat() * 0.12f, 0.07f, 2);
        }
        bolts.add(bo);
    }

    private void jag(List<float[]> out, float x0, float y0, float x1, float y1, float disp, int lvl) {
        if (lvl == 0) { out.add(new float[]{x0, y0, x1, y1}); return; }
        float mx = (x0 + x1) / 2 + (rnd.nextFloat() - .5f) * disp;
        float my = (y0 + y1) / 2 + (rnd.nextFloat() - .5f) * disp * 0.35f;
        jag(out, x0, y0, mx, my, disp * 0.55f, lvl - 1);
        jag(out, mx, my, x1, y1, disp * 0.55f, lvl - 1);
    }

    private static float clamp(float v) { return v < -1f ? -1f : Math.min(v, 1f); }
    private static float smooth(float a) { return a * a * (3 - 2 * a); }
    private static float sq(float a) { return a * a; }

    private static int col(int rgb, float a) {
        return ((int) (Math.max(0f, Math.min(1f, a)) * 255f) << 24) | (rgb & 0xFFFFFF);
    }

    private static int mix(int a, int b, float f) {
        int r = (int) (((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int g = (int) (((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = (int) ((a & 255) * (1 - f) + (b & 255) * f);
        return (r << 16) | (g << 8) | bl;
    }
}
