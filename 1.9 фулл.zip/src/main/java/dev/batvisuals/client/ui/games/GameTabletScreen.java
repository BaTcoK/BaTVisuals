package dev.batvisuals.client.ui.games;

import dev.batvisuals.client.ui.games.impl.ArkanoidGame;
import dev.batvisuals.client.ui.games.impl.PongGame;
import dev.batvisuals.client.ui.games.impl.SnakeGame;
import dev.batvisuals.client.ui.games.impl.SpaceShooterGame;
import dev.batvisuals.client.ui.games.impl.TetrisGame;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/**
 * Tablet-style 16:9 game window with close (X) button.
 * Игра рендерится напрямую внутри планшета через DrawContext — без браузера и HTML.
 */
public class GameTabletScreen extends Screen {

    private final String gameId;
    private final MiniGame game;

    // 16:9 tablet
    private float tabletW;
    private float tabletH;
    private float tabletX;
    private float tabletY;

    private long lastNanos;

    public GameTabletScreen(String gameId, String gameName) {
        super(Text.literal(gameName));
        this.gameId = gameId;
        this.game = createGame(gameId);
    }

    private static MiniGame createGame(String gameId) {
        return switch (gameId) {
            case "snake2" -> new SnakeGame();
            case "tetris" -> new TetrisGame();
            case "pong" -> new PongGame();
            case "arkanoid" -> new ArkanoidGame();
            case "space-shooter" -> new SpaceShooterGame();
            default -> new SnakeGame();
        };
    }

    @Override
    protected void init() {
        super.init();
        // 16:9, max ~82% of screen
        float maxW = this.width * 0.82f;
        float maxH = this.height * 0.82f;
        if (maxW / maxH > 16f / 9f) {
            tabletH = maxH;
            tabletW = tabletH * 16f / 9f;
        } else {
            tabletW = maxW;
            tabletH = tabletW * 9f / 16f;
        }
        tabletX = (this.width - tabletW) / 2f;
        tabletY = (this.height - tabletH) / 2f;

        float headerH = 28f;
        float gx = tabletX + 10f;
        float gy = tabletY + headerH + 10f;
        float gw = tabletW - 20f;
        float gh = tabletH - headerH - 20f;
        game.init(gx, gy, gw, gh);
        lastNanos = System.nanoTime();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastNanos) / 1_000_000_000f);
        lastNanos = now;
        if (!game.isGameOver()) game.tick(dt);

        // dim background
        context.fill(0, 0, this.width, this.height, 0xCC0A0A12);

        // tablet body + bezel
        context.fill((int) tabletX, (int) tabletY, (int) (tabletX + tabletW), (int) (tabletY + tabletH), 0xFF12141C);
        context.fill((int) (tabletX + 4), (int) (tabletY + 4), (int) (tabletX + tabletW - 4), (int) (tabletY + tabletH - 4), 0xFF1A1C26);

        // header bar
        float headerH = 28f;
        context.fill((int) (tabletX + 4), (int) (tabletY + 4), (int) (tabletX + tabletW - 4), (int) (tabletY + 4 + headerH), 0xFF222530);
        context.drawText(this.textRenderer, game.getName(), (int) (tabletX + 16), (int) (tabletY + 12), 0xFFFFFFFF, false);

        String scoreText = "Счёт: " + game.getScore();
        int scoreW = this.textRenderer.getWidth(scoreText);
        context.drawText(this.textRenderer, scoreText, (int) (tabletX + tabletW - 4 - scoreW - 40f), (int) (tabletY + 12), 0xFFAABBCC, false);

        // close X button (top-right)
        float closeSize = 20f;
        float closeX = tabletX + tabletW - closeSize - 12f;
        float closeY = tabletY + 8f;
        boolean closeHover = mouseX >= closeX && mouseX <= closeX + closeSize && mouseY >= closeY && mouseY <= closeY + closeSize;
        int closeBg = closeHover ? 0xFFE05555 : 0xFF3A3040;
        context.fill((int) closeX, (int) closeY, (int) (closeX + closeSize), (int) (closeY + closeSize), closeBg);
        context.drawText(this.textRenderer, "✕", (int) (closeX + 5), (int) (closeY + 5), 0xFFFFFFFF, false);

        // game content area
        float gx = tabletX + 10f;
        float gy = tabletY + headerH + 10f;
        float gw = tabletW - 20f;
        float gh = tabletH - headerH - 20f;
        game.render(context, gx, gy, gw, gh, mouseX, mouseY);

        if (game.isGameOver()) {
            context.fill((int) gx, (int) gy, (int) (gx + gw), (int) (gy + gh), 0x99000000);
            String over = "Игра окончена — счёт: " + game.getScore();
            int overW = this.textRenderer.getWidth(over);
            context.drawText(this.textRenderer, over, (int) (gx + gw / 2f - overW / 2f), (int) (gy + gh / 2f - 8f), 0xFFFFFFFF, false);
            String hint = "Нажми R для рестарта";
            int hintW = this.textRenderer.getWidth(hint);
            context.drawText(this.textRenderer, hint, (int) (gx + gw / 2f - hintW / 2f), (int) (gy + gh / 2f + 6f), 0xFFAABBCC, false);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        float closeSize = 20f;
        float closeX = tabletX + tabletW - closeSize - 12f;
        float closeY = tabletY + 8f;
        if (button == 0 && mouseX >= closeX && mouseX <= closeX + closeSize && mouseY >= closeY && mouseY <= closeY + closeSize) {
            this.close();
            return true;
        }
        if (game.mouseClicked(mouseX, mouseY, button)) return true;
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) { // ESC — close tablet
            this.close();
            return true;
        }
        if (game.keyPressed(keyCode, scanCode, modifiers)) return true;
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
        if (game.keyReleased(keyCode, scanCode, modifiers)) return true;
        return super.keyReleased(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false; // handled manually above so ESC doesn't also close ClickGui behind it
    }
}
