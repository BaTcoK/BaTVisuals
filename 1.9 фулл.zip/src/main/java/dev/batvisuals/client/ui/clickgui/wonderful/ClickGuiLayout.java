package dev.batvisuals.client.ui.clickgui.wonderful;

import dev.batvisuals.client.util.renderer.fonts.Fonts;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.Setting;
import dev.batvisuals.modules.settings.impl.*;

import net.minecraft.client.resource.language.I18n;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class ClickGuiLayout {

    public static final float HEIGHT = 250f;
    public static final float SIDEBAR_WIDTH = 108f;
    public static final float MAIN_WIDTH = 250f;
    public static final float SETTINGS_WIDTH = 112f;
    public static final float PANEL_GAP = 6f;
    public static final float RADIUS = 6f;

    public static final float SIDEBAR_PADDING = 6f;
    public static final float PROFILE_HEIGHT = 38f;
    public static final float SIDEBAR_ITEM_HEIGHT = 20f;
    public static final float SIDEBAR_ITEM_GAP = 2f;
    public static final float SIDEBAR_SECTION_GAP = 4f;

    public static final float MAIN_HEADER_HEIGHT = 26f;
    public static final float MAIN_PADDING = 8f;
    public static final float CARD_GAP = 6f;
    public static final int GRID_COLUMNS = 2;

    public static final float CARD_HEADER_HEIGHT = 16f;
    public static final float CARD_DESC_SIZE = 5.8f;
    public static final float CARD_DESC_LINE_HEIGHT = 7.5f;
    public static final int CARD_DESC_MAX_LINES = 4;
    public static final float CARD_BOTTOM_ZONE = 12f;
    public static final float CARD_MIN_HEIGHT = 30f;

    public static final float SEARCH_WIDTH = 88f;
    public static final float SEARCH_HEIGHT = 14f;
    public static final int SEARCH_MAX_CHARS = 24;

    public static final float SETTINGS_HEADER_HEIGHT = 20f;
    public static final float SETTINGS_PADDING = 7f;
    public static final float SETTING_GAP = 3f;
    public static final float CHIP_GAP_X = 3f;
    public static final float CHIP_GAP_Y = 3f;
    public static final float CHIP_PADDING_X = 4f;

    private ClickGuiLayout() {}

    public static Category[] getVisibleCategories() {
        // Визуалы → Утилиты → Игры → Темы → Навигатор → Друзья → Музыка → Конфиги
        return new Category[]{ Category.Render, Category.Utility, Category.Games, Category.Theme, Category.Gps, Category.Friends, Category.Music, Category.Config, Category.Cosmetics, Category.Profile };
    }


    public static float getTotalWidth() {
        return SIDEBAR_WIDTH + PANEL_GAP + MAIN_WIDTH + PANEL_GAP + SETTINGS_WIDTH;
    }

    public static float getSidebarX(float x) { return x; }
    public static float getMainX(float x) { return x + SIDEBAR_WIDTH + PANEL_GAP; }
    public static float getSettingsX(float x) { return getMainX(x) + MAIN_WIDTH + PANEL_GAP; }

    public static float getCardWidth() {
        return (MAIN_WIDTH - MAIN_PADDING * 2f - CARD_GAP * (GRID_COLUMNS - 1)) / GRID_COLUMNS;
    }

    public static float getGridViewHeight() {
        return HEIGHT - MAIN_HEADER_HEIGHT - MAIN_PADDING;
    }

    public static float getCardHeight(Module module, float cardWidth) {
        String desc = module.getDescription();
        try {
            if (desc != null && !desc.isBlank()) {
                String tr = I18n.translate(desc);
                if (tr != null && !tr.isBlank()) desc = tr;
            }
        } catch (Throwable ignored) {}
        int lines = wrapText(desc, CARD_DESC_SIZE, cardWidth - 12f, CARD_DESC_MAX_LINES).size();
        float height = CARD_HEADER_HEIGHT + lines * CARD_DESC_LINE_HEIGHT + CARD_BOTTOM_ZONE;
        return Math.max(height, CARD_MIN_HEIGHT);
    }

    public record CardPos(Module module, int column, float offsetY, float height) {}

    public static List<CardPos> layoutCards(List<Module> modules, float cardWidth) {
        List<CardPos> result = new ArrayList<>();
        float[] columnY = new float[GRID_COLUMNS];
        for (Module module : modules) {
            int column = 0;
            for (int i = 1; i < GRID_COLUMNS; i++) {
                if (columnY[i] < columnY[column]) column = i;
            }
            float height = getCardHeight(module, cardWidth);
            result.add(new CardPos(module, column, columnY[column], height));
            columnY[column] += height + CARD_GAP;
        }
        return result;
    }

    public static float getGridContentHeight(List<Module> modules, float cardWidth) {
        float max = 0f;
        for (CardPos pos : layoutCards(modules, cardWidth)) {
            max = Math.max(max, pos.offsetY() + pos.height());
        }
        return max;
    }

    public static float getSettingsInnerWidth() {
        return SETTINGS_WIDTH - SETTINGS_PADDING * 2f;
    }

    public static float getSettingsViewHeight() {
        return HEIGHT - SETTINGS_HEADER_HEIGHT - SETTINGS_PADDING;
    }

    public static List<String> wrapText(String text, float size, float maxWidth, int maxLines) {
        List<String> lines = new ArrayList<>();
        if (text == null || text.isBlank() || maxLines <= 0) return lines;
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            String candidate = line.isEmpty() ? word : line + " " + word;
            float w = Fonts.REGULAR != null ? Fonts.REGULAR.getWidth(candidate, size) : candidate.length() * size * 0.5f;
            if (w > maxWidth && !line.isEmpty()) {
                lines.add(line.toString());
                line = new StringBuilder(word);
                if (lines.size() == maxLines) return lines;
            } else {
                line = new StringBuilder(candidate);
            }
        }
        if (!line.isEmpty() && lines.size() < maxLines) lines.add(line.toString());
        return lines;
    }

    public static String truncate(String text, float size, float maxWidth) {
        if (text == null) return "";
        float tw = Fonts.REGULAR != null ? Fonts.REGULAR.getWidth(text, size) : text.length() * size * 0.5f;
        if (tw <= maxWidth) return text;
        String dots = "..";
        float dotsW = Fonts.REGULAR != null ? Fonts.REGULAR.getWidth(dots, size) : size;
        StringBuilder out = new StringBuilder();
        float w = 0f;
        for (char c : text.toCharArray()) {
            float cw = Fonts.REGULAR != null ? Fonts.REGULAR.getWidth(String.valueOf(c), size) : size * 0.5f;
            if (w + cw + dotsW > maxWidth) break;
            out.append(c);
            w += cw;
        }
        return out + dots;
    }

    public static boolean hasVisibleSettings(Module module) {
        List<Setting<?>> settings = module.getSettings();
        if (settings == null || settings.isEmpty()) return false;
        for (Setting<?> setting : settings) {
            if (setting != null && setting.isVisible()) return true;
        }
        return false;
    }

    public static float calculateChipsHeight(List<String> names, float innerWidth) {
        float x = 0f;
        int rows = 1;
        float rowHeight = 11f;
        for (String name : names) {
            float chipW = (Fonts.REGULAR != null ? Fonts.REGULAR.getWidth(name, 6.0f) : name.length() * 3f) + CHIP_PADDING_X * 2f;
            if (x + chipW > innerWidth && x > 0f) {
                x = 0f;
                rows++;
            }
            x += chipW + CHIP_GAP_X;
        }
        return 9.0f + rows * rowHeight + (rows - 1) * CHIP_GAP_Y + 2.0f;
    }

    public static float getSettingHeight(Setting<?> setting, float innerWidth) {
        if (setting instanceof BooleanSetting || setting instanceof BindSetting) return 12f;
        if (setting instanceof NumberSetting || setting instanceof StringSetting) return 22f;
        if (setting instanceof EnumSetting<?> es) {
            Enum<?>[] vals = es.getValue().getClass().getEnumConstants();
            List<String> names = new ArrayList<>();
            if (vals != null) {
                for (Enum<?> v : vals) names.add(chipLabel(v instanceof dev.batvisuals.modules.settings.api.Nameable n ? n.getName() : v.name()));
            }
            return calculateChipsHeight(names, innerWidth);
        }
        if (setting instanceof ListSetting ls) {
            java.util.List<String> names = new java.util.ArrayList<>();
            if (ls.getValue() != null) {
                for (BooleanSetting bs : ls.getValue()) names.add(chipLabel(bs.getName()));
            }
            return calculateChipsHeight(names, innerWidth);
        }
        if (setting instanceof ColorSetting) return 14f;
        return 12f;
    }

    public static float calculateSettingsHeight(Module module, float innerWidth) {
        List<Setting<?>> settings = module.getSettings();
        if (settings == null || settings.isEmpty()) return 0f;
        List<Setting<?>> visible = settings.stream().filter(Setting::isVisible).toList();
        float height = 0f;
        for (int i = 0; i < visible.size(); i++) {
            height += getSettingHeight(visible.get(i), innerWidth);
            if (i < visible.size() - 1) height += SETTING_GAP;
        }
        return height;
    }

    /** Same label used for chip width in render + click hit-test. */
    public static String chipLabel(String raw) {
        if (raw == null || raw.isBlank()) return "";
        try {
            String tr = I18n.translate(raw);
            if (tr != null && !tr.isBlank() && !tr.equals(raw)) return tr;
        } catch (Throwable ignored) {}
        if (raw.contains(".")) {
            String last = raw.substring(raw.lastIndexOf('.') + 1);
            if (!last.isEmpty()) return Character.toUpperCase(last.charAt(0)) + last.substring(1);
        }
        return raw;
    }

    public static boolean isHovered(double mouseX, double mouseY, float x, float y, float w, float h) {
        return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
    }
}
