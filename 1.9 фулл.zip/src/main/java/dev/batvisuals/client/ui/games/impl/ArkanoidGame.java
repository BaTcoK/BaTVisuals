package dev.batvisuals.client.ui.games.impl;

import dev.batvisuals.client.ui.games.MiniGame;
import net.minecraft.client.gui.DrawContext;

import java.util.Random;

public class ArkanoidGame implements MiniGame {

    private static final float FIELD_W = 320f;
    private static final float FIELD_H = 200f;
    private static final float PADDLE_W = 46f;
    private static final float PADDLE_H = 8f;
    private static final float BALL_SIZE = 6f;
    private static final int BRICK_COLS = 10;
    private static final int BRICK_ROWS = 5;

    private float paddleX;
    private float ballX, ballY, ballVX, ballVY;
    private boolean launched;
    private boolean left, right;
    private int score;
    private boolean gameOver;
    private boolean won;
    private final boolean[][] bricks = new boolean[BRICK_ROWS][BRICK_COLS];
    private final Random random = new Random();

    @Override
    public void init(float x, float y, float w, float h) {
        paddleX = FIELD_W / 2f - PADDLE_W / 2f;
        score = 0;
        gameOver = false;
        won = false;
        for (boolean[] row : bricks) java.util.Arrays.fill(row, true);
        resetBall();
    }

    private void resetBall() {
        ballX = paddleX + PADDLE_W / 2f;
        ballY = FIELD_H - 30f;
        ballVX = 0f;
        ballVY = 0f;
        launched = false;
    }

    @Override
    public void tick(float dt) {
        if (gameOver) return;
        if (left) paddleX -= 220f * dt;
        if (right) paddleX += 220f * dt;
        paddleX = Math.max(0, Math.min(FIELD_W - PADDLE_W, paddleX));

        if (!launched) {
            ballX = paddleX + PADDLE_W / 2f;
            return;
        }

        ballX += ballVX * dt;
        ballY += ballVY * dt;

        if (ballX <= 0) { ballX = 0; ballVX = -ballVX; }
        if (ballX >= FIELD_W - BALL_SIZE) { ballX = FIELD_W - BALL_SIZE; ballVX = -ballVX; }
        if (ballY <= 0) { ballY = 0; ballVY = -ballVY; }

        if (ballY >= FIELD_H) {
            gameOver = true;
            return;
        }

        float paddleY = FIELD_H - 18f;
        if (ballVY > 0 && ballY + BALL_SIZE >= paddleY && ballY <= paddleY + PADDLE_H
                && ballX + BALL_SIZE >= paddleX && ballX <= paddleX + PADDLE_W) {
            ballY = paddleY - BALL_SIZE;
            float hit = (ballX + BALL_SIZE / 2f - (paddleX + PADDLE_W / 2f)) / (PADDLE_W / 2f);
            float speed = (float) Math.hypot(ballVX, ballVY);
            ballVX = hit * speed;
            ballVY = -Math.abs(ballVY);
        }

        float brickW = FIELD_W / BRICK_COLS;
        float brickH = 12f;
        float brickTop = 16f;
        boolean anyLeft = false;
        outer:
        for (int r = 0; r < BRICK_ROWS; r++) {
            for (int c = 0; c < BRICK_COLS; c++) {
                if (!bricks[r][c]) continue;
                anyLeft = true;
                float bx = c * brickW;
                float by = brickTop + r * brickH;
                if (ballX + BALL_SIZE >= bx && ballX <= bx + brickW
                        && ballY + BALL_SIZE >= by && ballY <= by + brickH) {
                    bricks[r][c] = false;
                    score += 10;
                    ballVY = -ballVY;
                    break outer;
                }
            }
        }
        if (!anyLeft) {
            gameOver = true;
            won = true;
        }
    }

    @Override
    public void render(DrawContext context, float x, float y, float w, float h, int mouseX, int mouseY) {
        float scale = Math.min(w / FIELD_W, h / FIELD_H);
        float fx = x + (w - FIELD_W * scale) / 2f;
        float fy = y + (h - FIELD_H * scale) / 2f;

        context.fill((int) fx, (int) fy, (int) (fx + FIELD_W * scale), (int) (fy + FIELD_H * scale), 0xFF0C0E14);

        float brickW = FIELD_W / BRICK_COLS;
        float brickH = 12f;
        float brickTop = 16f;
        int[] rowColors = {0xFFE05F5F, 0xFFE0A05F, 0xFFE0D75F, 0xFF6FE07A, 0xFF5F7CE0};
        for (int r = 0; r < BRICK_ROWS; r++) {
            for (int c = 0; c < BRICK_COLS; c++) {
                if (!bricks[r][c]) continue;
                float bx = c * brickW;
                float by = brickTop + r * brickH;
                context.fill((int) (fx + bx * scale) + 1, (int) (fy + by * scale) + 1,
                        (int) (fx + (bx + brickW) * scale) - 1, (int) (fy + (by + brickH) * scale) - 1,
                        rowColors[r % rowColors.length]);
            }
        }

        float paddleY = FIELD_H - 18f;
        context.fill((int) (fx + paddleX * scale), (int) (fy + paddleY * scale),
                (int) (fx + (paddleX + PADDLE_W) * scale), (int) (fy + (paddleY + PADDLE_H) * scale), 0xFFDDDDDD);

        context.fill((int) (fx + ballX * scale), (int) (fy + ballY * scale),
                (int) (fx + (ballX + BALL_SIZE) * scale), (int) (fy + (ballY + BALL_SIZE) * scale), 0xFFFFFFFF);

        if (!launched && !gameOver) {
            var mc = net.minecraft.client.MinecraftClient.getInstance();
            context.drawText(mc.textRenderer, "Пробел — запуск мяча",
                    (int) (fx + FIELD_W * scale / 2f - 44f), (int) (fy + FIELD_H * scale / 2f), 0xFFAABBCC, false);
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (gameOver && keyCode == 82) { init(0, 0, 0, 0); return true; }
        if (keyCode == 32) { // SPACE
            if (!launched) {
                launched = true;
                ballVX = (random.nextFloat() * 2f - 1f) * 60f;
                ballVY = -180f;
            }
            return true;
        }
        if (keyCode == 263 || keyCode == 65) { left = true; return true; }  // LEFT / A
        if (keyCode == 262 || keyCode == 68) { right = true; return true; } // RIGHT / D
        return false;
    }

    @Override
    public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 263 || keyCode == 65) { left = false; return true; }
        if (keyCode == 262 || keyCode == 68) { right = false; return true; }
        return false;
    }

    @Override
    public boolean isGameOver() { return gameOver; }

    @Override
    public int getScore() { return score; }

    @Override
    public String getName() { return "Arkanoid" + (won ? " — Победа!" : ""); }
}
