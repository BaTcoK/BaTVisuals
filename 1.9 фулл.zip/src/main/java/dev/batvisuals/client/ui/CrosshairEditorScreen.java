package dev.batvisuals.client.ui;

import dev.batvisuals.client.managers.CrosshairPresetManager;
import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.renderer.fonts.Fonts;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.awt.Color;

public class CrosshairEditorScreen extends Screen {
    private static final int N = CrosshairPresetManager.SIZE;
    private int[] pixels = new int[N * N];
    private int current = 0xFFFFFFFF;
    private boolean eraser;
    private final int[] palette = {
            0xFFFFFFFF, 0xFF000000, 0xFFFF3B30, 0xFFFF9500, 0xFFFFCC00,
            0xFF34C759, 0xFF007AFF, 0xFF5856D6, 0xFFFF2D55, 0xFF8E8E93
    };

    public CrosshairEditorScreen() {
        super(Text.literal("Редактор прицела"));
        CrosshairPresetManager.Preset p = CrosshairPresetManager.getSelectedPreset();
        if (p != null && p.pixels != null) {
            System.arraycopy(p.pixels, 0, pixels, 0, Math.min(p.pixels.length, pixels.length));
        }
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {}

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        float panelW = 280, panelH = 300;
        float px = (width - panelW) / 2f, py = (height - panelH) / 2f;
        var m = ctx.getMatrices();
        Render2D.drawRoundedRect(m, px, py, panelW, panelH, 12f, new Color(22, 24, 32, 230));
        try {
            Render2D.drawFont(m, Fonts.BOLD.getFont(10f), "Редактор прицела", px + 16, py + 14, Color.WHITE);
        } catch (Throwable ignored) {}

        float cell = 30f, gap = 4f;
        float grid = N * cell + (N - 1) * gap;
        float gx = px + (panelW - grid) / 2f, gy = py + 40f;
        for (int r = 0; r < N; r++) {
            for (int c = 0; c < N; c++) {
                float x = gx + c * (cell + gap);
                float y = gy + r * (cell + gap);
                int argb = pixels[r * N + c];
                Color fill = argb == 0 ? new Color(48, 50, 60) : new Color(argb, true);
                Render2D.drawRoundedRect(m, x, y, cell, cell, 4f, fill);
            }
        }

        float sy = gy + grid + 14;
        try {
            Render2D.drawFont(m, Fonts.REGULAR.getFont(6.5f), "Цвет", px + 16, sy, new Color(180, 180, 190));
        } catch (Throwable ignored) {}
        float sx = px + 16, sy2 = sy + 14, step = 22f;
        for (int i = 0; i < palette.length; i++) {
            float x = sx + i * step;
            Render2D.drawRoundedRect(m, x, sy2, 18, 18, 5f, new Color(palette[i], true));
            if (!eraser && current == palette[i]) {
                Render2D.drawRoundedRect(m, x - 2, sy2 - 2, 22, 22, 6f, new Color(255, 255, 255, 55));
            }
        }
        float ex = sx + palette.length * step;
        Render2D.drawRoundedRect(m, ex, sy2, 18, 18, 5f, eraser ? new Color(70, 140, 220) : new Color(48, 50, 60));
        Render2D.drawRoundedRect(m, ex + 4, sy2 + 5, 10, 7, 1.5f, Color.WHITE);
        Render2D.drawRoundedRect(m, ex + 5, sy2 + 11, 8, 2.5f, 1f, new Color(220, 80, 80));

        float bw = 120, bh = 22;
        float bx = px + (panelW - bw) / 2f;
        float by = py + panelH - 32;
        boolean hov = mouseX >= bx && mouseX <= bx + bw && mouseY >= by && mouseY <= by + bh;
        Render2D.drawRoundedRect(m, bx, by, bw, bh, 7f, hov ? new Color(70, 140, 220) : new Color(40, 42, 52));
        try {
            String label = "Сохранить и выйти";
            float tw = Fonts.REGULAR.getWidth(label, 7f);
            Render2D.drawFont(m, Fonts.REGULAR.getFont(7f), label, bx + (bw - tw) / 2f, by + 8f, Color.WHITE);
        } catch (Throwable ignored) {}
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        float panelW = 280, panelH = 300;
        float px = (width - panelW) / 2f, py = (height - panelH) / 2f;
        float cell = 30f, gap = 4f;
        float grid = N * cell + (N - 1) * gap;
        float gx = px + (panelW - grid) / 2f, gy = py + 40f;
        for (int r = 0; r < N; r++) {
            for (int c = 0; c < N; c++) {
                float x = gx + c * (cell + gap), y = gy + r * (cell + gap);
                if (mouseX >= x && mouseX <= x + cell && mouseY >= y && mouseY <= y + cell) {
                    int idx = r * N + c;
                    if (eraser) pixels[idx] = 0;
                    else pixels[idx] = current;
                    return true;
                }
            }
        }
        float sy2 = gy + grid + 28, sx = px + 16, step = 22f;
        for (int i = 0; i < palette.length; i++) {
            float x = sx + i * step;
            if (mouseX >= x && mouseX <= x + 18 && mouseY >= sy2 && mouseY <= sy2 + 18) {
                current = palette[i]; eraser = false; return true;
            }
        }
        float ex = sx + palette.length * step;
        if (mouseX >= ex && mouseX <= ex + 18 && mouseY >= sy2 && mouseY <= sy2 + 18) {
            eraser = true; return true;
        }
        float bw = 120, bh = 22;
        float bx = px + (panelW - bw) / 2f;
        float by = py + panelH - 32;
        if (mouseX >= bx && mouseX <= bx + bw && mouseY >= by && mouseY <= by + bh) {
            CrosshairPresetManager.Preset p = new CrosshairPresetManager.Preset("custom");
            p.pixels = pixels.clone();
            CrosshairPresetManager.add(p);
            CrosshairPresetManager.setSelected("custom");
            if (client != null) client.setScreen(null);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            CrosshairPresetManager.Preset p = new CrosshairPresetManager.Preset("custom");
            p.pixels = pixels.clone();
            CrosshairPresetManager.add(p);
            CrosshairPresetManager.setSelected("custom");
            if (client != null) client.setScreen(null);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() { return false; }
}
