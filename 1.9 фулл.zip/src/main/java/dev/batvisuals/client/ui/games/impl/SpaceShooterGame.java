package dev.batvisuals.client.ui.games.impl;

import dev.batvisuals.client.ui.games.MiniGame;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class SpaceShooterGame implements MiniGame {

    private static final float FIELD_W = 320f;
    private static final float FIELD_H = 220f;
    private static final float SHIP_W = 18f;
    private static final float SHIP_H = 14f;

    private float shipX;
    private boolean left, right, firing;
    private float fireTimer;

    private final List<float[]> bullets = new ArrayList<>(); // x, y
    private final List<float[]> enemies = new ArrayList<>(); // x, y, vy
    private float spawnTimer;
    private float spawnInterval = 1.0f;

    private int score;
    private int lives;
    private boolean gameOver;
    private final Random random = new Random();

    @Override
    public void init(float x, float y, float w, float h) {
        shipX = FIELD_W / 2f - SHIP_W / 2f;
        bullets.clear();
        enemies.clear();
        score = 0;
        lives = 3;
        gameOver = false;
        spawnTimer = 0f;
        spawnInterval = 1.0f;
        fireTimer = 0f;
    }

    @Override
    public void tick(float dt) {
        if (gameOver) return;

        if (left) shipX -= 200f * dt;
        if (right) shipX += 200f * dt;
        shipX = Math.max(0, Math.min(FIELD_W - SHIP_W, shipX));

        fireTimer -= dt;
        if (firing && fireTimer <= 0f) {
            bullets.add(new float[]{shipX + SHIP_W / 2f - 1.5f, FIELD_H - 24f});
            fireTimer = 0.22f;
        }

        for (float[] b : bullets) b[1] -= 260f * dt;
        bullets.removeIf(b -> b[1] < -10f);

        spawnTimer += dt;
        if (spawnTimer >= spawnInterval) {
            spawnTimer = 0f;
            spawnInterval = Math.max(0.35f, spawnInterval - 0.01f);
            enemies.add(new float[]{random.nextFloat() * (FIELD_W - 16f), -16f, 45f + random.nextFloat() * 35f});
        }

        for (float[] e : enemies) e[1] += e[2] * dt;

        Iterator<float[]> eit = enemies.iterator();
        while (eit.hasNext()) {
            float[] e = eit.next();
            if (e[1] > FIELD_H) {
                eit.remove();
                continue;
            }
            // ship collision
            if (e[1] + 14f >= FIELD_H - 24f && e[1] <= FIELD_H - 24f + SHIP_H
                    && e[0] + 14f >= shipX && e[0] <= shipX + SHIP_W) {
                eit.remove();
                lives--;
                if (lives <= 0) gameOver = true;
                continue;
            }
            // bullet collision
            Iterator<float[]> bit = bullets.iterator();
            while (bit.hasNext()) {
                float[] b = bit.next();
                if (b[0] + 3f >= e[0] && b[0] <= e[0] + 14f && b[1] <= e[1] + 14f && b[1] >= e[1]) {
                    bit.remove();
                    eit.remove();
                    score += 10;
                    break;
                }
            }
        }
    }

    @Override
    public void render(DrawContext context, float x, float y, float w, float h, int mouseX, int mouseY) {
        float scale = Math.min(w / FIELD_W, h / FIELD_H);
        float fx = x + (w - FIELD_W * scale) / 2f;
        float fy = y + (h - FIELD_H * scale) / 2f;

        context.fill((int) fx, (int) fy, (int) (fx + FIELD_W * scale), (int) (fy + FIELD_H * scale), 0xFF06060C);

        // ship (triangle-ish via rect)
        float shipY = FIELD_H - 24f;
        context.fill((int) (fx + shipX * scale), (int) (fy + (shipY + 6f) * scale),
                (int) (fx + (shipX + SHIP_W) * scale), (int) (fy + (shipY + SHIP_H) * scale), 0xFF6FE07A);
        context.fill((int) (fx + (shipX + SHIP_W / 2f - 2f) * scale), (int) (fy + shipY * scale),
                (int) (fx + (shipX + SHIP_W / 2f + 2f) * scale), (int) (fy + (shipY + 6f) * scale), 0xFF9FFFA8);

        for (float[] b : bullets) {
            context.fill((int) (fx + b[0] * scale), (int) (fy + b[1] * scale),
                    (int) (fx + (b[0] + 3f) * scale), (int) (fy + (b[1] + 8f) * scale), 0xFFFFE05F);
        }

        for (float[] e : enemies) {
            context.fill((int) (fx + e[0] * scale), (int) (fy + e[1] * scale),
                    (int) (fx + (e[0] + 14f) * scale), (int) (fy + (e[1] + 14f) * scale), 0xFFE05F5F);
        }

        var mc = net.minecraft.client.MinecraftClient.getInstance();
        context.drawText(mc.textRenderer, "Жизни: " + lives, (int) (fx + 6f), (int) (fy + 4f), 0xFFAABBCC, false);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (gameOver && keyCode == 82) { init(0, 0, 0, 0); return true; }
        if (keyCode == 263 || keyCode == 65) { left = true; return true; }  // LEFT / A
        if (keyCode == 262 || keyCode == 68) { right = true; return true; } // RIGHT / D
        if (keyCode == 32) { firing = true; return true; }                  // SPACE
        return false;
    }

    @Override
    public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 263 || keyCode == 65) { left = false; return true; }
        if (keyCode == 262 || keyCode == 68) { right = false; return true; }
        if (keyCode == 32) { firing = false; return true; }
        return false;
    }

    @Override
    public boolean isGameOver() { return gameOver; }

    @Override
    public int getScore() { return score; }

    @Override
    public String getName() { return "Space Shooter"; }
}
