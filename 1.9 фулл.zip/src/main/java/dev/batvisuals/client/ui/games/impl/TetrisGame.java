package dev.batvisuals.client.ui.games.impl;

import dev.batvisuals.client.ui.games.MiniGame;
import net.minecraft.client.gui.DrawContext;

import java.util.Random;

public class TetrisGame implements MiniGame {

    private static final int COLS = 10;
    private static final int ROWS = 18;

    private static final int[][][] SHAPES = {
            {{0,1},{1,1},{2,1},{3,1}},           // I
            {{0,0},{1,0},{0,1},{1,1}},           // O
            {{1,0},{0,1},{1,1},{2,1}},           // T
            {{0,1},{1,1},{2,1},{2,0}},           // L
            {{0,0},{0,1},{1,1},{2,1}},           // J
            {{1,0},{2,0},{0,1},{1,1}},           // S
            {{0,0},{1,0},{1,1},{2,1}},           // Z
    };
    private static final int[] COLORS = {
            0xFF5FD3E0, 0xFFE0D75F, 0xFFB05FE0, 0xFFE0A05F, 0xFF5F7CE0, 0xFF6FE07A, 0xFFE05F5F
    };

    private final int[][] grid = new int[ROWS][COLS]; // 0 = empty, else color index+1
    private int[][] shape;
    private int shapeColor;
    private int px, py;
    private final Random random = new Random();

    private float dropTimer;
    private float dropInterval = 0.6f;
    private int score;
    private boolean gameOver;

    @Override
    public void init(float x, float y, float w, float h) {
        for (int[] row : grid) java.util.Arrays.fill(row, 0);
        score = 0;
        gameOver = false;
        dropInterval = 0.6f;
        dropTimer = 0f;
        spawn();
    }

    private void spawn() {
        int idx = random.nextInt(SHAPES.length);
        shape = deepCopy(SHAPES[idx]);
        shapeColor = idx + 1;
        px = COLS / 2 - 2;
        py = 0;
        if (collides(px, py, shape)) gameOver = true;
    }

    private int[][] deepCopy(int[][] s) {
        int[][] c = new int[s.length][2];
        for (int i = 0; i < s.length; i++) { c[i][0] = s[i][0]; c[i][1] = s[i][1]; }
        return c;
    }

    private boolean collides(int ox, int oy, int[][] s) {
        for (int[] cell : s) {
            int gx = ox + cell[0];
            int gy = oy + cell[1];
            if (gx < 0 || gx >= COLS || gy >= ROWS) return true;
            if (gy >= 0 && grid[gy][gx] != 0) return true;
        }
        return false;
    }

    private int[][] rotate(int[][] s) {
        // rotate around approximate center (pivot = second cell)
        int px0 = s[1][0], py0 = s[1][1];
        int[][] r = new int[s.length][2];
        for (int i = 0; i < s.length; i++) {
            int relX = s[i][0] - px0;
            int relY = s[i][1] - py0;
            r[i][0] = px0 - relY;
            r[i][1] = py0 + relX;
        }
        return r;
    }

    @Override
    public void tick(float dt) {
        if (gameOver) return;
        dropTimer += dt;
        if (dropTimer < dropInterval) return;
        dropTimer = 0f;
        softDrop();
    }

    private void softDrop() {
        if (!collides(px, py + 1, shape)) {
            py++;
        } else {
            lock();
            clearLines();
            spawn();
        }
    }

    private void lock() {
        for (int[] cell : shape) {
            int gx = px + cell[0];
            int gy = py + cell[1];
            if (gy >= 0 && gy < ROWS && gx >= 0 && gx < COLS) grid[gy][gx] = shapeColor;
        }
    }

    private void clearLines() {
        int cleared = 0;
        for (int r = ROWS - 1; r >= 0; r--) {
            boolean full = true;
            for (int c = 0; c < COLS; c++) if (grid[r][c] == 0) { full = false; break; }
            if (full) {
                cleared++;
                for (int rr = r; rr > 0; rr--) grid[rr] = grid[rr - 1].clone();
                grid[0] = new int[COLS];
                r++; // re-check same row after shift
            }
        }
        if (cleared > 0) {
            score += switch (cleared) { case 1 -> 100; case 2 -> 300; case 3 -> 500; default -> 800; };
            dropInterval = Math.max(0.15f, dropInterval - 0.01f * cleared);
        }
    }

    @Override
    public void render(DrawContext context, float x, float y, float w, float h, int mouseX, int mouseY) {
        float cell = Math.min(w / COLS, h / ROWS);
        float boardW = cell * COLS;
        float boardH = cell * ROWS;
        float ox = x + (w - boardW) / 2f;
        float oy = y + (h - boardH) / 2f;

        context.fill((int) ox, (int) oy, (int) (ox + boardW), (int) (oy + boardH), 0xFF0C0E14);

        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (grid[r][c] != 0) drawCell(context, ox, oy, cell, c, r, COLORS[grid[r][c] - 1]);
            }
        }

        if (!gameOver) {
            for (int[] cellPos : shape) {
                int gx = px + cellPos[0];
                int gy = py + cellPos[1];
                if (gy >= 0) drawCell(context, ox, oy, cell, gx, gy, COLORS[shapeColor - 1]);
            }
        }

        for (int gx = 0; gx <= COLS; gx++) {
            int lx = (int) (ox + gx * cell);
            context.fill(lx, (int) oy, lx + 1, (int) (oy + boardH), 0x1AFFFFFF);
        }
    }

    private void drawCell(DrawContext context, float ox, float oy, float cell, int gx, int gy, int color) {
        int pad = 1;
        int x0 = (int) (ox + gx * cell) + pad;
        int y0 = (int) (oy + gy * cell) + pad;
        int x1 = (int) (ox + (gx + 1) * cell) - pad;
        int y1 = (int) (oy + (gy + 1) * cell) - pad;
        context.fill(x0, y0, x1, y1, color);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (gameOver && keyCode == 82) { init(0, 0, 0, 0); return true; }
        if (gameOver) return false;
        switch (keyCode) {
            case 263 -> { if (!collides(px - 1, py, shape)) px--; return true; }  // LEFT
            case 262 -> { if (!collides(px + 1, py, shape)) px++; return true; }  // RIGHT
            case 264 -> { softDrop(); return true; }                              // DOWN
            case 265, 87 -> {                                                      // UP / W = rotate
                int[][] r = rotate(shape);
                if (!collides(px, py, r)) shape = r;
                return true;
            }
            case 65 -> { if (!collides(px - 1, py, shape)) px--; return true; }   // A
            case 68 -> { if (!collides(px + 1, py, shape)) px++; return true; }   // D
            case 83 -> { softDrop(); return true; }                               // S
            case 32 -> {                                                          // SPACE = hard drop
                while (!collides(px, py + 1, shape)) py++;
                softDrop();
                return true;
            }
            default -> { return false; }
        }
    }

    @Override
    public boolean isGameOver() { return gameOver; }

    @Override
    public int getScore() { return score; }

    @Override
    public String getName() { return "Tetris"; }
}
