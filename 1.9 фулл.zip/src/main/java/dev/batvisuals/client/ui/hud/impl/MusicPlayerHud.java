package dev.batvisuals.client.ui.hud.impl;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.events.impl.EventMouse;
import dev.batvisuals.client.events.impl.EventRender2D;
import dev.batvisuals.client.managers.MusicManager;
import dev.batvisuals.client.ui.hud.HudElement;
import dev.batvisuals.client.util.math.MathUtils;
import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.renderer.fonts.Fonts;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

import java.awt.Color;

/** HUD-плеер: обложка, название, автор, иконки prev/play/next. */
public class MusicPlayerHud extends HudElement {

    private static final Identifier I_PREV = Identifier.of("batvisuals", "hud/music_prev.png");
    private static final Identifier I_NEXT = Identifier.of("batvisuals", "hud/music_next.png");
    private static final Identifier I_PLAY = Identifier.of("batvisuals", "hud/music_play.png");
    private static final Identifier I_PAUSE = Identifier.of("batvisuals", "hud/music_pause.png");

    public MusicPlayerHud() {
        super("MusicPlayer");
        try {
            getPosition().getValue().setX(0.5f);
            getPosition().getValue().setY(0.88f);
        } catch (Throwable ignored) {}
    }

    @Override
    protected boolean closed() {
        try {
            var bs = batvisuals.getInstance().getHudManager().getElements().getName("MusicPlayer");
            if (bs != null) return !bs.getValue();
        } catch (Throwable ignored) {}
        return !isToggled();
    }

    @Override
    public void onRender2D(EventRender2D e) {
        super.onRender2D(e);
        if (fullNullCheck() || closed()) return;

        MatrixStack m = e.getContext().getMatrices();
        float ui = Math.max(0.7f, getUiScale());
        float w = 172f * ui;
        float h = 46f * ui;
        float x = getX();
        float y = getY();
        setBounds(x, y, w, h);

        Render2D.drawRoundedRect(m, x, y, w, h, 8f * ui, new Color(12, 14, 20, 190));
        Render2D.drawRoundedRect(m, x + 3f * ui, y + 3f * ui, 2f * ui, h - 6f * ui, 1.5f * ui,
                new Color(120, 90, 255, 220));

        float av = 32f * ui;
        float ax = x + 10f * ui;
        float ay = y + (h - av) / 2f;
        Render2D.drawRoundedRect(m, ax, ay, av, av, 6f * ui, new Color(30, 32, 40, 255));
        try {
            Identifier cover = MusicManager.getCurrentCover();
            Render2D.drawTexture(m, ax + 2f * ui, ay + 2f * ui, av - 4f * ui, av - 4f * ui, 4f * ui, cover, Color.WHITE);
        } catch (Throwable ignored) {}

        MusicManager.Track track = MusicManager.current();
        String title = track != null ? track.title : "Нет треков";
        String artist = track != null ? track.artist : "batvisuals/music";
        float tx = ax + av + 8f * ui;
        float titleSize = 7.2f * ui;
        float artistSize = 6f * ui;
        title = trunc(title, titleSize, w - (tx - x) - 8f * ui);
        artist = trunc(artist, artistSize, w - (tx - x) - 8f * ui);

        Render2D.drawFont(m, Fonts.BOLD.getFont(titleSize), title, tx, y + 7f * ui, Color.WHITE);
        Render2D.drawFont(m, Fonts.REGULAR.getFont(artistSize), artist, tx, y + 17f * ui, new Color(160, 165, 180));

        float btn = 16f * ui;
        float cy = y + h - btn - 5f * ui;
        float gap = 22f * ui;
        boolean playing = MusicManager.isPlaying();
        drawIconBtn(m, tx, cy, btn, I_PREV, ui);
        drawIconBtn(m, tx + gap, cy, btn, playing ? I_PAUSE : I_PLAY, ui);
        drawIconBtn(m, tx + gap * 2f, cy, btn, I_NEXT, ui);
    }

    private void drawIconBtn(MatrixStack m, float x, float y, float s, Identifier icon, float ui) {
        Render2D.drawRoundedRect(m, x, y, s, s, 4f * ui, new Color(35, 38, 48, 230));
        try {
            float pad = 3f * ui;
            Render2D.drawTexture(m, x + pad, y + pad, s - pad * 2f, s - pad * 2f, 2f * ui, icon, Color.WHITE);
        } catch (Throwable ignored) {}
    }

    private static String trunc(String s, float size, float maxW) {
        if (s == null) return "";
        if (Fonts.REGULAR.getWidth(s, size) <= maxW) return s;
        String out = s;
        while (out.length() > 1 && Fonts.REGULAR.getWidth(out + "…", size) > maxW) {
            out = out.substring(0, out.length() - 1);
        }
        return out + "…";
    }

    private int pendingBtn = -1; // 0=prev 1=play 2=next

    private int hitControl(int mx, int my) {
        float ui = Math.max(0.7f, getUiScale());
        float h = 46f * ui;
        float x = getX();
        float y = getY();
        float av = 32f * ui;
        float ax = x + 10f * ui;
        float tx = ax + av + 8f * ui;
        float btn = 16f * ui;
        float cy = y + h - btn - 5f * ui;
        float gap = 22f * ui;
        if (MathUtils.isHovered(tx, cy, btn, btn, mx, my)) return 0;
        if (MathUtils.isHovered(tx + gap, cy, btn, btn, mx, my)) return 1;
        if (MathUtils.isHovered(tx + gap * 2f, cy, btn, btn, mx, my)) return 2;
        return -1;
    }

    @Override
    public void onMouse(EventMouse e) {
        if (fullNullCheck() || closed()) return;

        // ПКМ — окно настроек (только в чате, через super)
        if (e.getButton() == 1) {
            super.onMouse(e);
            return;
        }
        if (e.getButton() != 0) {
            super.onMouse(e);
            return;
        }

        int mx = mouseX();
        int my = mouseY();
        boolean inChat = mc.currentScreen instanceof ChatScreen;

        if (e.getAction() == 1) { // press
            int hit = hitControl(mx, my);
            pendingBtn = hit;
            pressControlMs = System.currentTimeMillis();
            if (hit >= 0) {
                // по кнопке — не drag
                return;
            }
            // вне кнопок — drag только в чате (300мс)
            if (inChat) super.onMouse(e);
            return;
        }

        if (e.getAction() == 0) { // release
            int hit = hitControl(mx, my);
            int want = pendingBtn;
            long held = System.currentTimeMillis() - pressControlMs;
            boolean wasDrag = isDraggingHud();
            pendingBtn = -1;

            // короткий клик по той же кнопке = действие (можно без чата)
            if (!wasDrag && want >= 0 && hit == want && held < 400) {
                try {
                    if (want == 0) MusicManager.prev();
                    else if (want == 1) MusicManager.playPause();
                    else if (want == 2) MusicManager.next();
                } catch (Throwable ignored) {}
            }
            if (inChat) super.onMouse(e);
            else {
                // сброс состояния если super не вызывали
                try {
                    // no-op: drag state only set via super in chat
                } catch (Throwable ignored) {}
            }
        }
    }

    private long pressControlMs;
}

