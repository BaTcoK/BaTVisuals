package dev.batvisuals.client.ui;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class CrosshairCreateScreen extends Screen {
    public CrosshairCreateScreen() { super(Text.literal("Редактор прицела")); }
    public CrosshairCreateScreen(Screen parent) { this(); }
    @Override
    protected void init() {
        if (client != null) client.setScreen(new CrosshairEditorScreen());
    }
}
