package dev.batvisuals.client.ui.mainmenu;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.batvisuals.client.render.builders.impl.RectangleBuilder;
import dev.batvisuals.client.render.builders.impl.TextBuilder;
import dev.batvisuals.client.render.builders.states.QuadColorState;
import dev.batvisuals.client.render.builders.states.QuadRadiusState;
import dev.batvisuals.client.render.builders.states.SizeState;
import dev.batvisuals.client.util.animations.Animation;
import dev.batvisuals.client.util.animations.Easing;
import dev.batvisuals.client.util.renderer.fonts.Fonts;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.text.Text;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.resource.Resource;

import org.joml.Matrix4f;

import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.client.ui.BetaNotice;

public class MainMenu extends Screen {

    private static final Animation sessionTimer = new Animation(0, 0, true, Easing.LINEAR);
    private static boolean isFirstInstance = true;
    private static boolean welcomePlayed = false;

    /** Index 0 = Bg1Animated (Claude); 1+ = bg5..bg14 textures */
    private static final String[] BACKGROUND_BASES = {
            "anim:bg1",
            "textures/gui/backgrounds/bg5",
            "textures/gui/backgrounds/bg6",
            "textures/gui/backgrounds/bg7",
            "textures/gui/backgrounds/bg8",
            "textures/gui/backgrounds/bg9",
            "textures/gui/backgrounds/bg10",
            "textures/gui/backgrounds/bg11",
            "textures/gui/backgrounds/bg12",
            "textures/gui/backgrounds/bg13",
            "textures/gui/backgrounds/bg14"
    };
    private static final int ANIM_BG_COUNT = 1;

    private static final Identifier[] BACKGROUNDS = new Identifier[BACKGROUND_BASES.length];
    private static final Bg1Animated SHARED_BG1_ANIMATED = new Bg1Animated();
    private static boolean texturesLoaded = false;
    private static int currentBgIndex = 0;
    private static boolean bgIndexLoaded = false;

    private static final Animation bgTransitionAnimation = new Animation(400, 1.0, true, Easing.LINEAR);
    private boolean showBgPicker = false;
    private float bgPickerScroll = 0f;
    private float bgPickerScrollTarget = 0f;
    private int pendingBgIndex = -1; // preview while picker open; -1 = none

    private boolean themePickerOpen = false;
    private float themePickerAnim = 0f;
    private final List<AnimatedButton> buttons = new ArrayList<>();
    private Animation alphaAnimation;
    private boolean isExiting = false;
    private boolean isNewEntry = true;
    private int lastWidth = 0;
    private int lastHeight = 0;

    // Background zoom + mouse parallax
    private static final float BG_SCALE = 1.1f;
    private float parallaxX = 0f;
    private float parallaxY = 0f;
    private final Bg1Animated bg1Animated = SHARED_BG1_ANIMATED;

    public MainMenu() {
        super(Text.literal(I18n.translate("batvisuals.mainmenu.screen_title")));
        alphaAnimation = new Animation(500, 1.0, true, Easing.OUT_EXPO);

        if (isFirstInstance) {
            isFirstInstance = false;
        }

        if (!bgIndexLoaded) {
            currentBgIndex = loadSavedBgIndex();
            bgIndexLoaded = true;
        }
        // Загрузка текстур фона перенесена в init() - при вызове конструктора (из onInitialize,
        // до старта клиента) MinecraftClient.getResourceManager() ещё возвращает null.
    }

    private static File bgConfigFile() {
        File dir = new File(batvisuals.getInstance().getGlobalsDir(), "mainmenu");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, "background.txt");
    }

    private static int loadSavedBgIndex() {
        try {
            File file = bgConfigFile();
            if (!file.exists()) return 0;
            String raw = Files.readString(file.toPath(), StandardCharsets.UTF_8).trim();
            int idx = Integer.parseInt(raw);
            // Old builds: 0=bg1, 1=storm, 2+=images. Storm removed → shift images down.
            // Detect via companion marker or just: if idx==1 keep as first image (bg5) after one-time migrate write.
            if (idx < 0) return 0;
            if (idx >= BACKGROUND_BASES.length) {
                idx = idx - 1; // old index past storm
            }
            if (idx < 0 || idx >= BACKGROUND_BASES.length) return 0;
            return idx;
        } catch (Exception e) {
            return 0;
        }
    }

    private static void saveBgIndex(int index) {
        try {
            File file = bgConfigFile();
            File parent = file.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            Files.writeString(file.toPath(), String.valueOf(index), StandardCharsets.UTF_8);
        } catch (Exception e) {
            System.err.println("[BaTVisuals] Не удалось сохранить выбранный фон: " + e.getMessage());
        }
    }

    private void loadDynamicBackgrounds() {
        MinecraftClient client = MinecraftClient.getInstance();

        for (int i = 0; i < BACKGROUND_BASES.length; i++) {
            if (BACKGROUND_BASES[i].startsWith("anim:")) { BACKGROUNDS[i] = null; continue; }
            Identifier pngPath = Identifier.of("batvisuals", BACKGROUND_BASES[i] + ".png");
            Identifier jpgPath = Identifier.of("batvisuals", BACKGROUND_BASES[i] + ".jpg");

            Optional<Resource> resource = client.getResourceManager().getResource(pngPath);
            if (resource.isEmpty()) {
                resource = client.getResourceManager().getResource(jpgPath);
            }

            if (resource.isPresent()) {
                try (InputStream stream = resource.get().getInputStream()) {
                    NativeImage nativeImage = null;
                    try {
                        nativeImage = NativeImage.read(stream);
                    } catch (Exception pngFail) {
                        // JPG: ImageIO → PNG bytes → NativeImage (public API only)
                        try (InputStream stream2 = resource.get().getInputStream()) {
                            java.awt.image.BufferedImage bi = javax.imageio.ImageIO.read(stream2);
                            if (bi != null) {
                                java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                                javax.imageio.ImageIO.write(bi, "png", baos);
                                nativeImage = NativeImage.read(new java.io.ByteArrayInputStream(baos.toByteArray()));
                            }
                        } catch (Exception ignored) {}
                    }
                    if (nativeImage != null) {
                        NativeImageBackedTexture texture = new NativeImageBackedTexture(nativeImage);
                        Identifier dynamicId = Identifier.of("batvisuals", "dynamic_bg_" + i);
                        client.getTextureManager().registerTexture(dynamicId, texture);
                        BACKGROUNDS[i] = dynamicId;
                    } else {
                        BACKGROUNDS[i] = null;
                    }
                } catch (Exception e) {
                    System.err.println("[BaTVisuals] Ошибка чтения картинки: " + BACKGROUND_BASES[i]);
                    BACKGROUNDS[i] = null;
                }
            } else {
                System.err.println("[BaTVisuals] Фон не найден: " + BACKGROUND_BASES[i]);
                BACKGROUNDS[i] = null;
            }
        }
    }




    

    @Override
    protected void init() {

        super.init();

        if (!texturesLoaded) {
            loadDynamicBackgrounds();
            texturesLoaded = hasUsableBackgroundTextures();
        }

        lastWidth = this.width;
        lastHeight = this.height;
        buttons.clear();

        float buttonWidth = 125f;
        float buttonHeight = 22f;
        float margin = 3f;

        float centerX = this.width / 2f - buttonWidth / 2f;
        float centerY = this.height / 2f;

        buttons.add(new AnimatedButton(centerX, centerY - buttonHeight * 2f - margin * 2, buttonWidth, buttonHeight, I18n.translate("batvisuals.mainmenu.singleplayer"),
                btn -> startExitAnimation(new SelectWorldScreen(this))));

        buttons.add(new AnimatedButton(centerX, centerY - buttonHeight - margin, buttonWidth, buttonHeight, I18n.translate("batvisuals.mainmenu.multiplayer"),
                btn -> startExitAnimation(new MultiplayerScreen(this))));

        buttons.add(new AnimatedButton(centerX, centerY, buttonWidth, buttonHeight, I18n.translate("batvisuals.mainmenu.options"),
                btn -> startExitAnimation(new OptionsScreen(this, this.client.options))));

        float halfWidth = (buttonWidth - margin) / 2f;
        float rowY = centerY + buttonHeight + margin;

        // Optional: Mod Menu / Replay Mod (only if installed)
        boolean hasModMenu = FabricLoader.getInstance().isModLoaded("modmenu");
        boolean hasReplay = FabricLoader.getInstance().isModLoaded("replaymod");

        if (hasModMenu || hasReplay) {
            if (hasModMenu && hasReplay) {
                buttons.add(new AnimatedButton(centerX, rowY, halfWidth, buttonHeight, "Mods",
                        btn -> openModMenu()));
                buttons.add(new AnimatedButton(centerX + halfWidth + margin, rowY, halfWidth, buttonHeight, "Replay",
                        btn -> openReplayViewer()));
            } else if (hasModMenu) {
                buttons.add(new AnimatedButton(centerX, rowY, buttonWidth, buttonHeight, "Mods",
                        btn -> openModMenu()));
            } else {
                buttons.add(new AnimatedButton(centerX, rowY, buttonWidth, buttonHeight, "Replay Viewer",
                        btn -> openReplayViewer()));
            }
            rowY += buttonHeight + margin;
        }

        buttons.add(new AnimatedButton(centerX, rowY, halfWidth, buttonHeight, I18n.translate("batvisuals.mainmenu.altmanager"),
                btn -> startExitAnimation(new AltManagerScreen(this))));
        buttons.add(new AnimatedButton(centerX + halfWidth + margin, rowY, halfWidth, buttonHeight, I18n.translate("batvisuals.mainmenu.quit"),
                btn -> startExitAnimation(null)));

        if (isNewEntry) {
            isExiting = false;
            isNewEntry = false;
            alphaAnimation = new Animation(500, 1.0, true, Easing.OUT_EXPO);
            buttons.forEach(AnimatedButton::resetAnimations);
        }

        if (!welcomePlayed) {
            welcomePlayed = true;
            try {
                MinecraftClient.getInstance().getSoundManager().play(
                        PositionedSoundInstance.master(
                                SoundEvent.of(Identifier.of("batvisuals", "welcome")),
                                1.0f,
                                1.0f
                        )
                );
            } catch (Exception ignored) {}
        }
    }

    private void startExitAnimation(Screen nextScreen) {
        if (isExiting) return;

        isExiting = true;
        isNewEntry = true;
        alphaAnimation.update(false);

        if (nextScreen == null) {
            sessionTimer.reset();
        }

        new Thread(() -> {
            try {
                Thread.sleep(150);
                MinecraftClient.getInstance().execute(() -> {
                    if (nextScreen == null) MinecraftClient.getInstance().scheduleStop();
                    else MinecraftClient.getInstance().setScreen(nextScreen);
                });
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Site / Telegram bottom center
        if (button == 0) {
            float linkSize = 26f;
            float linkGap = 10f;
            float linksW = linkSize * 2 + linkGap;
            float linksX = this.width / 2f - linksW / 2f;
            float linksY = this.height - 36f;
            if (mouseX >= linksX && mouseX <= linksX + linkSize && mouseY >= linksY && mouseY <= linksY + linkSize) {
                openExternal("https://BaTVisuals.edgeone.dev");
                return true;
            }
            float tgX = linksX + linkSize + linkGap;
            if (mouseX >= tgX && mouseX <= tgX + linkSize && mouseY >= linksY && mouseY <= linksY + linkSize) {
                openExternal("https://t.me/BaTVisuals");
                return true;
            }
            String vanStr = "Обычное меню";
            float vanW = Fonts.REGULAR.getWidth(vanStr, 6.5f) + 16f;
            float vanH = 16f;
            float vanX = this.width - vanW - 10f;
            float vanY = 10f;
            if (mouseX >= vanX && mouseX <= vanX + vanW && mouseY >= vanY && mouseY <= vanY + vanH) {
                dev.batvisuals.client.ui.mainmenu.MenuStyle.setCustom(false);
                if (this.client != null) {
                    this.client.setScreen(new net.minecraft.client.gui.screen.TitleScreen());
                }
                return true;
            }
        }
        float btnW = 90f;
        float btnH = 16f;
        float btnX = 10f;
        float btnY = this.height - 30;

        // Open / close picker button
        if (mouseX >= btnX && mouseX <= btnX + btnW && mouseY >= btnY && mouseY <= btnY + btnH) {
            showBgPicker = !showBgPicker;
            if (showBgPicker) {
                bgPickerScroll = 0f;
                bgPickerScrollTarget = 0f;
                pendingBgIndex = currentBgIndex;
            } else {
                pendingBgIndex = -1;
            }
            return true;
        }

        // While picker is open — block all clicks to main menu
        if (showBgPicker) {
            float[] box = bgPickerBounds();
            float px = box[0], py = box[1], pw = box[2], ph = box[3];
            boolean inside = mouseX >= px && mouseX <= px + pw && mouseY >= py && mouseY <= py + ph;

            if (!inside) {
                // click outside panel: close only, do not hit main buttons
                showBgPicker = false;
                pendingBgIndex = -1;
                return true;
            }

            // footer buttons
            float footerH = 28f;
            float contentBottom = py + ph - footerH - 6f;
            float saveW = (pw - 24f) / 2f;
            float saveX = px + 8f;
            float cancelX = px + 8f + saveW + 8f;
            float footerY = py + ph - footerH - 4f;

            if (mouseY >= footerY && mouseY <= footerY + 22f) {
                if (mouseX >= saveX && mouseX <= saveX + saveW) {
                    int idx = pendingBgIndex >= 0 ? pendingBgIndex : currentBgIndex;
                    if (idx != currentBgIndex) {
                        currentBgIndex = idx;
                        if (idx == 0) { bg1Animated.reset(); bg1Animated.retry(); }
                        saveBgIndex(idx);
                        bgTransitionAnimation.reset();
                        bgTransitionAnimation.update(true);
                    }
                    showBgPicker = false;
                    pendingBgIndex = -1;
                    return true;
                }
                if (mouseX >= cancelX && mouseX <= cancelX + saveW) {
                    showBgPicker = false;
                    pendingBgIndex = -1;
                    return true;
                }
            }

            // thumbs in scroll area
            float pad = 10f;
            float gap = 8f;
            int cols = 2;
            float thumbW = (pw - pad * 2f - gap) / cols;
            float thumbH = thumbW * 0.58f;
            float listTop = py + 28f;
            float listH = contentBottom - listTop;
            float scroll = bgPickerScroll;

            for (int i = 0; i < BACKGROUNDS.length; i++) {
                int col = i % cols;
                int row = i / cols;
                float thumbX = px + pad + col * (thumbW + gap);
                float thumbY = listTop + row * (thumbH + gap) + scroll;
                if (thumbY + thumbH < listTop || thumbY > listTop + listH) continue;
                if (mouseX >= thumbX && mouseX <= thumbX + thumbW && mouseY >= thumbY && mouseY <= thumbY + thumbH
                        && mouseY >= listTop && mouseY <= listTop + listH) {
                    pendingBgIndex = i;
                    currentBgIndex = i;
                    if (i == 0) { bg1Animated.reset(); bg1Animated.retry(); }
                    saveBgIndex(i); // persist immediately
                    bgTransitionAnimation.reset();
                    bgTransitionAnimation.update(true);
                    return true;
                }
            }
            return true; // absorb all clicks inside panel
        }

        for (AnimatedButton btn : buttons) {
            if (btn.isMouseOver((int) mouseX, (int) mouseY)) {
                btn.onPress();
                return true;
            }
        }
        if (button == 0 && handleThemeCubeClick(mouseX, mouseY)) {
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    /** Centered adaptive picker bounds: [x, y, w, h] */
    private float[] bgPickerBounds() {
        float pw = Math.min(this.width * 0.78f, 340f);
        pw = Math.max(200f, Math.min(pw, this.width - 24f));
        float ph = Math.min(this.height * 0.72f, 300f);
        ph = Math.max(180f, Math.min(ph, this.height - 40f));
        float px = (this.width - pw) / 2f;
        float py = (this.height - ph) / 2f;
        return new float[]{px, py, pw, ph};
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (showBgPicker) {
            float[] box = bgPickerBounds();
            float pw = box[2], ph = box[3];
            float pad = 10f;
            float gap = 8f;
            int cols = 2;
            float thumbW = (pw - pad * 2f - gap) / cols;
            float thumbH = thumbW * 0.58f;
            int rows = (BACKGROUNDS.length + cols - 1) / cols;
            float contentH = rows * (thumbH + gap);
            float listH = ph - 28f - 34f;
            float maxScroll = Math.min(0f, listH - contentH);
            bgPickerScrollTarget = (float) Math.max(maxScroll, Math.min(0f, bgPickerScrollTarget + verticalAmount * 18f));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        if (showBgPicker) {
            showBgPicker = false;
            pendingBgIndex = -1;
            // reload saved index so ESC cancels preview
            currentBgIndex = loadSavedBgIndex();
            return true;
        }
        return false;
    }

    @Override
    public void render(DrawContext drawContext, int mouseX, int mouseY, float delta) {
        if (this.width != lastWidth || this.height != lastHeight) {
            this.init();
        }

        float alpha = alphaAnimation.getValue();
        Matrix4f matrix = drawContext.getMatrices().peek().getPositionMatrix();

        // ============================================
        // 1. РИСУЕМ ФОН НА САМОМ ЗАДНЕМ ПЛАНЕ
        // ============================================
        drawContext.getMatrices().push();

        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();

        // Parallax: mouse moves image to the opposite side (smooth)
        float invW = this.width > 0 ? 1f / this.width : 0f;
        float invH = this.height > 0 ? 1f / this.height : 0f;
        float targetX = -((mouseX * invW) - 0.5f) * 2f; // -1..1 opposite
        float targetY = -((mouseY * invH) - 0.5f) * 2f;
        float smooth = Math.min(1f, delta * 8f);
        parallaxX += (targetX - parallaxX) * smooth;
        parallaxY += (targetY - parallaxY) * smooth;

        float drawW = this.width * BG_SCALE;
        float drawH = this.height * BG_SCALE;
        float extraW = drawW - this.width;
        float extraH = drawH - this.height;
        float offsetX = -extraW * 0.5f + parallaxX * (extraW * 0.5f);
        float offsetY = -extraH * 0.5f + parallaxY * (extraH * 0.5f);

        int bgDraw = pendingBgIndex >= 0 && showBgPicker ? pendingBgIndex : currentBgIndex;
        if (bgDraw == 0) {
            // bg-1: procedural neon aurora + orbs + lightning (theme color)
            bg1Animated.render(drawContext, this.width, this.height, mouseX, mouseY, BG_SCALE);
        } else if (isAnimBg(bgDraw)) {
            renderAnimatedLightning(drawContext.getMatrices(), alpha, bgDraw);
        } else if (bgDraw >= 0 && bgDraw < BACKGROUNDS.length && BACKGROUNDS[bgDraw] != null) {
            drawContext.drawTexture(
                    RenderLayer::getGuiTextured,
                    BACKGROUNDS[bgDraw],
                    (int) offsetX, (int) offsetY,
                    0.0f, 0.0f,
                    (int) drawW, (int) drawH,
                    (int) drawW, (int) drawH
            );
        } else {
            new RectangleBuilder()
                    .size(new SizeState(this.width, this.height))
                    .radius(new QuadRadiusState(0))
                    .color(new QuadColorState(new Color(0, 0, 0, 255)))
                    .build()
                    .render(matrix, 0f, 0f, 0f);
        }

        drawContext.getMatrices().pop();

        // ============================================
        // КЛЮЧЕВОЙ ФИКС: принудительно сбрасываем (flush) буфер фона
        // ПРЕЖДЕ чем рисовать что-либо ещё поверх него.
        // drawTexture() кладёт вершины в буфер VertexConsumerProvider и
        // рисует их асинхронно (часто только в конце кадра), в то время
        // как твои кастомные билдеры (RectangleBuilder/TextBuilder) рисуют
        // немедленно. Из-за этого UI отрисовывался РАНЬШЕ фона, а потом
        // буфер фона сбрасывался и перекрывал уже нарисованные кнопки/текст.
        // draw() форсирует немедленный flush всего, что накопилось выше.
        // ============================================
        drawContext.draw();

        // ============================================
        // 2. СБРАСЫВАЕМ ВСЕ GL-СОСТОЯНИЯ перед UI
        // ============================================
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();

        // ============================================
        // 3. ЗАГОЛОВОК
        // ============================================
        // Logo icon (logo_clear) + BaTVisuals + version — not splash text banner
        float headerY = this.height / 2f - 118f;
        try {
            Identifier logoId = Identifier.of("batvisuals", "logo_clear.png");
            float logoS = 42f;
            float logoX = this.width / 2f - logoS / 2f;
            drawContext.drawTexture(RenderLayer::getGuiTextured, logoId,
                    (int) logoX, (int) headerY, 0f, 0f, (int) logoS, (int) logoS, (int) logoS, (int) logoS);
        } catch (Throwable ignored) {}

        String title = "BaTVisuals";
        float titleSize = 9f;
        float titleX = this.width / 2f - Fonts.BOLD.getWidth(title, titleSize) / 2f;
        float titleY = headerY + 48f;
        new TextBuilder()
                .font(Fonts.BOLD.font())
                .text(title)
                .size(titleSize)
                .color(new Color(235, 237, 245, (int) (alpha * 255)))
                .smoothness(0.5f)
                .build()
                .render(matrix, titleX, titleY, 0f);

        String ver = "Version 1.9";
        float verSize = 6f;
        float verX = this.width / 2f - Fonts.REGULAR.getWidth(ver, verSize) / 2f;
        new TextBuilder()
                .font(Fonts.REGULAR.font())
                .text(ver)
                .size(verSize)
                .color(new Color(160, 165, 180, (int) (alpha * 220)))
                .smoothness(0.5f)
                .build()
                .render(matrix, verX, titleY + 14f, 0f);

        // ============================================
        // 4. КОПИРАЙТ
        // ============================================
        String copyright = I18n.translate("batvisuals.mainmenu.copyright");
        float copyrightX = this.width - Fonts.REGULAR.getWidth(copyright, 6f) - 5;

        new TextBuilder()
                .font(Fonts.REGULAR.font())
                .text(copyright)
                .size(6f)
                .color(new Color(255, 255, 255, (int) (alpha * 255)))
                .smoothness(0.5f)
                .build()
                .render(matrix, copyrightX, this.height - 10, 0f);

        // Site + Telegram bottom center
        float linkSize = 26f;
        float linkGap = 10f;
        float linksW = linkSize * 2 + linkGap;
        float linksX = this.width / 2f - linksW / 2f;
        float linksY = this.height - 36f;
        // site
        boolean siteHov = mouseX >= linksX && mouseX <= linksX + linkSize && mouseY >= linksY && mouseY <= linksY + linkSize;
        new RectangleBuilder().size(new SizeState(linkSize, linkSize)).radius(new QuadRadiusState(6))
                .color(new QuadColorState(new Color(siteHov ? 55 : 32, siteHov ? 60 : 34, siteHov ? 80 : 44, (int)(230*alpha))))
                .build().render(matrix, linksX, linksY, 0f);
        try {
            Identifier logoId = Identifier.of("batvisuals", "logo_clear.png");
            drawContext.drawTexture(RenderLayer::getGuiTextured, logoId,
                    (int)(linksX+4), (int)(linksY+4), 0f, 0f, (int)(linkSize-8), (int)(linkSize-8), (int)(linkSize-8), (int)(linkSize-8));
        } catch (Throwable ignored) {}
        // tg
        float tgX = linksX + linkSize + linkGap;
        boolean tgHov = mouseX >= tgX && mouseX <= tgX + linkSize && mouseY >= linksY && mouseY <= linksY + linkSize;
        new RectangleBuilder().size(new SizeState(linkSize, linkSize)).radius(new QuadRadiusState(6))
                .color(new QuadColorState(new Color(tgHov ? 40 : 30, tgHov ? 160 : 136, tgHov ? 230 : 200, (int)(230*alpha))))
                .build().render(matrix, tgX, linksY, 0f);
        try {
            Identifier tgId = Identifier.of("batvisuals", "textures/gui/telegram_icon.png");
            drawContext.drawTexture(RenderLayer::getGuiTextured, tgId,
                    (int)(tgX+3), (int)(linksY+3), 0f, 0f, (int)(linkSize-6), (int)(linkSize-6), (int)(linkSize-6), (int)(linkSize-6));
        } catch (Throwable ignored) {}

        // Switch to vanilla title screen — top-right (not bottom center)
        String vanStr = "Обычное меню";
        float vanW = Fonts.REGULAR.getWidth(vanStr, 6.5f) + 16f;
        float vanH = 16f;
        float vanX = this.width - vanW - 10f;
        float vanY = 10f;
        boolean vanHov = mouseX >= vanX && mouseX <= vanX + vanW && mouseY >= vanY && mouseY <= vanY + vanH;
        new RectangleBuilder().size(new SizeState(vanW, vanH)).radius(new QuadRadiusState(5))
                .color(new QuadColorState(new Color(vanHov ? 50 : 28, vanHov ? 52 : 30, vanHov ? 65 : 38, (int)(220*alpha))))
                .build().render(matrix, vanX, vanY, 0f);
        new TextBuilder().font(Fonts.REGULAR.font()).text(vanStr).size(6.5f)
                .color(new Color(220, 225, 235, (int)(255*alpha))).smoothness(0.5f).build()
                .render(matrix, vanX + 8f, vanY + 4f, 0f);

        // ============================================
        // 5. КНОПКА СМЕНЫ ФОНА (Слева снизу)
        // ============================================
        float btnW = 80f;
        float btnH = 16f;
        float btnX = 10f;
        float btnY = this.height - 30;

        new RectangleBuilder()
                .size(new SizeState(btnW, btnH))
                .radius(new QuadRadiusState(4))
                .color(new QuadColorState(new Color(40, 40, 50, (int) (alpha * 200))))
                .build()
                .render(matrix, btnX, btnY, 0f);

        String bgBtnStr = "Сменить фон";
        float bgBtnTextX = btnX + btnW / 2f - Fonts.REGULAR.getWidth(bgBtnStr, 6f) / 2f;
        float bgBtnTextY = btnY + btnH / 2f - Fonts.REGULAR.getHeight(6f) / 2f;
        new TextBuilder()
                .font(Fonts.REGULAR.font())
                .text(bgBtnStr)
                .size(6f)
                .color(new Color(220, 220, 240, (int) (alpha * 255)))
                .smoothness(0.5f)
                .build()
                .render(matrix, bgBtnTextX, bgBtnTextY, 0f);

        // ============================================
        // 6. ЦЕНТРАЛЬНАЯ ПАНЕЛЬ ВЫБОРА ФОНОВ (14 шт, 2 колонки, скролл)
        // ============================================
        if (showBgPicker) {
            // smooth scroll
            bgPickerScroll += (bgPickerScrollTarget - bgPickerScroll) * 0.28f;
            if (Math.abs(bgPickerScrollTarget - bgPickerScroll) < 0.3f) bgPickerScroll = bgPickerScrollTarget;

            float[] box = bgPickerBounds();
            float px = box[0], py = box[1], pw = box[2], ph = box[3];

            // dim overlay — blocks visual of "clicks going through"
            new RectangleBuilder()
                    .size(new SizeState(this.width, this.height))
                    .radius(new QuadRadiusState(0))
                    .color(new QuadColorState(new Color(0, 0, 0, (int) (210 * alpha))))
                    .build()
                    .render(matrix, 0f, 0f, 0f);

            // panel
            new RectangleBuilder()
                    .size(new SizeState(pw, ph))
                    .radius(new QuadRadiusState(12))
                    .color(new QuadColorState(new Color(16, 16, 20, 245)))
                    .build()
                    .render(matrix, px, py, 0f);

            // title
            String pickerTitle = "Выбор фона";
            float titleW = Fonts.REGULAR.getWidth(pickerTitle, 8f);
            new TextBuilder()
                    .font(Fonts.REGULAR.font())
                    .text(pickerTitle)
                    .size(8f)
                    .color(new Color(240, 240, 250, (int) (255 * alpha)))
                    .smoothness(0.5f)
                    .build()
                    .render(matrix, px + (pw - titleW) / 2f, py + 10f, 0f);

            float pad = 10f;
            float gap = 8f;
            int cols = 2;
            float thumbW = (pw - pad * 2f - gap) / cols;
            float thumbH = thumbW * 0.58f;
            float listTop = py + 28f;
            float footerH = 28f;
            float listH = ph - 28f - footerH - 8f;
            int rows = (BACKGROUNDS.length + cols - 1) / cols;
            float contentH = rows * (thumbH + gap);
            float maxScroll = Math.min(0f, listH - contentH);
            if (bgPickerScrollTarget < maxScroll) bgPickerScrollTarget = maxScroll;
            if (bgPickerScrollTarget > 0f) bgPickerScrollTarget = 0f;

            // Clip thumbs strictly inside list area (no overflow over title/footer)
            int selected = pendingBgIndex >= 0 ? pendingBgIndex : currentBgIndex;
            int clipX1 = (int) Math.floor(px + 2);
            int clipY1 = (int) Math.floor(listTop);
            int clipX2 = (int) Math.ceil(px + pw - 2);
            int clipY2 = (int) Math.ceil(listTop + listH);
            drawContext.enableScissor(clipX1, clipY1, clipX2, clipY2);

            for (int i = 0; i < BACKGROUNDS.length; i++) {
                int col = i % cols;
                int row = i / cols;
                float thumbX = px + pad + col * (thumbW + gap);
                float thumbY = listTop + row * (thumbH + gap) + bgPickerScroll;
                // still skip far-off items for performance
                if (thumbY + thumbH < listTop - 2 || thumbY > listTop + listH + 2) continue;

                boolean sel = (i == selected);
                new RectangleBuilder()
                        .size(new SizeState(thumbW, thumbH))
                        .radius(new QuadRadiusState(6))
                        .color(new QuadColorState(sel ? new Color(90, 140, 255, 255) : new Color(40, 40, 48, 220)))
                        .build()
                        .render(matrix, thumbX, thumbY, 0f);

                if (isAnimBg(i)) {
                    int inset = 2;
                    new RectangleBuilder()
                            .size(new SizeState(thumbW - inset * 2, thumbH - inset * 2))
                            .radius(new QuadRadiusState(4))
                            .color(new QuadColorState(new Color(0, 0, 0, 255)))
                            .build()
                            .render(matrix, thumbX + inset, thumbY + inset, 0f);
                    // neon line preview
                    try {
                        Color ac = dev.batvisuals.client.managers.ThemeManager.getInstance().getCurrentTheme().getAccentColor();
                        new RectangleBuilder()
                                .size(new SizeState(thumbW * 0.55f, 2f))
                                .radius(new QuadRadiusState(1))
                                .color(new QuadColorState(new Color(ac.getRed(), ac.getGreen(), ac.getBlue(), 230)))
                                .build()
                                .render(matrix, thumbX + thumbW * 0.22f, thumbY + thumbH * 0.45f, 0f);
                    } catch (Throwable ignored) {}
                } else if (BACKGROUNDS[i] != null) {
                    RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, alpha);
                    RenderSystem.enableBlend();
                    RenderSystem.defaultBlendFunc();
                    RenderSystem.disableDepthTest();
                    int inset = 2;
                    drawContext.drawTexture(RenderLayer::getGuiTextured, BACKGROUNDS[i],
                            (int) thumbX + inset, (int) thumbY + inset, 0.0f, 0.0f,
                            (int) thumbW - inset * 2, (int) thumbH - inset * 2,
                            (int) thumbW - inset * 2, (int) thumbH - inset * 2);
                    RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
                }

                String lab = isAnimBg(i) ? "Neon BG-1" : ("bg" + (i + 4));
                float lw = Fonts.REGULAR.getWidth(lab, 5.5f);
                new TextBuilder()
                        .font(Fonts.REGULAR.font())
                        .text(lab)
                        .size(5.5f)
                        .color(new Color(255, 255, 255, (int) (220 * alpha)))
                        .smoothness(0.5f)
                        .build()
                        .render(matrix, thumbX + (thumbW - lw) / 2f, thumbY + thumbH - 11f, 0f);
            }

            // flush clipped textures before disabling scissor
            drawContext.draw();
            drawContext.disableScissor();

            // footer buttons
            float saveW = (pw - 24f) / 2f;
            float saveX = px + 8f;
            float cancelX = px + 8f + saveW + 8f;
            float footerY = py + ph - footerH - 2f;

            new RectangleBuilder()
                    .size(new SizeState(saveW, 22f))
                    .radius(new QuadRadiusState(6))
                    .color(new QuadColorState(new Color(55, 120, 220, 240)))
                    .build()
                    .render(matrix, saveX, footerY, 0f);
            String saveStr = "Сохранить";
            float sw = Fonts.REGULAR.getWidth(saveStr, 6.5f);
            new TextBuilder().font(Fonts.REGULAR.font()).text(saveStr).size(6.5f)
                    .color(new Color(255, 255, 255, (int) (255 * alpha))).smoothness(0.5f).build()
                    .render(matrix, saveX + (saveW - sw) / 2f, footerY + 7f, 0f);

            new RectangleBuilder()
                    .size(new SizeState(saveW, 22f))
                    .radius(new QuadRadiusState(6))
                    .color(new QuadColorState(new Color(50, 50, 58, 240)))
                    .build()
                    .render(matrix, cancelX, footerY, 0f);
            String cancelStr = "Выйти";
            float cw = Fonts.REGULAR.getWidth(cancelStr, 6.5f);
            new TextBuilder().font(Fonts.REGULAR.font()).text(cancelStr).size(6.5f)
                    .color(new Color(230, 230, 235, (int) (255 * alpha))).smoothness(0.5f).build()
                    .render(matrix, cancelX + (saveW - cw) / 2f, footerY + 7f, 0f);

            drawContext.draw();
        }

        // Main menu buttons only when picker is closed (picker is the top layer)
        if (!showBgPicker) {
            RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            for (AnimatedButton btn : buttons) {
                btn.render(drawContext, mouseX, mouseY, delta, alpha);
            }
            drawContext.draw();
            renderThemeCube(drawContext, mouseX, mouseY, alpha);
            drawContext.draw();
            BetaNotice.render(drawContext, this.width, this.height);
        } else {
            drawContext.draw();
        }
    }


    /**
     * Shared background for MainMenu / AltManager / other menu screens.
     * Draws the selected wallpaper texture (or dark gradient fallback), then flushes.
     */
    public static void drawSharedBackground(DrawContext drawContext, int width, int height) {
        if (!bgIndexLoaded) {
            currentBgIndex = loadSavedBgIndex();
            bgIndexLoaded = true;
        }
        ensureBackgroundsLoaded();
        var matrices = drawContext.getMatrices();
        matrices.push();
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();

        int idx = currentBgIndex;
        if (idx == 0) {
            SHARED_BG1_ANIMATED.render(drawContext, width, height, width / 2f, height / 2f, BG_SCALE);
        } else if (idx >= 0 && idx < BACKGROUNDS.length && BACKGROUNDS[idx] != null) {
            float scale = BG_SCALE;
            float dw = width * scale;
            float dh = height * scale;
            float ox = -(dw - width) * 0.5f;
            float oy = -(dh - height) * 0.5f;
            drawContext.drawTexture(RenderLayer::getGuiTextured, BACKGROUNDS[idx],
                    (int) ox, (int) oy, 0.0f, 0.0f, (int) dw, (int) dh, (int) dw, (int) dh);
        } else {
            Matrix4f matrix = matrices.peek().getPositionMatrix();
            new RectangleBuilder()
                    .size(new SizeState(width, height))
                    .radius(new QuadRadiusState(0))
                    .color(new QuadColorState(
                            new Color(7, 7, 10, 255), new Color(7, 7, 10, 255),
                            new Color(28, 28, 36, 255), new Color(28, 28, 36, 255)))
                    .build().render(matrix, 0f, 0f, 0f);
        }
        matrices.pop();
        drawContext.draw();
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
    }

    private static boolean hasUsableBackgroundTextures() {
        for (int i = 1; i < BACKGROUNDS.length; i++) {
            if (BACKGROUNDS[i] != null) return true;
        }
        return false;
    }

    private static void ensureBackgroundsLoaded() {
        if (texturesLoaded) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.getResourceManager() == null) return;

        try {
            boolean any = false;
            for (int i = 0; i < BACKGROUND_BASES.length; i++) {
                if (i == 0) { any = true; continue; }
                if (BACKGROUNDS[i] != null) { any = true; continue; }
                Identifier pngPath = Identifier.of("batvisuals", BACKGROUND_BASES[i] + ".png");
                Identifier jpgPath = Identifier.of("batvisuals", BACKGROUND_BASES[i] + ".jpg");
                Optional<Resource> resource = client.getResourceManager().getResource(pngPath);
                if (resource.isEmpty()) resource = client.getResourceManager().getResource(jpgPath);
                if (resource.isEmpty()) continue;
                NativeImage nativeImage = null;
                try (InputStream stream = resource.get().getInputStream()) {
                    try {
                        nativeImage = NativeImage.read(stream);
                    } catch (Throwable ignored) {}
                }
                if (nativeImage == null) {
                    try (InputStream stream = resource.get().getInputStream()) {
                        java.awt.image.BufferedImage bi = javax.imageio.ImageIO.read(stream);
                        if (bi != null) {
                            java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                            javax.imageio.ImageIO.write(bi, "png", baos);
                            nativeImage = NativeImage.read(new java.io.ByteArrayInputStream(baos.toByteArray()));
                        }
                    } catch (Throwable ignored) {}
                }
                if (nativeImage != null) {
                    Identifier dynamicId = Identifier.of("batvisuals", "dynamic_bg_" + i);
                    client.getTextureManager().registerTexture(dynamicId, new NativeImageBackedTexture(nativeImage));
                    BACKGROUNDS[i] = dynamicId;
                    any = true;
                }
            }
            texturesLoaded = any;
        } catch (Throwable ignored) {}
    }

    private static boolean isAnimBg(int idx) {
        return idx >= 0 && idx < BACKGROUND_BASES.length && BACKGROUND_BASES[idx].startsWith("anim:");
    }

    /** Black screen + neon lightning (theme accent). */
    // Persistent bolts with individual fade in/out
    private static final class Bolt {
        float x0, y0, x1, y1;
        long bornAt;
        long appearMs;
        long holdMs;
        long fadeMs;
        int seed;
    }
    private final java.util.List<Bolt> activeBolts = new java.util.ArrayList<>();
    private long lastBoltSpawn = 0L;

    private void renderAnimatedLightning(MatrixStack stack, float alpha, int variant) {
        Matrix4f matrix = stack.peek().getPositionMatrix();
        // solid black
        new RectangleBuilder()
                .size(new SizeState(this.width, this.height))
                .radius(new QuadRadiusState(0))
                .color(new QuadColorState(new Color(0, 0, 0, (int) (255 * alpha))))
                .build()
                .render(matrix, 0f, 0f, 0f);

        Color accent;
        try {
            accent = ThemeManager.getInstance().getCurrentTheme().getAccentColor();
        } catch (Throwable ex) {
            accent = new Color(120, 90, 255);
        }

        long now = System.currentTimeMillis();
        int maxBolts = variant == 0 ? 2 : 3;
        // spawn sparingly
        long spawnEvery = variant == 0 ? 900L : 700L;
        if (activeBolts.size() < maxBolts && now - lastBoltSpawn > spawnEvery) {
            java.util.Random rng = new java.util.Random(now ^ (variant * 1337L));
            Bolt b = new Bolt();
            b.x0 = rng.nextFloat() * this.width;
            b.y0 = -10f + rng.nextFloat() * 30f;
            b.x1 = rng.nextFloat() * this.width;
            b.y1 = this.height * (0.5f + rng.nextFloat() * 0.45f);
            b.bornAt = now;
            b.appearMs = 1000L + rng.nextInt(1000); // 1–2 s appear
            b.holdMs = 200L + rng.nextInt(400);
            b.fadeMs = 2000L + rng.nextInt(1000);   // 2–3 s fade
            b.seed = rng.nextInt();
            activeBolts.add(b);
            lastBoltSpawn = now;
        }

        // remove finished
        activeBolts.removeIf(b -> {
            long age = now - b.bornAt;
            return age > b.appearMs + b.holdMs + b.fadeMs;
        });

        for (Bolt b : activeBolts) {
            long age = now - b.bornAt;
            float intensity;
            if (age < b.appearMs) {
                intensity = age / (float) b.appearMs; // fade in 1–2s
            } else if (age < b.appearMs + b.holdMs) {
                intensity = 1f;
            } else {
                float f = (age - b.appearMs - b.holdMs) / (float) b.fadeMs;
                intensity = 1f - Math.min(1f, f); // fade out 2–3s
            }
            intensity = Math.max(0f, Math.min(1f, intensity));
            if (intensity <= 0.02f) continue;

            java.util.Random rng = new java.util.Random(b.seed);
            int segments = 7 + rng.nextInt(4);
            float px = b.x0, py = b.y0;
            for (int s = 0; s < segments; s++) {
                float tseg = (s + 1f) / segments;
                float nx = b.x0 + (b.x1 - b.x0) * tseg + (rng.nextFloat() - 0.5f) * 42f;
                float ny = b.y0 + (b.y1 - b.y0) * tseg + (rng.nextFloat() - 0.5f) * 22f;
                float thick = (variant == 0 ? 2.0f : 1.5f) * intensity;
                int ga = (int) (70 * intensity * alpha);
                int ca = (int) (240 * intensity * alpha);
                Color glow = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), ga);
                Color core = new Color(
                        Math.min(255, accent.getRed() + 90),
                        Math.min(255, accent.getGreen() + 90),
                        Math.min(255, accent.getBlue() + 90),
                        ca);
                drawBoltSeg(stack, px, py, nx, ny, thick * 3.5f, glow);
                drawBoltSeg(stack, px, py, nx, ny, thick, core);
                if (rng.nextFloat() < 0.28f) {
                    float bx = nx + (rng.nextFloat() - 0.5f) * 55f;
                    float by = ny + 15f + rng.nextFloat() * 40f;
                    drawBoltSeg(stack, nx, ny, bx, by, thick * 0.65f, core);
                }
                px = nx; py = ny;
            }
        }
    }

    private void drawBoltSeg(MatrixStack stack, float x1, float y1, float x2, float y2, float thick, Color c) {
        float dx = x2 - x1, dy = y2 - y1;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.5f) return;
        float ang = (float) Math.toDegrees(Math.atan2(dy, dx));
        stack.push();
        stack.translate(x1, y1, 0);
        stack.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotationDegrees(ang));
        Matrix4f m = stack.peek().getPositionMatrix();
        new RectangleBuilder()
                .size(new SizeState(len, thick))
                .radius(new QuadRadiusState(thick * 0.5f))
                .color(new QuadColorState(c))
                .build()
                .render(m, 0f, -thick * 0.5f, 0f);
        stack.pop();
    }

    private void openModMenu() {
        try {
            Class<?> api = Class.forName("com.terraformersmc.modmenu.api.ModMenuApi");
            java.lang.reflect.Method m = api.getMethod("createModsScreen", Screen.class);
            Object screen = m.invoke(null, this);
            if (screen instanceof Screen s) {
                startExitAnimation(s);
                return;
            }
        } catch (Throwable ignored) {}
        try {
            Class<?> clazz = Class.forName("com.terraformersmc.modmenu.gui.ModsScreen");
            Object screen = clazz.getConstructor(Screen.class).newInstance(this);
            if (screen instanceof Screen s) {
                startExitAnimation(s);
            }
        } catch (Throwable ignored) {}
    }

    private void openReplayViewer() {
        try {
            Class<?> modClass = Class.forName("com.replaymod.replay.ReplayModReplay");
            Object mod = modClass.getField("instance").get(null);
            Class<?> viewerClass = Class.forName("com.replaymod.replay.gui.screen.GuiReplayViewer");
            Object viewer = viewerClass.getConstructor(modClass).newInstance(mod);
            viewerClass.getMethod("display").invoke(viewer);
        } catch (Throwable t) {
            try {
                Class<?> modClass = Class.forName("com.replaymod.replay.ReplayModReplay");
                Object mod = modClass.getField("instance").get(null);
                Object handler = modClass.getMethod("getGuiHandler").invoke(mod);
                if (handler != null) {
                    handler.getClass().getMethod("openReplayViewer").invoke(handler);
                }
            } catch (Throwable ignored) {}
        }
    }


    private void renderThemeCube(DrawContext drawContext, int mouseX, int mouseY, float alpha) {
        float size = 22f;
        float margin = 14f;
        float cx = this.width - margin - size;
        float cy = this.height - margin - size;

        Color accent;
        try { accent = ThemeManager.getInstance().getThemeColor(); }
        catch (Throwable e) { accent = new Color(120, 140, 255); }

        boolean hov = mouseX >= cx && mouseX <= cx + size && mouseY >= cy && mouseY <= cy + size;
        Matrix4f matrix = drawContext.getMatrices().peek().getPositionMatrix();

        // outer ring
        new RectangleBuilder()
                .size(new SizeState(size + 4, size + 4))
                .radius(new QuadRadiusState(6))
                .color(new QuadColorState(new Color(20, 20, 28, (int) (alpha * (hov ? 220 : 180)))))
                .build()
                .render(matrix, cx - 2, cy - 2, 0f);

        new RectangleBuilder()
                .size(new SizeState(size, size))
                .radius(new QuadRadiusState(5))
                .color(new QuadColorState(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), (int) (alpha * 255))))
                .build()
                .render(matrix, cx, cy, 0f);

        // animate picker
        float target = themePickerOpen ? 1f : 0f;
        themePickerAnim += (target - themePickerAnim) * 0.2f;
        if (themePickerAnim < 0.01f && !themePickerOpen) return;
        if (themePickerAnim > 0.99f) themePickerAnim = 1f;

        ThemeManager.Theme[] themes;
        try { themes = ThemeManager.getInstance().getAvailableThemes(); }
        catch (Throwable e) { return; }
        if (themes == null || themes.length == 0) return;

        int cols = 4;
        float cell = 18f;
        float gap = 5f;
        int rows = (themes.length + cols - 1) / cols;
        float panelW = cols * cell + (cols + 1) * gap;
        float panelH = rows * cell + (rows + 1) * gap + 8f;
        float px = this.width - margin - panelW;
        float py = cy - 8f - panelH;
        if (py < 8f) py = 8f;

        float a = alpha * themePickerAnim;
        new RectangleBuilder()
                .size(new SizeState(panelW, panelH))
                .radius(new QuadRadiusState(10))
                .color(new QuadColorState(new Color(16, 16, 22, (int) (a * 235))))
                .build()
                .render(matrix, px, py, 0f);

        for (int i = 0; i < themes.length; i++) {
            int col = i % cols;
            int row = i / cols;
            float tx = px + gap + col * (cell + gap);
            float ty = py + gap + row * (cell + gap);
            Color tc;
            try { tc = themes[i].getAccentColor(); }
            catch (Throwable e) { tc = Color.GRAY; }
            boolean th = mouseX >= tx && mouseX <= tx + cell && mouseY >= ty && mouseY <= ty + cell;
            new RectangleBuilder()
                    .size(new SizeState(cell, cell))
                    .radius(new QuadRadiusState(4))
                    .color(new QuadColorState(new Color(tc.getRed(), tc.getGreen(), tc.getBlue(), (int) (a * (th ? 255 : 230)))))
                    .build()
                    .render(matrix, tx, ty, 0f);
        }
    }

    private boolean handleThemeCubeClick(double mouseX, double mouseY) {
        float size = 22f;
        float margin = 14f;
        float cx = this.width - margin - size;
        float cy = this.height - margin - size;

        // clicks on palette cells
        if (themePickerOpen && themePickerAnim > 0.5f) {
            ThemeManager.Theme[] themes;
            try { themes = ThemeManager.getInstance().getAvailableThemes(); }
            catch (Throwable e) { themes = null; }
            if (themes != null) {
                int cols = 4;
                float cell = 18f;
                float gap = 5f;
                int rows = (themes.length + cols - 1) / cols;
                float panelW = cols * cell + (cols + 1) * gap;
                float panelH = rows * cell + (rows + 1) * gap + 8f;
                float px = this.width - margin - panelW;
                float py = cy - 8f - panelH;
                if (py < 8f) py = 8f;

                for (int i = 0; i < themes.length; i++) {
                    int col = i % cols;
                    int row = i / cols;
                    float tx = px + gap + col * (cell + gap);
                    float ty = py + gap + row * (cell + gap);
                    if (mouseX >= tx && mouseX <= tx + cell && mouseY >= ty && mouseY <= ty + cell) {
                        try { ThemeManager.getInstance().setTheme(themes[i]); } catch (Throwable ignored) {}
                        return true;
                    }
                }
                // click outside panel closes
                if (!(mouseX >= px && mouseX <= px + panelW && mouseY >= py && mouseY <= py + panelH)) {
                    if (!(mouseX >= cx && mouseX <= cx + size && mouseY >= cy && mouseY <= cy + size)) {
                        themePickerOpen = false;
                        return true;
                    }
                }
            }
        }

        if (mouseX >= cx && mouseX <= cx + size && mouseY >= cy && mouseY <= cy + size) {
            themePickerOpen = !themePickerOpen;
            return true;
        }
        return false;
    }

    public static class AnimatedButton {
        private final float x, y, width, height;
        private final String message;
        private final PressAction action;
        private final Animation hoverAnimation;

        public AnimatedButton(float x, float y, float width, float height, String message, PressAction action) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.message = message;
            this.action = action;
            this.hoverAnimation = new Animation(200, 1.0, false, Easing.OUT_EXPO);
        }

        public void resetAnimations() {
            hoverAnimation.reset();
        }

        public void render(DrawContext drawContext, int mouseX, int mouseY, float delta, float alpha) {
            boolean hovered = isMouseOver(mouseX, mouseY);
            hoverAnimation.update(hovered);

            float hoverProgress = hoverAnimation.getValue();
            Matrix4f matrix = drawContext.getMatrices().peek().getPositionMatrix();

            new RectangleBuilder()
                    .size(new SizeState(width, height))
                    .radius(new QuadRadiusState(8))
                    .color(new QuadColorState(new Color(50, 50, 60, (int) (alpha * 150 + hoverProgress * 100))))
                    .build()
                    .render(matrix, x, y, 0f);

            Color themeAccent;
            try {
                themeAccent = ThemeManager.getInstance().getThemeColor();
            } catch (Throwable e) {
                themeAccent = new Color(120, 140, 255);
            }
            Color base = new Color(
                    Math.min(255, themeAccent.getRed() + 40),
                    Math.min(255, themeAccent.getGreen() + 40),
                    Math.min(255, themeAccent.getBlue() + 40)
            );
            Color hover = themeAccent;
            // Brighten hover toward white slightly
            int r = (int) (base.getRed() + (Math.min(255, hover.getRed() + 60) - base.getRed()) * hoverProgress);
            int g = (int) (base.getGreen() + (Math.min(255, hover.getGreen() + 60) - base.getGreen()) * hoverProgress);
            int b = (int) (base.getBlue() + (Math.min(255, hover.getBlue() + 60) - base.getBlue()) * hoverProgress);

            Color textColor = new Color(
                    Math.max(0, Math.min(255, r)),
                    Math.max(0, Math.min(255, g)),
                    Math.max(0, Math.min(255, b)),
                    (int) (alpha * 255));
            float textX = x + width / 2f - Fonts.REGULAR.getWidth(message, 7f) / 2f;
            float textY = y + height / 2f - Fonts.REGULAR.getHeight(7f) / 2f;

            new TextBuilder()
                    .font(Fonts.REGULAR.font())
                    .text(message)
                    .size(7f)
                    .color(textColor)
                    .smoothness(0.5f)
                    .build()
                    .render(matrix, textX, textY, 0f);
        }

        public boolean isMouseOver(int mouseX, int mouseY) {
            return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
        }

        public void onPress() {
            action.onPress(this);
        }
    }

    @FunctionalInterface
    public interface PressAction {
        void onPress(AnimatedButton button);
    }
    private void openExternal(String url) {
        try {
            net.minecraft.util.Util.getOperatingSystem().open(java.net.URI.create(url));
        } catch (Throwable t) {
            try {
                java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));
            } catch (Throwable ignored) {}
        }
    }

}
