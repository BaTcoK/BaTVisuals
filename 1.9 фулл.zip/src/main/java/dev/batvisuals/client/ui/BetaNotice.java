package dev.batvisuals.client.ui;

import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.renderer.fonts.Fonts;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.awt.Color;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * iOS-style top banner: solid black, fully rounded, bell icon + welcome text.
 */
public final class BetaNotice {

    private static final long DELAY_MS = 2000L;
    private static final long DISPLAY_MS = 5000L;
    private static final long ANIM_MS = 450L;

    private static final Identifier BELL = Identifier.of("batvisuals", "textures/gui/notify_bell.png");

    private static long screenOpenAt = -1L;
    private static boolean soundPlayed = false;
    private static boolean finished = false;
    private static boolean suppressForever = false;
    /** Once per client session — returning from Multiplayer/Options must not re-show. */
    private static boolean shownThisSession = false;

    private BetaNotice() {}

    public static void onMainMenuOpen() {
        if (loadSuppress() || shownThisSession) {
            finished = true;
            return;
        }
        // Only arm once; ignore further MainMenu opens this session
        if (screenOpenAt > 0L) return;
        screenOpenAt = System.currentTimeMillis();
        soundPlayed = false;
        finished = false;
    }

    public static void render(DrawContext context, int screenWidth, int screenHeight) {
        try {
            if (finished || suppressForever) return;
            if (screenOpenAt < 0L) onMainMenuOpen();

            long now = System.currentTimeMillis();
            long elapsed = now - screenOpenAt;
            if (elapsed < DELAY_MS) return;

            long showElapsed = elapsed - DELAY_MS;
            float alpha;
            float yOffset;

            if (showElapsed < ANIM_MS) {
                float t = easeOutCubic(showElapsed / (float) ANIM_MS);
                alpha = t;
                yOffset = -40f + 40f * t;
            } else if (showElapsed < DISPLAY_MS) {
                alpha = 1f;
                yOffset = 0f;
            } else if (showElapsed < DISPLAY_MS + ANIM_MS) {
                float t = easeInCubic((showElapsed - DISPLAY_MS) / (float) ANIM_MS);
                alpha = 1f - t;
                yOffset = -40f * t;
            } else {
                finished = true;
                shownThisSession = true;
                return;
            }

            if (!soundPlayed) {
                soundPlayed = true;
                try {
                    MinecraftClient.getInstance().getSoundManager().play(
                            PositionedSoundInstance.master(
                                    SoundEvent.of(Identifier.of("batvisuals", "notify")),
                                    1.0f, 1.0f
                            )
                    );
                } catch (Throwable ignored) {}
            }

            float bannerW = Math.min(260f, screenWidth * 0.7f);
            float bannerH = 42f;
            float x = (screenWidth - bannerW) / 2f;
            float y = 12f + yOffset;
            float radius = bannerH / 2f; // fully pill-rounded

            var matrices = context.getMatrices();
            int a = MathHelper.clamp((int) (255 * alpha), 0, 255);
            // Solid pure black, no shadow
            Render2D.drawRoundedRect(matrices, x, y, bannerW, bannerH, radius, new Color(0, 0, 0, a));

            // Bell icon left
            float icon = 20f;
            try {
                Render2D.drawTexture(matrices, x + 14f, y + (bannerH - icon) / 2f, icon, icon, 4f,
                        BELL, new Color(255, 255, 255, a));
            } catch (Throwable ignored) {}

            String msg = "Добро пожаловать!";
            float tw = Fonts.REGULAR.getWidth(msg, 8f);
            float tx = x + bannerW / 2f - tw / 2f + 6f;
            float ty = y + bannerH / 2f - Fonts.REGULAR.getHeight(8f) / 2f;
            Render2D.drawFont(matrices, Fonts.REGULAR.getFont(8f), msg, tx, ty, new Color(255, 255, 255, a));
        } catch (Throwable ignored) {
        }
    }

    private static float easeOutCubic(float t) {
        return 1f - (float) Math.pow(1 - t, 3);
    }

    private static float easeInCubic(float t) {
        return t * t * t;
    }

    private static File suppressFile() {
        try {
            File dir = new File(MinecraftClient.getInstance().runDirectory, "batvisuals");
            if (!dir.exists()) dir.mkdirs();
            return new File(dir, "welcome_suppress.txt");
        } catch (Throwable t) {
            return null;
        }
    }

    private static boolean loadSuppress() {
        try {
            File f = suppressFile();
            if (f == null || !f.exists()) return false;
            String s = Files.readString(f.toPath(), StandardCharsets.UTF_8).trim();
            return "1".equals(s) || "true".equalsIgnoreCase(s);
        } catch (Throwable t) {
            return false;
        }
    }

    public static void setSuppressForever(boolean v) {
        suppressForever = v;
        try {
            File f = suppressFile();
            if (f != null) Files.writeString(f.toPath(), v ? "1" : "0", StandardCharsets.UTF_8);
        } catch (Throwable ignored) {}
        if (v) finished = true;
    }
}
