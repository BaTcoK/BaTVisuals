package dev.batvisuals.client.ui.hud;

import dev.batvisuals.client.events.impl.EventMouse;
import dev.batvisuals.client.events.impl.EventRender2D;
import dev.batvisuals.client.util.animations.Animation;
import dev.batvisuals.client.util.animations.Easing;
import dev.batvisuals.client.util.math.MathUtils;
import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.renderer.fonts.Fonts;
import dev.batvisuals.modules.settings.Setting;
import dev.batvisuals.modules.settings.api.Position;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.PositionSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import dev.batvisuals.batvisuals;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.client.ui.hud.windows.Window;
import lombok.Getter;
import lombok.Setter;

import meteordevelopment.orbit.EventHandler;

import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.resource.language.I18n;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static dev.batvisuals.client.util.Wrapper.mc;
import static dev.batvisuals.modules.api.Module.fullNullCheck;


@Getter @Setter
public abstract class HudElement extends Module {

    private final PositionSetting position = new PositionSetting("setting.position", new Position(0, 0));
    private final NumberSetting scale = new NumberSetting("Scale", 1.0f, 0.5f, 2.0f, 0.05f);
    private final Animation hoverAnimation = new Animation(300, 1f, false, Easing.SMOOTH_STEP);
    private final Animation cornerAnimation = new Animation(200, 1f, false, Easing.OUT_QUART);
    protected final Animation toggledAnimation = new Animation(300, 1f, false, Easing.BOTH_SINE);
    private float dragX, dragY, width, height;
    private boolean dragging, button;
    private long pressStartMs;
    private float pressX, pressY;
    private static final long DRAG_HOLD_MS = 300;
    private final List<Setting<?>> settings = new ArrayList<>();
    private Window window;

    public HudElement(String name) {
        super(name, Category.Utility);
        settings.add(position);
        settings.add(scale);
        setToggled(true);
    }

    @EventHandler
    public void onRender2D(EventRender2D e) {
        if (fullNullCheck()) return;

        hoverAnimation.update(MathUtils.isHovered(getX(), getY(), getWidth(), getHeight(), mouseX(), mouseY()) && window == null || button || dragging);
        cornerAnimation.update(hoverAnimation.getValue() > 0);

        if (button) {
            // Блок: если уже тянем другой элемент, не позволяем этому элементу начинать/продолжать перетаскивание
            dev.batvisuals.client.ui.hud.HudElement current = batvisuals.getInstance().getHudManager().getCurrentDragging();
            if (current != null && current != this) {
                dragging = false;
                return;
            }

            // Проверяем, что пользователь находится в чате для перетаскивания
            if (!(mc.currentScreen instanceof ChatScreen)) {
                dragging = false;
                button = false;
                batvisuals.getInstance().getHudManager().setCurrentDragging(null);
                return;
            }

            // Перетаскивание только после удержания 300мс (или сдвиг >6px после 300мс)
            if (!allowsHudDrag() || !isHudVisible()) {
                dragging = false;
                button = false;
            } else if (!dragging && MathUtils.isHovered(getX(), getY(), getWidth(), getHeight(), mouseX(), mouseY())) {
                long held = System.currentTimeMillis() - pressStartMs;
                float dx = mouseX() - pressX;
                float dy = mouseY() - pressY;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                if (held >= DRAG_HOLD_MS || (held >= 80 && dist > 8f)) {
                    dragX = mouseX() - getX();
                    dragY = mouseY() - getY();
                    dragging = true;
                    batvisuals.getInstance().getHudManager().setCurrentDragging(this);
                }
            }

            if (dragging) {
                // Исправление: обновляем позицию только один раз за кадр
                float sw = mc.getWindow().getScaledWidth();
                float sh = mc.getWindow().getScaledHeight();
                float finalX = Math.min(Math.max(mouseX() - dragX, 0), sw - width);
                float finalY = Math.min(Math.max(mouseY() - dragY, 0), sh - height);

                // Snap-to guide lines
                float threshold = 6f; // px threshold to snap
                float edgePad = 4f;   // side guide line padding

                // Snap X to vertical center
                float centerX = sw / 2f - width / 2f; // align element center to screen center
                if (Math.abs((finalX + width / 2f) - sw / 2f) <= threshold) {
                    finalX = centerX;
                } else {
                    // Snap X to nearest side (left or right)
                    float leftX = edgePad;
                    float rightX = sw - edgePad - width;
                    if (Math.abs(finalX - leftX) <= threshold) finalX = leftX;
                    else if (Math.abs(finalX - rightX) <= threshold) finalX = rightX;
                }

                // Snap Y to horizontal center
                float centerY = sh / 2f - height / 2f;
                if (Math.abs((finalY + height / 2f) - sh / 2f) <= threshold) {
                    finalY = centerY;
                } else {
                    // Snap Y to nearest side (top or bottom)
                    float topY = edgePad;
                    float bottomY = sh - edgePad - height;
                    if (Math.abs(finalY - topY) <= threshold) finalY = topY;
                    else if (Math.abs(finalY - bottomY) <= threshold) finalY = bottomY;
                }

                // Обновляем позицию только если она действительно изменилась
                float newX = finalX / sw;
                float newY = finalY / sh;

                if (Math.abs(position.getValue().getX() - newX) > 0.001f ||
                    Math.abs(position.getValue().getY() - newY) > 0.001f) {
                    position.getValue().setX(newX);
                    position.getValue().setY(newY);
                    // Планируем автосохранение после изменения позиции
                    try {
                        dev.batvisuals.client.managers.AutoSaveManager asm = batvisuals.getInstance().getAutoSaveManager();
                        if (asm != null) asm.scheduleAutoSave();
                    } catch (Throwable ignored) {}
                }
            }
        } else {
            dragging = false;
        }

        // Красивая анимация появления углов при наведении с закруглениями
        if (mc.currentScreen instanceof ChatScreen && allowsHudDrag() && isHudVisible() && cornerAnimation.getValue() > 0) {
            float animationValue = cornerAnimation.getValue();
            float animatedCornerSize = 16f * animationValue; // анимированный размер углов
            int alpha = (int) (255 * animationValue); // анимированная прозрачность
            
            // Добавляем отступ от краев элемента
            float padding = 4f; // отступ углов от краев
            float cornerX = getX() - padding;
            float cornerY = getY() - padding;
            float cornerWidth = getWidth() + (padding * 2);
            float cornerHeight = getHeight() + (padding * 2);
            
            // Отладочная информация
            
            // Используем собственный метод рендеринга закругленных углов
            Render2D.drawRoundedCorner(
                    e.getContext().getMatrices(),
                    cornerX, cornerY,
                    cornerWidth, cornerHeight,
                    animatedCornerSize,
                    new Color(255, 255, 255, alpha) // белые углы
            );
        }

        // Hitbox + name only for enabled, movable HUD elements (not Watermark/Hotbar)
        if (mc.currentScreen instanceof ChatScreen && isHudVisible() && allowsHudDrag()
                && getWidth() > 1f && getHeight() > 1f) {
            try {
                float hx = getX(), hy = getY(), hw = getWidth(), hh = getHeight();
                Render2D.drawRoundedRect(e.getContext().getMatrices(), hx - 1f, hy - 1f, hw + 2f, hh + 2f, 3f,
                        new Color(255, 255, 255, dragging ? 50 : 22));
                String label = getDisplayName();
                float tw = Fonts.REGULAR.getWidth(label, 6.5f);
                float ly = Math.max(2f, hy - 13f);
                Render2D.drawRoundedRect(e.getContext().getMatrices(), hx, ly, tw + 8f, 11f, 3f,
                        new Color(10, 12, 18, 210));
                Render2D.drawFont(e.getContext().getMatrices(), Fonts.REGULAR.getFont(6.5f), label, hx + 4f, ly + 2f, Color.WHITE);
            } catch (Throwable ignored) {}
        }

        // Рисуем направляющие (центральные и боковые) только во время перетаскивания
        if (mc.currentScreen instanceof ChatScreen && dragging) {
            float sw = mc.getWindow().getScaledWidth();
            float sh = mc.getWindow().getScaledHeight();
            float edgePad = 4f;

            // Center lines
            Color guide = new Color(255, 255, 255, 110);
            // Vertical center
            Render2D.drawRoundedRect(e.getContext().getMatrices(), sw / 2f - 0.5f, 0, 1f, sh, 0f, guide);
            // Horizontal center
            Render2D.drawRoundedRect(e.getContext().getMatrices(), 0, sh / 2f - 0.5f, sw, 1f, 0f, guide);

            // Nearest side lines (vertical and horizontal)
            // Choose nearest X side to current element
            float leftX = edgePad;
            float rightX = sw - edgePad;
            float elemCenterX = getX() + getWidth() / 2f;
            float sideX = (Math.abs(elemCenterX - leftX) < Math.abs(elemCenterX - rightX)) ? leftX : rightX;
            Render2D.drawRoundedRect(e.getContext().getMatrices(), sideX - 0.5f, 0, 1f, sh, 0f, new Color(255, 255, 255, 80));

            float topY = edgePad;
            float bottomY = sh - edgePad;
            float elemCenterY = getY() + getHeight() / 2f;
            float sideY = (Math.abs(elemCenterY - topY) < Math.abs(elemCenterY - bottomY)) ? topY : bottomY;
            Render2D.drawRoundedRect(e.getContext().getMatrices(), 0, sideY - 0.5f, sw, 1f, 0f, new Color(255, 255, 255, 80));
        }

        if (window != null) {
            if (!(mc.currentScreen instanceof ChatScreen)) window.reset();

            if (window.closed()) {
                window = null;
                return;
            }

            window.render(e.getContext(), mouseX(), mouseY());
        }


        if (mc.currentScreen instanceof ChatScreen) {
            String text = I18n.translate("RMB.setting");
            int textWidth = mc.textRenderer.getWidth(text);
            int x = 10;
            int y = mc.getWindow().getScaledHeight() - 30;
            Render2D.drawFont(e.getContext().getMatrices(), Fonts.REGULAR.getFont(9f), text, x, y, new Color(255, 255, 255));
//            e.getContext().drawTextWithShadow(mc.textRenderer, text, x, y, 0xFFFFFF);
        }
    }

    @EventHandler
    public void onRender2DX2(EventRender2D e) {
        if (fullNullCheck()) return;

        Setting<?> setting = batvisuals.getInstance().getHudManager().getElements().getName(getName());
        if (setting != null && setting instanceof BooleanSetting) {
            toggledAnimation.update(((BooleanSetting) setting).getValue());
        } else {
            // Если элемент не зарегистрирован в списке элементов (например, динамический PerfHUD),
            // используем состояние модуля isToggled() вместо принудительного скрытия
            toggledAnimation.update(isToggled());
        }
    }

    @EventHandler
    public void onMouse(EventMouse e) {
        if (!(mc.currentScreen instanceof ChatScreen) || fullNullCheck()) return;

        if (e.getAction() == 0) {
            button = false;
            dragging = false;
            batvisuals.getInstance().getHudManager().setCurrentDragging(null);
            if (window != null) {
                try { window.mouseReleased(mouseX(), mouseY(), e.getButton()); } catch (Throwable ignored) {}
            }
            try {
                dev.batvisuals.client.managers.AutoSaveManager asm = batvisuals.getInstance().getAutoSaveManager();
                if (asm != null) asm.scheduleAutoSave();
            } catch (Throwable ignored) {}
        } else if (e.getAction() == 1) {
            // Кнопка мыши считается зажатой только если нет другого перетаскиваемого элемента
            if (batvisuals.getInstance().getHudManager().getCurrentDragging() == null ||
                batvisuals.getInstance().getHudManager().getCurrentDragging() == this) {
                button = true;
                pressStartMs = System.currentTimeMillis();
                pressX = mouseX();
                pressY = mouseY();
            }

            if (window != null) {
                if (MathUtils.isHovered(window.getX(), window.getY(), window.getWidth(), window.getFinalHeight(), mouseX(), mouseY())) {
                    window.mouseClicked(mouseX(), mouseY(), e.getButton());
                    return;
                } else window.reset();
            }

            if (e.getButton() == 1 && allowsHudDrag() && isHudVisible()) {
                float hitW = Math.max(getWidth(), 20f);
                float hitH = Math.max(getHeight(), 12f);
                if (MathUtils.isHovered(getX(), getY(), hitW, hitH, mouseX(), mouseY())) {
                    // Always open settings (Scale etc. from parent fields)
                    if (batvisuals.getInstance().getHudManager().getWindow() != null)
                        batvisuals.getInstance().getHudManager().getWindow().reset();
                    for (HudElement element : batvisuals.getInstance().getHudManager().getHudElements()) {
                        if (element.getWindow() == null) continue;
                        element.getWindow().reset();
                    }
                    if (settings.isEmpty()) {
                        // emergency: ensure scale is present
                        try { settings.add(scale); } catch (Throwable ignored) {}
                    }
                    float wx = mc.getWindow().getScaledWidth() / 2f - 55f;
                    float wy = mc.getWindow().getScaledHeight() * 0.18f;
                    window = new Window(wx, wy, 120, 12.5f, settings);
                }
            }
        }
    }

    public float getX() {
        if (mc.getWindow() == null) return 0f;
        return mc.getWindow().getScaledWidth() * position.getValue().getX();
    }

    public float getY() {
        if (mc.getWindow() == null) return 0f;
        return mc.getWindow().getScaledHeight() * position.getValue().getY();
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

    public float getUiScale() {
        try { return scale.getValue(); } catch (Throwable t) { return 1f; }
    }

    public NumberSetting getScaleSetting() { return scale; }

    /** Scale drawing around top-left of element. Pair with popScale. */
    protected void pushScale(net.minecraft.client.util.math.MatrixStack m) {
        float s = getUiScale();
        if (Math.abs(s - 1f) < 0.001f) { m.push(); return; }
        float ox = getX();
        float oy = getY();
        m.push();
        m.translate(ox, oy, 0f);
        m.scale(s, s, 1f);
        m.translate(-ox, -oy, 0f);
    }

    protected void popScale(net.minecraft.client.util.math.MatrixStack m, float unscaledW, float unscaledH) {
        m.pop();
        float s = getUiScale();
        setSize(unscaledW * s, unscaledH * s);
    }


    /** Watermark & Hotbar are fixed — no hitbox / drag. */
    protected boolean allowsHudDrag() {
        String n = getName();
        if (n == null) return true;
        String low = n.toLowerCase();
        return !(low.equals("watermark") || low.equals("hotbar") || low.equals("hotbarhud"));
    }

    /** Only interact with HUD elements that are currently enabled in layout. */
    protected boolean isHudVisible() {
        try {
            if (closed()) return false;
            var hm = batvisuals.getInstance().getHudManager();
            if (hm == null) return isToggled();
            String n = getName();
            if (n == null) return isToggled();
            String nNorm = n.replace("HUD", "").replace("Hud", "");
            for (var s : hm.getElements().getValue()) {
                if (s == null || s.getName() == null) continue;
                String sn = s.getName();
                String sNorm = sn.replace("HUD", "").replace("Hud", "");
                if (sn.equalsIgnoreCase(n) || sNorm.equalsIgnoreCase(nNorm)
                        || (n.equalsIgnoreCase("HotbarHUD") && sn.equalsIgnoreCase("Hotbar"))
                        || (n.equalsIgnoreCase("MusicPlayerHud") && sn.equalsIgnoreCase("MusicPlayer"))) {
                    return Boolean.TRUE.equals(s.getValue());
                }
            }
            return isToggled();
        } catch (Throwable ignored) {
            return isToggled();
        }
    }

    public String getDisplayName() {
        String n = getName();
        if (n == null) return "";
        return switch (n) {
            case "Watermark" -> "Ватермарка";
            case "DynamicIsland" -> "Dynamic Island";
            case "TargetHud" -> "Таргет HUD";
            case "Potions" -> "Зелья";
            case "ArmorHUD" -> "Броня";
            case "Hotbar" -> "Хотбар";
            case "TotemCounter" -> "Тотемы";
            case "Keystrokes" -> "Клавиши";
            case "MusicPlayer" -> "Музыка";
            case "PerfHUD" -> "Производительность";
            default -> n;
        };
    }

    public int mouseX() {
        return (int) (mc.mouse.getX() / mc.getWindow().getScaleFactor());
    }

    public int mouseY() {
        return (int) (mc.mouse.getY() / mc.getWindow().getScaleFactor());
    }

    /** Update hitbox size without moving the element (safe for drag). */
    /** true если ЛКМ отпустили быстро и без перетаскивания */
    public boolean wasShortClick() {
        return !dragging && (System.currentTimeMillis() - pressStartMs) < DRAG_HOLD_MS;
    }

    public boolean isDraggingHud() { return dragging; }

    public void setSize(float width, float height) {
        this.width = width;
        this.height = height;
    }

    public void setBounds(float x, float y, float width, float height) {
        this.width = width;
        this.height = height;
        position.getValue().setX(x / mc.getWindow().getScaledWidth());
        position.getValue().setY(y / mc.getWindow().getScaledHeight());
        // Планируем автосохранение при программном изменении границ/позиции
        try {
            dev.batvisuals.client.managers.AutoSaveManager asm = batvisuals.getInstance().getAutoSaveManager();
            if (asm != null) asm.scheduleAutoSave();
        } catch (Throwable ignored) {}
    }

    protected boolean closed() {
        return toggledAnimation.getValue() <= 0f;
    }

    /**
     * Вызывается при перетаскивании элемента для рисования углов
     */
    protected void onDragging(EventRender2D e) {
        if (dragging) {
            // Добавляем отступ от краев элемента
            float padding = 4f;
            float cornerX = getX() - padding;
            float cornerY = getY() - padding;
            float cornerWidth = getWidth() + (padding * 2);
            float cornerHeight = getHeight() + (padding * 2);
            
            // Используем собственный метод рендеринга закругленных углов
            Render2D.drawRoundedCorner(
                    e.getContext().getMatrices(),
                    cornerX, cornerY,
                    cornerWidth, cornerHeight,
                    16f, // размер углов
                    new Color(255, 255, 255, (int) (255 * hoverAnimation.getValue())), // белые углы
                    2f // толщина линий
            );
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }
}
