package dev.batvisuals.client.ui.games;

import net.minecraft.client.gui.DrawContext;

/**
 * Общий интерфейс мини-игры, рендерящейся внутри "экрана планшета" (GameTabletScreen).
 * Игра рисуется в прямоугольнике [x, y, w, h] переданном хостом — никаких отдельных
 * окон/браузеров, всё через обычный DrawContext.
 */
public interface MiniGame {

    /** Вызывается при старте игры (сброс состояния). */
    void init(float x, float y, float w, float h);

    /** Игровой тик — вызывается каждый кадр с dt в секундах. Игра сама решает, когда обновлять логику. */
    void tick(float dt);

    /** Отрисовка игры внутри области [x, y, w, h] (те же координаты, что переданы в init/resize). */
    void render(DrawContext context, float x, float y, float w, float h, int mouseX, int mouseY);

    /** Клавиатурный ввод (стрелки, WASD, пробел и т.д.). Возвращает true если обработано. */
    default boolean keyPressed(int keyCode, int scanCode, int modifiers) { return false; }

    default boolean keyReleased(int keyCode, int scanCode, int modifiers) { return false; }

    /** Клик мышью внутри области игры (координаты уже в системе планшета). Возвращает true если обработано. */
    default boolean mouseClicked(double mouseX, double mouseY, int button) { return false; }

    /** true если игра закончена (показывается экран Game Over с возможностью рестарта). */
    boolean isGameOver();

    /** Счёт для отображения в шапке планшета. */
    int getScore();

    /** Название игры для заголовка. */
    String getName();
}
