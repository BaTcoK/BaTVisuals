package dev.batvisuals.client.ui.games.impl;

import dev.batvisuals.client.ui.games.MiniGame;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Random;

public class SnakeGame implements MiniGame {

    private static final int COLS = 20;
    private static final int ROWS = 12;

    private final Deque<int[]> body = new ArrayDeque<>();
    private int dirX = 1, dirY = 0;
    private int nextDirX = 1, nextDirY = 0;
    private int foodX, foodY;
    private final Random random = new Random();

    private float stepTimer;
    private float stepInterval = 0.16f;
    private int score;
    private boolean gameOver;

    @Override
    public void init(float x, float y, float w, float h) {
        body.clear();
        int cx = COLS / 2, cy = ROWS / 2;
        body.addFirst(new int[]{cx, cy});
        body.addLast(new int[]{cx - 1, cy});
        body.addLast(new int[]{cx - 2, cy});
        dirX = 1; dirY = 0; nextDirX = 1; nextDirY = 0;
        score = 0;
        gameOver = false;
        stepTimer = 0f;
        stepInterval = 0.16f;
        spawnFood();
    }

    private void spawnFood() {
        do {
            foodX = random.nextInt(COLS);
            foodY = random.nextInt(ROWS);
        } while (occupies(foodX, foodY));
    }

    private boolean occupies(int x, int y) {
        for (int[] seg : body) if (seg[0] == x && seg[1] == y) return true;
        return false;
    }

    @Override
    public void tick(float dt) {
        if (gameOver) return;
        stepTimer += dt;
        if (stepTimer < stepInterval) return;
        stepTimer = 0f;

        dirX = nextDirX;
        dirY = nextDirY;

        int[] head = body.peekFirst();
        int nx = head[0] + dirX;
        int ny = head[1] + dirY;

        if (nx < 0 || nx >= COLS || ny < 0 || ny >= ROWS || occupies(nx, ny)) {
            gameOver = true;
            return;
        }

        body.addFirst(new int[]{nx, ny});
        if (nx == foodX && ny == foodY) {
            score += 10;
            stepInterval = Math.max(0.07f, stepInterval - 0.003f);
            spawnFood();
        } else {
            body.removeLast();
        }
    }

    @Override
    public void render(DrawContext context, float x, float y, float w, float h, int mouseX, int mouseY) {
        float cell = Math.min(w / COLS, h / ROWS);
        float boardW = cell * COLS;
        float boardH = cell * ROWS;
        float ox = x + (w - boardW) / 2f;
        float oy = y + (h - boardH) / 2f;

        context.fill((int) ox, (int) oy, (int) (ox + boardW), (int) (oy + boardH), 0xFF0C0E14);

        // grid
        for (int gx = 0; gx <= COLS; gx++) {
            int lx = (int) (ox + gx * cell);
            context.fill(lx, (int) oy, lx + 1, (int) (oy + boardH), 0x22FFFFFF);
        }
        for (int gy = 0; gy <= ROWS; gy++) {
            int ly = (int) (oy + gy * cell);
            context.fill((int) ox, ly, (int) (ox + boardW), ly + 1, 0x22FFFFFF);
        }

        // food
        drawCell(context, ox, oy, cell, foodX, foodY, 0xFFE05555);

        // snake
        boolean first = true;
        for (int[] seg : body) {
            drawCell(context, ox, oy, cell, seg[0], seg[1], first ? 0xFF6FE07A : 0xFF3FAE55);
            first = false;
        }
    }

    private void drawCell(DrawContext context, float ox, float oy, float cell, int gx, int gy, int color) {
        int pad = 1;
        int x0 = (int) (ox + gx * cell) + pad;
        int y0 = (int) (oy + gy * cell) + pad;
        int x1 = (int) (ox + (gx + 1) * cell) - pad;
        int y1 = (int) (oy + (gy + 1) * cell) - pad;
        context.fill(x0, y0, x1, y1, color);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (gameOver && keyCode == 82) { // R
            init(0, 0, 0, 0);
            return true;
        }
        switch (keyCode) {
            case 265 -> { if (dirY == 0) { nextDirX = 0; nextDirY = -1; } return true; } // UP
            case 264 -> { if (dirY == 0) { nextDirX = 0; nextDirY = 1; } return true; }  // DOWN
            case 263 -> { if (dirX == 0) { nextDirX = -1; nextDirY = 0; } return true; } // LEFT
            case 262 -> { if (dirX == 0) { nextDirX = 1; nextDirY = 0; } return true; }  // RIGHT
            case 87 -> { if (dirY == 0) { nextDirX = 0; nextDirY = -1; } return true; }  // W
            case 83 -> { if (dirY == 0) { nextDirX = 0; nextDirY = 1; } return true; }   // S
            case 65 -> { if (dirX == 0) { nextDirX = -1; nextDirY = 0; } return true; }  // A
            case 68 -> { if (dirX == 0) { nextDirX = 1; nextDirY = 0; } return true; }   // D
            default -> { return false; }
        }
    }

    @Override
    public boolean isGameOver() { return gameOver; }

    @Override
    public int getScore() { return score; }

    @Override
    public String getName() { return "Snake"; }
}
