package dev.batvisuals.client.ui.clickgui.wonderful;

import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.renderer.fonts.Fonts;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.Setting;
import dev.batvisuals.modules.settings.api.Nameable;
import dev.batvisuals.modules.settings.impl.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.util.math.MatrixStack;

import java.awt.Color;
import java.util.List;

public class ClickGuiSettingRenderer {

    public void render(DrawContext context, Module module, float x, float startY, float width,
                       Color accent, double mouseX, double mouseY, ClickGuiState state, float alphaMul) {
        List<Setting<?>> settings = module.getSettings();
        if (settings == null || settings.isEmpty() || alphaMul <= 0.001f) return;

        MatrixStack matrices = context.getMatrices();
        float y = startY;
        List<Setting<?>> visible = settings.stream().filter(Setting::isVisible).toList();

        for (int i = 0; i < visible.size(); i++) {
            Setting<?> setting = visible.get(i);
            if (setting instanceof BooleanSetting booleanSetting) {
                renderBoolean(matrices, x, y, width, alphaMul, accent, booleanSetting, state);
            } else if (setting instanceof NumberSetting numberSetting) {
                renderNumber(matrices, x, y, width, alphaMul, accent, numberSetting, state);
            } else if (setting instanceof EnumSetting<?> enumSetting) {
                renderEnum(matrices, x, y, width, alphaMul, accent, enumSetting, mouseX, mouseY);
            } else if (setting instanceof BindSetting bindSetting) {
                renderBind(matrices, x, y, width, alphaMul, accent, bindSetting, state);
            } else if (setting instanceof StringSetting stringSetting) {
                renderString(matrices, x, y, width, alphaMul, accent, stringSetting, state);
            } else if (setting instanceof ListSetting listSetting) {
                renderList(matrices, x, y, width, alphaMul, accent, listSetting, mouseX, mouseY);
            } else if (setting instanceof ColorSetting colorSetting) {
                renderColor(matrices, x, y, width, alphaMul, accent, colorSetting);
            } else {
                drawText(matrices, tr(setting.getName()), x, y + 1f, 6.5f, withAlpha(Color.WHITE, (int) (180 * alphaMul)));
            }

            y += ClickGuiLayout.getSettingHeight(setting, width);
            if (i < visible.size() - 1) y += ClickGuiLayout.SETTING_GAP;
        }
    }

    private void renderBoolean(MatrixStack matrices, float x, float y, float width, float alphaMul,
                               Color accent, BooleanSetting setting, ClickGuiState state) {
        boolean on = Boolean.TRUE.equals(setting.getValue());
        state.getBooleanBackgroundAnimation(setting).update(on);
        float t = state.getBooleanBackgroundAnimation(setting).getValue();

        Color nameCol = on ? withAlpha(accent, (int) (255 * alphaMul)) : withAlpha(Color.WHITE, (int) (200 * alphaMul));
        drawText(matrices, tr(setting.getName()), x, y + 1f, 6.5f, nameCol);

        float tw = 14f, th = 8f;
        float tx = x + width - tw;
        float ty = y + 2f;
        Color track = lerpColor(new Color(40, 40, 40), accent, t);
        Render2D.drawRoundedRect(matrices, tx, ty, tw, th, 4f, withAlpha(track, (int) (220 * alphaMul)));
        float knobX = tx + 1f + (tw - th) * t;
        Render2D.drawRoundedRect(matrices, knobX, ty + 1f, th - 2f, th - 2f, 3f, withAlpha(Color.WHITE, (int) (255 * alphaMul)));
    }

    private void renderNumber(MatrixStack matrices, float x, float y, float width, float alphaMul,
                              Color accent, NumberSetting setting, ClickGuiState state) {
        float val = setting.getValue();
        String valStr = String.format(Math.abs(setting.getIncrement() - 1f) < 0.001f ? "%.0f" : "%.2f", val);
        drawText(matrices, tr(setting.getName()), x, y, 6.5f, withAlpha(Color.WHITE, (int) (220 * alphaMul)));
        float nameW = textWidth(tr(setting.getName()), 6.5f);
        drawText(matrices, valStr, x + nameW + 3f, y, 6.5f, withAlpha(accent, (int) (255 * alphaMul)));

        float slY = y + 12f;
        float slH = 3f;
        Render2D.drawRoundedRect(matrices, x, slY, width, slH, 1.5f, withAlpha(new Color(30, 30, 30), (int) (255 * alphaMul)));
        float pct = state.getSliderPos(setting);
        if (pct > 0.001f) {
            Render2D.drawRoundedRect(matrices, x, slY, width * pct, slH, 1.5f, withAlpha(accent, (int) (255 * alphaMul)));
        }
        float knobX = x + width * pct - 2f;
        Render2D.drawRoundedRect(matrices, knobX, slY - 1.5f, 4f, 6f, 2f, withAlpha(Color.WHITE, (int) (255 * alphaMul)));
    }

    private void renderEnum(MatrixStack matrices, float x, float y, float width, float alphaMul,
                            Color accent, EnumSetting<?> setting, double mouseX, double mouseY) {
        drawText(matrices, tr(setting.getName()), x, y, 6.5f, withAlpha(Color.WHITE, (int) (200 * alphaMul)));
        float cx = x, cy = y + 9f, rowH = 11f;
        Enum<?>[] vals = setting.getValue().getClass().getEnumConstants();
        if (vals == null) return;
        for (Enum<?> val : vals) {
            String name = ClickGuiLayout.chipLabel(val instanceof Nameable n ? n.getName() : val.name());
            float chipW = textWidth(name, 6f) + ClickGuiLayout.CHIP_PADDING_X * 2f;
            if (cx + chipW > x + width && cx > x) {
                cx = x;
                cy += rowH + ClickGuiLayout.CHIP_GAP_Y;
            }
            boolean selected = val == setting.getValue();
            boolean hovered = ClickGuiLayout.isHovered(mouseX, mouseY, cx, cy, chipW, rowH);
            Color bg = selected ? withAlpha(accent, (int) (200 * alphaMul))
                    : withAlpha(new Color(35, 35, 35), (int) ((hovered ? 220 : 160) * alphaMul));
            Render2D.drawRoundedRect(matrices, cx, cy, chipW, rowH, 3f, bg);
            drawText(matrices, name, cx + ClickGuiLayout.CHIP_PADDING_X, cy + 2f, 6f,
                    withAlpha(Color.WHITE, (int) (255 * alphaMul)));
            cx += chipW + ClickGuiLayout.CHIP_GAP_X;
        }
    }

    private void renderBind(MatrixStack matrices, float x, float y, float width, float alphaMul,
                            Color accent, BindSetting setting, ClickGuiState state) {
        boolean binding = state.getBindingSetting() == setting;
        drawText(matrices, tr(setting.getName()), x, y + 1f, 6.5f, withAlpha(Color.WHITE, (int) (200 * alphaMul)));
        String key = binding ? "..." : (setting.getValue() != null ? setting.getValue().toString() : "None");
        float kw = textWidth(key, 6f);
        drawText(matrices, key, x + width - kw, y + 1.5f, 6f,
                binding ? withAlpha(accent, (int) (255 * alphaMul)) : withAlpha(new Color(180, 180, 180), (int) (220 * alphaMul)));
    }

    private void renderString(MatrixStack matrices, float x, float y, float width, float alphaMul,
                              Color accent, StringSetting setting, ClickGuiState state) {
        drawText(matrices, tr(setting.getName()), x, y, 6.5f, withAlpha(Color.WHITE, (int) (200 * alphaMul)));
        boolean editing = state.getEditingStringSetting() == setting;
        String text = setting.getValue() == null ? "" : setting.getValue();
        if (editing) text = text + (System.currentTimeMillis() / 500 % 2 == 0 ? "|" : "");
        Render2D.drawRoundedRect(matrices, x, y + 10f, width, 10f, 2f,
                withAlpha(editing ? new Color(40, 40, 50) : new Color(28, 28, 28), (int) (220 * alphaMul)));
        drawText(matrices, ClickGuiLayout.truncate(text, 6f, width - 4f), x + 2f, y + 11.5f, 6f,
                withAlpha(editing ? accent : Color.WHITE, (int) (240 * alphaMul)));
    }


    private void renderList(MatrixStack matrices, float x, float y, float width, float alphaMul,
                            Color accent, ListSetting setting, double mouseX, double mouseY) {
        drawText(matrices, tr(setting.getName()), x, y, 6.5f, withAlpha(Color.WHITE, (int) (200 * alphaMul)));
        float cx = x, cy = y + 9f, rowH = 11f;
        if (setting.getValue() == null) return;
        for (BooleanSetting opt : setting.getValue()) {
            String name = ClickGuiLayout.chipLabel(opt.getName());
            float chipW = textWidth(name, 6f) + ClickGuiLayout.CHIP_PADDING_X * 2f;
            if (cx + chipW > x + width && cx > x) {
                cx = x;
                cy += rowH + ClickGuiLayout.CHIP_GAP_Y;
            }
            boolean selected = Boolean.TRUE.equals(opt.getValue());
            boolean hovered = ClickGuiLayout.isHovered(mouseX, mouseY, cx, cy, chipW, rowH);
            Color bg = selected
                    ? withAlpha(accent, (int) (200 * alphaMul))
                    : withAlpha(new Color(35, 35, 35), (int) ((hovered ? 220 : 160) * alphaMul));
            Render2D.drawRoundedRect(matrices, cx, cy, chipW, rowH, 3f, bg);
            drawText(matrices, name, cx + ClickGuiLayout.CHIP_PADDING_X, cy + 2f, 6f,
                    withAlpha(Color.WHITE, (int) (255 * alphaMul)));
            cx += chipW + ClickGuiLayout.CHIP_GAP_X;
        }
    }

    private void renderColor(MatrixStack matrices, float x, float y, float width, float alphaMul,
                             Color accent, ColorSetting setting) {
        drawText(matrices, tr(setting.getName()), x, y + 2f, 6.5f, withAlpha(Color.WHITE, (int) (200 * alphaMul)));
        Color c;
        try {
            c = setting.getColor();
        } catch (Throwable t) {
            Integer rgb = setting.getValue();
            c = rgb != null ? new Color(rgb, true) : Color.WHITE;
        }
        Render2D.drawRoundedRect(matrices, x + width - 14f, y + 1f, 12f, 10f, 2f, withAlpha(c, (int) (255 * alphaMul)));
    }


    private String tr(String key) {
        if (key == null || key.isBlank()) return "";
        try {
            String t = I18n.translate(key);
            if (t != null && !t.isBlank() && !t.equals(key)) return t;
            // keys like setting.swapBind → last segment pretty
            if (key.contains(".")) {
                String last = key.substring(key.lastIndexOf('.') + 1);
                if (!last.isEmpty()) {
                    return last.substring(0, 1).toUpperCase() + last.substring(1);
                }
            }
            return key;
        } catch (Throwable e) {
            return key;
        }
    }

    private void drawText(MatrixStack matrices, String text, float x, float y, float size, Color color) {
        if (Fonts.REGULAR == null || text == null) return;
        try {
            Render2D.drawFont(matrices, Fonts.REGULAR.getFont(size), text, x, y, color);
        } catch (Throwable ignored) {}
    }

    private float textWidth(String text, float size) {
        if (Fonts.REGULAR == null || text == null) return text == null ? 0 : text.length() * size * 0.5f;
        return Fonts.REGULAR.getWidth(text, size);
    }

    private static Color withAlpha(Color c, int a) {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, a)));
    }

    private static Color lerpColor(Color a, Color b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        return new Color(
                (int) (a.getRed() + (b.getRed() - a.getRed()) * t),
                (int) (a.getGreen() + (b.getGreen() - a.getGreen()) * t),
                (int) (a.getBlue() + (b.getBlue() - a.getBlue()) * t),
                (int) (a.getAlpha() + (b.getAlpha() - a.getAlpha()) * t)
        );
    }
}
