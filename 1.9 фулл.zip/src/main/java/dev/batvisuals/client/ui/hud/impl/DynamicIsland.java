package dev.batvisuals.client.ui.hud.impl;

import dev.batvisuals.modules.impl.utility.NameProtect;

import dev.batvisuals.client.events.impl.EventRender2D;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.client.ui.hud.HudElement;
import dev.batvisuals.client.util.animations.Animation;
import dev.batvisuals.client.util.animations.Easing;
import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.renderer.fonts.Fonts;
import net.minecraft.client.gui.hud.ClientBossBar;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.util.math.MathHelper;

import java.awt.Color;
import java.lang.reflect.Field;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Draggable dynamic island: Online / Menu / PvP timer with smooth animations.
 */
public class DynamicIsland extends HudElement implements ThemeManager.ThemeChangeListener {

    private final Animation pvpAnim = new Animation(400, 1f, false, Easing.BOTH_SINE);
    // Smoothly animates panel width toward its target so it never snaps/jitters,
    // while still allowing the pill to grow/shrink around a fixed center.
    private final Animation widthAnim = new Animation(180, 1f, false, Easing.OUT_QUART);
    private float widthAnimFrom = 100f;
    private float widthAnimTo = 100f;
    private float lastRenderedWidth = -1f;
    private float pinnedCenterX = -1f;
    private float lastRelX = Float.NaN;

    private Color accent = new Color(55, 130, 230);
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm");

    /** 0=online, 1=menu, 2=menuClosing(red), 3=pvp, 4=afk, 5=combat, 6=lowFps, 7=lowPing(high ping actually) */
    private int statusMode = 0;
    private long menuClosedAt = 0L;
    private boolean wasChatOpen = false;
    private String pvpTimerText = "";
    private boolean pvpActive = false;

    // Boss bars that DynamicIsland claims (hide vanilla bar)
    public static volatile boolean hidePvpBossBars = false;
    public static volatile boolean hidePvpActionBar = false;
    private static String lastOverlayPvp = "";
    private static long lastOverlayPvpAt = 0L;

    public static void onOverlayMessage(String plain) {
        if (plain == null || plain.isBlank()) return;
        String low = plain.toLowerCase(java.util.Locale.ROOT);
        boolean looks = low.contains("пвп") || low.contains("pvp")
                || low.contains("режим") || low.contains("вы в");
        if (!looks) return;
        lastOverlayPvp = plain;
        lastOverlayPvpAt = System.currentTimeMillis();
    }

    public static boolean isRecentOverlayPvp() {
        return System.currentTimeMillis() - lastOverlayPvpAt < 3000L && lastOverlayPvp != null && !lastOverlayPvp.isEmpty();
    }
    public static volatile String lastPvpTimer = "";

    private static final Pattern TIME_PATTERN = Pattern.compile("(\\d{1,2}:\\d{2}(?::\\d{2})?)");

    // --- AFK detection ---
    private long lastActivityAt = System.currentTimeMillis();
    private float lastYaw, lastPitch;
    private static final long AFK_THRESHOLD_MS = 60_000L; // 1 min no input

    // --- Combat detection ---
    private long lastHurtAt = 0L;
    private float lastHealth = -1f;
    private static final long COMBAT_WINDOW_MS = 5_000L;

    // --- Low FPS tracking ---
    private static final int LOW_FPS_THRESHOLD = 40;

    // Fixed panel width: measured once against the widest possible status text
    private static final float PADDING = 7f;
    private static final float TEXT_X_OFFSET = 18f;
    private static final float RIGHT_MARGIN = 10f;

    public DynamicIsland() {
        super("DynamicIsland");
        try {
            ThemeManager tm = ThemeManager.getInstance();
            accent = tm.getThemeColor();
            tm.addThemeChangeListener(this);
        } catch (Throwable ignored) {}
        // default near top-center once (window may not exist yet during mod init)
        if (mc.getWindow() != null && getX() == 0 && getY() == 0) {
            { float __s = getUiScale(); setBounds(mc.getWindow().getScaledWidth() / 2f - 60, 10, (120) * __s, (18) * __s); };
        }
    }

    @Override
    public void onThemeChanged(ThemeManager.Theme theme) {
        try {
            accent = ThemeManager.getInstance().getThemeColor();
        } catch (Throwable ignored) {}
    }

    @Override
    public void onRender2D(EventRender2D e) {
        if (fullNullCheck() || closed()) return;

        updateStatus();

        MatrixStack matrices = e.getContext().getMatrices();
        pushScale(matrices);
        float height = 20f;
        float fontSize = 7.5f;
        float round = 10f;

        String name = mc.getSession().getUsername();
        try {
            NameProtect np = NameProtect.getInstance();
            if (np != null && np.isToggled()) name = np.getProtectedName(name);
        } catch (Throwable ignored) {}
        String clock = LocalTime.now().format(TIME_FMT);

        String statusText;
        Color statusColor;
        float pvpA = pvpAnim.getValue();

        switch (statusMode) {
            case 3 -> { // PvP
                statusText = "PvP  " + (pvpTimerText.isEmpty() ? lastPvpTimer : pvpTimerText);
                statusColor = new Color(255, 90, 90);
            }
            case 1 -> { // Menu open
                statusText = "Menu";
                statusColor = accent;
            }
            case 2 -> { // Menu just closed
                statusText = "Menu";
                statusColor = new Color(255, 70, 70);
            }
            case 4 -> { // AFK
                statusText = "AFK";
                statusColor = new Color(160, 160, 170);
            }
            case 5 -> { // Combat (recently took damage)
                statusText = "Combat";
                statusColor = new Color(255, 130, 60);
            }
            case 6 -> { // Low FPS
                statusText = "Low FPS  " + getFps();
                statusColor = new Color(230, 190, 70);
            }
            default -> {
                int ping = getPing();
                if (ping > 0 && ping < 150) {
                    statusText = "Online";
                    statusColor = new Color(100, 220, 140);
                } else if (ping <= 0) {
                    statusText = "Local";
                    statusColor = new Color(100, 220, 140);
                } else {
                    statusText = "High ping  " + ping;
                    statusColor = new Color(220, 180, 80);
                }
            }
        }

        String fullText = name + "  ·  " + clock + "  ·  " + statusText;

        // Natural width for the current text - no artificial max-width padding,
        // so there's no empty space on either side.
        float naturalWidth = Fonts.BOLD.getWidth(fullText, fontSize) + PADDING * 2f + TEXT_X_OFFSET - 8f + RIGHT_MARGIN;
        naturalWidth = Math.max(70f, naturalWidth);

        // Animate width smoothly toward the target instead of snapping,
        // so text changes (Online -> PvP 12:34, etc.) resize the pill fluidly.
        if (Math.abs(naturalWidth - widthAnimTo) > 0.5f) {
            widthAnimFrom = lastRenderedWidth >= 0f ? lastRenderedWidth : naturalWidth;
            widthAnimTo = naturalWidth;
            widthAnim.reset();
        }
        widthAnim.update(true);
        float t = widthAnim.getValue();
        float width = MathHelper.lerp(t, widthAnimFrom, widthAnimTo);
        lastRenderedWidth = width;

        String text = fullText; // width already fits the full text, no clipping needed

        // Pin the pill's center in place: growing/shrinking expands equally
        // left and right instead of only ever growing to the right of a
        // fixed left edge (which left a visible empty gap on one side).
        float storedX = getX();
        float relX = getPosition().getValue().getX();
        // Re-pin when config loads / resolution changes / drag (fixes "jumps after click")
        if (pinnedCenterX < 0f || isDragging() || Float.isNaN(lastRelX) || Math.abs(relX - lastRelX) > 0.0001f) {
            pinnedCenterX = storedX + Math.max(getWidth(), width) / 2f;
            lastRelX = relX;
        }
        float x = pinnedCenterX - width / 2f;
        float y = getY();

        Color bg = new Color(10, 10, 14, 215);
        Render2D.drawRoundedRect(matrices, x, y, width, height, round, bg);

        // left status dot
        Color dot = statusMode == 3
                ? new Color(255, 80, 80, (int) (180 + 75 * Math.abs(Math.sin(System.currentTimeMillis() / 250.0))))
                : statusColor;
        Render2D.drawRoundedRect(matrices, x + 7, y + height / 2f - 3f, 6f, 6f, 3f, dot);

        float textY = y + (height - Fonts.BOLD.getHeight(fontSize)) / 2f;
        Render2D.drawFont(matrices, Fonts.BOLD.getFont(fontSize), text, x + TEXT_X_OFFSET, textY, Color.WHITE);

        // subtle accent underline when pvp or combat
        if ((statusMode == 3 || statusMode == 5) && pvpA > 0.05f) {
            int a = (int) (180 * pvpA);
            Color underline = statusMode == 5 ? new Color(255, 140, 60, a) : new Color(255, 80, 80, a);
            Render2D.drawRoundedRect(matrices, x + 12, y + height - 3, width - 24, 1.5f, 1f, underline);
        }

        // ONLY size — keeps drag position
        popScale(matrices, width, height);;

        // Включаем drag/click-логику из HudElement (перетаскивание, углы, окно настроек)
        super.onRender2D(e);
    }

    private void updateStatus() {
        boolean chatOpen = mc.currentScreen instanceof ChatScreen;

        trackActivity();
        trackCombat();

        // PvP from boss bars
        scanPvpBossBars();

        if (pvpActive) {
            statusMode = 3;
            pvpAnim.update(true);
            hidePvpBossBars = true;
            hidePvpActionBar = true;
            wasChatOpen = chatOpen;
            return;
        } else {
            hidePvpBossBars = false;
        }

        boolean inCombat = System.currentTimeMillis() - lastHurtAt <= COMBAT_WINDOW_MS;
        if (inCombat) {
            statusMode = 5;
            pvpAnim.update(true);
            wasChatOpen = chatOpen;
            return;
        } else {
            pvpAnim.update(false);
        }

        if (chatOpen) {
            statusMode = 1;
            wasChatOpen = true;
            menuClosedAt = 0L;
            return;
        }

        if (wasChatOpen && !chatOpen) {
            wasChatOpen = false;
            menuClosedAt = System.currentTimeMillis();
            statusMode = 2; // red Menu
            return;
        }

        if (statusMode == 2) {
            if (System.currentTimeMillis() - menuClosedAt >= 2000L) {
                statusMode = 0;
            }
            return;
        }

        if (getFps() > 0 && getFps() < LOW_FPS_THRESHOLD) {
            statusMode = 6;
            return;
        }

        if (System.currentTimeMillis() - lastActivityAt >= AFK_THRESHOLD_MS) {
            statusMode = 4;
            return;
        }

        statusMode = 0;
    }

    /** Marks activity based on look direction or position changes; resets the AFK timer. */
    private void trackActivity() {
        if (mc.player == null) return;
        float yaw = mc.player.getYaw();
        float pitch = mc.player.getPitch();
        boolean looked = Math.abs(yaw - lastYaw) > 0.05f || Math.abs(pitch - lastPitch) > 0.05f;
        boolean moved = mc.player.getVelocity().lengthSquared() > 1.0E-5;
        if (looked || moved) {
            lastActivityAt = System.currentTimeMillis();
        }
        lastYaw = yaw;
        lastPitch = pitch;
    }

    /** Marks combat state when the player's health drops between ticks. */
    private void trackCombat() {
        if (mc.player == null) return;
        float health = mc.player.getHealth();
        if (lastHealth >= 0f && health < lastHealth) {
            lastHurtAt = System.currentTimeMillis();
        }
        lastHealth = health;
    }

    private int getFps() {
        try {
            return mc.getCurrentFps();
        } catch (Throwable t) {
            return -1;
        }
    }

    @SuppressWarnings("unchecked")
    private void scanPvpBossBars() {
        pvpActive = false;
        pvpTimerText = "";
        try {
            if (mc.inGameHud == null) return;
            Object hud = mc.inGameHud.getBossBarHud();
            if (hud == null) return;

            Map<UUID, ClientBossBar> bars = null;
            for (Field f : hud.getClass().getDeclaredFields()) {
                if (Map.class.isAssignableFrom(f.getType())) {
                    f.setAccessible(true);
                    Object val = f.get(hud);
                    if (val instanceof Map<?, ?> m && !m.isEmpty()) {
                        Object sample = m.values().iterator().next();
                        if (sample instanceof ClientBossBar || sample instanceof BossBar) {
                            bars = (Map<UUID, ClientBossBar>) val;
                            break;
                        }
                    }
                }
            }
            if (bars == null || bars.isEmpty()) return;

            for (ClientBossBar bar : bars.values()) {
                String title = bar.getName() != null ? bar.getName().getString() : "";
                if (title == null || title.isBlank()) continue;
                String low = title.toLowerCase(Locale.ROOT);
                boolean looksPvp = low.contains("пвп") || low.contains("pvp")
                        || low.contains("режим") || low.contains("вы в")
                        || low.contains("pvp-") || low.contains("pvp ");
                if (!looksPvp) continue;

                Matcher m = TIME_PATTERN.matcher(title);
                if (m.find()) {
                    pvpTimerText = m.group(1);
                    lastPvpTimer = pvpTimerText;
                } else {
                    // progress as mm:ss estimate if no explicit time
                    float prog = bar.getPercent();
                    if (prog > 0 && prog <= 1f) {
                        int sec = Math.round(prog * 300); // assume 5min max if unknown
                        pvpTimerText = String.format("%d:%02d", sec / 60, sec % 60);
                        lastPvpTimer = pvpTimerText;
                    }
                }
                pvpActive = true;
                break;
            }
        } catch (Throwable ignored) {}
    }

    private int getPing() {
        try {
            if (mc.getNetworkHandler() == null || mc.player == null) return 0;
            PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            return entry != null ? entry.getLatency() : 0;
        } catch (Throwable t) {
            return 0;
        }
    }
}
