package dev.batvisuals.client.ui;

import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.renderer.fonts.Fonts;
import dev.batvisuals.modules.impl.render.ViewModel;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.awt.Color;

/** ЛКМ — X/Y, ПКМ вверх/вниз — Z. Фиксированная чувствительность. */
public class ViewModelEditorScreen extends Screen {
    private final ViewModel module;
    private boolean rightHand = true;
    private boolean dragMove, dragZ;
    private final float[] snap = new float[6];
    private static final float SENS = 0.0035f;

    public ViewModelEditorScreen(ViewModel module) {
        super(Text.literal("ViewModel Editor"));
        this.module = module;
        snap[0] = v(module.mainX); snap[1] = v(module.mainY); snap[2] = v(module.mainZ);
        snap[3] = v(module.offX); snap[4] = v(module.offY); snap[5] = v(module.offZ);
    }

    private float v(dev.batvisuals.modules.settings.impl.NumberSetting s) {
        return s.getValue() != null ? s.getValue() : 0f;
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {}

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        var m = ctx.getMatrices();
        Render2D.drawRoundedRect(m, 8, 8, width - 16, 28, 6f, new Color(12, 12, 18, 200));
        drawBtn(m, 16, 12, 90, 20, "Сохранить", mouseX, mouseY);
        drawBtn(m, 112, 12, 70, 20, "Назад", mouseX, mouseY);

        float mid = width / 2f, sw = 160, sh = 20, sx = mid - sw / 2f, sy = 12;
        Render2D.drawRoundedRect(m, sx, sy, sw, sh, 5f, new Color(28, 28, 36, 220));
        Render2D.drawRoundedRect(m, mid - 1, sy + 3, 2, sh - 6, 1f, new Color(80, 80, 90));
        if (!rightHand) Render2D.drawRoundedRect(m, sx + 2, sy + 2, sw / 2 - 4, sh - 4, 4f, new Color(70, 140, 220, 180));
        if (rightHand) Render2D.drawRoundedRect(m, mid + 2, sy + 2, sw / 2 - 4, sh - 4, 4f, new Color(70, 140, 220, 180));
        try {
            Render2D.drawFont(m, Fonts.REGULAR.getFont(6.5f), "Левая", sx + 22, sy + 6, Color.WHITE);
            Render2D.drawFont(m, Fonts.REGULAR.getFont(6.5f), "Правая", mid + 18, sy + 6, Color.WHITE);
            Render2D.drawFont(m, Fonts.REGULAR.getFont(6f),
                    "ЛКМ — двигать (X/Y) · ПКМ вверх/вниз — глубина (Z)",
                    16, height - 18, new Color(160, 160, 170));
        } catch (Throwable ignored) {}
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawBtn(net.minecraft.client.util.math.MatrixStack m, float x, float y, float w, float h,
                         String label, int mx, int my) {
        boolean hov = mx >= x && mx <= x + w && my >= y && my <= y + h;
        Render2D.drawRoundedRect(m, x, y, w, h, 5f, hov ? new Color(70, 140, 220) : new Color(36, 36, 44));
        try {
            Render2D.drawFont(m, Fonts.REGULAR.getFont(6.5f), label, x + 10, y + 5.5f, Color.WHITE);
        } catch (Throwable ignored) {}
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            if (hit(mouseX, mouseY, 16, 12, 90, 20)) { if (client != null) client.setScreen(null); return true; }
            if (hit(mouseX, mouseY, 112, 12, 70, 20)) {
                module.mainX.setValue(snap[0]); module.mainY.setValue(snap[1]); module.mainZ.setValue(snap[2]);
                module.offX.setValue(snap[3]); module.offY.setValue(snap[4]); module.offZ.setValue(snap[5]);
                if (client != null) client.setScreen(null);
                return true;
            }
            float mid = width / 2f, sw = 160, sx = mid - sw / 2f, sy = 12;
            if (hit(mouseX, mouseY, sx, sy, sw / 2, 20)) { rightHand = false; return true; }
            if (hit(mouseX, mouseY, mid, sy, sw / 2, 20)) { rightHand = true; return true; }
            dragMove = true;
            return true;
        }
        if (button == 1) { dragZ = true; return true; }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) dragMove = false;
        if (button == 1) dragZ = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (dragMove && button == 0) {
            if (rightHand) {
                module.mainX.setValue(cl(v(module.mainX) + (float) dx * SENS));
                module.mainY.setValue(cl(v(module.mainY) - (float) dy * SENS));
            } else {
                module.offX.setValue(cl(v(module.offX) + (float) dx * SENS));
                module.offY.setValue(cl(v(module.offY) - (float) dy * SENS));
            }
            return true;
        }
        if (dragZ && button == 1) {
            // up mouse = closer / +Z or -Z depending on feel
            float d = (float) (-dy * SENS);
            if (rightHand) module.mainZ.setValue(cl(v(module.mainZ) + d));
            else module.offZ.setValue(cl(v(module.offZ) + d));
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    private float cl(float v) { return Math.max(-2f, Math.min(2f, v)); }
    private boolean hit(double mx, double my, float x, float y, float w, float h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    @Override
    public boolean shouldPause() { return false; }
}
