package dev.batvisuals.client.ui.hud.windows.components.impl;

import dev.batvisuals.client.ui.hud.windows.components.WindowComponent;
import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.renderer.fonts.Fonts;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import net.minecraft.client.gui.DrawContext;

import java.awt.Color;

public class NumberComponent extends WindowComponent {
    private final NumberSetting setting;
    private boolean dragging;

    public NumberComponent(String name, NumberSetting setting) {
        super(name);
        this.setting = setting;
        setHeight(26f);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        float a = getAnimation() != null ? getAnimation().getValue() : 1f;
        int alpha = (int) (255 * a);

        Render2D.drawFont(context.getMatrices(), Fonts.REGULAR.getFont(6.5f), getName(),
                getX() + 4f, getY() + 3f, new Color(220, 220, 230, alpha));

        float trackX = getX() + 4f;
        float trackY = getY() + 15f;
        float trackW = getWidth() - 8f;
        float trackH = 6f;

        // wide invisible hit area drawn as track
        Render2D.drawRoundedRect(context.getMatrices(), trackX, trackY, trackW, trackH, 3f,
                new Color(40, 40, 48, alpha));

        float min = setting.getMin();
        float max = setting.getMax();
        float val = setting.getValue();
        float t = (max > min) ? (val - min) / (max - min) : 0f;
        t = Math.max(0f, Math.min(1f, t));
        float fillW = Math.max(0f, trackW * t);
        Render2D.drawRoundedRect(context.getMatrices(), trackX, trackY, fillW, trackH, 3f,
                new Color(90, 140, 255, alpha));
        float kx = trackX + fillW - 4f;
        Render2D.drawRoundedRect(context.getMatrices(), kx, trackY - 3f, 8f, trackH + 6f, 4f,
                new Color(255, 255, 255, alpha));

        String vs = String.format("%.2f", val);
        float vw = Fonts.REGULAR.getWidth(vs, 5.5f);
        Render2D.drawFont(context.getMatrices(), Fonts.REGULAR.getFont(5.5f), vs,
                getX() + getWidth() - 4f - vw, getY() + 3f, new Color(180, 180, 190, alpha));

        if (dragging) {
            applyMouse(mouseX, trackX, trackW, min, max);
        }
    }

    private void applyMouse(double mouseX, float trackX, float trackW, float min, float max) {
        float ratio = ((float) mouseX - trackX) / trackW;
        ratio = Math.max(0f, Math.min(1f, ratio));
        float raw = min + ratio * (max - min);
        float inc = setting.getIncrement();
        if (inc > 0) raw = Math.round(raw / inc) * inc;
        setting.setValue(Math.max(min, Math.min(max, raw)));
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return;
        // full row is clickable (fixes "only works above slider")
        if (mouseX >= getX() && mouseX <= getX() + getWidth()
                && mouseY >= getY() && mouseY <= getY() + getHeight()) {
            dragging = true;
            float trackX = getX() + 4f;
            float trackW = getWidth() - 8f;
            applyMouse(mouseX, trackX, trackW, setting.getMin(), setting.getMax());
        }
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) dragging = false;
    }

    @Override public void keyPressed(int keyCode, int scanCode, int modifiers) {}
    @Override public void keyReleased(int keyCode, int scanCode, int modifiers) {}
    @Override public void charTyped(char chr, int modifiers) {}
}
