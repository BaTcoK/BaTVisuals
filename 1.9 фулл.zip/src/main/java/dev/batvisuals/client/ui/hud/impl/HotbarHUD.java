package dev.batvisuals.client.ui.hud.impl;

import dev.batvisuals.client.events.impl.EventRender2D;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.client.ui.hud.HudElement;
import dev.batvisuals.client.util.animations.Easing;
import dev.batvisuals.client.util.animations.infinity.InfinityAnimation;
import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.renderer.fonts.Fonts;

import java.awt.Color;

/**
 * Hotbar: fixed bottom-center, semi-transparent black slots,
 * theme-colored select sticks + bottom accent line.
 * Vanilla hearts/hunger left untouched.
 */
public class HotbarHUD extends HudElement {

    private final ThemeManager themeManager;

    private static final float SLOT = 22f;
    private static final float GAP = 2f;       // gap between slots
    private static final float PAD = 3f;       // outer pad of whole bar
    private static final float RADIUS = 3f;
    /** ~30% opaque black so world shows through */
    private static final Color SLOT_BG = new Color(0, 0, 0, 77);
    private static final Color SLOT_BG_EDGE = new Color(0, 0, 0, 40);

    private final InfinityAnimation selAnimX = new InfinityAnimation(Easing.OUT_QUAD);
    private float lastSelX = -1f;

    public HotbarHUD() {
        super("Hotbar");
        getSettings().removeIf(s -> "Scale".equalsIgnoreCase(s.getName()));
        this.themeManager = ThemeManager.getInstance();
    }

    @Override
    public void onRender2D(EventRender2D e) {
        if (fullNullCheck() || closed()) return;
        if (mc.player != null && mc.player.isSpectator()) return;

        var context = e.getContext();
        var matrices = context.getMatrices();

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        // 9 slots + gaps + outer pad
        float innerW = 9f * SLOT + 8f * GAP;
        float barW = innerW + PAD * 2f;
        float barH = SLOT + PAD * 2f;

        // Fixed bottom-center, no extra margin
        float baseX = (sw - barW) / 2f;
        float baseY = sh - barH;

        Color accent;
        try {
            accent = themeManager.getCurrentTheme().getAccentColor();
        } catch (Throwable t) {
            accent = new Color(80, 170, 255);
        }
        Color accentFull = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 255);
        Color accentSoft = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 200);

        setBounds(baseX, baseY, barW, barH);

        // Soft overall plate (very light, still see-through)
        Render2D.drawRoundedRect(matrices, baseX, baseY, barW, barH, RADIUS + 1f,
                new Color(0, 0, 0, 50));

        // Selected slot index
        int selected = 0;
        try {
            selected = mc.player.getInventory().selectedSlot;
        } catch (Throwable ignored) {}
        if (selected < 0) selected = 0;
        if (selected > 8) selected = 8;

        float slotsX = baseX + PAD;
        float slotsY = baseY + PAD;
        float targetSelX = slotsX + selected * (SLOT + GAP);
        if (lastSelX < 0f) lastSelX = targetSelX;
        float selX = selAnimX.animate(targetSelX, 90);
        lastSelX = selX;

        // Slot backgrounds
        for (int i = 0; i < 9; i++) {
            float sx = slotsX + i * (SLOT + GAP);
            float sy = slotsY;
            Render2D.drawRoundedRect(matrices, sx, sy, SLOT, SLOT, RADIUS, SLOT_BG);
            // subtle inner edge
            Render2D.drawRoundedRect(matrices, sx + 0.5f, sy + 0.5f, SLOT - 1f, 1f, 0.5f, SLOT_BG_EDGE);
        }

        // Theme sticks around selected slot (left + right)
        float stickW = 2.2f;
        float stickH = SLOT - 4f;
        float stickY = slotsY + 2f;
        Render2D.drawRoundedRect(matrices, selX + 1.5f, stickY, stickW, stickH, 1.2f, accentFull);
        Render2D.drawRoundedRect(matrices, selX + SLOT - stickW - 1.5f, stickY, stickW, stickH, 1.2f, accentFull);
        // thin top accent on selected
        Render2D.drawRoundedRect(matrices, selX + 3f, slotsY + 1.5f, SLOT - 6f, 1.4f, 0.8f, accentSoft);

        // Bottom theme line — left to right under the bar
        float lineH = 1.8f;
        float lineY = baseY + barH - lineH;
        Render2D.drawRoundedRect(matrices, baseX + 4f, lineY, barW - 8f, lineH, 1f, accentFull);
        // soft glow under line
        Render2D.drawRoundedRect(matrices, baseX + 8f, lineY + lineH - 0.5f, barW - 16f, 1.2f, 0.8f,
                new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 70));

        // Offhand
        if (mc.player != null) {
            var inv = mc.player.getInventory();
            var offhandStack = inv.getStack(40);
            if (!offhandStack.isEmpty()) {
                float ox = baseX - SLOT - GAP - 2f;
                float oy = slotsY;
                Render2D.drawRoundedRect(matrices, ox, oy, SLOT, SLOT, RADIUS, SLOT_BG);
                context.drawItem(offhandStack, (int) (ox + (SLOT - 16) / 2f), (int) (oy + (SLOT - 16) / 2f));
                if (offhandStack.getCount() > 1) {
                    String cnt = String.valueOf(offhandStack.getCount());
                    float cntSize = 7f;
                    float cntW = Fonts.REGULAR.getWidth(cnt, cntSize);
                    Render2D.drawFont(matrices, Fonts.REGULAR.getFont(cntSize), cnt,
                            ox + SLOT - 3f - cntW, oy + SLOT - 10f, Color.WHITE);
                }
            }

            // Items 0..8
            for (int i = 0; i <= 8; i++) {
                float ix = slotsX + i * (SLOT + GAP) + (SLOT - 16) / 2f;
                float iy = slotsY + (SLOT - 16) / 2f;
                var stack = inv.getStack(i);
                context.drawItem(stack, (int) ix, (int) iy);
                if (!stack.isEmpty() && stack.getCount() > 1) {
                    String cnt = String.valueOf(stack.getCount());
                    float cntSize = 7f;
                    float cntW = Fonts.REGULAR.getWidth(cnt, cntSize);
                    float slotLeft = slotsX + i * (SLOT + GAP);
                    Render2D.drawFont(matrices, Fonts.REGULAR.getFont(cntSize), cnt,
                            slotLeft + SLOT - 3f - cntW, slotsY + SLOT - 10f, Color.WHITE);
                }
            }
        }

        // Don't call super drag logic for fixed bar — still allow settings menu if needed
        // super.onRender2D(e);
    }
}
