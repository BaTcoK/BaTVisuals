package dev.batvisuals.client.ui.clickgui.wonderful;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.managers.FriendsManager;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.client.managers.WaypointManager;
import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.renderer.fonts.Fonts;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.impl.render.TargetEsp;
import dev.batvisuals.modules.settings.api.Bind;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

import java.awt.Color;
import java.util.List;

public class ClickGuiRenderer {

    private static final Identifier SIDEBAR_LOGO = Identifier.of("batvisuals", "hud/mod_logo.png");
    private static final Identifier TG_ICON = Identifier.of("batvisuals", "textures/gui/telegram_icon.png");
    private static final Identifier CAT_VISUALS = Identifier.of("batvisuals", "hud/cat_visuals.png");
    private static final Identifier CAT_UTILITY = Identifier.of("batvisuals", "hud/cat_utility.png");
    private static final Identifier CAT_THEME = Identifier.of("batvisuals", "hud/cat_theme.png");
    private static final Identifier CAT_GPS = Identifier.of("batvisuals", "hud/cat_gps.png");
    private static final Identifier CAT_FRIENDS = Identifier.of("batvisuals", "hud/cat_friends.png");
    private static final Identifier CAT_MUSIC = Identifier.of("batvisuals", "hud/cat_music.png");
    private static final Identifier CAT_CONFIG = Identifier.of("batvisuals", "hud/cat_config.png");
    private static final Identifier CAT_GAMES = Identifier.of("batvisuals", "hud/cat_games.png");
    private static final Identifier MUSIC_PREV = Identifier.of("batvisuals", "hud/music_prev.png");
    private static final Identifier MUSIC_NEXT = Identifier.of("batvisuals", "hud/music_next.png");
    private static final Identifier MUSIC_PLAY = Identifier.of("batvisuals", "hud/music_play.png");
    private static final Identifier MUSIC_PAUSE = Identifier.of("batvisuals", "hud/music_pause.png");
    private static final Identifier MUSIC_STOP = Identifier.of("batvisuals", "hud/music_stop.png");
    private static final float LINK_BTN_SIZE = 22f;
    private static final float LINK_BTN_GAP = 6f;
    private static final String URL_SITE = "https://BaTVisuals.edgeone.dev";
    private static final String URL_TG = "https://t.me/BaTVisuals";

    private final ClickGuiState state;
    private final ClickGuiSettingRenderer settingRenderer;

    public ClickGuiRenderer(ClickGuiState state, ClickGuiSettingRenderer settingRenderer) {
        this.state = state;
        this.settingRenderer = settingRenderer;
    }

    public void render(DrawContext context, int mouseX, int mouseY, Window window, float progress) {
        if (window == null) return;
        state.updateFocusMode();
        float focus = state.getFocusValue(); // 0 normal → 1 focus
        float alpha = progress * (1f - focus);
        Color accent = getAccent();
        float guiY = state.getY() + state.getRenderOffsetY();
        float guiX = state.getX();

        if (alpha > 0.02f) {
            renderSidebar(context, mouseX, mouseY, ClickGuiLayout.getSidebarX(guiX), guiY, accent, alpha);
            renderMain(context, mouseX, mouseY, ClickGuiLayout.getMainX(guiX), guiY, accent, alpha);
            renderSettingsPanel(context, mouseX, mouseY, ClickGuiLayout.getSettingsX(guiX), guiY, accent, alpha);
        }

        // TargetESP left preview: always when module selected (also while dragging sliders)
        Module sel = state.getSelectedModule();
        if (sel instanceof TargetEsp tesp && progress > 0.02f) {
            float previewA = Math.max(alpha, focus * progress);
            if (previewA > 0.02f) {
                renderTargetEspPreview(context, mouseX, mouseY, guiX, guiY, accent, previewA);
            }
        }

        if (focus > 0.02f && state.getDraggingSlider() != null) {
            renderFocusSlider(context, mouseX, mouseY, window, state.getDraggingSlider(), accent, focus * progress);
        }
    }

    private void renderTargetEspPreview(DrawContext context, int mouseX, int mouseY,
                                        float guiX, float guiY, Color accent, float panelA) {
        Module mod = state.getSelectedModule();
        if (!(mod instanceof TargetEsp tesp)) return;
        float gap = ClickGuiLayout.PANEL_GAP;
        float px = guiX - gap - TargetEspPreviewPanel.WIDTH;
        float py = guiY;
        TargetEspPreviewPanel.render(context, px, py, ClickGuiLayout.HEIGHT, mouseX, mouseY, accent, panelA, tesp);
    }

    /**
     * Minimal floating control while dragging a slider: name + value + track only.
     */
    private void renderFocusSlider(DrawContext context, int mouseX, int mouseY, Window window,
                                   NumberSetting setting, Color accent, float alpha) {
        MatrixStack matrices = context.getMatrices();
        float sw = window.getScaledWidth();
        float sh = window.getScaledHeight();

        float panelW = Math.min(280f, sw * 0.55f);
        float panelH = 48f;
        float x = (sw - panelW) / 2f;
        float y = sh * 0.72f;

        // soft shadow + glass panel
        Render2D.drawRoundedRect(matrices, x + 2, y + 3, panelW, panelH, 10f,
                withAlpha(new Color(0, 0, 0), (int) (90 * alpha)));
        Render2D.drawRoundedRect(matrices, x, y, panelW, panelH, 10f,
                withAlpha(new Color(14, 14, 18), (int) (200 * alpha)));
        // accent top line
        Render2D.drawRoundedRect(matrices, x + 12, y + 1, panelW - 24, 1.5f, 1f,
                withAlpha(accent, (int) (220 * alpha)));

        String name = tr(setting.getName());
        float val = setting.getValue();
        String valStr = String.format(Math.abs(setting.getIncrement() - 1f) < 0.001f ? "%.0f" : "%.2f", val);

        drawText(matrices, name, x + 14f, y + 10f, 7.5f, withAlpha(Color.WHITE, (int) (255 * alpha)));
        float nameW = textWidth(name, 7.5f);
        drawText(matrices, valStr, x + 14f + nameW + 6f, y + 10f, 7.5f, withAlpha(accent, (int) (255 * alpha)));

        float trackX = x + 14f;
        float trackW = panelW - 28f;
        float trackY = y + 32f;
        float trackH = 5f;
        Render2D.drawRoundedRect(matrices, trackX, trackY, trackW, trackH, 2.5f,
                withAlpha(new Color(35, 35, 42), (int) (255 * alpha)));

        float min = setting.getMin();
        float max = setting.getMax();
        float t = max - min == 0 ? 0 : (val - min) / (max - min);
        t = Math.max(0f, Math.min(1f, t));
        float fillW = Math.max(trackH, trackW * t);
        Render2D.drawRoundedRect(matrices, trackX, trackY, fillW, trackH, 2.5f,
                withAlpha(accent, (int) (255 * alpha)));
        // knob
        float knob = 10f;
        float kx = trackX + fillW - knob / 2f;
        float ky = trackY + trackH / 2f - knob / 2f;
        Render2D.drawRoundedRect(matrices, kx, ky, knob, knob, 5f,
                withAlpha(Color.WHITE, (int) (255 * alpha)));
    }

    private Color getAccent() {
        try {
            Color c = ThemeManager.getInstance().getCurrentTheme().getAccentColor();
            if (c != null) return c;
        } catch (Throwable ignored) {}
        return new Color(120, 90, 255);
    }

    private void renderSidebar(DrawContext context, int mouseX, int mouseY, float x, float y, Color accent, float alpha) {
        MatrixStack matrices = context.getMatrices();
        float w = ClickGuiLayout.SIDEBAR_WIDTH;
        float h = ClickGuiLayout.HEIGHT;

        Render2D.drawRoundedRect(matrices, x, y, w, h, ClickGuiLayout.RADIUS, withAlpha(new Color(18, 18, 22), (int) (240 * alpha)));
        Render2D.drawRoundedRect(matrices, x + 10f, y + 1f, w - 20f, 1.2f, 0.6f, withAlpha(accent, (int) (180 * alpha)));

        // Profile: logo + BaTVisuals
        float logoSize = 22f;
        float logoX = x + 8f;
        float logoY = y + (ClickGuiLayout.PROFILE_HEIGHT - logoSize) / 2f + 1f;
        try {
            Render2D.drawTexture(matrices, logoX, logoY, logoSize, logoSize, 5f, SIDEBAR_LOGO, Color.WHITE);
        } catch (Throwable ignored) {
            Render2D.drawRoundedRect(matrices, logoX, logoY, logoSize, logoSize, 5f, withAlpha(accent, (int) (200 * alpha)));
        }
        drawText(matrices, "BaTVisuals", logoX + logoSize + 6f, y + 15f, 7.5f, withAlpha(Color.WHITE, (int) (255 * alpha)));

        float pad = ClickGuiLayout.SIDEBAR_PADDING;
        float innerW = w - pad * 2f;
        state.updateSidebarScroll();
        float itemY = y + ClickGuiLayout.PROFILE_HEIGHT + ClickGuiLayout.SIDEBAR_SECTION_GAP + state.getSidebarScroll();
        float listTop = y + ClickGuiLayout.PROFILE_HEIGHT + ClickGuiLayout.SIDEBAR_SECTION_GAP;
        float listBottom = y + h - 6f;
        enableScissor(context, (int) x, (int) listTop, (int) (x + w), (int) listBottom);

        for (Category category : ClickGuiLayout.getVisibleCategories()) {
            if (itemY + ClickGuiLayout.SIDEBAR_ITEM_HEIGHT < listTop || itemY > listBottom) {
                itemY += ClickGuiLayout.SIDEBAR_ITEM_HEIGHT + ClickGuiLayout.SIDEBAR_ITEM_GAP;
                continue;
            }
            boolean selected = category == state.getSelectedCategory();
            boolean hovered = ClickGuiLayout.isHovered(mouseX, mouseY, x + pad, itemY, innerW, ClickGuiLayout.SIDEBAR_ITEM_HEIGHT);

            if (selected) {
                Render2D.drawRoundedRect(matrices, x + pad, itemY, innerW, ClickGuiLayout.SIDEBAR_ITEM_HEIGHT, 4f,
                        withAlpha(accent, (int) (180 * alpha)));
            } else if (hovered) {
                Render2D.drawRoundedRect(matrices, x + pad, itemY, innerW, ClickGuiLayout.SIDEBAR_ITEM_HEIGHT, 4f,
                        withAlpha(new Color(40, 40, 48), (int) (180 * alpha)));
            }

            // icon + label
            float iconSz = 12f;
            float iconX = x + pad + 5f;
            float iconY = itemY + (ClickGuiLayout.SIDEBAR_ITEM_HEIGHT - iconSz) / 2f;
            Identifier icon = categoryIcon(category);
            Color iconCol = selected ? withAlpha(Color.WHITE, (int) (255 * alpha))
                    : withAlpha(new Color(210, 210, 220), (int) ((hovered ? 255 : 170) * alpha));
            try {
                Render2D.drawTexture(matrices, iconX, iconY, iconSz, iconSz, 2f, icon, iconCol);
            } catch (Throwable ignored) {
                Render2D.drawRoundedRect(matrices, iconX, iconY, iconSz, iconSz, 3f, withAlpha(accent, (int) (160 * alpha)));
            }

            String label = categoryDisplayName(category);
            Color textCol = selected ? withAlpha(Color.WHITE, (int) (255 * alpha))
                    : withAlpha(new Color(200, 200, 210), (int) ((hovered ? 240 : 180) * alpha));
            drawText(matrices, label, iconX + iconSz + 6f, itemY + (ClickGuiLayout.SIDEBAR_ITEM_HEIGHT - 7f) / 2f, 7f, textCol);

            // left accent strip when selected
            if (selected) {
                Render2D.drawRoundedRect(matrices, x + pad + 1f, itemY + 4f, 2f, ClickGuiLayout.SIDEBAR_ITEM_HEIGHT - 8f, 1f,
                        withAlpha(Color.WHITE, (int) (220 * alpha)));
            }

            itemY += ClickGuiLayout.SIDEBAR_ITEM_HEIGHT + ClickGuiLayout.SIDEBAR_ITEM_GAP;
        }
        disableScissor(context);

    }

    private String categoryDisplayName(Category category) {
        if (category == null) return "Modules";
        return switch (category) {
            case Render -> "Визуалы";
            case Utility -> "Утилиты";
            case Games -> "Игры";
            case Theme -> "Темы";
            case Gps -> "Навигатор";
            case Friends -> "Друзья";
            case Music -> "Музыка";
            case Config -> "Конфиги";
            case Cosmetics -> "Косметика";
            case Profile -> "Профиль";
            default -> category.name();
        };
    }

    private Identifier categoryIcon(Category category) {
        if (category == null) return CAT_VISUALS;
        return switch (category) {
            case Render -> CAT_VISUALS;
            case Utility -> CAT_UTILITY;
            case Games -> CAT_GAMES;
            case Theme -> CAT_THEME;
            case Gps -> CAT_GPS;
            case Friends -> CAT_FRIENDS;
            case Music -> CAT_MUSIC;
            case Config -> CAT_CONFIG;
            default -> CAT_VISUALS;
        };
    }

    private void renderMain(DrawContext context, int mouseX, int mouseY, float x, float y, Color accent, float alpha) {
        MatrixStack matrices = context.getMatrices();
        float w = ClickGuiLayout.MAIN_WIDTH;
        float h = ClickGuiLayout.HEIGHT;

        Render2D.drawRoundedRect(matrices, x, y, w, h, ClickGuiLayout.RADIUS, withAlpha(new Color(18, 18, 22), (int) (240 * alpha)));
        Render2D.drawRoundedRect(matrices, x + 10f, y + 1f, w - 20f, 1.2f, 0.6f, withAlpha(accent, (int) (180 * alpha)));

        String title = categoryDisplayName(state.getSelectedCategory());
        drawText(matrices, title, x + 10f, y + 8f, 9f, withAlpha(Color.WHITE, (int) (255 * alpha)));

        // Search only for module categories
        Category category = state.getSelectedCategory();
        boolean modulesTab = category == Category.Render || category == Category.Utility || category == Category.Cosmetics;
        if (modulesTab) {
            float searchX = x + w - ClickGuiLayout.SEARCH_WIDTH - 8f;
            float searchY = y + (ClickGuiLayout.MAIN_HEADER_HEIGHT - ClickGuiLayout.SEARCH_HEIGHT) / 2f;
            boolean searchHover = ClickGuiLayout.isHovered(mouseX, mouseY, searchX, searchY, ClickGuiLayout.SEARCH_WIDTH, ClickGuiLayout.SEARCH_HEIGHT);
            Color searchBg = state.isSearchActive()
                    ? withAlpha(new Color(40, 40, 50), (int) (230 * alpha))
                    : withAlpha(new Color(28, 28, 34), (int) ((searchHover ? 220 : 180) * alpha));
            Render2D.drawRoundedRect(matrices, searchX, searchY, ClickGuiLayout.SEARCH_WIDTH, ClickGuiLayout.SEARCH_HEIGHT, 4f, searchBg);
            String searchDisplay = state.getSearchText().isEmpty() && !state.isSearchActive() ? "Search..." : state.getSearchText();
            if (state.isSearchActive() && System.currentTimeMillis() / 500 % 2 == 0) searchDisplay += "|";
            drawText(matrices, ClickGuiLayout.truncate(searchDisplay, 6f, ClickGuiLayout.SEARCH_WIDTH - 8f),
                    searchX + 4f, searchY + 3.5f, 6f,
                    withAlpha(state.isSearchActive() ? Color.WHITE : new Color(140, 140, 150), (int) (220 * alpha)));
        }

        float contentY = y + ClickGuiLayout.MAIN_HEADER_HEIGHT;
        float viewH = ClickGuiLayout.getGridViewHeight();
        enableScissor(context, (int) x, (int) contentY, (int) (x + w), (int) (contentY + viewH));

        if (category == Category.Profile) {
            renderProfilePanel(matrices, context, x, contentY, w, mouseX, mouseY, accent, alpha);
            disableScissor(context);
            return;
        }
        if (category == Category.Theme) {
            renderThemesPanel(matrices, x, contentY, w, mouseX, mouseY, accent, alpha);
            disableScissor(context);
            return;
        }
        if (category == Category.Friends) {
            renderFriendsPanel(matrices, x + 8f, contentY, w - 16f, mouseX, mouseY, accent, alpha);
            disableScissor(context);
            return;
        }

        if (category == Category.Music) {
            renderMusicPanel(matrices, x + 8f, contentY, w - 16f, mouseX, mouseY, accent, alpha);
            disableScissor(context);
            return;
        }

        if (category == Category.Gps) {
            renderGpsPanel(matrices, x + 8f, contentY, w - 16f, mouseX, mouseY, accent, alpha);
            disableScissor(context);
            return;
        }

        if (category == Category.Games) {
            renderGamesPanel(matrices, x + 8f, contentY, w - 16f, mouseX, mouseY, accent, alpha);
            disableScissor(context);
            return;
        }

        if (category == Category.Config) {
            renderConfigsPanel(matrices, x, contentY, w, mouseX, mouseY, accent, alpha);
            disableScissor(context);
            return;
        }

        List<Module> modules = state.getModules(category);
        float cardW = ClickGuiLayout.getCardWidth();
        float scroll = state.getGridScroll(category);
        float gridTop = contentY + ClickGuiLayout.MAIN_PADDING / 2f;

        for (ClickGuiLayout.CardPos pos : ClickGuiLayout.layoutCards(modules, cardW)) {
            Module module = pos.module();
            float cardX = x + ClickGuiLayout.MAIN_PADDING + pos.column() * (cardW + ClickGuiLayout.CARD_GAP);
            float cardY = gridTop + pos.offsetY() + scroll;
            float cardH = pos.height();

            boolean hovered = ClickGuiLayout.isHovered(mouseX, mouseY, cardX, cardY, cardW, cardH);
            state.getCardHoverAnimation(module).update(hovered);
            float hoverT = state.getCardHoverAnimation(module).getValue();

            boolean enabled = module.isToggled();
            state.getToggleAnimation(module).update(enabled);
            float toggleT = state.getToggleAnimation(module).getValue();

            Color cardBg = lerpColor(new Color(26, 26, 32), new Color(34, 34, 42), hoverT);
            Render2D.drawRoundedRect(matrices, cardX, cardY, cardW, cardH, 5f, withAlpha(cardBg, (int) (230 * alpha)));

            Color nameCol = enabled ? withAlpha(Color.WHITE, (int) (255 * alpha)) : withAlpha(new Color(190, 190, 200), (int) (210 * alpha));
            // Избранное — крупное сердечко
            boolean fav = dev.batvisuals.client.managers.FavoritesManager.isFavorite(module.getName());
            float hx = cardX + 6f;
            float hy = cardY + 3.5f;
            drawHeart(matrices, hx, hy, 11f, fav,
                    withAlpha(fav ? new Color(255, 55, 90) : new Color(120, 120, 135), (int) (255 * alpha)));

            drawText(matrices, ClickGuiLayout.truncate(module.getName(), 7.5f, cardW - 48f),
                    cardX + 22f, cardY + 4f, 7.5f, nameCol);

            float tw = 16f, th = 9f;
            float tx = cardX + cardW - tw - 5f;
            float ty = cardY + 4.5f;
            Color track = lerpColor(new Color(45, 45, 55), accent, toggleT);
            Render2D.drawRoundedRect(matrices, tx, ty, tw, th, 4.5f, withAlpha(track, (int) (230 * alpha)));
            float knobX = tx + 1.5f + (tw - th) * toggleT;
            Render2D.drawRoundedRect(matrices, knobX, ty + 1.2f, th - 2.4f, th - 2.4f, 3.5f, withAlpha(Color.WHITE, (int) (255 * alpha)));

            String rawDesc = module.getDescription();
            String desc = rawDesc;
            try {
                if (rawDesc != null && !rawDesc.isBlank()) {
                    String tr = I18n.translate(rawDesc);
                    if (tr != null && !tr.isBlank()) desc = tr;
                }
            } catch (Throwable ignored) {}
            List<String> lines = ClickGuiLayout.wrapText(desc, ClickGuiLayout.CARD_DESC_SIZE,
                    cardW - 12f, ClickGuiLayout.CARD_DESC_MAX_LINES);
            float dy = cardY + ClickGuiLayout.CARD_HEADER_HEIGHT;
            for (String line : lines) {
                drawText(matrices, line, cardX + 6f, dy, ClickGuiLayout.CARD_DESC_SIZE,
                        withAlpha(new Color(150, 150, 160), (int) (200 * alpha)));
                dy += ClickGuiLayout.CARD_DESC_LINE_HEIGHT;
            }

            float bottomY = cardY + cardH - 10f;
            Bind bind = module.getBind();
            String bindStr = state.getBindingModule() == module ? "..." : (bind != null ? bind.toString() : "None");
            drawText(matrices, bindStr, cardX + 6f, bottomY, 5.5f,
                    withAlpha(state.getBindingModule() == module ? accent : new Color(120, 120, 130), (int) (200 * alpha)));

            if (ClickGuiLayout.hasVisibleSettings(module)) {
                boolean selected = state.getSelectedModule() == module;
                drawText(matrices, selected ? "<<" : ">>", cardX + cardW - 14f, bottomY, 6f,
                        withAlpha(selected ? accent : new Color(140, 140, 150), (int) (220 * alpha)));
            }
        }

        disableScissor(context);
    }

    private void renderThemesPanel(MatrixStack matrices, float x, float contentY, float w,
                                   int mouseX, int mouseY, Color accent, float alpha) {
        float scroll = state.getGridScroll(Category.Theme);
        float pad = ClickGuiLayout.MAIN_PADDING;
        float y = contentY + pad / 2f + scroll;
        float innerW = w - pad * 2f;
        float cardW = (innerW - 6f) / 2f;
        float cardH = 28f;

        ThemeManager tm = ThemeManager.getInstance();
        ThemeManager.Theme[] themesArr;
        try {
            themesArr = tm.getAvailableThemes();
            if (themesArr == null) themesArr = new ThemeManager.Theme[0];
        } catch (Throwable t) {
            themesArr = new ThemeManager.Theme[0];
        }

        drawText(matrices, "Палитра тем", x + pad, y, 7f, withAlpha(new Color(180, 180, 190), (int) (220 * alpha)));
        y += 14f;

        float col0 = x + pad;
        float col1 = x + pad + cardW + 6f;
        float y0 = y, y1 = y;
        int drawn = 0;
        for (ThemeManager.Theme theme : themesArr) {
            String name = theme.getName() != null ? theme.getName() : "Theme";
            // skip Purple / Gray / Серая
            String low = name.toLowerCase();
            if (low.contains("purple") || low.contains("серая") || low.contains("серый") || low.equals("gray") || low.equals("grey")) {
                continue;
            }

            boolean left = (drawn % 2) == 0;
            float cx = left ? col0 : col1;
            float cy = left ? y0 : y1;

            boolean selected = false;
            try {
                ThemeManager.Theme cur = tm.getCurrentTheme();
                selected = cur != null && cur.getName() != null && cur.getName().equals(theme.getName());
            } catch (Throwable ignored) {}
            boolean hovered = ClickGuiLayout.isHovered(mouseX, mouseY, cx, cy, cardW, cardH);

            Color bg = selected ? withAlpha(accent, (int) (150 * alpha))
                    : withAlpha(new Color(28, 28, 34), (int) ((hovered ? 220 : 180) * alpha));
            Render2D.drawRoundedRect(matrices, cx, cy, cardW, cardH, 5f, bg);

            // single accent circle (theme color, not white)
            Color dot;
            try {
                dot = theme.getAccentColor();
                if (dot == null) dot = accent;
                // if almost white, use background or a mid tone from theme
                if (dot.getRed() > 240 && dot.getGreen() > 240 && dot.getBlue() > 240) {
                    try { dot = theme.getBackgroundColor(); } catch (Throwable ignored2) {}
                    if (dot == null || (dot.getRed() > 240 && dot.getGreen() > 240 && dot.getBlue() > 240)) {
                        dot = new Color(200, 200, 210);
                    }
                }
            } catch (Throwable ex) {
                dot = accent;
            }
            float sw = 12f;
            float sx = cx + 8f;
            float sy = cy + (cardH - sw) / 2f;
            Render2D.drawRoundedRect(matrices, sx, sy, sw, sw, sw / 2f, withAlpha(dot, (int) (255 * alpha)));

            drawText(matrices, ClickGuiLayout.truncate(name, 7f, cardW - 28f),
                    sx + sw + 6f, cy + 9f, 7f, withAlpha(Color.WHITE, (int) (240 * alpha)));

            if (left) y0 += cardH + 6f;
            else y1 += cardH + 6f;
            drawn++;
        }
    }

    private void renderConfigsPanel(MatrixStack matrices, float x, float contentY, float w,
                                    int mouseX, int mouseY, Color accent, float alpha) {
        float scroll = state.getGridScroll(Category.Config);
        float pad = ClickGuiLayout.MAIN_PADDING;
        float y = contentY + pad / 2f + scroll;
        float innerW = w - pad * 2f;

        drawText(matrices, "Конфиги", x + pad, y, 7f, withAlpha(new Color(180, 180, 190), (int) (220 * alpha)));
        y += 14f;

        float btnH = 18f;
        boolean createHover = ClickGuiLayout.isHovered(mouseX, mouseY, x + pad, y, innerW, btnH);
        Render2D.drawRoundedRect(matrices, x + pad, y, innerW, btnH, 4f,
                withAlpha(createHover ? accent : new Color(35, 35, 42), (int) (200 * alpha)));
        String createLabel = state.isConfigCreateActive() ? "Введите имя..." : "+ Создать конфиг";
        float cw = Fonts.REGULAR != null ? Fonts.REGULAR.getWidth(createLabel, 7f) : 90f;
        String displayCreate = createLabel;
        if (state.isConfigCreateActive()) {
            displayCreate = state.getConfigCreateBuffer() == null ? "" : state.getConfigCreateBuffer();
            if (System.currentTimeMillis() / 500 % 2 == 0) displayCreate += "|";
            displayCreate = "Имя: " + displayCreate;
        }
        float dcw = Fonts.REGULAR != null ? Fonts.REGULAR.getWidth(displayCreate, 7f) : cw;
        drawText(matrices, displayCreate, x + pad + (innerW - dcw) / 2f, y + 5f, 7f, withAlpha(Color.WHITE, (int) (255 * alpha)));
        y += btnH + 8f;

        // rename bar
        if (state.isConfigRenameActive()) {
            float renH = 18f;
            Render2D.drawRoundedRect(matrices, x + pad, y, innerW, renH, 4f, withAlpha(new Color(40, 40, 50), (int) (230 * alpha)));
            String buf = state.getConfigRenameBuffer() == null ? "" : state.getConfigRenameBuffer();
            if (System.currentTimeMillis() / 500 % 2 == 0) buf += "|";
            drawText(matrices, "Rename: " + buf, x + pad + 6f, y + 5f, 6.5f, withAlpha(accent, (int) (255 * alpha)));
            y += renH + 6f;
        }

        String[] configs = new String[0];
        try {
            configs = batvisuals.getInstance().getConfigManager().getConfigList();
            if (configs == null) configs = new String[0];
        } catch (Throwable ignored) {}

        for (String cfg : configs) {
            float rowH = 22f;
            boolean hovered = ClickGuiLayout.isHovered(mouseX, mouseY, x + pad, y, innerW, rowH);
            Render2D.drawRoundedRect(matrices, x + pad, y, innerW, rowH, 4f,
                    withAlpha(hovered ? new Color(40, 42, 52) : new Color(28, 28, 34), (int) (200 * alpha)));

            drawText(matrices, ClickGuiLayout.truncate(cfg, 7f, innerW - 88f), x + pad + 8f, y + 7f, 7f,
                    withAlpha(Color.WHITE, (int) (240 * alpha)));

            // right-side actions
            float actW = 28f;
            float actH = 14f;
            float delX = x + pad + innerW - actW - 6f;
            float renX = delX - actW - 4f;
            float actY = y + (rowH - actH) / 2f;

            boolean renHov = ClickGuiLayout.isHovered(mouseX, mouseY, renX, actY, actW, actH);
            boolean delHov = ClickGuiLayout.isHovered(mouseX, mouseY, delX, actY, actW, actH);

            Render2D.drawRoundedRect(matrices, renX, actY, actW, actH, 3f,
                    withAlpha(renHov ? accent : new Color(50, 50, 60), (int) (220 * alpha)));
            drawText(matrices, "Ren", renX + 5f, actY + 3f, 6f, withAlpha(Color.WHITE, (int) (255 * alpha)));

            Render2D.drawRoundedRect(matrices, delX, actY, actW, actH, 3f,
                    withAlpha(delHov ? new Color(180, 60, 60) : new Color(50, 50, 60), (int) (220 * alpha)));
            drawText(matrices, "Del", delX + 6f, actY + 3f, 6f, withAlpha(Color.WHITE, (int) (255 * alpha)));

            y += rowH + 4f;
        }
    }

    private void renderSettingsPanel(DrawContext context, int mouseX, int mouseY, float x, float y, Color accent, float alpha) {
        float panelProgress = state.getSettingsPanelProgress();
        if (panelProgress < 0.01f) return;

        Module module = state.getSelectedModule();
        float mul = panelProgress * alpha;
        MatrixStack matrices = context.getMatrices();
        float w = ClickGuiLayout.SETTINGS_WIDTH;
        float h = ClickGuiLayout.HEIGHT;

        float slide = (1f - panelProgress) * 24f;
        x = x + slide;

        Render2D.drawRoundedRect(matrices, x, y, w, h, ClickGuiLayout.RADIUS, withAlpha(new Color(18, 18, 22), (int) (240 * mul)));

        String title = module != null ? ClickGuiLayout.truncate(module.getName(), 8f, w - 16f) : "Settings";
        drawText(matrices, title, x + 8f, y + 6f, 8f, withAlpha(Color.WHITE, (int) (255 * mul)));

        if (module == null) return;

        float contentY = y + ClickGuiLayout.SETTINGS_HEADER_HEIGHT;
        enableScissor(context, (int) x, (int) contentY, (int) (x + w), (int) (y + h));

        float startY = contentY + state.getSettingsScroll() + 2f;
        settingRenderer.render(context, module, x + ClickGuiLayout.SETTINGS_PADDING, startY,
                ClickGuiLayout.getSettingsInnerWidth(), accent, mouseX, mouseY, state, mul);

        disableScissor(context);
    }


    private void renderFriendsPanel(MatrixStack matrices, float x, float contentY, float w,
                                    int mouseX, int mouseY, Color accent, float alpha) {
        float y = contentY + state.getFriendsListScroll();
        drawText(matrices, "Friend name", x, y, 7f, withAlpha(new Color(180, 180, 190), (int) (255 * alpha)));
        y += 12f;
        float fieldH = 18f;
        boolean nickFocus = state.isFriendsNickActive();
        Color fieldBg = withAlpha(nickFocus ? new Color(40, 40, 52) : new Color(28, 28, 34), (int) (230 * alpha));
        Render2D.drawRoundedRect(matrices, x, y, w, fieldH, 5f, fieldBg);
        if (nickFocus) {
            Render2D.drawRoundedRect(matrices, x, y, w, 1.2f, 1f, withAlpha(accent, (int) (220 * alpha)));
        }
        String nick = state.getFriendsNickBuffer();
        boolean empty = nick == null || nick.isEmpty();
        String show = empty && !nickFocus ? "Type a name..." : (empty ? "" : nick) + (nickFocus && (System.currentTimeMillis() / 500) % 2 == 0 ? "|" : "");
        drawText(matrices, show, x + 8f, y + 5f, 7f, withAlpha(empty && !nickFocus ? new Color(120, 120, 130) : Color.WHITE, (int) (255 * alpha)));
        float fieldY = y;
        y += fieldH + 4f;

        // Online player suggestions (max 5 visible)
        java.util.List<String> suggestions = getOnlinePlayerSuggestions(nick == null ? "" : nick);
        if (nickFocus && !suggestions.isEmpty()) {
            int maxVisible = 5;
            int scroll = state.getFriendsSuggestScroll();
            if (scroll > Math.max(0, suggestions.size() - maxVisible)) {
                scroll = Math.max(0, suggestions.size() - maxVisible);
                state.setFriendsSuggestScroll(scroll);
            }
            float sugH = 16f;
            int visible = Math.min(maxVisible, suggestions.size() - scroll);
            float boxH = visible * sugH + 4f;
            Render2D.drawRoundedRect(matrices, x, y, w, boxH, 5f, withAlpha(new Color(22, 22, 28), (int) (245 * alpha)));
            for (int i = 0; i < visible; i++) {
                String name = suggestions.get(scroll + i);
                float sy = y + 2f + i * sugH;
                boolean hov = ClickGuiLayout.isHovered(mouseX, mouseY, x + 2f, sy, w - 4f, sugH);
                if (hov) {
                    Render2D.drawRoundedRect(matrices, x + 2f, sy, w - 4f, sugH, 3f, withAlpha(accent, (int) (160 * alpha)));
                }
                drawText(matrices, name, x + 8f, sy + 4f, 6.5f, withAlpha(Color.WHITE, (int) (255 * alpha)));
            }
            if (suggestions.size() > maxVisible) {
                String more = (scroll + maxVisible) + "/" + suggestions.size();
                drawText(matrices, more, x + w - 28f, y + boxH - 12f, 5.5f, withAlpha(new Color(140, 140, 150), (int) (255 * alpha)));
            }
            y += boxH + 6f;
        } else {
            y += 4f;
        }

        float btnW = (w - 6f) / 2f;
        float btnH = 20f;
        boolean addH = ClickGuiLayout.isHovered(mouseX, mouseY, x, y, btnW, btnH);
        boolean clearH = ClickGuiLayout.isHovered(mouseX, mouseY, x + btnW + 6f, y, btnW, btnH);
        Render2D.drawRoundedRect(matrices, x, y, btnW, btnH, 5f, withAlpha(addH ? accent : new Color(45, 45, 55), (int) (230 * alpha)));
        Render2D.drawRoundedRect(matrices, x + btnW + 6f, y, btnW, btnH, 5f, withAlpha(clearH ? new Color(180, 60, 60) : new Color(45, 45, 55), (int) (230 * alpha)));
        drawText(matrices, "Add", x + 12f, y + 6f, 7f, withAlpha(Color.WHITE, (int) (255 * alpha)));
        drawText(matrices, "Clear all", x + btnW + 18f, y + 6f, 7f, withAlpha(Color.WHITE, (int) (255 * alpha)));
        y += btnH + 12f;
        drawText(matrices, "Friends list", x, y, 7.5f, withAlpha(Color.WHITE, (int) (255 * alpha)));
        y += 14f;
        var friends = FriendsManager.getFriendEntries();
        if (friends.isEmpty()) {
            drawText(matrices, "Empty", x + 4f, y, 7f, withAlpha(new Color(130, 130, 140), (int) (255 * alpha)));
            return;
        }
        float rowH = 28f;
        for (FriendsManager.FriendEntry fr : friends) {
            boolean online = FriendsManager.isFriendOnline(fr);
            boolean rowHover = ClickGuiLayout.isHovered(mouseX, mouseY, x, y, w, rowH);
            Render2D.drawRoundedRect(matrices, x, y, w, rowH, 5f, withAlpha(rowHover ? new Color(40, 40, 50) : new Color(26, 26, 32), (int) (220 * alpha)));
            Color dot = online ? new Color(80, 220, 120) : new Color(120, 120, 130);
            Render2D.drawRoundedRect(matrices, x + 6f, y + 10f, 7f, 7f, 3.5f, withAlpha(dot, (int) (255 * alpha)));
            String name = fr.nick == null ? "?" : fr.nick;
            drawText(matrices, name, x + 18f, y + 4f, 7f, withAlpha(Color.WHITE, (int) (255 * alpha)));
            String sub = online ? "online" : "offline";
            if (fr.uuidKey != null && fr.uuidKey.length() >= 8) sub += "  " + fr.uuidKey.substring(0, 8);
            drawText(matrices, sub, x + 18f, y + 15f, 5.5f, withAlpha(online ? new Color(140, 220, 160) : new Color(130, 130, 140), (int) (255 * alpha)));
            float delW = 44f;
            boolean delH = ClickGuiLayout.isHovered(mouseX, mouseY, x + w - delW - 4f, y + 4f, delW, rowH - 8f);
            Render2D.drawRoundedRect(matrices, x + w - delW - 4f, y + 4f, delW, rowH - 8f, 4f, withAlpha(delH ? new Color(190, 55, 55) : new Color(55, 40, 40), (int) (230 * alpha)));
            drawText(matrices, "Del", x + w - delW + 8f, y + 9f, 6.5f, withAlpha(Color.WHITE, (int) (255 * alpha)));
            y += rowH + 4f;
        }
    }

    /** Online players matching typed prefix (tab + Firebase presence). */
    private java.util.List<String> getOnlinePlayerSuggestions(String query) {
        java.util.LinkedHashSet<String> out = new java.util.LinkedHashSet<>();
        try {
            var mc = net.minecraft.client.MinecraftClient.getInstance();
            String q = query == null ? "" : query.trim().toLowerCase();
            String self = mc != null && mc.player != null ? mc.player.getGameProfile().getName() : null;
            if (mc != null && mc.getNetworkHandler() != null) {
                for (var entry : mc.getNetworkHandler().getPlayerList()) {
                    if (entry == null || entry.getProfile() == null) continue;
                    String name = entry.getProfile().getName();
                    if (name == null || name.isEmpty()) continue;
                    if (self != null && name.equalsIgnoreCase(self)) continue;
                    if (FriendsManager.checkFriend(name)) continue;
                    if (!q.isEmpty() && !name.toLowerCase().startsWith(q)) continue;
                    out.add(name);
                }
            }
            try {
                var fb = dev.batvisuals.batvisuals.getInstance().getFirebaseManager();
                if (fb != null) {
                    for (String key : fb.onlineKeysSnapshot()) {
                        String nick = fb.getNick(key);
                        if (nick == null || nick.isEmpty()) continue;
                        if (self != null && nick.equalsIgnoreCase(self)) continue;
                        if (FriendsManager.checkFriend(nick)) continue;
                        if (!q.isEmpty() && !nick.toLowerCase().startsWith(q)) continue;
                        out.add(nick);
                    }
                }
            } catch (Throwable ignored) {}
        } catch (Throwable ignored) {}
        java.util.List<String> list = new java.util.ArrayList<>(out);
        list.sort(String.CASE_INSENSITIVE_ORDER);
        return list;
    }

    private void renderGpsPanel(MatrixStack matrices, float x, float contentY, float w,
                                int mouseX, int mouseY, Color accent, float alpha) {
        float y = contentY + state.getGpsListScroll();

        // Авто Ивент — чекбокс сверху
        boolean autoEv = dev.batvisuals.client.managers.WaypointManager.isAutoEvent();
        float box = 12f;
        boolean boxHover = ClickGuiLayout.isHovered(mouseX, mouseY, x, y, w, box + 4f);
        Render2D.drawRoundedRect(matrices, x, y + 1f, box, box, 3f,
                withAlpha(autoEv ? accent : new Color(40, 40, 48), (int) ((boxHover ? 240 : 200) * alpha)));
        if (autoEv) {
            drawText(matrices, "✓", x + 2.5f, y + 1.5f, 8f, withAlpha(Color.WHITE, (int) (255 * alpha)));
        }
        drawText(matrices, "Авто Ивент", x + box + 6f, y + 2f, 7.5f, withAlpha(Color.WHITE, (int) (255 * alpha)));
        y += box + 10f;

        // текущий контекст (сервер/мир)
        String ctx = dev.batvisuals.client.managers.WaypointManager.getCurrentContext();
        drawText(matrices, "Контекст: " + ctx, x, y, 5.5f, withAlpha(new Color(130, 130, 140), (int) (255 * alpha)));
        y += 12f;

        drawText(matrices, "Waypoint name", x, y, 7f, withAlpha(new Color(180, 180, 190), (int) (255 * alpha)));
        y += 12f;
        float fieldH = 18f;
        drawGpsField(matrices, x, y, w, fieldH, state.getGpsNameBuffer(), state.isGpsNameActive(), "Name...", accent, alpha);
        y += fieldH + 6f;
        float half = (w - 6f) / 2f;
        drawText(matrices, "X", x, y, 6.5f, withAlpha(new Color(160, 160, 170), (int) (255 * alpha)));
        drawText(matrices, "Z", x + half + 6f, y, 6.5f, withAlpha(new Color(160, 160, 170), (int) (255 * alpha)));
        y += 11f;
        drawGpsField(matrices, x, y, half, fieldH, state.getGpsXBuffer(), state.isGpsXActive(), "X", accent, alpha);
        drawGpsField(matrices, x + half + 6f, y, half, fieldH, state.getGpsZBuffer(), state.isGpsZActive(), "Z", accent, alpha);
        y += fieldH + 8f;
        float btnW = (w - 6f) / 2f;
        float btnH = 20f;
        boolean addH = ClickGuiLayout.isHovered(mouseX, mouseY, x, y, btnW, btnH);
        boolean clearH = ClickGuiLayout.isHovered(mouseX, mouseY, x + btnW + 6f, y, btnW, btnH);
        Render2D.drawRoundedRect(matrices, x, y, btnW, btnH, 5f, withAlpha(addH ? accent : new Color(45, 45, 55), (int) (230 * alpha)));
        Render2D.drawRoundedRect(matrices, x + btnW + 6f, y, btnW, btnH, 5f, withAlpha(clearH ? new Color(180, 60, 60) : new Color(45, 45, 55), (int) (230 * alpha)));
        drawText(matrices, "Add", x + 12f, y + 6f, 7f, withAlpha(Color.WHITE, (int) (255 * alpha)));
        drawText(matrices, "Clear all", x + btnW + 18f, y + 6f, 7f, withAlpha(Color.WHITE, (int) (255 * alpha)));
        y += btnH + 12f;
        drawText(matrices, "Waypoints", x, y, 7.5f, withAlpha(Color.WHITE, (int) (255 * alpha)));
        y += 14f;
        var list = WaypointManager.list();
        if (list.isEmpty()) {
            drawText(matrices, "Empty", x + 4f, y, 7f, withAlpha(new Color(130, 130, 140), (int) (255 * alpha)));
            return;
        }
        float rowH = 24f;
        for (var wp : list) {
            boolean rowHover = ClickGuiLayout.isHovered(mouseX, mouseY, x, y, w, rowH);
            Render2D.drawRoundedRect(matrices, x, y, w, rowH, 5f, withAlpha(rowHover ? new Color(40, 40, 50) : new Color(26, 26, 32), (int) (220 * alpha)));
            drawText(matrices, wp.name, x + 8f, y + 3f, 7f, withAlpha(Color.WHITE, (int) (255 * alpha)));
            drawText(matrices, String.format("X: %d  Z: %d", (int) wp.pos.x, (int) wp.pos.z), x + 8f, y + 13f, 6f, withAlpha(new Color(150, 150, 160), (int) (255 * alpha)));
            float delW = 44f;
            boolean delH = ClickGuiLayout.isHovered(mouseX, mouseY, x + w - delW - 4f, y + 3f, delW, rowH - 6f);
            Render2D.drawRoundedRect(matrices, x + w - delW - 4f, y + 3f, delW, rowH - 6f, 4f, withAlpha(delH ? new Color(190, 55, 55) : new Color(55, 40, 40), (int) (230 * alpha)));
            drawText(matrices, "Del", x + w - delW + 4f, y + 8f, 6.5f, withAlpha(Color.WHITE, (int) (255 * alpha)));
            y += rowH + 4f;
        }
    }

    

    private void renderMusicPanel(MatrixStack matrices, float x, float contentY, float w,
                                  int mouseX, int mouseY, Color accent, float alpha) {
        float scroll = state.getGridScroll(Category.Music);
        float y = contentY + 6f + scroll;

        // --- сейчас играет ---
        var cur = dev.batvisuals.client.managers.MusicManager.current();
        float cardH = 52f;
        Render2D.drawRoundedRect(matrices, x, y, w, cardH, 6f, withAlpha(new Color(24, 26, 34), (int) (235 * alpha)));

        float av = 40f;
        float ax = x + 6f, ay = y + 6f;
        Render2D.drawRoundedRect(matrices, ax, ay, av, av, 5f, withAlpha(new Color(35, 38, 48), (int) (255 * alpha)));
        try {
            var cover = dev.batvisuals.client.managers.MusicManager.getCurrentCover();
            Render2D.drawTexture(matrices, ax + 2f, ay + 2f, av - 4f, av - 4f, 4f, cover, Color.WHITE);
        } catch (Throwable ignored) {}

        String title = cur != null ? cur.title : "Нет треков";
        String artist = cur != null ? cur.artist : "Положи файлы в batvisuals/music";
        title = ClickGuiLayout.truncate(title, 7f, w - av - 16f);
        artist = ClickGuiLayout.truncate(artist, 6f, w - av - 16f);
        drawText(matrices, title, ax + av + 8f, y + 10f, 7.5f, withAlpha(Color.WHITE, (int) (255 * alpha)));
        drawText(matrices, artist, ax + av + 8f, y + 22f, 6f, withAlpha(new Color(160, 165, 180), (int) (255 * alpha)));

        // кнопки управления (иконки)
        float btn = 20f;
        float by = y + cardH - btn - 5f;
        float bx0 = ax + av + 8f;
        float gap = 5f;
        boolean playing = dev.batvisuals.client.managers.MusicManager.isPlaying();
        Identifier[] icons = {MUSIC_PREV, playing ? MUSIC_PAUSE : MUSIC_PLAY, MUSIC_NEXT, MUSIC_STOP};
        float bx = bx0;
        for (int i = 0; i < 4; i++) {
            boolean hov = ClickGuiLayout.isHovered(mouseX, mouseY, bx, by, btn, btn);
            Render2D.drawRoundedRect(matrices, bx, by, btn, btn, 5f,
                    withAlpha(hov ? accent : new Color(40, 42, 52), (int) (230 * alpha)));
            try {
                float pad = 3.5f;
                Render2D.drawTexture(matrices, bx + pad, by + pad, btn - pad * 2f, btn - pad * 2f, 2f,
                        icons[i], withAlpha(Color.WHITE, (int) (255 * alpha)));
            } catch (Throwable ignored) {}
            bx += btn + gap;
        }
        y += cardH + 10f;

        // громкость
        drawText(matrices, "Громкость", x, y, 6f, withAlpha(new Color(160, 160, 170), (int) (255 * alpha)));
        y += 11f;
        float trackH = 6f;
        float vol = dev.batvisuals.client.managers.MusicManager.getVolume();
        float knob = 10f;
        Render2D.drawRoundedRect(matrices, x, y, w, trackH, 3f, withAlpha(new Color(35, 35, 42), (int) (220 * alpha)));
        Render2D.drawRoundedRect(matrices, x, y, w * vol, trackH, 3f, withAlpha(new Color(90, 200, 140), (int) (220 * alpha)));
        Render2D.drawRoundedRect(matrices, x + w * vol - knob / 2f, y - 2f, knob, trackH + 4f, 4f,
                withAlpha(Color.WHITE, (int) (255 * alpha)));
        drawText(matrices, (int) (vol * 100) + "%", x + w - 28f, y - 12f, 6f, withAlpha(new Color(180, 180, 190), (int) (255 * alpha)));
        y += trackH + 12f;

        // переключатели
        String[] tNames = {"Повтор трека", "Случайный порядок", "Автовоспроизведение"};
        boolean[] tVals = {
            dev.batvisuals.client.managers.MusicManager.isLoopTrack(),
            dev.batvisuals.client.managers.MusicManager.isShuffle(),
            dev.batvisuals.client.managers.MusicManager.isAutoPlayOnSelect()
        };
        float tH = 14f;
        for (int ti = 0; ti < 3; ti++) {
            boolean on = tVals[ti];
            boolean hov = ClickGuiLayout.isHovered(mouseX, mouseY, x, y, w, tH + 2f);
            Render2D.drawRoundedRect(matrices, x, y + 1f, 12f, 12f, 3f,
                    withAlpha(on ? accent : new Color(40, 40, 48), (int) ((hov ? 240 : 200) * alpha)));
            if (on) drawText(matrices, "✓", x + 2.5f, y + 1.5f, 8f, withAlpha(Color.WHITE, (int) (255 * alpha)));
            drawText(matrices, tNames[ti], x + 18f, y + 2.5f, 6.5f, withAlpha(Color.WHITE, (int) (255 * alpha)));
            y += tH + 4f;
        }
        y += 6f;

        // toolbar
        float btnH = 18f;
        float bw = (w - 6f) / 2f;
        boolean rHover = ClickGuiLayout.isHovered(mouseX, mouseY, x, y, bw, btnH);
        Render2D.drawRoundedRect(matrices, x, y, bw, btnH, 5f, withAlpha(rHover ? accent : new Color(40, 42, 52), (int) (220 * alpha)));
        drawText(matrices, "Обновить список", x + 8f, y + 5f, 6.5f, withAlpha(Color.WHITE, (int) (255 * alpha)));
        y += btnH + 10f;

        drawText(matrices, "Треки", x, y, 7.5f, withAlpha(Color.WHITE, (int) (255 * alpha)));
        y += 14f;

        var tracks = dev.batvisuals.client.managers.MusicManager.list();
        if (tracks.isEmpty()) {
            drawText(matrices, "Пусто — кинь .mp3 / .wav в папку", x, y, 6.5f, withAlpha(new Color(150, 150, 160), (int) (255 * alpha)));
            return;
        }
        float rowH = 30f;
        int i = 0;
        int curIdx = dev.batvisuals.client.managers.MusicManager.getIndex();
        for (var tr : tracks) {
            boolean hover = ClickGuiLayout.isHovered(mouseX, mouseY, x, y, w, rowH);
            boolean active = i == curIdx;
            Color bg = active ? withAlpha(accent, (int) (140 * alpha))
                    : withAlpha(hover ? new Color(40, 40, 50) : new Color(26, 26, 32), (int) (220 * alpha));
            Render2D.drawRoundedRect(matrices, x, y, w, rowH, 5f, bg);

            // mini cover
            try {
                var cvr = dev.batvisuals.client.managers.MusicManager.getCover(tr);
                Render2D.drawTexture(matrices, x + 4f, y + 4f, 22f, 22f, 3f, cvr, Color.WHITE);
            } catch (Throwable ignored) {}

            String tn = ClickGuiLayout.truncate(tr.title == null ? "?" : tr.title, 7f, w - 90f);
            String ar = ClickGuiLayout.truncate(tr.artist == null ? "" : tr.artist, 5.5f, w - 90f);
            drawText(matrices, tn, x + 32f, y + 5f, 7f, withAlpha(Color.WHITE, (int) (255 * alpha)));
            drawText(matrices, ar, x + 32f, y + 16f, 5.5f, withAlpha(new Color(160, 165, 180), (int) (255 * alpha)));

            float delW = 40f;
            boolean delH = ClickGuiLayout.isHovered(mouseX, mouseY, x + w - delW - 4f, y + 5f, delW, rowH - 10f);
            Render2D.drawRoundedRect(matrices, x + w - delW - 4f, y + 5f, delW, rowH - 10f, 4f,
                    withAlpha(delH ? new Color(190, 55, 55) : new Color(55, 40, 40), (int) (230 * alpha)));
            drawText(matrices, "Удал.", x + w - delW + 2f, y + 10f, 6f, withAlpha(Color.WHITE, (int) (255 * alpha)));
            y += rowH + 4f;
            i++;
        }
    }

    private void drawGpsField(MatrixStack matrices, float x, float y, float w, float h,
                              String value, boolean focused, String placeholder, Color accent, float alpha) {
        Render2D.drawRoundedRect(matrices, x, y, w, h, 5f, withAlpha(focused ? new Color(40, 40, 52) : new Color(28, 28, 34), (int) (230 * alpha)));
        if (focused) Render2D.drawRoundedRect(matrices, x, y, w, 1.2f, 1f, withAlpha(accent, (int) (220 * alpha)));
        boolean empty = value == null || value.isEmpty();
        String show = empty ? (focused ? ((System.currentTimeMillis() / 500) % 2 == 0 ? "|" : "") : placeholder)
                : value + (focused && (System.currentTimeMillis() / 500) % 2 == 0 ? "|" : "");
        drawText(matrices, show, x + 8f, y + 5f, 7f, withAlpha(empty && !focused ? new Color(120, 120, 130) : Color.WHITE, (int) (255 * alpha)));
    }

    private void drawText(MatrixStack matrices, String text, float x, float y, float size, Color color) {
        if (Fonts.REGULAR == null || text == null) return;
        try {
            Render2D.drawFont(matrices, Fonts.REGULAR.getFont(size), text, x, y, color);
        } catch (Throwable ignored) {}
    }

    private void enableScissor(DrawContext context, int x1, int y1, int x2, int y2) {
        context.enableScissor(x1, y1, x2, y2);
    }

    private void disableScissor(DrawContext context) {
        context.disableScissor();
    }

    private static Color withAlpha(Color c, int a) {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, a)));
    }

    private static Color lerpColor(Color a, Color b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        return new Color(
                (int) (a.getRed() + (b.getRed() - a.getRed()) * t),
                (int) (a.getGreen() + (b.getGreen() - a.getGreen()) * t),
                (int) (a.getBlue() + (b.getBlue() - a.getBlue()) * t),
                (int) (a.getAlpha() + (b.getAlpha() - a.getAlpha()) * t)
        );
    }

    private static String tr(String key) {
        try {
            String s = I18n.translate(key);
            return s != null ? s : key;
        } catch (Throwable e) {
            return key == null ? "" : key;
        }
    }

    private static float textWidth(String text, float size) {
        try {
            return Fonts.REGULAR.getWidth(text, size);
        } catch (Throwable e) {
            return text != null ? text.length() * size * 0.5f : 0f;
        }
    }



    private void drawHeart(MatrixStack matrices, float cx, float cy, float size, boolean filled, Color color) {
        // Крупное сердце: геометрия + символ поверх для читаемости
        float s = size;
        float r = s * 0.42f;
        try {
            // левая и правая «доли»
            Render2D.drawRoundedRect(matrices, cx, cy, s * 0.58f, s * 0.58f, r, color);
            Render2D.drawRoundedRect(matrices, cx + s * 0.42f, cy, s * 0.58f, s * 0.58f, r, color);
            // низ (ромб-ish)
            Render2D.drawRoundedRect(matrices, cx + s * 0.12f, cy + s * 0.28f, s * 0.76f, s * 0.55f, s * 0.2f, color);
        } catch (Throwable ignored) {}
        try {
            // Символ — всегда видно
            String sym = filled ? "❤" : "♡";
            float fs = Math.max(9f, s * 0.95f);
            float tw = Fonts.MEDIUM.getWidth(sym, fs);
            drawText(matrices, sym, cx + (s - tw) * 0.5f, cy + s * 0.05f, fs, color);
        } catch (Throwable t) {
            try {
                drawText(matrices, filled ? "<3" : "<>", cx, cy + 1f, Math.max(8f, s * 0.7f), color);
            } catch (Throwable ignored) {}
        }
    }

    private static final String[] GAME_IDS = {"snake2", "tetris", "pong", "arkanoid", "space-shooter"};
    private static final Identifier[] GAME_ICONS = {
            Identifier.of("batvisuals", "hud/game_snake.png"),
            Identifier.of("batvisuals", "hud/game_tetris.png"),
            Identifier.of("batvisuals", "hud/game_pong.png"),
            Identifier.of("batvisuals", "hud/game_arkanoid.png"),
            Identifier.of("batvisuals", "hud/game_space_shooter.png")
    };
    private static final String[] GAME_NAMES = {"Snake", "Tetris", "Pong", "Arkanoid", "Space Shooter"};
    private static final String[] GAME_DESCS = {
            "Классическая змейка",
            "Собери линии из блоков",
            "Отбивай мяч ракеткой",
            "Разбей все кирпичи",
            "Уничтожай инопланетян"
    };

    private void renderGamesPanel(MatrixStack matrices, float x, float contentY, float w,
                                  int mouseX, int mouseY, Color accent, float alpha) {
        float scroll = state.getGridScroll(Category.Games);
        float y = contentY + 8f + scroll;

        drawText(matrices, "Мини-игры (HTML)", x, y, 7.5f, withAlpha(Color.WHITE, (int) (255 * alpha)));
        y += 16f;
        drawText(matrices, "Нажми «Играть» — откроется окно 16:9", x, y, 6f,
                withAlpha(new Color(150, 155, 170), (int) (255 * alpha)));
        y += 18f;

        float rowH = 44f;
        for (int i = 0; i < GAME_IDS.length; i++) {
            boolean hover = ClickGuiLayout.isHovered(mouseX, mouseY, x, y, w, rowH);
            Render2D.drawRoundedRect(matrices, x, y, w, rowH, 6f,
                    withAlpha(hover ? new Color(36, 38, 48) : new Color(26, 28, 36), (int) (230 * alpha)));

            float iconSz = 34f;
            float ix = x + 8f;
            float iy = y + (rowH - iconSz) / 2f;
            Render2D.drawTexture(matrices, ix, iy, iconSz, iconSz, 6f, GAME_ICONS[i],
                    withAlpha(Color.WHITE, (int) (255 * alpha)));

            drawText(matrices, GAME_NAMES[i], ix + iconSz + 10f, y + 10f, 8f, withAlpha(Color.WHITE, (int) (255 * alpha)));
            drawText(matrices, GAME_DESCS[i], ix + iconSz + 10f, y + 24f, 6f,
                    withAlpha(new Color(150, 155, 170), (int) (255 * alpha)));

            float btnW = 56f;
            float btnH = 22f;
            float bx = x + w - btnW - 10f;
            float by = y + (rowH - btnH) / 2f;
            boolean btnHover = ClickGuiLayout.isHovered(mouseX, mouseY, bx, by, btnW, btnH);
            Render2D.drawRoundedRect(matrices, bx, by, btnW, btnH, 5f,
                    withAlpha(btnHover ? accent : new Color(45, 50, 65), (int) (240 * alpha)));
            drawText(matrices, "Играть", bx + 10f, by + 6f, 7f, withAlpha(Color.WHITE, (int) (255 * alpha)));

            y += rowH + 6f;
        }
    }

    private void renderProfilePanel(MatrixStack matrices, DrawContext context,
                                    float x, float contentY, float w,
                                    int mouseX, int mouseY, Color accent, float alpha) {
        float pad = 12f;
        float cx = x + pad;
        float cy = contentY + pad;
        net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();

        float head = 40f;
        try {
            if (mc.player != null) {
                // Только голова скина (не всё тело)
                net.minecraft.client.gui.PlayerSkinDrawer.draw(
                        context,
                        mc.player.getSkinTextures(),
                        (int) cx, (int) cy, (int) head);
            } else {
                Render2D.drawRoundedRect(matrices, cx, cy, head, head, 6f,
                        withAlpha(new Color(40, 40, 48), (int) (230 * alpha)));
            }
        } catch (Throwable ignored) {
            Render2D.drawRoundedRect(matrices, cx, cy, head, head, 6f,
                    withAlpha(new Color(40, 40, 48), (int) (230 * alpha)));
        }

        float tx = cx + head + 10f;
        String nick = "Гость";
        try {
            if (mc.player != null) nick = mc.player.getGameProfile().getName();
        } catch (Throwable ignored) {}
        drawText(matrices, nick, tx, cy + 4f, 9f, withAlpha(Color.WHITE, (int) (255 * alpha)));
        drawText(matrices, "Аккаунт: Гость", tx, cy + 18f, 6.5f, withAlpha(new Color(160, 165, 180), (int) (230 * alpha)));

        String server = "Оффлайн";
        try {
            if (mc.getCurrentServerEntry() != null) {
                server = mc.getCurrentServerEntry().address;
            } else if (mc.isInSingleplayer()) {
                server = "Одиночная игра";
            }
        } catch (Throwable ignored) {}
        drawText(matrices, "Сервер: " + server, tx, cy + 30f, 6.5f, withAlpha(new Color(160, 165, 180), (int) (230 * alpha)));

        int online = 0;
        try {
            var fb = batvisuals.getInstance().getFirebaseManager();
            if (fb != null) online = fb.getOnlineCount();
        } catch (Throwable ignored) {}
        drawText(matrices, "Общий онлайн: " + online, tx, cy + 40f, 6.5f,
                withAlpha(new Color(160, 165, 180), (int) (230 * alpha)));

        float rowY = cy + head + 28f;
        drawText(matrices, "HWID", cx, rowY, 7f, withAlpha(new Color(180, 185, 200), (int) (230 * alpha)));
        String hwid = dev.batvisuals.client.util.HwidUtil.getHwid();
        drawText(matrices, hwid, cx, rowY + 14f, 7.5f, withAlpha(Color.WHITE, (int) (255 * alpha)));

        float btnW = 90f;
        float btnH = 18f;
        float btnX = cx;
        float btnY = rowY + 32f;
        boolean hov = ClickGuiLayout.isHovered(mouseX, mouseY, btnX, btnY, btnW, btnH);
        Render2D.drawRoundedRect(matrices, btnX, btnY, btnW, btnH, 5f,
                withAlpha(hov ? accent : new Color(40, 42, 52), (int) ((hov ? 220 : 200) * alpha)));
        String copy = "Скопировать";
        float tw = Fonts.REGULAR.getWidth(copy, 6.5f);
        drawText(matrices, copy, btnX + (btnW - tw) / 2f, btnY + 5f, 6.5f,
                withAlpha(Color.WHITE, (int) (255 * alpha)));
        state.profileCopyBtnX = btnX;
        state.profileCopyBtnY = btnY;
        state.profileCopyBtnW = btnW;
        state.profileCopyBtnH = btnH;
    }

}
