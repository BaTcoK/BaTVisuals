package dev.batvisuals.client.ui.clickgui.wonderful;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.managers.FriendsManager;
import dev.batvisuals.client.managers.WaypointManager;
import net.minecraft.util.math.Vec3d;
import dev.batvisuals.client.managers.ThemeManager;

import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.impl.utility.ClientSound;
import dev.batvisuals.modules.settings.Setting;
import dev.batvisuals.modules.settings.api.Bind;
import dev.batvisuals.modules.settings.impl.*;
import net.minecraft.client.util.Window;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class ClickGuiInputHandler {

    private final ClickGuiState state;

    private NumberSetting draggingSlider;
    private float draggingSliderX;
    private float draggingSliderW;

    private boolean draggingGui;
    private double dragOffsetX;
    private double dragOffsetY;

    public ClickGuiInputHandler(ClickGuiState state) {
        this.state = state;
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button, Window window) {
        if (window == null) return false;
        float guiX = state.getX();
        float guiY = state.getY() + state.getRenderOffsetY();

        // Module bind via mouse buttons (MMB+)
        if (state.getBindingModule() != null && button >= 0) {
            if (button == GLFW.GLFW_MOUSE_BUTTON_MIDDLE || button >= 2) {
                state.getBindingModule().setBind(new Bind(button, true));
                state.setBindingModule(null);
                return true;
            }
        }
        if (state.getBindingSetting() instanceof BindSetting bs && button >= 0) {
            if (button == GLFW.GLFW_MOUSE_BUTTON_MIDDLE || button >= 2) {
                bs.setValue(new Bind(button, true));
                state.setBindingSetting(null);
                return true;
            }
        }

        // Search
        float mainX = ClickGuiLayout.getMainX(guiX);
        float searchX = mainX + ClickGuiLayout.MAIN_WIDTH - ClickGuiLayout.SEARCH_WIDTH - 8f;
        float searchY = guiY + (ClickGuiLayout.MAIN_HEADER_HEIGHT - ClickGuiLayout.SEARCH_HEIGHT) / 2f;
        if (button == 0 && ClickGuiLayout.isHovered(mouseX, mouseY, searchX, searchY, ClickGuiLayout.SEARCH_WIDTH, ClickGuiLayout.SEARCH_HEIGHT)) {
            state.setSearchActive(true);
            state.setSearchCursor(state.getSearchText().length());
            return true;
        }
        if (button == 0 && state.isSearchActive()) {
            state.setSearchActive(false);
        }

        // Sidebar categories
        float sidebarX = ClickGuiLayout.getSidebarX(guiX);
        float pad = ClickGuiLayout.SIDEBAR_PADDING;
        float innerW = ClickGuiLayout.SIDEBAR_WIDTH - pad * 2f;
        float itemY = guiY + ClickGuiLayout.PROFILE_HEIGHT + ClickGuiLayout.SIDEBAR_SECTION_GAP + state.getSidebarScroll();
        float listTop = guiY + ClickGuiLayout.PROFILE_HEIGHT + ClickGuiLayout.SIDEBAR_SECTION_GAP;
        float listBottom = guiY + ClickGuiLayout.HEIGHT - 6f;
        for (Category category : ClickGuiLayout.getVisibleCategories()) {
            if (itemY + ClickGuiLayout.SIDEBAR_ITEM_HEIGHT < listTop || itemY > listBottom) {
                itemY += ClickGuiLayout.SIDEBAR_ITEM_HEIGHT + ClickGuiLayout.SIDEBAR_ITEM_GAP;
                continue;
            }
            if (button == 0 && ClickGuiLayout.isHovered(mouseX, mouseY, sidebarX + pad, itemY, innerW, ClickGuiLayout.SIDEBAR_ITEM_HEIGHT)) {
                state.setSelectedCategory(category);
                ClientSound.playUiClick();
                return true;
            }
            itemY += ClickGuiLayout.SIDEBAR_ITEM_HEIGHT + ClickGuiLayout.SIDEBAR_ITEM_GAP;
        }

        // Profile copy HWID
        if (button == 0 && state.getSelectedCategory() == Category.Profile) {
            if (ClickGuiLayout.isHovered(mouseX, mouseY,
                    state.profileCopyBtnX, state.profileCopyBtnY,
                    state.profileCopyBtnW, state.profileCopyBtnH)) {
                try {
                    net.minecraft.client.MinecraftClient.getInstance().keyboard.setClipboard(dev.batvisuals.client.util.HwidUtil.getHwid());
                } catch (Throwable ignored) {}
                return true;
            }
        }

        // Module grid / special panels
        float contentY = guiY + ClickGuiLayout.MAIN_HEADER_HEIGHT;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, mainX, contentY, ClickGuiLayout.MAIN_WIDTH, ClickGuiLayout.getGridViewHeight())) {
            Category category = state.getSelectedCategory();
            if (category == Category.Theme) {
                if (button == 0) handleThemeClick(mouseX, mouseY, mainX, contentY);
                return true;
            }
            if (category == Category.Friends) {
                if (button == 0) handleFriendsClick(mouseX, mouseY, mainX, contentY);
                return true;
            }
            if (category == Category.Gps) {
                if (button == 0) handleGpsClick(mouseX, mouseY, mainX, contentY);
                return true;
            }
            if (category == Category.Music) {
                if (button == 0) handleMusicClick(mouseX, mouseY, mainX, contentY);
                return true;
            }
            if (category == Category.Games) {
                if (button == 0) handleGamesClick(mouseX, mouseY, mainX, contentY);
                return true;
            }
            if (category == Category.Config) {
                if (button == 0) handleConfigClick(mouseX, mouseY, mainX, contentY);
                return true;
            }
            List<Module> modules = state.getModules(category);
            float cardW = ClickGuiLayout.getCardWidth();
            float scroll = state.getGridScroll(category);
            float gridTop = contentY + ClickGuiLayout.MAIN_PADDING / 2f;

            for (ClickGuiLayout.CardPos pos : ClickGuiLayout.layoutCards(modules, cardW)) {
                Module module = pos.module();
                float cardX = mainX + ClickGuiLayout.MAIN_PADDING + pos.column() * (cardW + ClickGuiLayout.CARD_GAP);
                float cardY = gridTop + pos.offsetY() + scroll;
                float cardH = pos.height();
                if (!ClickGuiLayout.isHovered(mouseX, mouseY, cardX, cardY, cardW, cardH)) continue;

                // Сердце (избранное) — слева
                float heartX = cardX + 4f;
                float heartY = cardY + 2f;
                float heartS = 18f;
                if (button == 0 && ClickGuiLayout.isHovered(mouseX, mouseY, heartX, heartY, heartS, heartS)) {
                    dev.batvisuals.client.managers.FavoritesManager.toggle(module.getName());
                    ClientSound.playUiClick();
                    return true;
                }

                // Toggle switch справа
                float toggleW = 22f;
                float toggleH = 14f;
                if (button == 0 && ClickGuiLayout.isHovered(mouseX, mouseY, cardX + cardW - toggleW - 4f, cardY + 2f, toggleW + 2f, toggleH)) {
                    module.toggle();
                    ClientSound.playUiClick();
                    return true;
                }

                // MMB — bind (не трогаем)
                if (button == 2) {
                    state.setBindingModule(module);
                    return true;
                }

                // ПКМ — настройки
                if (button == 1) {
                    if (ClickGuiLayout.hasVisibleSettings(module)) {
                        state.setSelectedModule(module);
                        ClientSound.playUiClickAlt();
                    }
                    return true;
                }

                // ЛКМ по карточке — вкл/выкл модуля
                if (button == 0) {
                    module.toggle();
                    ClientSound.playUiClick();
                    return true;
                }
                return true;
            }
            return tryStartDrag(mouseX, mouseY, button);
        }

        // Settings panel
        Module selected = state.getSelectedModule();
        if (selected != null) {
            float settingsX = ClickGuiLayout.getSettingsX(guiX);
            float settingsContentY = guiY + ClickGuiLayout.SETTINGS_HEADER_HEIGHT;
            if (ClickGuiLayout.isHovered(mouseX, mouseY, settingsX, guiY, ClickGuiLayout.SETTINGS_WIDTH, ClickGuiLayout.HEIGHT)) {
                if (mouseY < settingsContentY) {
                    return tryStartDrag(mouseX, mouseY, button);
                }
                return handleSettingClick(mouseX, mouseY, button,
                        settingsX + ClickGuiLayout.SETTINGS_PADDING,
                        settingsContentY + state.getSettingsScroll(),
                        ClickGuiLayout.getSettingsInnerWidth(),
                        selected.getSettings());
            }
        }

        if (isOverAnyPanel(mouseX, mouseY, guiX, guiY)) {
            return tryStartDrag(mouseX, mouseY, button);
        }

        return false;
    }

    private boolean isOverAnyPanel(double mouseX, double mouseY, float guiX, float guiY) {
        if (ClickGuiLayout.isHovered(mouseX, mouseY, ClickGuiLayout.getSidebarX(guiX), guiY,
                ClickGuiLayout.SIDEBAR_WIDTH, ClickGuiLayout.HEIGHT)) return true;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, ClickGuiLayout.getMainX(guiX), guiY,
                ClickGuiLayout.MAIN_WIDTH, ClickGuiLayout.HEIGHT)) return true;
        return state.getSelectedModule() != null
                && ClickGuiLayout.isHovered(mouseX, mouseY, ClickGuiLayout.getSettingsX(guiX), guiY,
                ClickGuiLayout.SETTINGS_WIDTH, ClickGuiLayout.HEIGHT);
    }



    private boolean isSkippedTheme(String name) {
        if (name == null) return true;
        String low = name.toLowerCase();
        return low.contains("purple") || low.contains("серая") || low.contains("серый")
                || low.equals("gray") || low.equals("grey");
    }


    private void handleFriendsClick(double mouseX, double mouseY, float mainX, float contentY) {
        float x = mainX + 8f;
        float w = ClickGuiLayout.MAIN_WIDTH - 16f;
        float y = contentY + state.getFriendsListScroll() + 12f;
        float fieldH = 18f;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, x, y, w, fieldH)) { state.startFriendsNick(); return; }
        y += fieldH + 4f;

        // Suggestions click
        String nickQ = state.getFriendsNickBuffer() == null ? "" : state.getFriendsNickBuffer();
        java.util.List<String> suggestions = collectOnlineSuggestions(nickQ);
        if (state.isFriendsNickActive() && !suggestions.isEmpty()) {
            int maxVisible = 5;
            int scroll = state.getFriendsSuggestScroll();
            if (scroll > Math.max(0, suggestions.size() - maxVisible)) scroll = Math.max(0, suggestions.size() - maxVisible);
            float sugH = 16f;
            int visible = Math.min(maxVisible, suggestions.size() - scroll);
            float boxH = visible * sugH + 4f;
            for (int i = 0; i < visible; i++) {
                float sy = y + 2f + i * sugH;
                if (ClickGuiLayout.isHovered(mouseX, mouseY, x + 2f, sy, w - 4f, sugH)) {
                    String pick = suggestions.get(scroll + i);
                    FriendsManager.addFriend(pick);
                    state.setFriendsNickBuffer("");
                    state.clearFriendsNick();
                    return;
                }
            }
            y += boxH + 6f;
        } else {
            y += 4f;
        }

        float btnW = (w - 6f) / 2f;
        float btnH = 20f;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, x, y, btnW, btnH)) {
            String nick = state.getFriendsNickBuffer().trim();
            if (!nick.isEmpty()) { FriendsManager.addFriend(nick); state.setFriendsNickBuffer(""); state.clearFriendsNick(); }
            return;
        }
        if (ClickGuiLayout.isHovered(mouseX, mouseY, x + btnW + 6f, y, btnW, btnH)) { FriendsManager.clear(); return; }
        y += btnH + 12f + 14f;
        float rowH = 28f, delW = 44f;
        for (FriendsManager.FriendEntry fr : new java.util.ArrayList<>(FriendsManager.getFriendEntries())) {
            if (ClickGuiLayout.isHovered(mouseX, mouseY, x + w - delW - 4f, y + 4f, delW, rowH - 8f)) {
                FriendsManager.removeFriendEntry(fr); return;
            }
            y += rowH + 4f;
        }
        state.clearFriendsNick();
    }

    private java.util.List<String> collectOnlineSuggestions(String query) {
        java.util.List<String> out = new java.util.ArrayList<>();
        try {
            var mc = net.minecraft.client.MinecraftClient.getInstance();
            if (mc == null || mc.getNetworkHandler() == null) return out;
            String q = query == null ? "" : query.trim().toLowerCase();
            String self = mc.player != null ? mc.player.getGameProfile().getName() : null;
            for (var entry : mc.getNetworkHandler().getPlayerList()) {
                if (entry == null || entry.getProfile() == null) continue;
                String name = entry.getProfile().getName();
                if (name == null || name.isEmpty()) continue;
                if (self != null && name.equalsIgnoreCase(self)) continue;
                if (FriendsManager.checkFriend(name)) continue;
                if (!q.isEmpty() && !name.toLowerCase().startsWith(q)) continue;
                out.add(name);
            }
            out.sort(String.CASE_INSENSITIVE_ORDER);
        } catch (Throwable ignored) {}
        return out;
    }


    private static final String[] GAME_IDS = {"snake2", "tetris", "pong", "arkanoid", "space-shooter"};
    private static final String[] GAME_NAMES = {"Snake", "Tetris", "Pong", "Arkanoid", "Space Shooter"};

    private void handleGamesClick(double mouseX, double mouseY, float mainX, float contentY) {
        float x = mainX + 8f;
        float w = ClickGuiLayout.MAIN_WIDTH - 16f;
        float scroll = state.getGridScroll(Category.Games);
        float y = contentY + 8f + scroll + 16f + 18f;

        float rowH = 44f;
        for (int i = 0; i < GAME_IDS.length; i++) {
            float btnW = 56f;
            float btnH = 22f;
            float bx = x + w - btnW - 10f;
            float by = y + (rowH - btnH) / 2f;
            if (ClickGuiLayout.isHovered(mouseX, mouseY, bx, by, btnW, btnH)) {
                openGame(GAME_IDS[i], GAME_NAMES[i]);
                return;
            }
            y += rowH + 6f;
        }
    }

    private void openGame(String gameId, String gameName) {
        try {
            net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
            if (mc != null) {
                mc.setScreen(new dev.batvisuals.client.ui.games.GameTabletScreen(gameId, gameName));
            }
        } catch (Throwable ignored) {}
    }

    private void handleGpsClick(double mouseX, double mouseY, float mainX, float contentY) {
        float x = mainX + 8f;
        float w = ClickGuiLayout.MAIN_WIDTH - 16f;
        float y = contentY + state.getGpsListScroll();
        // Авто Ивент checkbox
        float box = 12f;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, x, y, w, box + 4f)) {
            dev.batvisuals.client.managers.WaypointManager.setAutoEvent(
                    !dev.batvisuals.client.managers.WaypointManager.isAutoEvent());
            return;
        }
        y += box + 10f + 12f; // checkbox + context line
        float fieldH = 18f;
        y += 12f; // "Waypoint name" label
        if (ClickGuiLayout.isHovered(mouseX, mouseY, x, y, w, fieldH)) { state.startGpsName(); return; }
        y += fieldH + 6f + 11f;
        float half = (w - 6f) / 2f;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, x, y, half, fieldH)) { state.startGpsX(); return; }
        if (ClickGuiLayout.isHovered(mouseX, mouseY, x + half + 6f, y, half, fieldH)) { state.startGpsZ(); return; }
        y += fieldH + 8f;
        float btnW = (w - 6f) / 2f;
        float btnH = 20f;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, x, y, btnW, btnH)) {
            try {
                String name = state.getGpsNameBuffer().trim();
                double gx = Double.parseDouble(state.getGpsXBuffer().trim().replace(',', '.'));
                double gz = Double.parseDouble(state.getGpsZBuffer().trim().replace(',', '.'));
                if (!name.isEmpty()) {
                    double gy = 64;
                    try {
                        if (net.minecraft.client.MinecraftClient.getInstance().player != null)
                            gy = net.minecraft.client.MinecraftClient.getInstance().player.getY();
                    } catch (Throwable ignored) {}
                    WaypointManager.add(name, new Vec3d(gx + 0.5, gy, gz + 0.5));
                    state.setGpsNameBuffer(""); state.setGpsXBuffer(""); state.setGpsZBuffer(""); state.clearGpsFocus();
                }
            } catch (Exception ignored) {}
            return;
        }
        if (ClickGuiLayout.isHovered(mouseX, mouseY, x + btnW + 6f, y, btnW, btnH)) { WaypointManager.clear(); return; }
        y += btnH + 12f + 14f;
        float rowH = 24f, delW = 44f;
        for (var wp : new java.util.ArrayList<>(WaypointManager.list())) {
            if (ClickGuiLayout.isHovered(mouseX, mouseY, x + w - delW - 4f, y + 3f, delW, rowH - 6f)) {
                WaypointManager.remove(wp.name); return;
            }
            y += rowH + 4f;
        }
        state.clearGpsFocus();
    }

    private void handleThemeClick(double mouseX, double mouseY, float mainX, float contentY) {
        try {
            ThemeManager tm = ThemeManager.getInstance();
            ThemeManager.Theme[] arr = tm.getAvailableThemes();
            if (arr == null) return;
            float pad = ClickGuiLayout.MAIN_PADDING;
            float scroll = state.getGridScroll(Category.Theme);
            float y = contentY + pad / 2f + scroll + 14f;
            float innerW = ClickGuiLayout.MAIN_WIDTH - pad * 2f;
            float cardW = (innerW - 6f) / 2f;
            float cardH = 28f;
            float col0 = mainX + pad;
            float col1 = mainX + pad + cardW + 6f;
            float y0 = y, y1 = y;
            int drawn = 0;
            for (ThemeManager.Theme theme : arr) {
                String name = theme.getName();
                if (isSkippedTheme(name)) continue;
                boolean left = (drawn % 2) == 0;
                float cx = left ? col0 : col1;
                float cy = left ? y0 : y1;
                if (ClickGuiLayout.isHovered(mouseX, mouseY, cx, cy, cardW, cardH)) {
                    tm.setTheme(theme);
                    return;
                }
                if (left) y0 += cardH + 6f; else y1 += cardH + 6f;
                drawn++;
            }
        } catch (Throwable ignored) {}
    }

    private void handleConfigClick(double mouseX, double mouseY, float mainX, float contentY) {
        try {
            float pad = ClickGuiLayout.MAIN_PADDING;
            float scroll = state.getGridScroll(Category.Config);
            float y = contentY + pad / 2f + scroll + 14f;
            float innerW = ClickGuiLayout.MAIN_WIDTH - pad * 2f;
            float btnH = 18f;

            // create/save default
            if (ClickGuiLayout.isHovered(mouseX, mouseY, mainX + pad, y, innerW, btnH)) {
                if (state.isConfigCreateActive()) {
                    // already typing — ignore click on button
                    return;
                }
                state.startConfigCreate();
                return;
            }
            y += btnH + 8f;

            if (state.isConfigRenameActive()) {
                y += 18f + 6f;
            }

            String[] configs = batvisuals.getInstance().getConfigManager().getConfigList();
            if (configs == null) return;
            for (String cfg : configs) {
                float rowH = 22f;
                float actW = 28f;
                float actH = 14f;
                float delX = mainX + pad + innerW - actW - 6f;
                float renX = delX - actW - 4f;
                float actY = y + (rowH - actH) / 2f;

                if (ClickGuiLayout.isHovered(mouseX, mouseY, delX, actY, actW, actH)) {
                    batvisuals.getInstance().getConfigManager().deleteConfig(cfg);
                    if (state.isConfigRenameActive() && cfg.equals(state.getConfigRenameTarget())) {
                        state.clearConfigRename();
                    }
                    return;
                }
                if (ClickGuiLayout.isHovered(mouseX, mouseY, renX, actY, actW, actH)) {
                    state.startConfigRename(cfg);
                    return;
                }
                // click row body -> load
                if (ClickGuiLayout.isHovered(mouseX, mouseY, mainX + pad, y, innerW - 70f, rowH)) {
                    batvisuals.getInstance().getConfigManager().loadConfig(cfg);
                    return;
                }
                y += rowH + 4f;
            }
        } catch (Throwable ignored) {}
    }

    private boolean tryStartDrag(double mouseX, double mouseY, int button) {
        // GUI is static — dragging disabled
        return true;
    }

    private boolean handleSettingClick(double mouseX, double mouseY, int button, float x, float startY, float width,
                                       List<Setting<?>> settings) {
        if (settings == null) return true;
        float y = startY;
        List<Setting<?>> visible = settings.stream().filter(Setting::isVisible).toList();
        for (int i = 0; i < visible.size(); i++) {
            Setting<?> setting = visible.get(i);

            if (setting instanceof BooleanSetting booleanSetting) {
                if (ClickGuiLayout.isHovered(mouseX, mouseY, x, y - 1, width, 12)) {
                    if (button == 0) {
                        booleanSetting.setValue(!Boolean.TRUE.equals(booleanSetting.getValue()));
                        ClientSound.playUiClick();
                        return true;
                    }
                }
            } else if (setting instanceof NumberSetting numberSetting) {
                if (button == 0 && ClickGuiLayout.isHovered(mouseX, mouseY, x, y + 9, width, 8)) {
                    numberSetting.setValue(state.getSliderValue(numberSetting, x, mouseX, width));
                    draggingSlider = numberSetting;
                    draggingSliderX = x;
                    draggingSliderW = width;
                    ClientSound.playUiSlider();
                    state.setDraggingSlider(numberSetting);
                    return true;
                }
            } else if (setting instanceof EnumSetting<?> enumSetting) {
                float cx = x, cy = y + 9f, rowH = 11f;
                Enum<?>[] vals = enumSetting.getValue().getClass().getEnumConstants();
                if (vals != null) {
                    for (Enum<?> val : vals) {
                        String name = val instanceof dev.batvisuals.modules.settings.api.Nameable n ? n.getName() : val.name();
                        float chipW = (dev.batvisuals.client.util.renderer.fonts.Fonts.REGULAR != null
                                ? dev.batvisuals.client.util.renderer.fonts.Fonts.REGULAR.getWidth(name, 6f)
                                : name.length() * 3.5f) + ClickGuiLayout.CHIP_PADDING_X * 2f;
                        if (cx + chipW > x + width && cx > x) {
                            cx = x;
                            cy += rowH + ClickGuiLayout.CHIP_GAP_Y;
                        }
                        if (button == 0 && ClickGuiLayout.isHovered(mouseX, mouseY, cx, cy, chipW, rowH)) {
                            @SuppressWarnings({"unchecked", "rawtypes"})
                            EnumSetting raw = (EnumSetting) enumSetting;
                            raw.setValue(val);
                            return true;
                        }
                        cx += chipW + ClickGuiLayout.CHIP_GAP_X;
                    }
                }
            } else if (setting instanceof BindSetting bindSetting) {
                if (button == 0 && ClickGuiLayout.isHovered(mouseX, mouseY, x, y - 1, width, 12)) {
                    state.setBindingSetting(bindSetting);
                    return true;
                }
            } else if (setting instanceof StringSetting stringSetting) {
                if (button == 0 && ClickGuiLayout.isHovered(mouseX, mouseY, x, y + 9, width, 11)) {
                    state.setEditingStringSetting(stringSetting);
                    return true;
                }
            } else if (setting instanceof ListSetting listSetting) {
                if (button == 0 && listSetting.getValue() != null) {
                    float cx = x, cy = y + 9f, rowH = 11f;
                    for (BooleanSetting opt : listSetting.getValue()) {
                        String name = ClickGuiLayout.chipLabel(opt.getName());
                        float chipW = (dev.batvisuals.client.util.renderer.fonts.Fonts.REGULAR != null
                                ? dev.batvisuals.client.util.renderer.fonts.Fonts.REGULAR.getWidth(name, 6f)
                                : name.length() * 3.5f) + ClickGuiLayout.CHIP_PADDING_X * 2f;
                        if (cx + chipW > x + width && cx > x) {
                            cx = x;
                            cy += rowH + ClickGuiLayout.CHIP_GAP_Y;
                        }
                        if (ClickGuiLayout.isHovered(mouseX, mouseY, cx, cy, chipW, rowH)) {
                            if (listSetting.isSingleSelect()) {
                                for (BooleanSetting o : listSetting.getValue()) {
                                    o.setValue(o == opt);
                                }
                            } else {
                                opt.setValue(!Boolean.TRUE.equals(opt.getValue()));
                            }
                            return true;
                        }
                        cx += chipW + ClickGuiLayout.CHIP_GAP_X;
                    }
                }
            }

            y += ClickGuiLayout.getSettingHeight(setting, width);
            if (i < visible.size() - 1) y += ClickGuiLayout.SETTING_GAP;
        }
        return true;
    }


    private void tryCommitUiScale(NumberSetting slider) {
        try {
            dev.batvisuals.modules.impl.render.UI ui =
                    dev.batvisuals.batvisuals.getInstance().getModuleManager()
                            .getModule(dev.batvisuals.modules.impl.render.UI.class);
            if (ui != null && slider == ui.getGuiScaleSetting()) {
                ui.commitGuiScale();
            }
        } catch (Throwable ignored) {}
    }

    public boolean mouseReleased(int button) {
        if (button == 0) {
            if (draggingGui) {
                draggingGui = false;
                return true;
            }
            if (draggingSlider != null) {
                // Apply GUI Scale only on release (UI module only)
                tryCommitUiScale(draggingSlider);
                state.setDraggingSlider(null);
                draggingSlider = null;
                return true;
            }
        }
        return false;
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button) {
        if (button != 0) return false;
        // draggingGui disabled
        if (false && draggingGui) {
            return true;
        }
        if (draggingSlider != null) {
            draggingSlider.setValue(state.getSliderValue(draggingSlider, draggingSliderX, mouseX, draggingSliderW));
            ClientSound.playUiSlider();
            return true;
        }
        return false;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double verticalAmount) {
        float guiX = state.getX();
        float guiY = state.getY() + state.getRenderOffsetY();

        // sidebar category list scroll
        float sidebarX = guiX;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, sidebarX, guiY, ClickGuiLayout.SIDEBAR_WIDTH, ClickGuiLayout.HEIGHT)) {
            state.addSidebarScroll((float) (verticalAmount * 18f));
            return true;
        }

        float mainX = ClickGuiLayout.getMainX(guiX);
        float contentY = guiY + ClickGuiLayout.MAIN_HEADER_HEIGHT;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, mainX, contentY, ClickGuiLayout.MAIN_WIDTH, ClickGuiLayout.getGridViewHeight())) {
            if (state.getSelectedCategory() == Category.Friends) {
                if (state.isFriendsNickActive()) {
                    state.addFriendsSuggestScroll(verticalAmount < 0 ? 1 : -1);
                    return true;
                }
                state.addFriendsListScroll(verticalAmount);
                return true;
            }
            if (state.getSelectedCategory() == Category.Gps) {
                state.addGpsListScroll(verticalAmount);
                return true;
            }
            // Music / Theme / modules — общий скролл сетки
            state.addGridScroll(state.getSelectedCategory(), verticalAmount);
            return true;
        }

        float settingsX = ClickGuiLayout.getSettingsX(guiX);
        if (state.getSelectedModule() != null
                && ClickGuiLayout.isHovered(mouseX, mouseY, settingsX, guiY, ClickGuiLayout.SETTINGS_WIDTH, ClickGuiLayout.HEIGHT)) {
            state.addSettingsScroll(verticalAmount);
            return true;
        }
        return false;
    }

    public boolean charTyped(char chr, int modifiers) {

        if (state.isConfigCreateActive()) {
            if (Character.isISOControl(chr)) return false;
            String buf = state.getConfigCreateBuffer();
            if (buf.length() >= 24) return true;
            state.setConfigCreateBuffer(buf + chr);
            return true;
        }

        if (state.isFriendsNickActive()) {
            if (chr >= 32 && chr != 127) {
                String buf = state.getFriendsNickBuffer();
                if (buf.length() < 24) state.setFriendsNickBuffer(buf + chr);
            }
            return true;
        }
        if (state.isGpsNameActive()) {
            if (chr >= 32 && chr != 127) {
                String buf = state.getGpsNameBuffer();
                if (buf.length() < 24) state.setGpsNameBuffer(buf + chr);
            }
            return true;
        }
        if (state.isGpsXActive() || state.isGpsZActive()) {
            if ((chr >= '0' && chr <= '9') || chr == '-' || chr == '.' || chr == ',') {
                if (state.isGpsXActive()) {
                    String buf = state.getGpsXBuffer();
                    if (buf.length() < 12) state.setGpsXBuffer(buf + chr);
                } else {
                    String buf = state.getGpsZBuffer();
                    if (buf.length() < 12) state.setGpsZBuffer(buf + chr);
                }
            }
            return true;
        }
        if (state.isConfigRenameActive()) {
            if (Character.isISOControl(chr)) return false;
            String buf = state.getConfigRenameBuffer();
            if (buf.length() >= 24) return true;
            state.setConfigRenameBuffer(buf + chr);
            return true;
        }
        if (state.getEditingStringSetting() != null) {
            if (Character.isISOControl(chr)) return false;
            StringSetting setting = state.getEditingStringSetting();
            String text = setting.getValue() == null ? "" : setting.getValue();
            int cursor = Math.max(0, Math.min(state.getStringCursor(), text.length()));
            setting.setValue(text.substring(0, cursor) + chr + text.substring(cursor));
            state.setStringCursor(cursor + 1);
            return true;
        }

        if (!state.isSearchActive() || Character.isISOControl(chr)) return false;
        String text = state.getSearchText();
        if (text.length() >= ClickGuiLayout.SEARCH_MAX_CHARS) return true;
        int cursor = Math.max(0, Math.min(state.getSearchCursor(), text.length()));
        state.setSearchText(text.substring(0, cursor) + chr + text.substring(cursor));
        state.setSearchCursor(cursor + 1);
        return true;
    }

    public boolean keyPressed(int keyCode, int modifiers) {
        if (state.isFriendsNickActive()) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) { state.clearFriendsNick(); return true; }
            if (keyCode == GLFW.GLFW_KEY_ENTER) {
                String nick = state.getFriendsNickBuffer().trim();
                if (!nick.isEmpty()) FriendsManager.addFriend(nick);
                state.setFriendsNickBuffer("");
                state.clearFriendsNick();
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                String buf = state.getFriendsNickBuffer();
                if (!buf.isEmpty()) state.setFriendsNickBuffer(buf.substring(0, buf.length() - 1));
                return true;
            }
            return true;
        }
        if (state.isGpsNameActive() || state.isGpsXActive() || state.isGpsZActive()) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) { state.clearGpsFocus(); return true; }
            if (keyCode == GLFW.GLFW_KEY_ENTER) {
                try {
                    String name = state.getGpsNameBuffer().trim();
                    double gx = Double.parseDouble(state.getGpsXBuffer().trim().replace(',', '.'));
                    double gz = Double.parseDouble(state.getGpsZBuffer().trim().replace(',', '.'));
                    if (!name.isEmpty()) {
                        WaypointManager.add(name, new Vec3d(gx + 0.5, 60, gz + 0.5));
                        state.setGpsNameBuffer("");
                        state.setGpsXBuffer("");
                        state.setGpsZBuffer("");
                    }
                } catch (Exception ignored) {}
                state.clearGpsFocus();
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (state.isGpsNameActive()) {
                    String buf = state.getGpsNameBuffer();
                    if (!buf.isEmpty()) state.setGpsNameBuffer(buf.substring(0, buf.length() - 1));
                } else if (state.isGpsXActive()) {
                    String buf = state.getGpsXBuffer();
                    if (!buf.isEmpty()) state.setGpsXBuffer(buf.substring(0, buf.length() - 1));
                } else {
                    String buf = state.getGpsZBuffer();
                    if (!buf.isEmpty()) state.setGpsZBuffer(buf.substring(0, buf.length() - 1));
                }
                return true;
            }
            return true;
        }
        if (state.isConfigCreateActive()) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                state.clearConfigCreate();
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ENTER) {
                try {
                    String name = state.getConfigCreateBuffer();
                    if (name != null && !name.isBlank()) {
                        String safe = name.trim().replaceAll("[^a-zA-Z0-9_а-яА-ЯёЁ-]", "_");
                        if (!safe.isBlank()) {
                            batvisuals.getInstance().getConfigManager().saveConfig(safe);
                        }
                    }
                } catch (Throwable ignored) {}
                state.clearConfigCreate();
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                String buf = state.getConfigCreateBuffer();
                if (!buf.isEmpty()) state.setConfigCreateBuffer(buf.substring(0, buf.length() - 1));
                return true;
            }
            return true;
        }
        if (state.isConfigRenameActive()) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                state.clearConfigRename();
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ENTER) {
                try {
                    String oldName = state.getConfigRenameTarget();
                    String newName = state.getConfigRenameBuffer();
                    if (oldName != null && newName != null && !newName.isBlank() && !newName.equals(oldName)) {
                        batvisuals.getInstance().getConfigManager().renameConfig(oldName, newName.trim());
                    }
                } catch (Throwable ignored) {}
                state.clearConfigRename();
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                String buf = state.getConfigRenameBuffer();
                if (!buf.isEmpty()) state.setConfigRenameBuffer(buf.substring(0, buf.length() - 1));
                return true;
            }
            return true;
        }
        if (state.getEditingStringSetting() != null) {
            StringSetting setting = state.getEditingStringSetting();
            String text = setting.getValue() == null ? "" : setting.getValue();
            int cursor = Math.max(0, Math.min(state.getStringCursor(), text.length()));
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) {
                state.setEditingStringSetting(null);
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (cursor > 0) {
                    setting.setValue(text.substring(0, cursor - 1) + text.substring(cursor));
                    state.setStringCursor(cursor - 1);
                }
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_DELETE) {
                if (cursor < text.length()) setting.setValue(text.substring(0, cursor) + text.substring(cursor + 1));
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_LEFT) {
                state.setStringCursor(Math.max(0, cursor - 1));
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_RIGHT) {
                state.setStringCursor(Math.min(text.length(), cursor + 1));
                return true;
            }
            return true;
        }

        if (state.isSearchActive()) {
            String text = state.getSearchText();
            int cursor = Math.max(0, Math.min(state.getSearchCursor(), text.length()));
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) {
                state.setSearchActive(false);
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (cursor > 0) {
                    state.setSearchText(text.substring(0, cursor - 1) + text.substring(cursor));
                    state.setSearchCursor(cursor - 1);
                }
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_DELETE) {
                if (cursor < text.length()) state.setSearchText(text.substring(0, cursor) + text.substring(cursor + 1));
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_LEFT) {
                state.setSearchCursor(Math.max(0, cursor - 1));
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_RIGHT) {
                state.setSearchCursor(Math.min(text.length(), cursor + 1));
                return true;
            }
            return true;
        }

        if (state.getBindingModule() != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                state.setBindingModule(null);
            } else if (keyCode == GLFW.GLFW_KEY_DELETE || keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                state.getBindingModule().setBind(new Bind(-1, false));
                state.setBindingModule(null);
            } else {
                state.getBindingModule().setBind(new Bind(keyCode, false));
                state.setBindingModule(null);
            }
            return true;
        }

        if (state.getBindingSetting() instanceof BindSetting bs) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                state.setBindingSetting(null);
            } else if (keyCode == GLFW.GLFW_KEY_DELETE || keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                bs.setValue(new Bind(-1, false));
                state.setBindingSetting(null);
            } else {
                bs.setValue(new Bind(keyCode, false));
                state.setBindingSetting(null);
            }
            return true;
        }

        if (keyCode == GLFW.GLFW_KEY_ESCAPE && state.getSelectedModule() != null) {
            state.setSelectedModule(state.getSelectedModule()); // toggle off
            return true;
        }

        return false;
    }



    private void openExternalUrl(String url) {
        try {
            net.minecraft.util.Util.getOperatingSystem().open(java.net.URI.create(url));
        } catch (Throwable t) {
            try {
                java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));
            } catch (Throwable ignored) {}
        }
    }

    private void handleMusicClick(double mouseX, double mouseY, float mainX, float contentY) {
        float x = mainX + 8f;
        float w = ClickGuiLayout.MAIN_WIDTH - 16f;
        float scroll = state.getGridScroll(Category.Music);
        float y = contentY + 6f + scroll;

        float cardH = 52f;
        float av = 40f;
        float ax = x + 6f;
        float btn = 20f;
        float by = y + cardH - btn - 5f;
        float bx0 = ax + av + 8f;
        float gap = 5f;
        float bx = bx0;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, bx, by, btn, btn)) {
            dev.batvisuals.client.managers.MusicManager.prev();
            return;
        }
        bx += btn + gap;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, bx, by, btn, btn)) {
            dev.batvisuals.client.managers.MusicManager.playPause();
            return;
        }
        bx += btn + gap;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, bx, by, btn, btn)) {
            dev.batvisuals.client.managers.MusicManager.next();
            return;
        }
        bx += btn + gap;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, bx, by, btn, btn)) {
            dev.batvisuals.client.managers.MusicManager.stop();
            return;
        }
        y += cardH + 10f;

        // volume label + slider
        y += 11f;
        float trackH = 6f;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, x, y - 4f, w, trackH + 8f)) {
            float tt = (float) ((mouseX - x) / w);
            tt = Math.max(0f, Math.min(1f, tt));
            dev.batvisuals.client.managers.MusicManager.setVolume(tt);
            return;
        }
        y += trackH + 12f;

        float tH = 14f;
        float tGap = 4f;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, x, y, w, tH + 2f)) {
            dev.batvisuals.client.managers.MusicManager.setLoopTrack(
                    !dev.batvisuals.client.managers.MusicManager.isLoopTrack());
            return;
        }
        y += tH + tGap;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, x, y, w, tH + 2f)) {
            dev.batvisuals.client.managers.MusicManager.setShuffle(
                    !dev.batvisuals.client.managers.MusicManager.isShuffle());
            return;
        }
        y += tH + tGap;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, x, y, w, tH + 2f)) {
            dev.batvisuals.client.managers.MusicManager.setAutoPlayOnSelect(
                    !dev.batvisuals.client.managers.MusicManager.isAutoPlayOnSelect());
            return;
        }
        y += tH + tGap + 6f;

        float btnH = 18f;
        float bw = (w - 6f) / 2f;
        if (ClickGuiLayout.isHovered(mouseX, mouseY, x, y, bw, btnH)) {
            dev.batvisuals.client.managers.MusicManager.refresh();
            return;
        }
        y += btnH + 10f + 14f; // + "Треки"

        float rowH = 30f;
        float delW = 40f;
        var tracks = new java.util.ArrayList<>(dev.batvisuals.client.managers.MusicManager.list());
        for (int i = 0; i < tracks.size(); i++) {
            if (ClickGuiLayout.isHovered(mouseX, mouseY, x + w - delW - 4f, y + 5f, delW, rowH - 10f)) {
                dev.batvisuals.client.managers.MusicManager.delete(i);
                return;
            }
            if (ClickGuiLayout.isHovered(mouseX, mouseY, x, y, w, rowH)) {
                if (dev.batvisuals.client.managers.MusicManager.isAutoPlayOnSelect()) {
                    dev.batvisuals.client.managers.MusicManager.selectAndPlay(i);
                } else {
                    dev.batvisuals.client.managers.MusicManager.select(i);
                }
                return;
            }
            y += rowH + 4f;
        }
    }

}
