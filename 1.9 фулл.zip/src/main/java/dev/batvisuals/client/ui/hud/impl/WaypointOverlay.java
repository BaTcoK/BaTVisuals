package dev.batvisuals.client.ui.hud.impl;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.events.impl.EventRender2D;
import dev.batvisuals.client.managers.WaypointManager;
import dev.batvisuals.client.util.world.WorldUtils;
import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.renderer.fonts.Fonts;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

import java.awt.Color;

/** Always-on waypoint markers; edge-clamped when off-screen / far. */
public class WaypointOverlay {

    private static final Color PANEL = new Color(18, 20, 28, 210);
    private static final Color PANEL_EDGE = new Color(255, 255, 255, 28);
    private static final Color DIST = new Color(170, 190, 210);
    private static final Color ACCENT = new Color(80, 170, 255);
    private static final Identifier PIN = batvisuals.id("hud/waypoint_pin.png");

    @EventHandler
    public void onRender2D(EventRender2D e) {
        var mc = batvisuals.mc;
        if (mc == null || mc.player == null || mc.world == null) return;
        // waypoints always visible in this build

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        float margin = 18f;

        Vec3d eye = mc.player.getEyePos();
        Vec3d look = mc.player.getRotationVec(1.0f);

        for (WaypointManager.Waypoint w : WaypointManager.list()) {
            if (w == null || w.pos == null || w.name == null) continue;

            Vec3d target = w.pos.add(0, 1.0, 0);
            double dx = mc.player.getX() - w.pos.x;
            double dz = mc.player.getZ() - w.pos.z;
            int distM = (int) Math.sqrt(dx * dx + dz * dz);

            Vec3d screen = WorldUtils.getPosition(target);
            float sx = (float) screen.x;
            float sy = (float) screen.y;
            boolean behind = screen.z <= 0.0 || screen.z > 1.0 || Float.isNaN(sx) || Float.isNaN(sy);

            if (behind) {
                Vec3d to = target.subtract(eye);
                Vec3d forward = look.normalize();
                Vec3d right = forward.crossProduct(new Vec3d(0, 1, 0));
                if (right.lengthSquared() < 1e-6) right = new Vec3d(1, 0, 0);
                right = right.normalize();
                Vec3d up = right.crossProduct(forward).normalize();
                double rx = to.dotProduct(right);
                double ry = -to.dotProduct(up);
                double len = Math.sqrt(rx * rx + ry * ry);
                if (len < 1e-4) { rx = 0; ry = -1; len = 1; }
                rx /= len;
                ry /= len;
                float cx = sw / 2f, cy = sh / 2f;
                float maxX = cx - margin, maxY = cy - margin;
                float scale = Math.min(maxX / (float) Math.abs(rx), maxY / (float) Math.abs(ry));
                if (!Float.isFinite(scale) || scale > 10000) scale = Math.min(maxX, maxY);
                sx = cx + (float) rx * scale;
                sy = cy + (float) ry * scale;
            } else {
                // clamp to screen edges if near edge
                sx = Math.max(margin, Math.min(sw - margin, sx));
                sy = Math.max(margin, Math.min(sh - margin, sy));
            }

            String name = w.name;
            String distText = distM + "m";
            float nameSize = 7.5f, distSize = 6.5f, pin = 11f, gap = 4f, padX = 6f, padY = 4.5f;
            float nameW = Fonts.BOLD.getWidth(name, nameSize);
            float distW = Fonts.REGULAR.getWidth(distText, distSize);
            float textColW = Math.max(nameW, distW);
            float width = padX + pin + gap + textColW + padX;
            float height = padY + Math.max(pin, Fonts.BOLD.getHeight(nameSize) + 2f + Fonts.REGULAR.getHeight(distSize)) + padY;

            float x = sx - width / 2f;
            float y = sy - height - 10f;
            x = Math.max(4f, Math.min(sw - width - 4f, x));
            y = Math.max(4f, Math.min(sh - height - 4f, y));

            var matrices = e.getContext().getMatrices();
            Render2D.drawRoundedRect(matrices, x + 1.5f, y + 2f, width, height, 6f, new Color(0, 0, 0, 90));
            Render2D.drawRoundedRect(matrices, x, y, width, height, 6f, PANEL);
            Render2D.drawRoundedRect(matrices, x, y + 3f, 2.5f, height - 6f, 1.5f, ACCENT);

            float pinX = x + padX + 2f;
            float pinY = y + (height - pin) / 2f;
            try {
                Render2D.drawTexture(matrices, pinX, pinY, pin, pin, 0f, PIN, Color.WHITE);
            } catch (Throwable t) {
                Render2D.drawRoundedRect(matrices, pinX, pinY, pin, pin, pin / 2f, ACCENT);
            }

            float textX = pinX + pin + gap;
            float nameY = y + padY;
            float distY = nameY + Fonts.BOLD.getHeight(nameSize) + 1.5f;
            Render2D.drawFont(matrices, Fonts.BOLD.getFont(nameSize), name, textX, nameY, Color.WHITE);
            Render2D.drawFont(matrices, Fonts.REGULAR.getFont(distSize), distText, textX, distY, DIST);
            Render2D.drawRoundedRect(matrices, x + 4f, y + 1f, width - 8f, 1.2f, 1f, PANEL_EDGE);
        }
    }
}
