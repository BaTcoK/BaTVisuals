package dev.batvisuals.client.ui.hud.impl;

import dev.batvisuals.client.events.impl.EventRender2D;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.client.ui.hud.HudElement;
import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.renderer.fonts.Fonts;
import dev.batvisuals.client.util.perf.Perf;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registries;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

/**
 * Один блок: заголовок + список эффектов. Без мигания, иконки компактные.
 */
public class Potions extends HudElement implements ThemeManager.ThemeChangeListener {

	private static final Identifier POTION_ICON = Identifier.of("batvisuals", "textures/hud/potion_icon.png");

	private final ThemeManager themeManager;
	private Color bgColor;
	private Color textColor;
	private Color negativeColor;

	public final BooleanSetting showNegative = new BooleanSetting("ShowNegative", true);
	public final BooleanSetting highlightLowDuration = new BooleanSetting("HighlightLowDuration", true);

	public Potions() {
		super("Potions");
		this.themeManager = ThemeManager.getInstance();
		applyTheme(themeManager.getCurrentTheme());
		themeManager.addThemeChangeListener(this);
		this.getSettings().add(showNegative);
		this.getSettings().add(highlightLowDuration);
	}

	@Override
	public void onDisable() {
		themeManager.removeThemeChangeListener(this);
		super.onDisable();
	}

	@Override
	public void onThemeChanged(ThemeManager.Theme theme) {
		applyTheme(theme);
	}

	private void applyTheme(ThemeManager.Theme theme) {
		this.bgColor = new Color(0, 0, 0, 200);
		this.textColor = Color.WHITE;
		this.negativeColor = new Color(255, 90, 90);
	}

	@Override
	public void onRender2D(EventRender2D e) {
		if (fullNullCheck() || closed()) return;
		try (var __ = Perf.scopeCpu("Potions.onRender2D")) {
			renderInner(e);
		}
	}

	private void renderInner(EventRender2D e) {
		ClientPlayerEntity player = mc.player;
		boolean previewMode = mc.currentScreen != null
				&& !(mc.world != null && player != null && !player.getStatusEffects().isEmpty());

		List<StatusEffectInstance> effects = new ArrayList<>();
		if (player != null) {
			Collection<StatusEffectInstance> active = player.getStatusEffects();
			for (StatusEffectInstance eff : active) {
				StatusEffect type = eff.getEffectType().value();
				if (!showNegative.getValue() && !type.isBeneficial()) continue;
				effects.add(eff);
			}
			effects.sort(Comparator.comparingInt(StatusEffectInstance::getDuration));
		}

		List<String> texts = new ArrayList<>();
		List<String> icons = new ArrayList<>();
		List<StatusEffectInstance> rows = new ArrayList<>();

		if (previewMode && effects.isEmpty()) {
			texts.add("Speed II");
			icons.add("speed");
			rows.add(null);
		} else {
			for (StatusEffectInstance eff : effects) {
				StatusEffect type = eff.getEffectType().value();
				String name = type.getName().getString();
				String level = eff.getAmplifier() > 0 ? " " + toRoman(eff.getAmplifier() + 1) : "";
				texts.add(name + level);
				Identifier rid = Registries.STATUS_EFFECT.getId(type);
				icons.add(rid != null ? rid.getPath() : "");
				rows.add(eff);
			}
		}

		if (texts.isEmpty() && !(mc.currentScreen instanceof net.minecraft.client.gui.screen.ChatScreen)) {
			return;
		}
		if (texts.isEmpty()) return;

		float uiScale = Math.max(0.5f, getUiScale());
		float font = 7f * uiScale;
		float titleFont = 7.5f * uiScale;
		float pad = 5f * uiScale;
		float headerH = 18f * uiScale;
		float rowH = 14f * uiScale;
		float icon = 10f * uiScale;
		float radius = 6f * uiScale;

		float targetWidth = 100f;
		for (String t : texts) {
			float w = icon + 2 * pad + Fonts.MEDIUM.getWidth(t, font) + 32f * uiScale;
			if (w > targetWidth) targetWidth = w;
		}
		targetWidth = Math.max(90f, Math.min(targetWidth, 170f));

		float listH = texts.size() * rowH + pad * 0.5f;
		float totalH = headerH + listH + pad * 0.5f;

		float posX = getX();
		float posY = getY();
		setBounds(posX, posY, targetWidth * getUiScale(), totalH * getUiScale());

		var matrices = e.getContext().getMatrices();
		matrices.push();

		Render2D.drawRoundedRect(matrices, posX, posY, targetWidth, totalH, radius, bgColor);

		try {
			float headerIcon = 12f * uiScale;
			Render2D.drawTexture(matrices, posX + pad, posY + (headerH - headerIcon) / 2f,
					headerIcon, headerIcon, 3f, POTION_ICON, Color.WHITE);
		} catch (Throwable ignored) {}
		String title = net.minecraft.client.resource.language.I18n.translate("hud.potions.title");
		float titleX = posX + pad + 12f * uiScale + 4f;
		float titleY = posY + headerH / 2f - Fonts.MEDIUM.getHeight(titleFont) / 2f;
		Render2D.drawFont(matrices, Fonts.MEDIUM.getFont(titleFont), title, titleX, titleY, textColor);

		Render2D.drawRoundedRect(matrices, posX + pad, posY + headerH - 1f,
				targetWidth - pad * 2f, 1f, 0.5f, new Color(40, 40, 40, 180));

		float curY = posY + headerH + 2f * uiScale;
		Color liveAccent = themeManager.getCurrentTheme().getAccentColor();

		for (int i = 0; i < texts.size(); i++) {
			StatusEffectInstance eff = rows.get(i);
			StatusEffect type = eff == null ? null : eff.getEffectType().value();
			boolean negative = type != null && !type.isBeneficial();
			boolean low = eff != null && eff.getDuration() <= 200;
			Color draw = (low && highlightLowDuration.getValue())
					? liveAccent : (negative ? negativeColor : textColor);

			String iconKey = icons.get(i) == null ? "" : icons.get(i);
			float iconX = posX + pad;
			float rowCenterY = curY + rowH / 2f;

			if (!iconKey.isEmpty()) {
				try {
					Identifier tex = Identifier.of("minecraft", "textures/mob_effect/" + iconKey + ".png");
					Render2D.drawTexture(matrices, iconX, curY + (rowH - icon) / 2f,
							icon, icon, 1.5f, 0f, 0f, 1f, 1f, tex, Color.WHITE);
				} catch (Throwable ignored) {}
			}

			String nameText = texts.get(i);
			float nameTextX = iconX + icon + 4f;
			float nameTextY = rowCenterY - Fonts.MEDIUM.getHeight(font) / 2f;
			if (!nameText.isBlank()) {
				Render2D.drawFont(matrices, Fonts.MEDIUM.getFont(font), nameText, nameTextX, nameTextY, draw);
			}

			String time = (eff == null) ? "0:30" : formatDuration(eff.getDuration());
			if (!time.isBlank()) {
				float tw = Fonts.MEDIUM.getWidth(time, font);
				float pillW = tw + 5f * uiScale;
				float pillH = rowH - 3f * uiScale;
				float pillX = posX + targetWidth - pad - pillW;
				float pillY = curY + (rowH - pillH) / 2f;
				Render2D.drawRoundedRect(matrices, pillX, pillY, pillW, pillH, 2.5f * uiScale, new Color(20, 20, 20, 220));
				Render2D.drawFont(matrices, Fonts.MEDIUM.getFont(font), time,
						pillX + (pillW - tw) / 2f, rowCenterY - Fonts.MEDIUM.getHeight(font) / 2f, Color.WHITE);
			}
			curY += rowH;
		}

		matrices.pop();
		super.onRender2D(e);
	}

	private String toRoman(int number) {
		return switch (number) {
			case 1 -> "I";
			case 2 -> "II";
			case 3 -> "III";
			case 4 -> "IV";
			case 5 -> "V";
			default -> String.valueOf(number);
		};
	}

	private String formatDuration(int ticks) {
		int sec = Math.max(0, ticks / 20);
		return String.format("%d:%02d", sec / 60, sec % 60);
	}
}
