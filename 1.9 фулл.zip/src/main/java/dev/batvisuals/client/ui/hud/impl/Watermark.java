package dev.batvisuals.client.ui.hud.impl;

import dev.batvisuals.modules.impl.utility.NameProtect;

import dev.batvisuals.client.events.impl.EventRender2D;
import dev.batvisuals.client.ui.hud.HudElement;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.renderer.fonts.Fonts;
import dev.batvisuals.client.util.renderer.fonts.Font;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

import java.awt.Color;

/**
 * Updated watermark: logo box + info segments (user | fps | ping), theme accent.
 */
public class Watermark extends HudElement implements ThemeManager.ThemeChangeListener {

    private static final Identifier LOGO = Identifier.of("batvisuals", "hud/mod_logo.png");

    private final ThemeManager themeManager;
    private Color accent;
    private float bossOffsetSmooth = 0f;

    public Watermark() {
        super("Watermark");
        this.themeManager = ThemeManager.getInstance();
        applyTheme(themeManager.getCurrentTheme());
        themeManager.addThemeChangeListener(this);
    }

    private void applyTheme(ThemeManager.Theme theme) {
        try {
            this.accent = themeManager.getThemeColor();
        } catch (Throwable t) {
            this.accent = new Color(55, 130, 230);
        }
    }

    @Override
    public void onThemeChanged(ThemeManager.Theme theme) {
        applyTheme(theme);
    }

    @Override
    public void onRender2D(EventRender2D e) {
        if (fullNullCheck() || closed()) return;

        MatrixStack matrices = e.getContext().getMatrices();
        Font medium = Fonts.MEDIUM;
        Font icons = Fonts.ICONS;

        // Static top-center; smooth push down when boss bars visible
        float totalWEstimate = 200f;
        int sw = mc.getWindow().getScaledWidth();
        float x = (sw - totalWEstimate) / 2f;
        float targetBoss = 0f;
        try {
            Object bb = mc.inGameHud.getBossBarHud();
            java.lang.reflect.Field f = bb.getClass().getDeclaredField("bossBars");
            f.setAccessible(true);
            Object map = f.get(bb);
            if (map instanceof java.util.Map<?,?> m) {
                targetBoss = Math.min(m.size(), 4) * 22f;
            }
        } catch (Throwable ignored) {
            try {
                // yarn intermediary fallback
                Object bb = mc.inGameHud.getBossBarHud();
                for (java.lang.reflect.Field f : bb.getClass().getDeclaredFields()) {
                    f.setAccessible(true);
                    Object v = f.get(bb);
                    if (v instanceof java.util.Map<?,?> m && !m.isEmpty()) {
                        targetBoss = Math.min(m.size(), 4) * 22f;
                        break;
                    }
                }
            } catch (Throwable ignored2) {}
        }
        bossOffsetSmooth += (targetBoss - bossOffsetSmooth) * 0.12f;
        float y = 6f + bossOffsetSmooth;
        pushScale(matrices);
        float padding = 4f;
        float fontSize = 7f;
        float iconSize = 8f;
        float logoSize = 14f;
        float logoPad = 4f;
        float height = 20f;
        float radius = 5f;

        String username = mc.getSession().getUsername();
        try {
            NameProtect np = NameProtect.getInstance();
            if (np != null && np.isToggled()) username = np.getProtectedName(username);
        } catch (Throwable ignored) {}
        int fps = mc.getCurrentFps();
        int ping = getPing();
        String fpsText = fps + " FPS";
        String pingText = ping + " ms";

        float userW = medium.getWidth(username, fontSize);
        float fpsW = medium.getWidth(fpsText, fontSize);
        float pingW = medium.getWidth(pingText, fontSize);
        float sep = 1f;
        float gap = 4f;
        float textGap = 3f;

        float logoBoxW = logoSize + logoPad * 2f;
        float contentW = iconSize + textGap + userW + gap + sep + gap
                + iconSize + textGap + fpsW + gap + sep + gap
                + iconSize + textGap + pingW;
        float mainW = contentW + padding * 2f;
        float totalW = logoBoxW + mainW;
        x = (sw - totalW) / 2f;

        Color bg = new Color(12, 12, 16, 200);
        Color bgLogo = new Color(12, 12, 16, 230);

        // Background
        Render2D.drawRoundedRect(matrices, x, y, totalW, height, radius, bg);
        // Logo plate
        Render2D.drawRoundedRect(matrices, x, y, logoBoxW, height, radius, bgLogo);
        // Accent strip under logo plate
        Render2D.drawRoundedRect(matrices, x + 2, y + height - 3, logoBoxW - 4, 1.5f,
                1f, new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 220));

        // Logo
        try {
            Render2D.drawTexture(matrices, x + logoPad, y + (height - logoSize) / 2f, logoSize, logoSize, 3f, LOGO, Color.WHITE);
        } catch (Throwable ignored) {}

        float cx = x + logoBoxW + padding;
        float textY = y + (height - medium.getHeight(fontSize)) / 2f;
        float iconY = y + (height - iconSize) / 2f;
        Color white = Color.WHITE;
        Color dim = new Color(255, 255, 255, 90);

        // user
        try {
            Render2D.drawFont(matrices, icons.getFont(iconSize), "U", cx, iconY - 1, accent);
        } catch (Throwable t) {
            Render2D.drawRoundedRect(matrices, cx, iconY + 1, 3, 3, 1f, accent);
        }
        cx += iconSize + textGap;
        Render2D.drawFont(matrices, medium.getFont(fontSize), username, cx, textY, white);
        cx += userW + gap;
        Render2D.drawRoundedRect(matrices, cx, y + 5, sep, height - 10, 0.5f, dim);
        cx += sep + gap;

        // fps
        try {
            Render2D.drawFont(matrices, icons.getFont(iconSize), "F", cx, iconY - 1, accent);
        } catch (Throwable t) {
            Render2D.drawRoundedRect(matrices, cx, iconY + 1, 3, 3, 1f, accent);
        }
        cx += iconSize + textGap;
        Render2D.drawFont(matrices, medium.getFont(fontSize), fpsText, cx, textY, white);
        cx += fpsW + gap;
        Render2D.drawRoundedRect(matrices, cx, y + 5, sep, height - 10, 0.5f, dim);
        cx += sep + gap;

        // ping
        try {
            Render2D.drawFont(matrices, icons.getFont(iconSize), "P", cx, iconY - 1, accent);
        } catch (Throwable t) {
            Render2D.drawRoundedRect(matrices, cx, iconY + 1, 3, 3, 1f, accent);
        }
        cx += iconSize + textGap;
        Render2D.drawFont(matrices, medium.getFont(fontSize), pingText, cx, textY, white);

        popScale(matrices, totalW, height);

        // Включаем drag/click-логику из HudElement (перетаскивание, углы, окно настроек)
        super.onRender2D(e);
    }

    private int getPing() {
        try {
            if (mc.getNetworkHandler() == null || mc.player == null) return 0;
            PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            return entry != null ? entry.getLatency() : 0;
        } catch (Throwable t) {
            return 0;
        }
    }
}
