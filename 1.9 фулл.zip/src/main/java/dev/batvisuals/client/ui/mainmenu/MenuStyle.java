package dev.batvisuals.client.ui.mainmenu;

import dev.batvisuals.batvisuals;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * Persist custom vs vanilla title screen preference. Default = custom.
 */
public final class MenuStyle {
    private static Boolean cached;

    private MenuStyle() {}

    private static File file() {
        File dir = new File(batvisuals.getInstance().getGlobalsDir(), "mainmenu");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, "use_custom.txt");
    }

    public static boolean isCustom() {
        if (cached != null) return cached;
        try {
            File f = file();
            if (!f.exists()) {
                cached = true; // default custom
                save(true);
                return true;
            }
            String s = Files.readString(f.toPath(), StandardCharsets.UTF_8).trim();
            cached = !"false".equalsIgnoreCase(s);
        } catch (Throwable t) {
            cached = true;
        }
        return cached;
    }

    public static void setCustom(boolean custom) {
        cached = custom;
        save(custom);
    }

    private static void save(boolean custom) {
        try {
            Files.writeString(file().toPath(), custom ? "true" : "false", StandardCharsets.UTF_8);
        } catch (Throwable ignored) {}
    }
}
