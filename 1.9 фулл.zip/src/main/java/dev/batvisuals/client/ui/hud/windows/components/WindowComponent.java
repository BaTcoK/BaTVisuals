package dev.batvisuals.client.ui.hud.windows.components;

import dev.batvisuals.client.ui.hud.windows.components.impl.BooleanComponent;
import dev.batvisuals.client.ui.clickgui.components.Component;
import dev.batvisuals.client.util.animations.Animation;
import lombok.*;

@Getter @Setter
public abstract class WindowComponent extends Component {
	protected Animation animation;

	public WindowComponent(String name) {
		super(name);
	}
}