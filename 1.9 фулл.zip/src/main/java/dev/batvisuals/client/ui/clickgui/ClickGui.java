package dev.batvisuals.client.ui.clickgui;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.ui.clickgui.wonderful.ClickGuiInputHandler;
import dev.batvisuals.client.ui.clickgui.wonderful.ClickGuiRenderer;
import dev.batvisuals.client.ui.clickgui.wonderful.ClickGuiSettingRenderer;
import dev.batvisuals.client.ui.clickgui.wonderful.ClickGuiState;
import dev.batvisuals.client.util.Wrapper;
import dev.batvisuals.client.util.animations.Animation;
import dev.batvisuals.client.util.animations.Easing;
import dev.batvisuals.modules.impl.render.UI;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.Window;
import net.minecraft.text.Text;

/**
 * ClickGUI for BaTVisuals — port of the "wonderful" layout (sidebar + card grid + settings panel).
 * LMB: toggle / open settings / interact
 * RMB: open settings on module card
 * MMB: bind module key
 */
public class ClickGui extends Screen implements Wrapper {

    private static final ClickGuiState STATE = new ClickGuiState();

    private final ClickGuiState state = STATE;
    private final ClickGuiRenderer renderer = new ClickGuiRenderer(state, new ClickGuiSettingRenderer());
    private final ClickGuiInputHandler inputHandler = new ClickGuiInputHandler(state);

    private final Animation openAnimation = new Animation(220L, 1.0, true, Easing.EASE_OUT_CUBIC);
    private boolean needToClose = false;
    private float currentScale = 1f;

    /** Compatibility with old ModuleComponent hover description. */
    private String description = "";

    public ClickGui() {
        super(Text.of("batvisuals-clickgui"));
        state.refreshModules();
    }

    public void setDescription(String text) {
        this.description = text == null ? "" : text;
    }

    public String getDescription() {
        return description;
    }

    @Override
    protected void init() {
        super.init();
        this.needToClose = false;
        openAnimation.update(true);
        openAnimation.reset();
        state.refreshModules();
    }

    /** Called by UI module on disable. */
    public void close() {
        this.needToClose = true;
        openAnimation.update(false);
    }

    private float getGuiScale() {
        try {
            UI ui = batvisuals.getInstance().getModuleManager().getModule(UI.class);
            if (ui == null) return 1f;
            float s = ui.getGuiScale();
            return s <= 0f ? 1f : s;
        } catch (Throwable t) {
            return 1f;
        }
    }

    private float screenCenterX() {
        return mc.getWindow().getScaledWidth() / 2f;
    }

    private float screenCenterY() {
        return mc.getWindow().getScaledHeight() / 2f;
    }

    private double unscaleX(double mouseX) {
        float cx = screenCenterX();
        return cx + (mouseX - cx) / currentScale;
    }

    private double unscaleY(double mouseY) {
        float cy = screenCenterY();
        return cy + (mouseY - cy) / currentScale;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        openAnimation.update(!needToClose);

        float progress = openAnimation.getValue();
        if (needToClose && progress < 0.02F) {
            mc.setScreen(null);
            return;
        }

        currentScale = getGuiScale();
        Window window = mc.getWindow();

        // Position in logical (unscaled) space; scale around screen center
        state.updatePosition(window);
        state.setRenderOffsetY((1.0f - progress) * 15.0f);

        boolean doScale = Math.abs(currentScale - 1f) > 0.001f;
        if (doScale) {
            context.getMatrices().push();
            float cx = screenCenterX();
            float cy = screenCenterY();
            context.getMatrices().translate(cx, cy, 0);
            context.getMatrices().scale(currentScale, currentScale, 1f);
            context.getMatrices().translate(-cx, -cy, 0);
        }

        int logicalMx = (int) unscaleX(mouseX);
        int logicalMy = (int) unscaleY(mouseY);
        renderer.render(context, logicalMx, logicalMy, window, progress);

        if (doScale) {
            context.getMatrices().pop();
        }
    }


    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // While adjusting a slider — no dim overlay, so user sees the game (e.g. HandShader)
        try {
            if (state.isFocusMode()) {
                float f = state.getFocusValue();
                // soft residual dim only when partially focused
                if (f < 0.95f) {
                    int a = (int) (80 * (1f - f));
                    context.fill(0, 0, width, height, (a << 24));
                }
                return;
            }
        } catch (Throwable ignored) {}
        super.renderBackground(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (needToClose) return true;
        mouseX = unscaleX(mouseX);
        mouseY = unscaleY(mouseY);
        return inputHandler.mouseClicked(mouseX, mouseY, button, mc.getWindow())
                || super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        mouseX = unscaleX(mouseX);
        mouseY = unscaleY(mouseY);
        if (inputHandler.mouseDragged(mouseX, mouseY, button)) return true;
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (inputHandler.mouseReleased(button)) return true;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (needToClose) return true;
        mouseX = unscaleX(mouseX);
        mouseY = unscaleY(mouseY);
        return inputHandler.mouseScrolled(mouseX, mouseY, verticalAmount)
                || super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) { // ESC
            if (inputHandler.keyPressed(keyCode, modifiers)) return true;
            this.needToClose = true;
            openAnimation.update(false);
            try {
                UI ui = batvisuals.getInstance().getModuleManager().getModule(UI.class);
                if (ui != null && ui.isToggled()) ui.setToggled(false);
            } catch (Throwable ignored) {}
            return true;
        }
        return inputHandler.keyPressed(keyCode, modifiers) || super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (needToClose) return true;
        return inputHandler.charTyped(chr, modifiers) || super.charTyped(chr, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false; // we handle ESC ourselves for smooth close
    }
}
