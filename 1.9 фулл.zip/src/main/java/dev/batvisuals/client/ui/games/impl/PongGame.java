package dev.batvisuals.client.ui.games.impl;

import dev.batvisuals.client.ui.games.MiniGame;
import net.minecraft.client.gui.DrawContext;

import java.util.Random;

public class PongGame implements MiniGame {

    private static final float FIELD_W = 320f;
    private static final float FIELD_H = 180f;
    private static final float PADDLE_W = 8f;
    private static final float PADDLE_H = 42f;
    private static final float BALL_SIZE = 8f;

    private float playerY, aiY;
    private float ballX, ballY, ballVX, ballVY;
    private int playerScore, aiScore;
    private boolean gameOver;
    private boolean up, down;
    private final Random random = new Random();

    @Override
    public void init(float x, float y, float w, float h) {
        playerY = FIELD_H / 2f - PADDLE_H / 2f;
        aiY = FIELD_H / 2f - PADDLE_H / 2f;
        playerScore = 0;
        aiScore = 0;
        gameOver = false;
        resetBall(random.nextBoolean());
    }

    private void resetBall(boolean towardPlayer) {
        ballX = FIELD_W / 2f;
        ballY = FIELD_H / 2f;
        ballVX = (towardPlayer ? -1 : 1) * 130f;
        ballVY = (random.nextFloat() * 2f - 1f) * 100f;
    }

    @Override
    public void tick(float dt) {
        if (gameOver) return;
        if (up) playerY -= 220f * dt;
        if (down) playerY += 220f * dt;
        playerY = Math.max(0, Math.min(FIELD_H - PADDLE_H, playerY));

        float aiCenter = aiY + PADDLE_H / 2f;
        float target = ballY;
        if (aiCenter < target - 6f) aiY += 150f * dt;
        else if (aiCenter > target + 6f) aiY -= 150f * dt;
        aiY = Math.max(0, Math.min(FIELD_H - PADDLE_H, aiY));

        ballX += ballVX * dt;
        ballY += ballVY * dt;

        if (ballY <= 0) { ballY = 0; ballVY = -ballVY; }
        if (ballY >= FIELD_H - BALL_SIZE) { ballY = FIELD_H - BALL_SIZE; ballVY = -ballVY; }

        // player paddle (left, x=10)
        if (ballVX < 0 && ballX <= 10f + PADDLE_W && ballX >= 10f
                && ballY + BALL_SIZE >= playerY && ballY <= playerY + PADDLE_H) {
            ballX = 10f + PADDLE_W;
            ballVX = -ballVX * 1.05f;
            ballVY += (ballY - (playerY + PADDLE_H / 2f)) * 2.5f;
        }

        // ai paddle (right, x=FIELD_W-18)
        float aiX = FIELD_W - 18f;
        if (ballVX > 0 && ballX + BALL_SIZE >= aiX && ballX <= aiX + PADDLE_W
                && ballY + BALL_SIZE >= aiY && ballY <= aiY + PADDLE_H) {
            ballX = aiX - BALL_SIZE;
            ballVX = -ballVX * 1.05f;
            ballVY += (ballY - (aiY + PADDLE_H / 2f)) * 2.5f;
        }

        if (ballX < -20f) {
            aiScore++;
            checkEnd();
            if (!gameOver) resetBall(false);
        } else if (ballX > FIELD_W + 20f) {
            playerScore++;
            checkEnd();
            if (!gameOver) resetBall(true);
        }
    }

    private void checkEnd() {
        if (playerScore >= 7 || aiScore >= 7) gameOver = true;
    }

    @Override
    public void render(DrawContext context, float x, float y, float w, float h, int mouseX, int mouseY) {
        float scale = Math.min(w / FIELD_W, h / FIELD_H);
        float fx = x + (w - FIELD_W * scale) / 2f;
        float fy = y + (h - FIELD_H * scale) / 2f;

        context.fill((int) fx, (int) fy, (int) (fx + FIELD_W * scale), (int) (fy + FIELD_H * scale), 0xFF0C0E14);

        // center dashed line
        int dashes = 12;
        for (int i = 0; i < dashes; i++) {
            if (i % 2 == 0) continue;
            int ly0 = (int) (fy + (FIELD_H * scale) * i / dashes);
            int ly1 = (int) (fy + (FIELD_H * scale) * (i + 1) / dashes);
            int lx = (int) (fx + FIELD_W * scale / 2f);
            context.fill(lx, ly0, lx + 1, ly1, 0x33FFFFFF);
        }

        context.fill((int) (fx + 10f * scale), (int) (fy + playerY * scale),
                (int) (fx + (10f + PADDLE_W) * scale), (int) (fy + (playerY + PADDLE_H) * scale), 0xFF6FE07A);

        float aiX = FIELD_W - 18f;
        context.fill((int) (fx + aiX * scale), (int) (fy + aiY * scale),
                (int) (fx + (aiX + PADDLE_W) * scale), (int) (fy + (aiY + PADDLE_H) * scale), 0xFFE07A6F);

        context.fill((int) (fx + ballX * scale), (int) (fy + ballY * scale),
                (int) (fx + (ballX + BALL_SIZE) * scale), (int) (fy + (ballY + BALL_SIZE) * scale), 0xFFFFFFFF);

        String scoreText = playerScore + "  :  " + aiScore;
        var mc = net.minecraft.client.MinecraftClient.getInstance();
        context.drawText(mc.textRenderer, scoreText,
                (int) (fx + FIELD_W * scale / 2f - 14f), (int) (fy + 6f), 0xFFAABBCC, false);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (gameOver && keyCode == 82) { init(0, 0, 0, 0); return true; }
        if (keyCode == 265 || keyCode == 87) { up = true; return true; }   // UP / W
        if (keyCode == 264 || keyCode == 83) { down = true; return true; } // DOWN / S
        return false;
    }

    @Override
    public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 265 || keyCode == 87) { up = false; return true; }
        if (keyCode == 264 || keyCode == 83) { down = false; return true; }
        return false;
    }

    @Override
    public boolean isGameOver() { return gameOver; }

    @Override
    public int getScore() { return playerScore; }

    @Override
    public String getName() { return "Pong"; }
}
