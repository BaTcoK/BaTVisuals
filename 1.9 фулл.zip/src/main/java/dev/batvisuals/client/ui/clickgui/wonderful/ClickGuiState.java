package dev.batvisuals.client.ui.clickgui.wonderful;

import dev.batvisuals.client.managers.ThemeManager;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.util.animations.Animation;
import dev.batvisuals.client.util.animations.Easing;
import dev.batvisuals.client.managers.FriendsManager;
import dev.batvisuals.client.managers.WaypointManager;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.impl.render.TargetEsp;
import dev.batvisuals.modules.settings.Setting;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import dev.batvisuals.modules.settings.impl.StringSetting;
import net.minecraft.client.util.Window;

import java.util.*;

public class ClickGuiState {

    private static final Map<Character, Character> RU_TO_EN = new HashMap<>();

    static {
        String ru = "йцукенгшщзхъфывапролджэячсмитьбюЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮ";
        String en = "qwertyuiop[]asdfghjkl;'zxcvbnm,.QWERTYUIOP[]ASDFGHJKL;'ZXCVBNM,.";
        int length = Math.min(ru.length(), en.length());
        for (int i = 0; i < length; i++) {
            RU_TO_EN.put(ru.charAt(i), en.charAt(i));
        }
    }

    private final Map<Module, Animation> toggleAnimation = new IdentityHashMap<>();
    private final Map<Module, Animation> cardHoverAnimation = new IdentityHashMap<>();
    private final Map<BooleanSetting, Animation> booleanBackgroundAnimation = new HashMap<>();
    private final Map<NumberSetting, Animation> sliderAnimation = new HashMap<>();
    private final Map<Category, Float> gridScrollTarget = new EnumMap<>(Category.class);
    private final Map<Category, Float> gridScrollCurrent = new EnumMap<>(Category.class);
    private final Map<Category, Animation> gridScrollAnimation = new EnumMap<>(Category.class);
    private final Map<Category, List<Module>> modulesByCategory = new EnumMap<>(Category.class);
    private final List<Module> allModules = new ArrayList<>();

    private final Animation settingsPanelAnimation = new Animation(800L, 1.0, false, Easing.EASE_OUT_CUBIC);
    private final Animation settingsScrollAnimation = new Animation(250L, 1.0, true, Easing.EASE_OUT_CUBIC);
    /** 0 = full GUI, 1 = slider-focus mode (GUI hidden). */
    private final Animation focusAnimation = new Animation(280L, 1.0, false, Easing.EASE_OUT_CUBIC);
    private float settingsScrollAnimValue = 0f;

    private float x;
    private float y;
    private float renderOffsetY;
    private boolean positionInitialized;

    private Category selectedCategory = Category.Render;
    private Module selectedModule;
    private float settingsScrollTarget;

    private Setting<?> bindingSetting;
    private Module bindingModule;

    private boolean searchActive;
    private String searchText = "";
    private int searchCursor;

    private StringSetting editingStringSetting;
    private int stringCursor;

    private NumberSetting draggingSlider;

    private String configRenameTarget;
    private String configRenameBuffer = "";
    private boolean configRenameActive;
    
    // Friends / GPS panels
    private boolean friendsNickActive;
    private String friendsNickBuffer = "";
    private float friendsListScroll;
    private int friendsSuggestScroll = 0; // index offset for player suggestions
    public float profileCopyBtnX, profileCopyBtnY, profileCopyBtnW, profileCopyBtnH;
    private float sidebarScrollTarget = 0f;
    private float sidebarScrollCurrent = 0f;
    private boolean gpsNameActive, gpsXActive, gpsZActive;
    private String gpsNameBuffer = "", gpsXBuffer = "", gpsZBuffer = "";
    private float gpsListScroll;

    public boolean isFriendsNickActive() { return friendsNickActive; }
    public String getFriendsNickBuffer() { return friendsNickBuffer; }
    public void startFriendsNick() { clearFormFocus(); friendsNickActive = true; friendsNickBuffer = ""; }
    public void setFriendsNickBuffer(String s) { friendsNickBuffer = s == null ? "" : s; friendsSuggestScroll = 0; }
    public void clearFriendsNick() { friendsNickActive = false; friendsSuggestScroll = 0; }
    public int getFriendsSuggestScroll() { return friendsSuggestScroll; }
    public void setFriendsSuggestScroll(int v) { friendsSuggestScroll = Math.max(0, v); }
    public void addFriendsSuggestScroll(int delta) { friendsSuggestScroll = Math.max(0, friendsSuggestScroll + delta); }
    public float getFriendsListScroll() { return friendsListScroll; }
    public void addFriendsListScroll(double a) {
        friendsListScroll = (float) Math.min(0, friendsListScroll + a * 12);
        int n = Math.max(0, FriendsManager.getFriends().size());
        float max = Math.min(0f, 120f - n * 22f);
        if (friendsListScroll < max) friendsListScroll = max;
    }

    public boolean isGpsNameActive() { return gpsNameActive; }
    public boolean isGpsXActive() { return gpsXActive; }
    public boolean isGpsZActive() { return gpsZActive; }
    public String getGpsNameBuffer() { return gpsNameBuffer; }
    public String getGpsXBuffer() { return gpsXBuffer; }
    public String getGpsZBuffer() { return gpsZBuffer; }
    public void startGpsName() { clearFormFocus(); gpsNameActive = true; }
    public void startGpsX() { clearFormFocus(); gpsXActive = true; }
    public void startGpsZ() { clearFormFocus(); gpsZActive = true; }
    public void setGpsNameBuffer(String s) { gpsNameBuffer = s == null ? "" : s; }
    public void setGpsXBuffer(String s) { gpsXBuffer = s == null ? "" : s; }
    public void setGpsZBuffer(String s) { gpsZBuffer = s == null ? "" : s; }
    public void clearGpsFocus() { gpsNameActive = gpsXActive = gpsZActive = false; }
    public float getGpsListScroll() { return gpsListScroll; }
    public void addGpsListScroll(double a) {
        gpsListScroll = (float) Math.min(0, gpsListScroll + a * 12);
        int n = Math.max(0, WaypointManager.list().size());
        float max = Math.min(0f, 120f - n * 26f);
        if (gpsListScroll < max) gpsListScroll = max;
    }

    
    // BaTAI chat
    private boolean aiInputActive;
    private boolean aiKeyActive;
    private String aiInputBuffer = "";
    private String aiKeyBuffer = "";
    private float aiChatScroll;

    public boolean isAiInputActive() { return aiInputActive; }
    public boolean isAiKeyActive() { return aiKeyActive; }
    public String getAiInputBuffer() { return aiInputBuffer; }
    public String getAiKeyBuffer() { return aiKeyBuffer; }
    public void startAiInput() { clearFormFocus(); aiInputActive = true; }
    public void startAiKey() { clearFormFocus(); aiKeyActive = true; }
    public void setAiInputBuffer(String s) { aiInputBuffer = s == null ? "" : s; }
    public void setAiKeyBuffer(String s) { aiKeyBuffer = s == null ? "" : s; }
    public void clearAiFocus() { aiInputActive = false; aiKeyActive = false; }
    public float getAiChatScroll() { return aiChatScroll; }
    public void addAiChatScroll(double a) {
        aiChatScroll = (float) Math.min(0, aiChatScroll + a * 14);
        float max = -2000f;
        if (aiChatScroll < max) aiChatScroll = max;
    }

    public void clearFormFocus() {
        aiInputActive = false;
        aiKeyActive = false;
        friendsNickActive = false;
        gpsNameActive = gpsXActive = gpsZActive = false;
    }
    private boolean configCreateActive;
    private String configCreateBuffer = "";

    public ClickGuiState() {
        refreshModules();
    }

    public void refreshModules() {
        allModules.clear();
        try {
            if (batvisuals.getInstance() != null && batvisuals.getInstance().getModuleManager() != null) {
                allModules.addAll(batvisuals.getInstance().getModuleManager().getModules());
            }
        } catch (Throwable ignored) {}
        for (Category category : Category.values()) {
            modulesByCategory.put(category, allModules.stream()
                    .filter(module -> module.getCategory() == category)
                    .toList());
            gridScrollTarget.putIfAbsent(category, 0f);
            gridScrollAnimation.putIfAbsent(category, new Animation(300L, 1.0, true, Easing.EASE_OUT_CUBIC));
        }
        if (selectedCategory == null || modulesByCategory.getOrDefault(selectedCategory, List.of()).isEmpty()) {
            Category[] visible = ClickGuiLayout.getVisibleCategories();
            if (visible.length > 0) selectedCategory = visible[0];
        }
    }

    public void updatePosition(Window window) {
        // Center on sidebar+main. Settings open → shift left so all three stay centered.
        // Exception: TargetEsp — do NOT shift (preview sits on the left without moving ClickGUI).
        float totalW = ClickGuiLayout.SIDEBAR_WIDTH + ClickGuiLayout.PANEL_GAP + ClickGuiLayout.MAIN_WIDTH;
        if (selectedModule != null && !(selectedModule instanceof TargetEsp)) {
            totalW = ClickGuiLayout.getTotalWidth();
        }
        this.x = (window.getScaledWidth() / 2F) - (totalW / 2F);
        this.y = (window.getScaledHeight() / 2F) - (ClickGuiLayout.HEIGHT / 2F);
        positionInitialized = true;
    }

    public float getX() { return x; }
    public float getY() { return y; }
    public void setX(float x) { this.x = x; }
    public void setY(float y) { this.y = y; }
    public float getRenderOffsetY() { return renderOffsetY; }
    public void setRenderOffsetY(float renderOffsetY) { this.renderOffsetY = renderOffsetY; }

    public Category getSelectedCategory() { return selectedCategory; }

    public void setSelectedCategory(Category category) {
        if (this.selectedCategory != category) {
            this.selectedCategory = category;
            this.selectedModule = null;
            this.settingsScrollTarget = 0f;
            this.settingsScrollAnimValue = 0f;
        }
    }

    public Module getSelectedModule() { return selectedModule; }

    public void setSelectedModule(Module module) {
        if (this.selectedModule == module) {
            this.selectedModule = null;
        } else {
            this.selectedModule = module;
        }
        this.settingsScrollTarget = 0f;
        this.settingsScrollAnimValue = 0f;
    }

    public float getSettingsPanelProgress() {
        settingsPanelAnimation.update(selectedModule != null);
        return settingsPanelAnimation.getValue();
    }

    public float getSettingsPanelValue() {
        settingsPanelAnimation.update(selectedModule != null);
        return (float) settingsPanelAnimation.getValue();
    }

    public List<Module> getModules(Category category) {
        List<Module> modules = new ArrayList<>(modulesByCategory.getOrDefault(category, List.of()));
        if (!searchText.isBlank()) {
            String query = searchText.toLowerCase(Locale.ROOT);
            String queryEn = toEnglish(searchText).toLowerCase(Locale.ROOT);
            modules = modules.stream()
                    .filter(module -> {
                        String name = module.getName().toLowerCase(Locale.ROOT);
                        return name.contains(query) || name.contains(queryEn);
                    })
                    .collect(java.util.stream.Collectors.toCollection(ArrayList::new));
        }
        // Избранные сверху
        modules.sort((a, b) -> {
            boolean fa = dev.batvisuals.client.managers.FavoritesManager.isFavorite(a.getName());
            boolean fb = dev.batvisuals.client.managers.FavoritesManager.isFavorite(b.getName());
            if (fa == fb) return 0;
            return fa ? -1 : 1;
        });
        return modules;
    }

    public String toEnglish(String text) {
        StringBuilder result = new StringBuilder();
        for (char c : text.toCharArray()) {
            result.append(RU_TO_EN.getOrDefault(c, c));
        }
        return result.toString();
    }

    public float getGridScroll(Category category) {
        float target = gridScrollTarget.getOrDefault(category, 0f);
        float cur = gridScrollCurrent.getOrDefault(category, target);
        // smooth lerp — feels like soft scroll list
        cur += (target - cur) * 0.22f;
        if (Math.abs(target - cur) < 0.15f) cur = target;
        gridScrollCurrent.put(category, cur);
        return cur;
    }

    public void addGridScroll(Category category, double amount) {
        float contentHeight;
        if (category == Category.Friends || category == Category.Gps) {
            contentHeight = 400f;
        } else if (category == Category.Music) {
            contentHeight = Math.max(ClickGuiLayout.getGridViewHeight() + 1f,
                    dev.batvisuals.client.managers.MusicManager.estimatePanelContentHeight());
        } else if (category == Category.Games) {
            contentHeight = 8f + 16f + 18f + 5 * (44f + 6f) + 20f;
        } else if (category == Category.Config) {
            contentHeight = estimateConfigPanelHeight();
        } else if (category == Category.Theme) {
            contentHeight = estimateThemePanelHeight();
        } else {
            contentHeight = ClickGuiLayout.getGridContentHeight(getModules(category), ClickGuiLayout.getCardWidth());
        }
        float maxScroll = Math.min(0f, ClickGuiLayout.getGridViewHeight() - contentHeight);
        float target = gridScrollTarget.getOrDefault(category, 0f) + (float) (amount * 22f);
        gridScrollTarget.put(category, Math.max(maxScroll, Math.min(0f, target)));
    }

    private float estimateConfigPanelHeight() {
        int n = 0;
        try {
            String[] list = dev.batvisuals.batvisuals.getInstance().getConfigManager().getConfigList();
            if (list != null) n = list.length;
        } catch (Throwable ignored) {}
        // title + create btn + optional rename + rows
        float h = 14f + 18f + 8f;
        if (isConfigRenameActive()) h += 18f + 6f;
        if (isConfigCreateActive()) h += 0f; // create uses the button itself
        h += n * (22f + 4f) + 12f;
        return h;
    }

    private float estimateThemePanelHeight() {
        int n = 0;
        try {
            var arr = ThemeManager.getInstance().getAvailableThemes();
            if (arr != null) {
                for (var th : arr) {
                    if (th == null || th.getName() == null) { n++; continue; }
                    String low = th.getName().toLowerCase();
                    if (low.contains("purple") || low.contains("серая") || low.contains("серый")
                            || low.equals("gray") || low.equals("grey")) continue;
                    n++;
                }
            }
        } catch (Throwable ignored) {}
        // 2 columns
        int rows = (n + 1) / 2;
        return 14f + rows * (28f + 6f) + 12f;
    }

    public float getSettingsScroll() {
        // approach target
        float diff = settingsScrollTarget - settingsScrollAnimValue;
        settingsScrollAnimValue += diff * 0.35f;
        if (Math.abs(diff) < 0.15f) settingsScrollAnimValue = settingsScrollTarget;
        return settingsScrollAnimValue;
    }

    public void addSettingsScroll(double amount) {
        if (selectedModule == null) return;
        float contentHeight = ClickGuiLayout.calculateSettingsHeight(selectedModule, ClickGuiLayout.getSettingsInnerWidth());
        float maxScroll = Math.min(0f, ClickGuiLayout.getSettingsViewHeight() - contentHeight - 4f);
        settingsScrollTarget = Math.max(maxScroll, Math.min(0f, settingsScrollTarget + (float) (amount * 15f)));
    }

    public Animation getToggleAnimation(Module module) {
        return toggleAnimation.computeIfAbsent(module, key -> new Animation(200L, 1.0, module.isToggled(), Easing.EASE_OUT_CUBIC));
    }

    public Animation getCardHoverAnimation(Module module) {
        return cardHoverAnimation.computeIfAbsent(module, key -> new Animation(150L, 1.0, false, Easing.EASE_OUT_CUBIC));
    }

    public Animation getBooleanBackgroundAnimation(BooleanSetting setting) {
        return booleanBackgroundAnimation.computeIfAbsent(setting, key -> new Animation(200L, 1.0, Boolean.TRUE.equals(setting.getValue()), Easing.EASE_OUT_CUBIC));
    }

    public Animation getSliderAnimation(NumberSetting setting) {
        return sliderAnimation.computeIfAbsent(setting, key -> new Animation(300L, 1.0, true, Easing.EASE_OUT_CUBIC));
    }

    public float getSliderPos(NumberSetting setting) {
        float delta = setting.getMax() - setting.getMin();
        if (delta <= 0f) return 0f;
        return (setting.getValue() - setting.getMin()) / delta;
    }

    public float getSliderValue(NumberSetting setting, float posX, double mouseX, float sliderWidth) {
        float delta = setting.getMax() - setting.getMin();
        float clickedX = (float) mouseX - posX;
        float value = Math.max(0f, Math.min(1f, clickedX / sliderWidth));
        float outValue = setting.getMin() + delta * value;
        float increment = setting.getIncrement();
        if (increment > 0f) outValue = Math.round(outValue / increment) * increment;
        return Math.max(setting.getMin(), Math.min(setting.getMax(), outValue));
    }

    public boolean isDraggingSlider(NumberSetting setting) { return draggingSlider == setting; }
    public NumberSetting getDraggingSlider() { return draggingSlider; }
    public void setDraggingSlider(NumberSetting setting) { this.draggingSlider = setting; }

    public void updateFocusMode() {
        focusAnimation.update(draggingSlider != null);
    }

    /** 0 = normal GUI, 1 = focus (only active slider visible). */
    public float getFocusValue() {
        return focusAnimation.getValue();
    }

    public boolean isFocusMode() {
        return focusAnimation.getValue() > 0.05f;
    }

    public Setting<?> getBindingSetting() { return bindingSetting; }
    public void setBindingSetting(Setting<?> bindingSetting) { this.bindingSetting = bindingSetting; }
    public Module getBindingModule() { return bindingModule; }
    public void setBindingModule(Module bindingModule) { this.bindingModule = bindingModule; }

    public boolean isSearchActive() { return searchActive; }
    public void setSearchActive(boolean searchActive) { this.searchActive = searchActive; }
    public String getSearchText() { return searchText; }
    public void setSearchText(String searchText) { this.searchText = searchText; }
    public int getSearchCursor() { return searchCursor; }
    public void setSearchCursor(int searchCursor) { this.searchCursor = searchCursor; }

    public StringSetting getEditingStringSetting() { return editingStringSetting; }

    public void setEditingStringSetting(StringSetting editingStringSetting) {
        this.editingStringSetting = editingStringSetting;
        this.stringCursor = editingStringSetting == null || editingStringSetting.getValue() == null
                ? 0 : editingStringSetting.getValue().length();
    }

    public int getStringCursor() { return stringCursor; }
    public void setStringCursor(int stringCursor) { this.stringCursor = stringCursor; }

    public String getConfigRenameTarget() { return configRenameTarget; }
    public String getConfigRenameBuffer() { return configRenameBuffer; }
    public boolean isConfigRenameActive() { return configRenameActive; }
    public void startConfigRename(String name) {
        this.configRenameTarget = name;
        this.configRenameBuffer = name;
        this.configRenameActive = true;
    }
    public void setConfigRenameBuffer(String buf) { this.configRenameBuffer = buf == null ? "" : buf; }
    public void clearConfigRename() {
        this.configRenameActive = false;
        this.configRenameTarget = null;
        this.configRenameBuffer = "";
    }

    public boolean isConfigCreateActive() { return configCreateActive; }
    public String getConfigCreateBuffer() { return configCreateBuffer; }
    public void startConfigCreate() {
        this.configCreateActive = true;
        this.configCreateBuffer = "";
        clearConfigRename();
    }
    public void setConfigCreateBuffer(String buf) { this.configCreateBuffer = buf == null ? "" : buf; }
    public void clearConfigCreate() {
        this.configCreateActive = false;
        this.configCreateBuffer = "";
    }


    public boolean isAnyFormActive() {
        return friendsNickActive || gpsNameActive || gpsXActive || gpsZActive
                || configCreateActive || configRenameActive || searchActive;
    }
    public float getSidebarScroll() { return sidebarScrollCurrent; }
    public void addSidebarScroll(float delta) {
        sidebarScrollTarget += delta;
        float content = ClickGuiLayout.getVisibleCategories().length * ClickGuiLayout.SIDEBAR_ITEM_HEIGHT
                + Math.max(0, ClickGuiLayout.getVisibleCategories().length - 1) * ClickGuiLayout.SIDEBAR_ITEM_GAP;
        float viewport = ClickGuiLayout.HEIGHT - ClickGuiLayout.PROFILE_HEIGHT
                - ClickGuiLayout.SIDEBAR_SECTION_GAP - 6f;
        float max = Math.max(0f, content - viewport);
        sidebarScrollTarget = Math.max(-max, Math.min(0f, sidebarScrollTarget));
    }
    public void updateSidebarScroll() {
        sidebarScrollCurrent += (sidebarScrollTarget - sidebarScrollCurrent) * 0.25f;
        if (Math.abs(sidebarScrollTarget - sidebarScrollCurrent) < 0.05f) sidebarScrollCurrent = sidebarScrollTarget;
    }

}
