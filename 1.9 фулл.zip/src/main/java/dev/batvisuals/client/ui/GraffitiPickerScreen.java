package dev.batvisuals.client.ui;

import dev.batvisuals.client.managers.GraffitiManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Full mouse UI while choosing graffiti — freezes look, free cursor.
 */
public class GraffitiPickerScreen extends Screen {

    public interface Callback {
        void onPick(int imageIndex);
        void onCancel();
    }

    private static final Identifier[] TEX = new Identifier[GraffitiManager.IMAGE_COUNT];
    static {
        for (int i = 0; i < TEX.length; i++) {
            TEX[i] = Identifier.of("batvisuals", "textures/graffiti/g" + i + ".png");
        }
    }

    private final Callback callback;
    private int hover = -1;

    public GraffitiPickerScreen(Callback callback) {
        super(Text.literal("Graffiti"));
        this.callback = callback;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // dim overlay
        ctx.fill(0, 0, this.width, this.height, 0x88000000);

        float cx = this.width / 2f;
        float cy = this.height / 2f;
        float radius = 58f;
        int n = GraffitiManager.IMAGE_COUNT;
        hover = -1;

        for (int i = 0; i < n; i++) {
            double ang = -Math.PI / 2 + (2 * Math.PI * i / n);
            float x = cx + (float) Math.cos(ang) * radius;
            float y = cy + (float) Math.sin(ang) * radius;
            float size = 32f;
            boolean hov = mouseX >= x - size / 2 && mouseX <= x + size / 2
                    && mouseY >= y - size / 2 && mouseY <= y + size / 2;
            if (hov) {
                hover = i;
                size = 40f;
            }
            int bg = hov ? 0xF0FFFFFF : 0xC0101018;
            ctx.fill((int) (x - size / 2 - 3), (int) (y - size / 2 - 3),
                    (int) (x + size / 2 + 3), (int) (y + size / 2 + 3), bg);
            int ix = (int) (x - size / 2);
            int iy = (int) (y - size / 2);
            int isz = (int) size;
            ctx.drawTexture(RenderLayer::getGuiTextured, TEX[i], ix, iy, 0f, 0f, isz, isz, isz, isz);
        }

        String hint = hover >= 0 ? "ЛКМ — наклеить" : "Выбери фото · ESC — отмена";
        ctx.drawText(this.textRenderer, hint,
                (int) cx - this.textRenderer.getWidth(hint) / 2,
                (int) cy + 78, 0xFFFFFFFF, true);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && hover >= 0) {
            callback.onPick(hover);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) { // ESC
            callback.onCancel();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        callback.onCancel();
    }
}
