package dev.batvisuals.client.ui.clickgui.wonderful;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.renderer.fonts.Fonts;
import dev.batvisuals.modules.impl.render.TargetEsp;
import dev.batvisuals.modules.impl.render.TargetEspExtra;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.RotationAxis;

import java.awt.Color;

/**
 * Left preview: vanilla InventoryScreen.drawEntity (real player model)
 * + TargetESP modes rendered in model-local space (same algorithms as in-world).
 * ClickGUI is NOT shifted for TargetEsp — panel draws to the left of fixed GUI.
 */
public final class TargetEspPreviewPanel {

    public static final float WIDTH = 130f;

    private TargetEspPreviewPanel() {}

    public static void render(DrawContext context, float x, float y, float height,
                              int mouseX, int mouseY, Color accent, float alpha,
                              TargetEsp module) {
        if (alpha < 0.02f || module == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player == null) return;

        // Panel chrome
        Render2D.drawRoundedRect(context.getMatrices(), x, y, WIDTH, height, 10f,
                new Color(12, 12, 14, (int) (220 * alpha)));
        Render2D.drawRoundedRect(context.getMatrices(), x + 3f, y + 3f, 3f, height - 6f, 1.5f,
                new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), (int) (220 * alpha)));

        int ta = (int) (255 * alpha);
        Render2D.drawFont(context.getMatrices(), Fonts.MEDIUM.getFont(8f), "Превью цели",
                x + 12f, y + 8f, new Color(255, 255, 255, ta));
        Render2D.drawFont(context.getMatrices(), Fonts.MEDIUM.getFont(6.2f), module.previewModeName(),
                x + 12f, y + 20f, new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), ta));

        float bodyTop = y + 32f;
        float bodyH = height - 52f;
        float cx = x + WIDTH / 2f;
        float cy = bodyTop + bodyH * 0.72f;

        // Soft floor under model
        Render2D.drawRoundedRect(context.getMatrices(),
                cx - 32f, cy + 2f, 64f, 12f, 6f,
                new Color(0, 0, 0, (int) (100 * alpha)));

        // --- Real 3D player (vanilla InventoryScreen) ---
        int size = 56;
        int x1 = (int) (cx - 48);
        int y1 = (int) bodyTop;
        int x2 = (int) (cx + 48);
        int y2 = (int) (bodyTop + bodyH + 8);
        try {
            // mouse relative to entity for look-at
            InventoryScreen.drawEntity(context, x1, y1, x2, y2, size, 0.0625f,
                    (float) mouseX, (float) mouseY, player);
        } catch (Throwable t) {
            try {
                InventoryScreen.drawEntity(context, x1, y1, x2, y2, size, 0.0625f,
                        cx, cy - 20f, player);
            } catch (Throwable t2) {
                Render2D.drawFont(context.getMatrices(), Fonts.MEDIUM.getFont(7f), "Нет модели",
                        cx - 24f, cy - 10f, new Color(255, 255, 255, ta));
            }
        }

        // --- TargetESP in local space around the model (same math as world modes) ---
        MatrixStack ms = context.getMatrices();
        ms.push();
        // Anchor at roughly entity feet/center in panel
        ms.translate(cx, cy - 22f, 50);
        // GUI Y is down; scale so 1 block ≈ ~28 px
        float pxPerBlock = 30f;
        ms.scale(pxPerBlock, -pxPerBlock, pxPerBlock);
        try {
            module.renderGuiPreview3D(ms, 1.0f, alpha);
        } catch (Throwable ignored) {
        }
        ms.pop();

        Render2D.drawFont(context.getMatrices(), Fonts.MEDIUM.getFont(5.5f), "InventoryScreen + ESP",
                x + 10f, y + height - 14f, new Color(180, 180, 180, (int) (160 * alpha)));
    }
}
