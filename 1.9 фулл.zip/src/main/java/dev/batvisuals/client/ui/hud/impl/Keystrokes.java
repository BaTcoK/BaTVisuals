package dev.batvisuals.client.ui.hud.impl;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.events.impl.EventRender2D;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.client.ui.hud.HudElement;
import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.renderer.fonts.Fonts;
import dev.batvisuals.modules.settings.Setting;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.math.MatrixStack;

import java.awt.Color;

/**
 * Keystrokes. ПКМ → только галочка «Чёрный фон» (выкл = прозрачный с обводкой).
 * Scale убран из настроек (масштаб фиксированный).
 */
public class Keystrokes extends HudElement implements ThemeManager.ThemeChangeListener {

    /** true = чёрный фон, false = прозрачный + чёрная обводка */
    private final BooleanSetting blackBg = new BooleanSetting("Чёрный фон", true);

    private final ThemeManager themeManager;
    private Color accent = new Color(80, 160, 255);

    private float aW, aA, aS, aD, aSpace, aLmb, aRmb;

    public Keystrokes() {
        super("Keystrokes");
        this.themeManager = ThemeManager.getInstance();
        try { accent = themeManager.getThemeColor(); } catch (Throwable ignored) {}
        themeManager.addThemeChangeListener(this);

        // Position не нужен в ПКМ (перетаскивание в чате), Scale оставляем
        try {
            getSettings().removeIf(s -> {
                String n = s.getName();
                return n != null && (n.equalsIgnoreCase("setting.position")
                        || n.toLowerCase().contains("position"));
            });
        } catch (Throwable ignored) {}

        getSettings().add(blackBg);

        try {
            getPosition().getValue().setX(0.04f);
            getPosition().getValue().setY(0.45f);
        } catch (Throwable ignored) {}
    }

    @Override
    public void onThemeChanged(ThemeManager.Theme theme) {
        try { accent = themeManager.getThemeColor(); } catch (Throwable t) {
            accent = new Color(80, 160, 255);
        }
    }

    @Override
    public void onDisable() {
        themeManager.removeThemeChangeListener(this);
        super.onDisable();
    }

    @Override
    protected boolean closed() {
        try {
            var bs = batvisuals.getInstance().getHudManager().getElements().getName("Keystrokes");
            if (bs != null) return !bs.getValue();
        } catch (Throwable ignored) {}
        return !isToggled();
    }

    private static float lerp(float cur, float target, float speed) {
        return cur + (target - cur) * Math.min(1f, speed);
    }

    private static boolean down(KeyBinding kb) {
        try {
            return kb != null && kb.isPressed();
        } catch (Throwable t) {
            return false;
        }
    }

    @Override
    public void onRender2D(EventRender2D e) {
        super.onRender2D(e);
        if (fullNullCheck() || closed()) return;

        MatrixStack m = e.getContext().getMatrices();
        float ui = Math.max(0.5f, getUiScale());
        float key = 18f * ui;
        float gap = 3f * ui;
        float blockW = key * 3f + gap * 2f;
        float blockH = key * 4f + gap * 3f;
        float x = getX();
        float y = getY();
        setBounds(x, y, blockW, blockH);

        float speed = 0.35f;
        aW = lerp(aW, down(mc.options.forwardKey) ? 1f : 0f, speed);
        aA = lerp(aA, down(mc.options.leftKey) ? 1f : 0f, speed);
        aS = lerp(aS, down(mc.options.backKey) ? 1f : 0f, speed);
        aD = lerp(aD, down(mc.options.rightKey) ? 1f : 0f, speed);
        aSpace = lerp(aSpace, down(mc.options.jumpKey) ? 1f : 0f, speed);
        aLmb = lerp(aLmb, mc.options.attackKey.isPressed() ? 1f : 0f, speed);
        aRmb = lerp(aRmb, mc.options.useKey.isPressed() ? 1f : 0f, speed);

        boolean useBlack = blackBg.getValue();
        float font = 7.2f * ui;
        float radius = 4f * ui;

        drawKey(m, x + key + gap, y, key, key, "W", aW, font, radius, useBlack);
        float row2Y = y + key + gap;
        drawKey(m, x, row2Y, key, key, "A", aA, font, radius, useBlack);
        drawKey(m, x + key + gap, row2Y, key, key, "S", aS, font, radius, useBlack);
        drawKey(m, x + (key + gap) * 2f, row2Y, key, key, "D", aD, font, radius, useBlack);
        float row3Y = row2Y + key + gap;
        drawKey(m, x, row3Y, blockW, key, "SPACE", aSpace, font, radius, useBlack);
        float row4Y = row3Y + key + gap;
        float half = (blockW - gap) / 2f;
        drawKey(m, x, row4Y, half, key, "LMB", aLmb, font, radius, useBlack);
        drawKey(m, x + half + gap, row4Y, half, key, "RMB", aRmb, font, radius, useBlack);
    }

    private void drawKey(MatrixStack m, float x, float y, float w, float h,
                         String label, float press, float font, float radius, boolean useBlack) {
        press = Math.max(0f, Math.min(1f, press));
        float shrink = press * 1.5f;
        float kx = x + shrink, ky = y + shrink;
        float kw = w - shrink * 2f, kh = h - shrink * 2f;

        if (useBlack) {
            int r = (int) (25 + (accent.getRed() - 25) * press);
            int g = (int) (25 + (accent.getGreen() - 25) * press);
            int b = (int) (25 + (accent.getBlue() - 25) * press);
            Render2D.drawRoundedRect(m, kx, ky, kw, kh, radius, new Color(r, g, b, 200));
        } else {
            int a = (int) (15 + 90 * press);
            Render2D.drawRoundedRect(m, kx, ky, kw, kh, radius,
                    new Color((int) (accent.getRed() * press), (int) (accent.getGreen() * press),
                            (int) (accent.getBlue() * press), a));
            try {
                Render2D.drawBorder(m, kx, ky, kw, kh, radius, 1.0f, 1.0f, new Color(0, 0, 0, 230));
            } catch (Throwable t) {
                float tkn = 1.2f;
                Color bord = new Color(0, 0, 0, 230);
                Render2D.drawRoundedRect(m, kx, ky, kw, tkn, 0, bord);
                Render2D.drawRoundedRect(m, kx, ky + kh - tkn, kw, tkn, 0, bord);
                Render2D.drawRoundedRect(m, kx, ky, tkn, kh, 0, bord);
                Render2D.drawRoundedRect(m, kx + kw - tkn, ky, tkn, kh, 0, bord);
            }
        }

        float tw = Fonts.MEDIUM.getWidth(label, font);
        float th = Fonts.MEDIUM.getHeight(font);
        Render2D.drawFont(m, Fonts.MEDIUM.getFont(font), label,
                kx + (kw - tw) / 2f, ky + (kh - th) / 2f, Color.WHITE);
    }
}
