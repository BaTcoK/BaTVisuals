package dev.batvisuals.client.util;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;

/** Vanilla-safe visibility — modules must not reveal invisible players. */
public final class EntityVisibility {
    private EntityVisibility() {}

    public static boolean isConcealed(Entity entity) {
        if (entity == null) return true;
        try {
            if (entity.isInvisible()) return true;
        } catch (Throwable ignored) {}
        if (entity instanceof LivingEntity living) {
            try {
                if (living.hasStatusEffect(StatusEffects.INVISIBILITY)) return true;
            } catch (Throwable ignored) {}
        }
        return false;
    }

    public static boolean canShowCosmetic(Entity entity) {
        return entity != null && entity.isAlive() && !isConcealed(entity);
    }
}
