package dev.batvisuals.client.util.notify;

import net.minecraft.util.Identifier;

public record NotifyIcon(String icon, Identifier texture) {
    public NotifyIcon(String icon) {
        this(icon, null);
    }

    public boolean hasTexture() {
        return texture != null;
    }
}
