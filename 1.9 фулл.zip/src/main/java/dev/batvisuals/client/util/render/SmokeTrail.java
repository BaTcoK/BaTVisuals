package dev.batvisuals.client.util.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.*;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Random;

/**
 * Soft billboard smoke puffs under the local player while moving on ground.
 */
public class SmokeTrail {

    private static final int MAX_PUFFS = 600;
    private static final int SEGMENTS = 8;
    private static final float BASE_SIZE = 0.35f;
    private static final float BASE_ALPHA = 0.65f;
    private static final double MIN_SPEED_SQ = 0.0025;

    private static final class Puff {
        double x, y, z;
        float vx, vy, vz;
        long bornNs;
        float size;
    }

    private final ArrayList<Puff> puffs = new ArrayList<>();
    private final Random rng = new Random();
    private double lastX, lastZ;
    private boolean hasLast;

    public void clear() {
        puffs.clear();
        hasLast = false;
    }

    public void tick(MinecraftClient mc, float lifeSec) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) {
            clear();
            return;
        }

        long now = System.nanoTime();
        long lifeNs = (long) (lifeSec * 1_000_000_000L);
        puffs.removeIf(e -> now - e.bornNs > lifeNs);

        double dx = p.getX() - lastX, dz = p.getZ() - lastZ;
        boolean moved = hasLast && dx * dx + dz * dz > MIN_SPEED_SQ;
        lastX = p.getX();
        lastZ = p.getZ();
        hasLast = true;

        if (!moved || !p.isOnGround() || p.isTouchingWater() || puffs.size() >= MAX_PUFFS) return;

        // точка чуть позади по ходу движения, чтобы дым оставался за ногами
        double len = Math.sqrt(dx * dx + dz * dz);
        double bx = -dx / len * 0.25, bz = -dz / len * 0.25;

        for (int i = 0; i < 2; i++) {
            Puff e = new Puff();
            e.x = p.getX() + bx + (rng.nextDouble() - 0.5) * 0.3;
            e.y = p.getY() + 0.08;
            e.z = p.getZ() + bz + (rng.nextDouble() - 0.5) * 0.3;
            e.vx = (rng.nextFloat() - 0.5f) * 0.12f;
            e.vz = (rng.nextFloat() - 0.5f) * 0.12f;
            e.vy = 0.12f + rng.nextFloat() * 0.1f;
            e.size = BASE_SIZE * (0.8f + rng.nextFloat() * 0.5f);
            e.bornNs = now;
            puffs.add(e);
        }
    }

    /**
     * Вызывать из EventRender3D.Game: к этому моменту GameRendererMixin уже положил
     * матрицу камеры в ModelViewStack, поэтому вершины идут в camera-relative координатах
     * с единичной матрицей (так же, как Trails).
     */
    public void render(Camera camera, boolean white, int themeRgb, float lifeSec) {
        if (puffs.isEmpty()) return;

        Vec3d cam = camera.getPos();
        Quaternionf q = new Quaternionf(camera.getRotation());
        Vector3f right = new Vector3f(1, 0, 0).rotate(q);
        Vector3f up = new Vector3f(0, 1, 0).rotate(q);

        int rgb = white ? 0xFFFFFF : (themeRgb & 0xFFFFFF);
        long now = System.nanoTime();

        float[] cs = new float[SEGMENTS + 1], sn = new float[SEGMENTS + 1];
        for (int i = 0; i <= SEGMENTS; i++) {
            double a = (Math.PI * 2.0 * i) / SEGMENTS;
            cs[i] = (float) Math.cos(a);
            sn[i] = (float) Math.sin(a);
        }

        Matrix4f positionMatrix = new Matrix4f();
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);

        for (Puff e : puffs) {
            float age = (now - e.bornNs) / 1_000_000_000f;
            float t = age / Math.max(0.05f, lifeSec);
            if (t >= 1f) continue;

            float inv = 1f - t;
            int alpha = (int) (255f * BASE_ALPHA * inv * inv);
            if (alpha <= 0) continue;
            int center = (alpha << 24) | rgb;
            int edge = rgb; // alpha 0 at rim

            float r = e.size * (0.6f + 1.4f * t);
            float cx = (float) (e.x + e.vx * age - cam.x);
            float cy = (float) (e.y + e.vy * age - cam.y);
            float cz = (float) (e.z + e.vz * age - cam.z);

            for (int i = 0; i < SEGMENTS; i++) {
                float x1 = cx + (right.x * cs[i] + up.x * sn[i]) * r;
                float y1 = cy + (right.y * cs[i] + up.y * sn[i]) * r;
                float z1 = cz + (right.z * cs[i] + up.z * sn[i]) * r;
                float x2 = cx + (right.x * cs[i + 1] + up.x * sn[i + 1]) * r;
                float y2 = cy + (right.y * cs[i + 1] + up.y * sn[i + 1]) * r;
                float z2 = cz + (right.z * cs[i + 1] + up.z * sn[i + 1]) * r;

                b.vertex(positionMatrix, cx, cy, cz).color(center);
                b.vertex(positionMatrix, x1, y1, z1).color(edge);
                b.vertex(positionMatrix, x2, y2, z2).color(edge);
            }
        }

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();

        dev.batvisuals.client.util.render.SafeDraw.draw(b);

        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
    }
}
