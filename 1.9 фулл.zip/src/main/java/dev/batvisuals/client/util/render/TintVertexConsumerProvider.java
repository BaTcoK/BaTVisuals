package dev.batvisuals.client.util.render;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;

/**
 * Multiplies every vertex colour by a fixed RGBA (for HandShader solid tint).
 */
public final class TintVertexConsumerProvider implements VertexConsumerProvider {
    private final VertexConsumerProvider parent;
    private final float r, g, b, a;

    public TintVertexConsumerProvider(VertexConsumerProvider parent, float r, float g, float b, float a) {
        this.parent = parent;
        this.r = r;
        this.g = g;
        this.b = b;
        this.a = a;
    }

    @Override
    public VertexConsumer getBuffer(RenderLayer layer) {
        return new TintingVertexConsumer(parent.getBuffer(layer), r, g, b, a);
    }

    private static final class TintingVertexConsumer implements VertexConsumer {
        private final VertexConsumer delegate;
        private final float r, g, b, a;

        TintingVertexConsumer(VertexConsumer delegate, float r, float g, float b, float a) {
            this.delegate = delegate;
            this.r = r;
            this.g = g;
            this.b = b;
            this.a = a;
        }

        @Override
        public VertexConsumer vertex(float x, float y, float z) {
            delegate.vertex(x, y, z);
            return this;
        }

        @Override
        public VertexConsumer color(int red, int green, int blue, int alpha) {
            int nr = Math.min(255, Math.round(red * r));
            int ng = Math.min(255, Math.round(green * g));
            int nb = Math.min(255, Math.round(blue * b));
            int na = Math.min(255, Math.round(alpha * a));
            delegate.color(nr, ng, nb, na);
            return this;
        }

        @Override
        public VertexConsumer texture(float u, float v) {
            delegate.texture(u, v);
            return this;
        }

        @Override
        public VertexConsumer overlay(int u, int v) {
            delegate.overlay(u, v);
            return this;
        }

        @Override
        public VertexConsumer light(int u, int v) {
            delegate.light(u, v);
            return this;
        }

        @Override
        public VertexConsumer normal(float x, float y, float z) {
            delegate.normal(x, y, z);
            return this;
        }
    }
}
