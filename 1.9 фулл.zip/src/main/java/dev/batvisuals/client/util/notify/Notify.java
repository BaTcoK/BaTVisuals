package dev.batvisuals.client.util.notify;

import dev.batvisuals.client.events.impl.EventRender2D;
import dev.batvisuals.client.util.Wrapper;
import dev.batvisuals.client.util.animations.Animation;
import dev.batvisuals.client.util.animations.Easing;
import dev.batvisuals.client.util.math.TimerUtils;
import dev.batvisuals.client.util.renderer.fonts.Fonts;
import dev.batvisuals.client.util.renderer.Render2D;
import lombok.Getter;

import java.awt.*;

@Getter
public class Notify implements Wrapper {

    private final NotifyIcon icon;
    private final String notify;
    private final long delay;
    private float y;
    private final Animation animation = new Animation(420, 1f, true, Easing.BOTH_SINE);
    private final TimerUtils timer = new TimerUtils();

    public Notify(NotifyIcon icon, String notify, long delay) {
        this.icon = icon;
        this.notify = notify;
        this.delay = delay;
        y = mc.getWindow().getScaledHeight() / 2f + 12;
        timer.reset();
    }

    public void render(EventRender2D e, float targetY) {
        y = animate(y, targetY);
        float textW = Fonts.MEDIUM.getWidth(notify, 9f);
        float iconSlot = 12f;
        float padX = 8f;
        float height = 20f;
        float width = textW + iconSlot + padX * 2f + 4f;
        float x = mc.getWindow().getScaledWidth() / 2f - width / 2f;

        if (timer.passed(delay)) animation.update(false);
        float a = (float) animation.getValue();
        if (a < 0.01f) return;

        // slide-in from slightly below + fade
        float slide = (1f - a) * 8f;
        float drawY = y + slide;

        int bgA = (int) (200 * a);
        int blurA = (int) (55 * a);
        int fgA = (int) (255 * a);

        // Soft blur halo
        Render2D.drawShaderBlurRect(
                e.getContext().getMatrices(),
                x - 4f, drawY - 4f,
                width + 8f, height + 8f,
                8f, 12f,
                new Color(255, 255, 255, blurA)
        );
        // Rounded dark panel
        Render2D.drawRoundedRect(
                e.getContext().getMatrices(),
                x, drawY,
                width, height,
                8f,
                new Color(12, 12, 14, bgA)
        );

        float iconX = x + padX;
        float iconY = drawY + (height - 10f) / 2f;
        if (icon.hasTexture()) {
            Render2D.drawTexture(
                    e.getContext().getMatrices(),
                    iconX - 1f, iconY - 1f,
                    12f, 12f,
                    3f,
                    icon.texture(),
                    new Color(255, 255, 255, fgA)
            );
        } else {
            Render2D.drawFont(
                    e.getContext().getMatrices(),
                    Fonts.ICONS.getFont(9f),
                    icon.icon(),
                    iconX, iconY,
                    new Color(255, 255, 255, fgA)
            );
        }

        Render2D.drawFont(
                e.getContext().getMatrices(),
                Fonts.MEDIUM.getFont(9f),
                notify,
                x + padX + iconSlot + 2f,
                drawY + (height - 9f) / 2f - 0.5f,
                new Color(255, 255, 255, fgA)
        );
    }

    public float animate(float value, float target) {
        return value + (target - value) / 6.5f;
    }

    public boolean expired() {
        return timer.passed(delay) && animation.getValue() < 0.01f;
    }
}
