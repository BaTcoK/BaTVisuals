package dev.batvisuals.client.util;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.UUID;

/**
 * Stable per-install HWID for BaTVisuals (one id per machine/user folder).
 */
public final class HwidUtil {
    private static String cached;

    private HwidUtil() {}

    public static synchronized String getHwid() {
        if (cached != null) return cached;
        try {
            File dir = new File(System.getProperty("user.home", "."), ".batvisuals");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, "hwid.txt");
            if (f.exists()) {
                String s = Files.readString(f.toPath(), StandardCharsets.UTF_8).trim();
                if (!s.isEmpty()) {
                    cached = s;
                    return cached;
                }
            }
            String raw = System.getProperty("user.name", "u")
                    + "|" + System.getProperty("os.name", "os")
                    + "|" + System.getProperty("os.arch", "arch")
                    + "|" + System.getenv().getOrDefault("COMPUTERNAME",
                        System.getenv().getOrDefault("HOSTNAME", UUID.randomUUID().toString()));
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] dig = md.digest(raw.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 16; i++) sb.append(String.format("%02X", dig[i]));
            // format XXXX-XXXX-XXXX-XXXX
            String hex = sb.toString();
            cached = hex.substring(0, 4) + "-" + hex.substring(4, 8) + "-"
                    + hex.substring(8, 12) + "-" + hex.substring(12, 16);
            Files.writeString(f.toPath(), cached, StandardCharsets.UTF_8);
            return cached;
        } catch (Throwable t) {
            cached = "GUEST-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
            return cached;
        }
    }
}
