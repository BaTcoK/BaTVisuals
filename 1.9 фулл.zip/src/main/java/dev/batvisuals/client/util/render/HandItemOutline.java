package dev.batvisuals.client.util.render;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.util.Identifier;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Предметы/блоки в руке (обе руки).
 *
 * ЗАЛИВКА: цвет темы подмешивается прямо в вершины самого предмета (его же слой, тот же depth/cull/blend),
 * поэтому работает для любых моделей: плоские предметы, блоки, инструменты, щиты, прозрачные блоки.
 * Раньше заливка рисовалась вторым слоем поверх предмета и на практике не была видна.
 *
 * ОБВОДКА: геометрический inverted hull в рендере предмета.
 */
public final class HandItemOutline implements VertexConsumerProvider {

    private static final ThreadLocal<Integer> FIRST_PERSON_DEPTH = ThreadLocal.withInitial(() -> 0);
    private static final ThreadLocal<Deque<HandItemOutline>> ACTIVE = ThreadLocal.withInitial(ArrayDeque::new);

    public static void beginFirstPerson() {
        FIRST_PERSON_DEPTH.set(FIRST_PERSON_DEPTH.get() + 1);
    }

    public static void endFirstPerson() {
        int d = Math.max(0, FIRST_PERSON_DEPTH.get() - 1);
        if (d == 0) FIRST_PERSON_DEPTH.remove(); else FIRST_PERSON_DEPTH.set(d);
    }

    public static boolean isFirstPerson() {
        return FIRST_PERSON_DEPTH.get() > 0;
    }

    public static void pushActive(HandItemOutline outline) { ACTIVE.get().push(outline); }

    public static HandItemOutline popActive() {
        Deque<HandItemOutline> q = ACTIVE.get();
        if (q.isEmpty()) return null;
        HandItemOutline value = q.pop();
        if (q.isEmpty()) ACTIVE.remove();
        return value;
    }

    private final VertexConsumerProvider parent;
    private final HandFillProvider.Style st;
    private final boolean fill;
    private final boolean hull;

    private float[] q = new float[15 * 128];
    private int len;

    public HandItemOutline(VertexConsumerProvider parent, HandFillProvider.Style st) {
        this.parent = parent;
        this.st = st;
        this.fill = st.itemFill && st.itemAlpha > 0.01f;
        this.hull = st.outline && st.itemOutline && st.width > 0f;
    }

    @Override
    public VertexConsumer getBuffer(RenderLayer layer) {
        VertexConsumer real = parent.getBuffer(layer);
        if (!fill && !hull) return real;
        if (layer.toString().toLowerCase(java.util.Locale.ROOT).contains("glint")) return real;
        boolean collectHull = hull && layer.getDrawMode() == VertexFormat.DrawMode.QUADS;
        return new Tee(real, collectHull);
    }

    /** Fallback-обводка (только если экранная недоступна). Вызвать после рендера предмета. */
    public void flush() {
        int count = len / 15;
        try {
            if (!hull || count == 0) return;
            Identifier tex = HandFillProvider.white();
            if (tex == null) return;
            VertexConsumer out = parent.getBuffer(RenderLayer.getEntitySolid(tex));
            // плоские спрайт-предметы: контур по силуэту; блоки/объёмные модели: inverted hull
            if (!flatOutline(out, count)) {
                for (int i = 0; i + 15 <= len; i += 15) HandFillProvider.hull(out, st, q, i);
            }
        } finally {
            len = 0;
        }
    }

    // ───────────────────────── заливка ─────────────────────────

    /** Множитель цвета вершины предмета (RGB). k = 1 - прозрачность; 0xFFFFFF = без изменений. */
    private int tintAt(float x, float y, float z) {
        float k = Math.max(0f, Math.min(1f, st.itemAlpha));
        if (st.theme == 7) return st.glassArgb(x, y, z, 0f, 1f, 0f) & 0xFFFFFF;
        if (st.theme == 4) return HandFillProvider.Style.mix(0xFFFFFF, st.base, k);
        int f = st.fill(x, y, z);
        return HandFillProvider.Style.mix(0xFFFFFF, f, k);
    }

    /**
     * Спрайт-модель (builtin/generated) = 2 больших квада (перед/зад, весь прямоугольник 16x16, прозрачные пиксели
     * отсекаются альфой) + узкие боковые квады ровно по силуэту. Hull по большим квадам даёт сплошной прямоугольник —
     * это и был «искажённый» предмет. Здесь большие квады пропускаются, а по каждому боковому квада строится плоская
     * полоса наружу (в плоскости предмета, на середине толщины) — получается контур по реальной форме.
     * Возвращает false, если модель не плоская (блок и т.п.) — тогда обычный hull.
     */
    private boolean flatOutline(VertexConsumer out, int count) {
        float[] area = new float[count];
        float maxA = 0f;
        int big = -1;
        for (int i = 0; i < count; i++) {
            int o = i * 15;
            float e1x = q[o + 3] - q[o], e1y = q[o + 4] - q[o + 1], e1z = q[o + 5] - q[o + 2];
            float e2x = q[o + 9] - q[o], e2y = q[o + 10] - q[o + 1], e2z = q[o + 11] - q[o + 2];
            float cx = e1y * e2z - e1z * e2y, cy = e1z * e2x - e1x * e2z, cz = e1x * e2y - e1y * e2x;
            float a = (float) Math.sqrt(cx * cx + cy * cy + cz * cz);
            area[i] = a;
            if (a > maxA) { maxA = a; big = i; }
        }
        if (big < 0 || maxA < 1e-9f) return false;

        float nx = q[big * 15 + 12], ny = q[big * 15 + 13], nz = q[big * 15 + 14];
        float nl = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (nl < 1e-6f) return false;
        nx /= nl; ny /= nl; nz /= nl;

        int faces = 0, sides = 0;
        for (int i = 0; i < count; i++) {
            int o = i * 15;
            float qx = q[o + 12], qy = q[o + 13], qz = q[o + 14];
            float ql = (float) Math.sqrt(qx * qx + qy * qy + qz * qz);
            if (ql < 1e-6f) return false;
            float d = Math.abs((qx * nx + qy * ny + qz * nz) / ql);
            if (area[i] >= maxA * 0.4f) {
                if (d < 0.97f) return false;
                faces++;
            } else if (area[i] <= maxA * 0.25f) {
                if (d > 0.35f) return false;
                sides++;
            } else {
                return false;
            }
        }
        if (faces < 2 || sides == 0) return false;

        float w = st.width;
        for (int i = 0; i < count; i++) {
            if (area[i] > maxA * 0.25f) continue;
            int o = i * 15;
            // ребро толщины = то, что ближе к нормали плоскости; второе ребро = тангенс по краю силуэта
            float e1x = q[o + 3] - q[o], e1y = q[o + 4] - q[o + 1], e1z = q[o + 5] - q[o + 2];
            float e2x = q[o + 9] - q[o], e2y = q[o + 10] - q[o + 1], e2z = q[o + 11] - q[o + 2];
            float l1 = (float) Math.sqrt(e1x * e1x + e1y * e1y + e1z * e1z);
            float l2 = (float) Math.sqrt(e2x * e2x + e2y * e2y + e2z * e2z);
            if (l1 < 1e-7f || l2 < 1e-7f) continue;
            float d1 = Math.abs(e1x * nx + e1y * ny + e1z * nz) / l1;
            float d2 = Math.abs(e2x * nx + e2y * ny + e2z * nz) / l2;
            float tx, ty, tz, tl;
            if (d1 > d2) { tx = e2x; ty = e2y; tz = e2z; tl = l2; }
            else { tx = e1x; ty = e1y; tz = e1z; tl = l1; }
            tx /= tl; ty /= tl; tz /= tl;

            // наружная нормаль бокового квада, спроецированная в плоскость предмета
            float sx = q[o + 12], sy = q[o + 13], sz = q[o + 14];
            float sd = sx * nx + sy * ny + sz * nz;
            sx -= nx * sd; sy -= ny * sd; sz -= nz * sd;
            float sl = (float) Math.sqrt(sx * sx + sy * sy + sz * sz);
            if (sl < 1e-6f) continue;
            sx /= sl; sy /= sl; sz /= sl;

            // центр бокового квада = середина толщины; половина тангенс-ребра в обе стороны + w для закрытия углов
            float cx = (q[o] + q[o + 3] + q[o + 6] + q[o + 9]) * 0.25f;
            float cy = (q[o + 1] + q[o + 4] + q[o + 7] + q[o + 10]) * 0.25f;
            float cz = (q[o + 2] + q[o + 5] + q[o + 8] + q[o + 11]) * 0.25f;
            float half = tl * 0.5f + w;
            float ax = cx - tx * half, ay = cy - ty * half, az = cz - tz * half;
            float bx = cx + tx * half, by = cy + ty * half, bz = cz + tz * half;
            float dx = ax + sx * w, dy = ay + sy * w, dz = az + sz * w;
            float ex = bx + sx * w, ey = by + sy * w, ez = bz + sz * w;
            // A B E D, оба направления обхода: culling оставит видимую сторону
            band(out, ax, ay, az, bx, by, bz, ex, ey, ez, dx, dy, dz);
            band(out, dx, dy, dz, ex, ey, ez, bx, by, bz, ax, ay, az);
        }
        return true;
    }

    private void band(VertexConsumer out, float x0, float y0, float z0, float x1, float y1, float z1,
                      float x2, float y2, float z2, float x3, float y3, float z3) {
        HandFillProvider.put(out, x0, y0, z0, st.line(x0, y0, z0));
        HandFillProvider.put(out, x1, y1, z1, st.line(x1, y1, z1));
        HandFillProvider.put(out, x2, y2, z2, st.line(x2, y2, z2));
        HandFillProvider.put(out, x3, y3, z3, st.line(x3, y3, z3));
    }

    private void store(float[] c) {
        if (len + 15 > q.length) {
            if (q.length >= 15 * 2048) return;
            q = java.util.Arrays.copyOf(q, q.length * 2);
        }
        System.arraycopy(c, 0, q, len, 15);
        len += 15;
    }

    /** Пропускает вершины в настоящий буфер (с подмешанным цветом темы) и, для fallback-обводки, запоминает квады. */
    private final class Tee implements VertexConsumer {
        private final VertexConsumer o;
        private float px, py, pz;
        private int tint = 0xFFFFFF;
        private final float[] c = new float[15];
        private int n;

        private final boolean collectHull;

        Tee(VertexConsumer o, boolean collectHull) {
            this.o = o;
            this.collectHull = collectHull;
        }

        @Override
        public VertexConsumer vertex(float x, float y, float z) {
            o.vertex(x, y, z);
            px = x; py = y; pz = z;
            if (fill) tint = tintAt(x, y, z);
            return this;
        }

        @Override
        public VertexConsumer color(int r, int g, int b, int a) {
            if (fill) {
                r = r * ((tint >> 16) & 255) / 255;
                g = g * ((tint >> 8) & 255) / 255;
                b = b * (tint & 255) / 255;
            }
            o.color(r, g, b, a);
            return this;
        }

        @Override public VertexConsumer texture(float u, float v) { o.texture(u, v); return this; }
        @Override public VertexConsumer overlay(int u, int v) { o.overlay(u, v); return this; }
        @Override public VertexConsumer light(int u, int v) { o.light(u, v); return this; }

        @Override
        public VertexConsumer normal(float x, float y, float z) {
            o.normal(x, y, z);
            if (collectHull) {
                c[n * 3] = px; c[n * 3 + 1] = py; c[n * 3 + 2] = pz;
                if (n == 0) { c[12] = x; c[13] = y; c[14] = z; }
                if (++n == 4) { store(c); n = 0; }
            }
            return this;
        }
    }
}
