package dev.batvisuals.client.util;

public final class LogUtil {
    public static void info(String msg) { System.out.println("[batvisuals] " + msg); }
    public static void warn(String msg) { System.out.println("[batvisuals][WARN] " + msg); }
}

