package dev.batvisuals.client.util.render;

import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;

/**
 * Безопасная замена BufferRenderer.drawWithGlobalProgram(buf.end()).
 * Ванильный end() на буфере без единой вершины кидает IllegalStateException("BufferBuilder was empty") -
 * это и был краш (искры StormFx, дым SmokeTrail, пустые списки частиц и т.д.). Здесь пустой буфер просто пропускается.
 */
public final class SafeDraw {
    private SafeDraw() {}

    public static void draw(BufferBuilder buf) {
        if (buf == null) return;
        BuiltBuffer built;
        try {
            built = buf.end();
        } catch (IllegalStateException empty) {
            return;
        }
        if (built != null) BufferRenderer.drawWithGlobalProgram(built);
    }
}
