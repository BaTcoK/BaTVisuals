package dev.batvisuals.client.util.notify;

import lombok.experimental.UtilityClass;
import net.minecraft.util.Identifier;

@UtilityClass
public class NotifyIcons {
    public NotifyIcon successIcon = new NotifyIcon("A");
    public NotifyIcon failIcon = new NotifyIcon("B");
    public NotifyIcon dangerIcon = new NotifyIcon("C");
    public NotifyIcon warnIcon = new NotifyIcon("C", Identifier.of("batvisuals", "textures/gui/notify_warn.png"));
}
