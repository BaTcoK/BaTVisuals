package dev.batvisuals.client.util.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Random;

/** TargetESP: 3D-молнии (бьют по цели сверху, не из неба) и «Электро» (мелкие дуги и искры на теле). */
public final class StormFx {

    private static final Identifier GLOW = Identifier.of("batvisuals", "hud/glow.png");
    private static final boolean LOW = System.getenv("POJAV_RENDERER") != null;
    private final Random rng = new Random();

    private static final class Bolt {
        float[] main;
        final ArrayList<float[]> branches = new ArrayList<>();
        long born;
        float life;
        double ex, ey, ez;
    }

    private static final class Arc {
        LivingEntity ent;
        float[] rel;
        long born;
        float life;
    }

    private static final class Spark {
        double x, y, z;
        float vx, vy, vz, size, life;
        long born;
    }

    private final ArrayList<Bolt> bolts = new ArrayList<>();
    private final ArrayList<Arc> arcs = new ArrayList<>();
    private final ArrayList<Spark> sparks = new ArrayList<>();
    private long nextAuto, lastMs;
    private float arcAcc, sparkAcc;

    public void clear() {
        bolts.clear();
        arcs.clear();
        sparks.clear();
        nextAuto = 0;
        lastMs = 0;
    }

    // ───────────────────────── молнии ─────────────────────────

    /** Удар молнии по сущности. */
    public void strike(Entity target, float height, boolean branches) {
        if (target == null || bolts.size() > 12) return;
        Bolt b = new Bolt();
        double ex = target.getX() + (rng.nextDouble() - .5) * .15, ey = target.getY(), ez = target.getZ() + (rng.nextDouble() - .5) * .15;
        double sx = ex + (rng.nextDouble() - .5) * 2.4, sy = ey + height, sz = ez + (rng.nextDouble() - .5) * 2.4;
        b.main = jag(sx, sy, sz, ex, ey, ez, 6, height * .11);
        b.born = System.currentTimeMillis();
        b.life = .38f;
        b.ex = ex; b.ey = ey; b.ez = ez;
        if (branches) {
            int n = b.main.length / 3;
            int cnt = 2 + rng.nextInt(3);
            for (int i = 0; i < cnt; i++) {
                int k = n / 4 + rng.nextInt(n / 2);
                double bx = b.main[k * 3], by = b.main[k * 3 + 1], bz = b.main[k * 3 + 2];
                double len = 1.0 + rng.nextDouble() * 1.8;
                double ang = rng.nextDouble() * Math.PI * 2;
                b.branches.add(jag(bx, by, bz, bx + Math.cos(ang) * len, by - len * (.5 + rng.nextDouble() * .6), bz + Math.sin(ang) * len, 3, len * .22));
            }
        }
        bolts.add(b);
    }

    /** Авто-удары каждые min..max секунд по текущей цели. */
    public void tickAuto(LivingEntity target, float minS, float maxS, float height, boolean branches) {
        long now = System.currentTimeMillis();
        if (target == null) { nextAuto = 0; return; }
        if (nextAuto == 0) nextAuto = now + 250;
        if (now >= nextAuto) {
            strike(target, height, branches);
            float lo = Math.min(minS, maxS), hi = Math.max(minS, maxS);
            nextAuto = now + (long) ((lo + rng.nextFloat() * (hi - lo)) * 1000f);
        }
    }

    public void renderBolts(Camera cam, int rgb, float thick) {
        long now = System.currentTimeMillis();
        bolts.removeIf(b -> (now - b.born) / 1000f > b.life);
        if (bolts.isEmpty()) return;
        Vec3d c = cam.getPos();
        begin(true);
        for (int pass = 0; pass < 2; pass++) {
            int col = pass == 0 ? rgb : 0xFFFFFF;
            float wMul = pass == 0 ? 4.5f : 1f, aMul = pass == 0 ? .35f : 1f;
            BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            int quads = 0;
            for (Bolt b : bolts) {
                float t = (now - b.born) / 1000f / b.life;
                float flick = ((now / 24) % 3 == 0) ? .55f : 1f;
                float env = (float) Math.pow(1f - t, 1.3) * flick;
                quads += ribbon(bb, b.main, .03f * thick * wMul, col, env * aMul, true, c);
                for (float[] br : b.branches) quads += ribbon(bb, br, .017f * thick * wMul, col, env * aMul * .8f, false, c);
            }
            if (quads > 0) dev.batvisuals.client.util.render.SafeDraw.draw(bb);
        }
        // вспышка в точке удара
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, GLOW);
        BufferBuilder fl = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        Vector3f r = new Vector3f(1, 0, 0).rotate(cam.getRotation()), u = new Vector3f(0, 1, 0).rotate(cam.getRotation());
        for (Bolt b : bolts) {
            float t = (now - b.born) / 1000f / b.life;
            float a = (float) Math.pow(1f - t, 1.6);
            billboard(fl, b.ex - c.x, b.ey - c.y + .1, b.ez - c.z, .9f * thick * (.6f + .4f * t), r, u, argb(rgb, a * .8f));
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(fl);
        end();
    }

    // ───────────────────────── электро ─────────────────────────

    public void tickElectro(LivingEntity t, float density, float size) {
        long now = System.currentTimeMillis();
        double dt = lastMs > 0 ? MathHelper.clamp((now - lastMs) / 1000.0, 0.001, 0.1) : 0.016;
        lastMs = now;
        arcs.removeIf(a -> (now - a.born) / 1000f > a.life || a.ent == null || !a.ent.isAlive());
        sparks.removeIf(s -> (now - s.born) / 1000f > s.life);
        if (t == null) return;
        float h = t.getHeight(), w = t.getWidth();
        arcAcc += (float) dt * density;
        while (arcAcc >= 1f && arcs.size() < (LOW ? 40 : 90)) {
            arcAcc -= 1f;
            double ang = rng.nextDouble() * Math.PI * 2, rad = w * (.5 + rng.nextDouble() * .15);
            float x = (float) Math.cos(ang) * (float) rad, z = (float) Math.sin(ang) * (float) rad, y = rng.nextFloat() * h;
            int n = 4 + rng.nextInt(3);
            float[] p = new float[n * 3];
            float dx = (float) Math.cos(ang), dz = (float) Math.sin(ang);
            for (int i = 0; i < n; i++) {
                p[i * 3] = x; p[i * 3 + 1] = y; p[i * 3 + 2] = z;
                float seg = (.06f + rng.nextFloat() * .08f) * size;
                x += (dx * .6f + (rng.nextFloat() - .5f)) * seg;
                y += (rng.nextFloat() - .5f) * seg * 1.6f;
                z += (dz * .6f + (rng.nextFloat() - .5f)) * seg;
            }
            Arc a = new Arc();
            a.ent = t; a.rel = p; a.born = now; a.life = .1f + rng.nextFloat() * .18f;
            arcs.add(a);
        }
        sparkAcc += (float) dt * density * .9f;
        while (sparkAcc >= 1f && sparks.size() < (LOW ? 60 : 140)) {
            sparkAcc -= 1f;
            double ang = rng.nextDouble() * Math.PI * 2, rad = w * (.45 + rng.nextDouble() * .25);
            Spark s = new Spark();
            s.x = t.getX() + Math.cos(ang) * rad; s.y = t.getY() + rng.nextDouble() * h; s.z = t.getZ() + Math.sin(ang) * rad;
            s.vx = (rng.nextFloat() - .5f) * .25f; s.vy = .1f + rng.nextFloat() * .3f; s.vz = (rng.nextFloat() - .5f) * .25f;
            s.size = (.014f + rng.nextFloat() * .028f) * size;
            s.life = .35f + rng.nextFloat() * .45f; s.born = now;
            sparks.add(s);
        }
    }

    public void renderElectro(Camera cam, float tickDelta, int rgb, float size) {
        if (arcs.isEmpty() && sparks.isEmpty()) return;
        long now = System.currentTimeMillis();
        Vec3d c = cam.getPos();
        begin(true);
        for (int pass = 0; pass < 2; pass++) {
            int col = pass == 0 ? rgb : 0xFFFFFF;
            float wMul = pass == 0 ? 4f : 1f, aMul = pass == 0 ? .3f : 1f;
            BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            int quads = 0;
            float[] tmp = new float[0];
            for (Arc a : arcs) {
                float t = (now - a.born) / 1000f / a.life;
                float env = (1f - t) * (((now / 30) + (a.born & 3)) % 2 == 0 ? 1f : .6f);
                Vec3d p = new Vec3d(
                        MathHelper.lerp(tickDelta, a.ent.lastRenderX, a.ent.getX()),
                        MathHelper.lerp(tickDelta, a.ent.lastRenderY, a.ent.getY()),
                        MathHelper.lerp(tickDelta, a.ent.lastRenderZ, a.ent.getZ()));
                if (tmp.length != a.rel.length) tmp = new float[a.rel.length];
                for (int i = 0; i < tmp.length; i += 3) {
                    tmp[i] = (float) (p.x + a.rel[i]); tmp[i + 1] = (float) (p.y + a.rel[i + 1]); tmp[i + 2] = (float) (p.z + a.rel[i + 2]);
                }
                quads += ribbon(bb, tmp, .008f * size * wMul, col, env * aMul, false, c);
            }
            if (quads > 0) dev.batvisuals.client.util.render.SafeDraw.draw(bb);
        }
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, GLOW);
        BufferBuilder sp = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        Vector3f r = new Vector3f(1, 0, 0).rotate(cam.getRotation()), u = new Vector3f(0, 1, 0).rotate(cam.getRotation());
        for (Spark s : sparks) {
            float age = (now - s.born) / 1000f, t = age / s.life;
            float a = (float) Math.pow(1f - t, 1.2) * (.6f + .4f * (float) Math.sin(age * 40f));
            billboard(sp, s.x + s.vx * age - c.x, s.y + s.vy * age - c.y, s.z + s.vz * age - c.z, s.size * (1f + t), r, u, argb(rgb, a));
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(sp);
        end();
    }

    // ───────────────────────── превью в GUI (локальные координаты, +Y вверх) ─────────────────────────

    public void previewBolt(MatrixStack ms, float anim, int rgb, float h) {
        long now = System.currentTimeMillis();
        long slot = now / 1300L;
        float t = (now % 1300L) / 1300f;
        if (t > .45f) return;
        Random r = new Random(slot * 7919L);
        float[] p = jagLocal(r, 0f, h * .5f + 1.6f, 0f, 0f, -h * .5f, 0f, 6, .17f);
        begin(false);
        Matrix4f m = ms.peek().getPositionMatrix();
        float env = (1f - t / .45f) * anim;
        for (int pass = 0; pass < 2; pass++) {
            BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            ribbonLocal(bb, m, p, (pass == 0 ? .1f : .022f), pass == 0 ? rgb : 0xFFFFFF, env * (pass == 0 ? .35f : 1f));
            dev.batvisuals.client.util.render.SafeDraw.draw(bb);
        }
        end();
    }

    public void previewElectro(MatrixStack ms, float anim, int rgb, float h) {
        long now = System.currentTimeMillis();
        begin(false);
        Matrix4f m = ms.peek().getPositionMatrix();
        for (int pass = 0; pass < 2; pass++) {
            BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            for (int i = 0; i < 14; i++) {
                long slot = now / 130L + i * 31L;
                Random r = new Random(slot * 104729L + i);
                float ang = r.nextFloat() * 6.283f, y = (r.nextFloat() - .5f) * h;
                float x = (float) Math.cos(ang) * .3f, z = (float) Math.sin(ang) * .3f;
                float[] p = new float[12];
                for (int k = 0; k < 4; k++) {
                    p[k * 3] = x; p[k * 3 + 1] = y; p[k * 3 + 2] = z;
                    x += (r.nextFloat() - .5f) * .14f + (float) Math.cos(ang) * .04f;
                    y += (r.nextFloat() - .5f) * .16f;
                    z += (r.nextFloat() - .5f) * .14f + (float) Math.sin(ang) * .04f;
                }
                ribbonLocal(bb, m, p, pass == 0 ? .035f : .009f, pass == 0 ? rgb : 0xFFFFFF, anim * (pass == 0 ? .3f : 1f));
            }
            dev.batvisuals.client.util.render.SafeDraw.draw(bb);
        }
        end();
    }

    // ───────────────────────── геометрия ─────────────────────────

    private float[] jag(double ax, double ay, double az, double bx, double by, double bz, int iters, double disp) {
        int n = (1 << iters) + 1;
        float[] p = new float[n * 3];
        p[0] = (float) ax; p[1] = (float) ay; p[2] = (float) az;
        p[(n - 1) * 3] = (float) bx; p[(n - 1) * 3 + 1] = (float) by; p[(n - 1) * 3 + 2] = (float) bz;
        subdiv(rng, p, 0, n - 1, (float) disp);
        return p;
    }

    private float[] jagLocal(Random r, float ax, float ay, float az, float bx, float by, float bz, int iters, float disp) {
        int n = (1 << iters) + 1;
        float[] p = new float[n * 3];
        p[0] = ax; p[1] = ay; p[2] = az;
        p[(n - 1) * 3] = bx; p[(n - 1) * 3 + 1] = by; p[(n - 1) * 3 + 2] = bz;
        subdiv(r, p, 0, n - 1, disp);
        return p;
    }

    private static void subdiv(Random r, float[] p, int lo, int hi, float disp) {
        if (hi - lo < 2) return;
        int mid = (lo + hi) >> 1;
        p[mid * 3] = (p[lo * 3] + p[hi * 3]) * .5f + (r.nextFloat() - .5f) * 2f * disp;
        p[mid * 3 + 1] = (p[lo * 3 + 1] + p[hi * 3 + 1]) * .5f + (r.nextFloat() - .5f) * .5f * disp;
        p[mid * 3 + 2] = (p[lo * 3 + 2] + p[hi * 3 + 2]) * .5f + (r.nextFloat() - .5f) * 2f * disp;
        subdiv(r, p, lo, mid, disp * .55f);
        subdiv(r, p, mid, hi, disp * .55f);
    }

    /** Лента лицом к камере, мягкие края. p — мировые координаты. Возвращает число квадов. */
    private static int ribbon(BufferBuilder b, float[] p, float w, int rgb, float alpha, boolean fadeTop, Vec3d cam) {
        int n = p.length / 3;
        if (n < 2 || alpha <= .01f) return 0;
        float[] sx = new float[n], sy = new float[n], sz = new float[n];
        for (int i = 0; i < n; i++) {
            int a = Math.max(0, i - 1), c = Math.min(n - 1, i + 1);
            float dx = p[c * 3] - p[a * 3], dy = p[c * 3 + 1] - p[a * 3 + 1], dz = p[c * 3 + 2] - p[a * 3 + 2];
            float vx = (float) (p[i * 3] - cam.x), vy = (float) (p[i * 3 + 1] - cam.y), vz = (float) (p[i * 3 + 2] - cam.z);
            float cx = dy * vz - dz * vy, cy = dz * vx - dx * vz, cz = dx * vy - dy * vx;
            float l = (float) Math.sqrt(cx * cx + cy * cy + cz * cz);
            if (l < 1e-6f) { cx = 1; cy = 0; cz = 0; l = 1; }
            float k = w * (.7f + .3f * i / (n - 1f)) / l;
            sx[i] = cx * k; sy[i] = cy * k; sz[i] = cz * k;
        }
        int q = 0;
        for (int i = 0; i < n - 1; i++) {
            float a0 = alpha * (fadeTop ? Math.min(1f, i / (n - 1f) * 5.5f) : 1f);
            float a1 = alpha * (fadeTop ? Math.min(1f, (i + 1) / (n - 1f) * 5.5f) : 1f);
            int c0 = argb(rgb, a0), c1 = argb(rgb, a1), e0 = rgb & 0xFFFFFF, e1 = rgb & 0xFFFFFF;
            float x0 = (float) (p[i * 3] - cam.x), y0 = (float) (p[i * 3 + 1] - cam.y), z0 = (float) (p[i * 3 + 2] - cam.z);
            float x1 = (float) (p[i * 3 + 3] - cam.x), y1 = (float) (p[i * 3 + 4] - cam.y), z1 = (float) (p[i * 3 + 5] - cam.z);
            b.vertex(x0 - sx[i], y0 - sy[i], z0 - sz[i]).color(e0);
            b.vertex(x0, y0, z0).color(c0);
            b.vertex(x1, y1, z1).color(c1);
            b.vertex(x1 - sx[i + 1], y1 - sy[i + 1], z1 - sz[i + 1]).color(e1);
            b.vertex(x0, y0, z0).color(c0);
            b.vertex(x0 + sx[i], y0 + sy[i], z0 + sz[i]).color(e0);
            b.vertex(x1 + sx[i + 1], y1 + sy[i + 1], z1 + sz[i + 1]).color(e1);
            b.vertex(x1, y1, z1).color(c1);
            q += 2;
        }
        return q;
    }

    /** GUI-вариант: лента в плоскости XY (камера смотрит вдоль Z). */
    private static void ribbonLocal(BufferBuilder b, Matrix4f m, float[] p, float w, int rgb, float alpha) {
        int n = p.length / 3;
        int cc = argb(rgb, alpha), ec = rgb & 0xFFFFFF;
        for (int i = 0; i < n - 1; i++) {
            float x0 = p[i * 3], y0 = p[i * 3 + 1], z0 = p[i * 3 + 2], x1 = p[i * 3 + 3], y1 = p[i * 3 + 4], z1 = p[i * 3 + 5];
            float dx = x1 - x0, dy = y1 - y0, l = (float) Math.sqrt(dx * dx + dy * dy);
            if (l < 1e-6f) continue;
            float sx = -dy / l * w, sy = dx / l * w;
            b.vertex(m, x0 - sx, y0 - sy, z0).color(ec);
            b.vertex(m, x0, y0, z0).color(cc);
            b.vertex(m, x1, y1, z1).color(cc);
            b.vertex(m, x1 - sx, y1 - sy, z1).color(ec);
            b.vertex(m, x0, y0, z0).color(cc);
            b.vertex(m, x0 + sx, y0 + sy, z0).color(ec);
            b.vertex(m, x1 + sx, y1 + sy, z1).color(ec);
            b.vertex(m, x1, y1, z1).color(cc);
        }
    }

    private static void billboard(BufferBuilder b, double x, double y, double z, float s, Vector3f r, Vector3f u, int col) {
        float cx = (float) x, cy = (float) y, cz = (float) z;
        b.vertex(cx - r.x * s - u.x * s, cy - r.y * s - u.y * s, cz - r.z * s - u.z * s).texture(0, 1).color(col);
        b.vertex(cx - r.x * s + u.x * s, cy - r.y * s + u.y * s, cz - r.z * s + u.z * s).texture(0, 0).color(col);
        b.vertex(cx + r.x * s + u.x * s, cy + r.y * s + u.y * s, cz + r.z * s + u.z * s).texture(1, 0).color(col);
        b.vertex(cx + r.x * s - u.x * s, cy + r.y * s - u.y * s, cz + r.z * s - u.z * s).texture(1, 1).color(col);
    }

    private static int argb(int rgb, float a) {
        return (MathHelper.clamp((int) (a * 255f), 0, 255) << 24) | (rgb & 0xFFFFFF);
    }

    private static void begin(boolean depth) {
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        if (depth) RenderSystem.enableDepthTest(); else RenderSystem.disableDepthTest();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
    }

    private static void end() {
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }
}
