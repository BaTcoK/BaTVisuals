package dev.batvisuals.client.util.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.awt.Color;

/**
 * Рука: процедурная заливка по теме (CPU "шейдер", per-vertex) + обводка inverted hull.
 * Без GL_POLYGON_MODE, работает на GLES/MobileGlues.
 */
public final class HandFillProvider implements VertexConsumerProvider {

    private static Identifier whiteTex;
    private static boolean whiteInit;
    static final float STEP = System.getenv("POJAV_RENDERER") != null ? 0.09f : 0.05f;

    static Identifier white() {
        if (!whiteInit) {
            whiteInit = true;
            try {
                Identifier id = Identifier.of("batvisuals", "dyn/hand_white");
                NativeImage img = new NativeImage(2, 2, false);
                for (int y = 0; y < 2; y++) for (int x = 0; x < 2; x++) img.setColorArgb(x, y, 0xFFFFFFFF);
                MinecraftClient.getInstance().getTextureManager().registerTexture(id, new NativeImageBackedTexture(img));
                whiteTex = id;
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
        return whiteTex;
    }

    // ───────────────────────── Style: цвета тем ─────────────────────────

    /** theme: 0 Обычный, 1 Вода, 2 Каустика, 3 Плазма, 4 Неон, 5 Радуга, 6 Галактика, 7 Стекло */
    public static final class Style {
        public final int theme, base, c1, c2;
        public final boolean outline;
        public final float width, time;
        /** Прозрачность темы «Стекло» (0.2..1). */
        public final float glass;
        /** Заливка предметов в руке (HandItemOutline). */
        public boolean itemFill = true;
        public boolean itemOutline = true;
        public float itemAlpha = 0.6f;
        private final float h0, s0;

        public Style(int theme, int base, int c1, int c2, boolean outline, float width, float time) {
            this(theme, base, c1, c2, outline, width, time, 0.55f);
        }

        public Style(int theme, int base, int c1, int c2, boolean outline, float width, float time, float glass) {
            this.glass = glass;
            this.theme = theme;
            this.base = base & 0xFFFFFF;
            this.c1 = c1 & 0xFFFFFF;
            this.c2 = c2 & 0xFFFFFF;
            this.outline = outline;
            this.width = width * (theme == 4 ? 1.7f : 1f);
            this.time = time;
            float[] hsb = Color.RGBtoHSB((base >> 16) & 255, (base >> 8) & 255, base & 255, null);
            this.h0 = hsb[0];
            this.s0 = hsb[1];
        }

        public int fill(float x, float y, float z) {
            float t = time;
            switch (theme) {
                case 1: { // Вода
                    float a = sin(x * 11f + t * 1.7f + sin(y * 9f - t * 1.1f) * 1.6f) * .5f + .5f;
                    float b = sin(z * 10f - t * 1.3f + x * 7f) * .5f + .5f;
                    float k = a * .6f + b * .4f;
                    return mix(scale(base, .45f), mix(base, 0xFFFFFF, .6f), k * k);
                }
                case 2: { // Каустика (как в SkyFX)
                    float b = caustic(x, y, z, t);
                    return add(scale(base, b * 1.5f), scale(base, .2f));
                }
                case 3: { // Плазма
                    float v = sin(x * 14f + t) + sin(y * 13f - t * 1.2f) + sin((x + y + z) * 10f + t * .8f)
                            + sin((float) Math.sqrt(x * x + y * y + z * z) * 16f - t * 1.5f);
                    v = v * .125f + .5f;
                    return hsv(h0 + .18f * sin(v * 6.283f), s0, .35f + .65f * v);
                }
                case 4: // Неон: тёмное стекло
                    return scale(base, .08f + .04f * sin(t * 2f + y * 6f));
                case 5: // Радуга
                    return hsv(t * .15f + x * 2.2f + y * 1.6f, .85f, .95f);
                case 6: { // Галактика
                    float n = (sin(x * 8f + t * .5f) * sin(y * 7f - t * .4f + z * 5f)) * .5f + .5f;
                    int c = mix(scale(base, .12f), mix(base, hsv(h0 + .25f, .8f, 1f), .5f), n);
                    float h = hash(Math.round(x * 55f), Math.round(y * 55f), Math.round(z * 55f));
                    if (h > .93f) c = mix(c, 0xFFFFFF, .5f + .5f * sin(t * 4f + h * 50f));
                    return c;
                }
                default:
                    return base;
            }
        }

        public int line(float x, float y, float z) {
            switch (theme) {
                case 1: case 2: case 3:
                    return mix(base, 0xFFFFFF, .55f + .35f * sin(time * 2.2f + x * 8f + y * 5f));
                case 4:
                    return mix(base, 0xFFFFFF, .25f + .5f * (.5f + .5f * sin(time * 3f + x * 10f + y * 6f)));
                case 5:
                    return hsv(time * .15f + x * 2.2f + y * 1.6f + .5f, .9f, 1f);
                case 6:
                    return mix(base, 0xFFFFFF, .45f + .45f * sin(time * 2f + y * 8f));
                case 7: // Стекло: переливающаяся светлая кромка
                    return mix(hsv(time * .12f + x * 2f + y * 1.4f, .5f, 1f), 0xFFFFFF, .5f + .2f * sin(time * 2f + x * 6f));
                default: {
                    float w = .5f + .5f * sin(time * 2.2f + (x * 6f + y * 9f + z * 4f));
                    return mix(c1, c2, w);
                }
            }
        }

        /** Стекло: ARGB. Френель по нормали и позиции (камера в начале координат) + радужный переход + бегущий блик. */
        public int glassArgb(float x, float y, float z, float nx, float ny, float nz) {
            float len = (float) Math.sqrt(x * x + y * y + z * z);
            float fr = .5f;
            if (len > 1e-5f) {
                float d = Math.abs((nx * -x + ny * -y + nz * -z) / len);
                fr = 1f - Math.min(1f, d);
            }
            int irid = hsv(time * .10f + fr * .65f + x * 1.3f + y * .9f, .38f + .30f * fr, 1f);
            int c = mix(irid, base, .22f);
            float sw = sin((x * 5f + y * 7f + z * 3f) - time * 1.8f);
            sw = sw > 0f ? sw : 0f;
            sw *= sw; sw *= sw; sw *= sw;
            c = mix(c, 0xFFFFFF, Math.min(1f, sw * .85f + fr * fr * .25f));
            float a = glass * (.45f + .55f * fr * (float) Math.sqrt(fr)) + .35f * sw;
            int ai = (int) (Math.max(.12f, Math.min(.95f, a)) * 255f);
            return (ai << 24) | c;
        }

        public int lineAlpha() {
            return theme == 7 ? 235 : 255;
        }

        private static float caustic(float x, float y, float z, float t) {
            float px = x * 9f, py = y * 9f, pz = z * 9f, ix = px, iy = py, iz = pz, c = 1f;
            for (int n = 0; n < 4; n++) {
                float tt = t * (1f - 3f / (n + 1));
                float nx = px + cos(tt - ix) + sin(tt + iy);
                float ny = py + sin(tt - iy) + cos(tt + iz);
                float nz = pz + cos(tt - iz) + sin(tt + ix);
                ix = nx; iy = ny; iz = nz;
                float a = px / sin(ix + tt), b = py / cos(iy + tt), d = pz / sin(iz + tt);
                float len = (float) Math.sqrt(a * a + b * b + d * d);
                if (len > 1e-4f && !Float.isInfinite(len)) c += 1f / len;
            }
            c = 1.5f - (float) Math.sqrt(c / 4f);
            float br = c * c * c * c;
            return br < 0f ? 0f : Math.min(br, 1f);
        }

        private static float hash(int x, int y, int z) {
            int h = x * 374761393 + y * 668265263 + z * 1274126177;
            h = (h ^ (h >>> 13)) * 1274126177;
            return ((h ^ (h >>> 16)) & 0xFFFF) / 65535f;
        }

        private static float sin(float v) { return (float) Math.sin(v); }
        private static float cos(float v) { return (float) Math.cos(v); }

        private static int c255(float v) { return v < 0f ? 0 : v > 255f ? 255 : (int) v; }

        static int mix(int a, int b, float k) {
            k = k < 0f ? 0f : Math.min(k, 1f);
            return (c255(((a >> 16) & 255) * (1f - k) + ((b >> 16) & 255) * k) << 16)
                    | (c255(((a >> 8) & 255) * (1f - k) + ((b >> 8) & 255) * k) << 8)
                    | c255((a & 255) * (1f - k) + (b & 255) * k);
        }

        static int scale(int c, float k) {
            return (c255(((c >> 16) & 255) * k) << 16) | (c255(((c >> 8) & 255) * k) << 8) | c255((c & 255) * k);
        }

        static int add(int a, int b) {
            return (c255(((a >> 16) & 255) + ((b >> 16) & 255)) << 16)
                    | (c255(((a >> 8) & 255) + ((b >> 8) & 255)) << 8)
                    | c255((a & 255) + (b & 255));
        }

        static int hsv(float h, float s, float v) {
            return Color.HSBtoRGB(h - (float) Math.floor(h), Math.max(0f, Math.min(s, 1f)), Math.max(0f, Math.min(v, 1f))) & 0xFFFFFF;
        }
    }

    // ───────────────────────── общие примитивы ─────────────────────────

    private static final int[] S1 = {-1, 1, 1, -1};
    private static final int[] S2 = {-1, -1, 1, 1};

    static void put(VertexConsumer out, float x, float y, float z, int rgb) {
        put(out, x, y, z, rgb, 255);
    }

    static void put(VertexConsumer out, float x, float y, float z, int rgb, int a) {
        out.vertex(x, y, z)
                .color((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255, a)
                .texture(0f, 0f)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(LightmapTextureManager.MAX_LIGHT_COORDINATE)
                .normal(0f, 1f, 0f);
    }

    /** q[o..o+11] = 4 вершины xyz, q[o+12..o+14] = нормаль. Обратный порядок вершин: culling оставит только задние грани. */
    static void hull(VertexConsumer out, Style st, float[] q, int o) {
        float w = st.width;
        float e1x = q[o + 3] - q[o], e1y = q[o + 4] - q[o + 1], e1z = q[o + 5] - q[o + 2];
        float e2x = q[o + 9] - q[o], e2y = q[o + 10] - q[o + 1], e2z = q[o + 11] - q[o + 2];
        float nx = q[o + 12], ny = q[o + 13], nz = q[o + 14];
        float l1 = (float) Math.sqrt(e1x * e1x + e1y * e1y + e1z * e1z);
        float l2 = (float) Math.sqrt(e2x * e2x + e2y * e2y + e2z * e2z);
        float ln = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (l1 < 1e-6f || l2 < 1e-6f || ln < 1e-6f) return;
        e1x /= l1; e1y /= l1; e1z /= l1;
        e2x /= l2; e2y /= l2; e2z /= l2;
        float ux = nx / ln, uy = ny / ln, uz = nz / ln;
        float[] hp = new float[12];
        for (int k = 0; k < 4; k++) {
            hp[k * 3] = q[o + k * 3] + w * (S1[k] * e1x + S2[k] * e2x + ux);
            hp[k * 3 + 1] = q[o + k * 3 + 1] + w * (S1[k] * e1y + S2[k] * e2y + uy);
            hp[k * 3 + 2] = q[o + k * 3 + 2] + w * (S1[k] * e1z + S2[k] * e2z + uz);
        }
        if (st.theme == 7) {
            // слой стекла без culling -> отсекаем лицевые грани hull вручную (камера в начале координат)
            // порядок вывода 3,2,1,0: нормаль по (a1-a0)x(a2-a0), a0=P3 a1=P2 a2=P1
            float ax = hp[6] - hp[9], ay = hp[7] - hp[10], az = hp[8] - hp[11];
            float bx = hp[3] - hp[9], by = hp[4] - hp[10], bz = hp[5] - hp[11];
            float cx = ay * bz - az * by, cy = az * bx - ax * bz, cz = ax * by - ay * bx;
            if (cx * -hp[9] + cy * -hp[10] + cz * -hp[11] <= 0f) return;
        }
        for (int k = 3; k >= 0; k--) {
            float px = hp[k * 3], py = hp[k * 3 + 1], pz = hp[k * 3 + 2];
            put(out, px, py, pz, st.line(px, py, pz), st.lineAlpha());
        }
    }

    // ───────────────────────── провайдер руки ─────────────────────────

    private final VertexConsumerProvider parent;
    private final Style st;

    public HandFillProvider(VertexConsumerProvider parent, Style st) {
        this.parent = parent;
        this.st = st;
    }

    @Override
    public VertexConsumer getBuffer(RenderLayer layer) {
        Identifier tex = white();
        if (tex == null) return parent.getBuffer(layer); // fallback: ваниль
        RenderLayer rl = st.theme == 7 ? RenderLayer.getEntityTranslucent(tex) : RenderLayer.getEntitySolid(tex);
        return new Quads(parent.getBuffer(rl));
    }

    private final class Quads implements VertexConsumer {
        private final VertexConsumer out;
        private float pendX, pendY, pendZ;
        private final float[] q = new float[15];
        private int n;

        Quads(VertexConsumer out) { this.out = out; }

        @Override public VertexConsumer vertex(float x, float y, float z) { pendX = x; pendY = y; pendZ = z; return this; }
        @Override public VertexConsumer color(int r, int g, int b, int a) { return this; }
        @Override public VertexConsumer texture(float u, float v) { return this; }
        @Override public VertexConsumer overlay(int u, int v) { return this; }
        @Override public VertexConsumer light(int u, int v) { return this; }

        /** normal() идёт последним в последовательности вершины, значит вершина готова. */
        @Override
        public VertexConsumer normal(float x, float y, float z) {
            q[n * 3] = pendX; q[n * 3 + 1] = pendY; q[n * 3 + 2] = pendZ;
            if (n == 0) { q[12] = x; q[13] = y; q[14] = z; }
            if (++n == 4) { emit(); n = 0; }
            return this;
        }

        private void emit() {
            if (st.outline && st.width > 0f) hull(out, st, q, 0);
            if (st.theme == 0) {
                for (int i = 0; i < 4; i++) put(out, q[i * 3], q[i * 3 + 1], q[i * 3 + 2], st.base);
                return;
            }
            if (st.theme == 7) {
                emitGlass();
                return;
            }
            // тема: сетка n1 x n2, цвет считается на каждой вершине
            float l1 = dist(0, 1), l2 = dist(0, 3);
            int n1 = Math.max(1, Math.min(12, (int) Math.ceil(l1 / STEP)));
            int n2 = Math.max(1, Math.min(12, (int) Math.ceil(l2 / STEP)));
            for (int i = 0; i < n1; i++) {
                for (int j = 0; j < n2; j++) {
                    sub(i / (float) n1, j / (float) n2);
                    sub((i + 1) / (float) n1, j / (float) n2);
                    sub((i + 1) / (float) n1, (j + 1) / (float) n2);
                    sub(i / (float) n1, (j + 1) / (float) n2);
                }
            }
        }

        private void emitGlass() {
            float nx = q[12], ny = q[13], nz = q[14];
            float nl = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (nl > 1e-6f) { nx /= nl; ny /= nl; nz /= nl; }
            float l1 = dist(0, 1), l2 = dist(0, 3);
            int n1 = Math.max(1, Math.min(12, (int) Math.ceil(l1 / STEP)));
            int n2 = Math.max(1, Math.min(12, (int) Math.ceil(l2 / STEP)));
            for (int i = 0; i < n1; i++) {
                for (int j = 0; j < n2; j++) {
                    glassVertex(i / (float) n1, j / (float) n2, nx, ny, nz);
                    glassVertex((i + 1) / (float) n1, j / (float) n2, nx, ny, nz);
                    glassVertex((i + 1) / (float) n1, (j + 1) / (float) n2, nx, ny, nz);
                    glassVertex(i / (float) n1, (j + 1) / (float) n2, nx, ny, nz);
                }
            }
        }

        private void glassVertex(float s, float t, float nx, float ny, float nz) {
            float x = bil(0, s, t), y = bil(1, s, t), z = bil(2, s, t);
            int argb = st.glassArgb(x, y, z, nx, ny, nz);
            put(out, x, y, z, argb & 0xFFFFFF, argb >>> 24);
        }

        private float dist(int a, int b) {
            float dx = q[b * 3] - q[a * 3], dy = q[b * 3 + 1] - q[a * 3 + 1], dz = q[b * 3 + 2] - q[a * 3 + 2];
            return (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        }

        /** билинейная точка квада (s вдоль 0→1, t вдоль 0→3) */
        private void sub(float s, float t) {
            float x = bil(0, s, t), y = bil(1, s, t), z = bil(2, s, t);
            put(out, x, y, z, st.fill(x, y, z));
        }

        private float bil(int c, float s, float t) {
            float a = q[c] + (q[3 + c] - q[c]) * s;
            float b = q[9 + c] + (q[6 + c] - q[9 + c]) * s;
            return a + (b - a) * t;
        }
    }
}
