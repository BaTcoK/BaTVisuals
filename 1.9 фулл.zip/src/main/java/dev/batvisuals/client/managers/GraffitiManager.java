package dev.batvisuals.client.managers;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Local + Firebase-synced graffiti stickers on blocks.
 * Image payload is only an index (0..N) — all clients ship the same textures.
 */
public class GraffitiManager {

    public static final int IMAGE_COUNT = 12;
    public static final long LIFETIME_MS = 5 * 60 * 1000L;

    public static final class Sticker {
        public final int x, y, z;
        public final int face; // Direction.getId()
        public final int image;
        public final long expiresAt;
        public final String dim;
        public final String id;
        /** Yaw in degrees — rotation on floor/ceiling so sticker faces player look. */
        public final float yaw;

        public Sticker(String id, int x, int y, int z, int face, int image, long expiresAt, String dim, float yaw) {
            this.id = id;
            this.x = x; this.y = y; this.z = z;
            this.face = face; this.image = image;
            this.expiresAt = expiresAt; this.dim = dim;
            this.yaw = yaw;
        }

        public boolean expired() {
            return System.currentTimeMillis() > expiresAt;
        }
    }

    private final List<Sticker> stickers = new CopyOnWriteArrayList<>();
    private final ExecutorService io = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "bat-graffiti");
        t.setDaemon(true);
        return t;
    });
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private String baseUrl; // firebase root, injected
    private long lastPull;

    public void setBaseUrl(String url) {
        this.baseUrl = url;
    }

    public List<Sticker> getStickers() {
        prune();
        return stickers;
    }

    public void addLocal(Sticker s) {
        // One graffiti per block (any face) — replace old
        java.util.List<Sticker> removed = new java.util.ArrayList<>();
        stickers.removeIf(o -> {
            boolean same = o.x == s.x && o.y == s.y && o.z == s.z
                    && (o.dim == null || s.dim == null || o.dim.equals(s.dim));
            if (same) removed.add(o);
            return same;
        });
        for (Sticker r : removed) {
            try { deleteRemote(r.id); } catch (Throwable ignored) {}
        }
        stickers.add(s);
        push(s);
    }

    private void deleteRemote(String id) {
        if (baseUrl == null || baseUrl.isEmpty() || id == null) return;
        io.execute(() -> {
            try {
                String path = baseUrl + "/graffiti/" + id + ".json";
                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create(path))
                        .timeout(Duration.ofSeconds(6))
                        .DELETE()
                        .build();
                http.send(req, HttpResponse.BodyHandlers.discarding());
            } catch (Throwable ignored) {}
        });
    }

    public void remove(String id) {
        if (id == null) return;
        stickers.removeIf(s -> id.equals(s.id));
    }

    private void prune() {
        stickers.removeIf(Sticker::expired);
    }

    public void tickPull(String serverKey) {
        long now = System.currentTimeMillis();
        if (now - lastPull < 4000) return;
        lastPull = now;
        if (baseUrl == null || baseUrl.isEmpty() || serverKey == null) return;
        io.execute(() -> pull(serverKey));
    }

    private void push(Sticker s) {
        if (baseUrl == null || baseUrl.isEmpty()) return;
        io.execute(() -> {
            try {
                JsonObject o = new JsonObject();
                o.addProperty("x", s.x);
                o.addProperty("y", s.y);
                o.addProperty("z", s.z);
                o.addProperty("face", s.face);
                o.addProperty("image", s.image);
                o.addProperty("expiresAt", s.expiresAt);
                o.addProperty("dim", s.dim);
                o.addProperty("yaw", s.yaw);
                JsonObject ts = new JsonObject();
                ts.addProperty(".sv", "timestamp"); // серверное время Firebase — защита от разницы часов
                o.add("ts", ts);
                String path = baseUrl + "/graffiti/" + s.id + ".json";
                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create(path))
                        .timeout(Duration.ofSeconds(6))
                        .header("Content-Type", "application/json")
                        .PUT(HttpRequest.BodyPublishers.ofString(o.toString()))
                        .build();
                http.send(req, HttpResponse.BodyHandlers.discarding());
            } catch (Throwable ignored) {}
        });
    }

    private void pull(String serverKey) {
        try {
            // Global graffiti list (shared for all BaTVisuals users)
            String path = baseUrl + "/graffiti.json";
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(path))
                    .timeout(Duration.ofSeconds(6))
                    .GET()
                    .build();
            HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() >= 300 || res.body() == null || res.body().equals("null")) return;
            JsonElement root = JsonParser.parseString(res.body());
            if (!root.isJsonObject()) return;
            long now = System.currentTimeMillis();
            long srvNow = -1;
            try {
                var dh = res.headers().firstValue("Date");
                if (dh.isPresent()) srvNow = java.time.ZonedDateTime.parse(dh.get(),
                        java.time.format.DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli();
            } catch (Throwable ignored) {}
            int cleaned = 0;
            for (var e : root.getAsJsonObject().entrySet()) {
                if (!e.getValue().isJsonObject()) continue;
                JsonObject o = e.getValue().getAsJsonObject();
                long exp = o.has("expiresAt") ? o.get("expiresAt").getAsLong() : 0;
                if (srvNow > 0 && o.has("ts") && o.get("ts").isJsonPrimitive()) {
                    // срок считаем от серверного времени, а не от часов отправителя
                    exp = now + LIFETIME_MS - (srvNow - o.get("ts").getAsLong());
                }
                if (exp < now) {
                    if (exp < now - 600_000L && cleaned++ < 10) deleteRemote(e.getKey());
                    continue;
                }
                String id = e.getKey();
                boolean exists = false;
                for (Sticker s : stickers) if (s.id.equals(id)) { exists = true; break; }
                if (exists) continue;
                float yaw = o.has("yaw") ? o.get("yaw").getAsFloat() : 0f;
                stickers.add(new Sticker(
                        id,
                        o.get("x").getAsInt(),
                        o.get("y").getAsInt(),
                        o.get("z").getAsInt(),
                        o.get("face").getAsInt(),
                        o.get("image").getAsInt(),
                        exp,
                        o.has("dim") ? o.get("dim").getAsString() : "minecraft:overworld",
                        yaw
                ));
            }
            prune();
        } catch (Throwable ignored) {}
    }
}
