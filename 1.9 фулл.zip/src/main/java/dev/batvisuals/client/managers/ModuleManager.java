package dev.batvisuals.client.managers;

import dev.batvisuals.modules.impl.render.SkyFX;

import dev.batvisuals.modules.impl.utility.FakeFPS;

import dev.batvisuals.client.events.impl.EventKey;
import dev.batvisuals.client.events.impl.EventMouse;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.settings.Setting;
import dev.batvisuals.modules.settings.impl.BindSetting;
import dev.batvisuals.modules.settings.api.Bind;
import dev.batvisuals.modules.impl.render.*;
import dev.batvisuals.modules.impl.utility.*;
import dev.batvisuals.client.util.Wrapper;
import dev.batvisuals.batvisuals;
import lombok.Getter;
import meteordevelopment.orbit.EventHandler;
import org.lwjgl.glfw.GLFW;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Getter
public class ModuleManager implements Wrapper {

    private final List<Module> modules = new ArrayList<>();
    private final Map<Module, Bind> defaultBinds = new HashMap<>();

    public ModuleManager() {
        batvisuals.getInstance().getEventHandler().subscribe(this);
        addModules(
                new NoRender(),
                new Pets(),
                new Graffiti(),
                new Crosshair(),
                new ViewModel(),
                new TargetEsp(),
                new ShowArmor(),
                new HandUP(),
                new AutoSprint(),
                new FTHelper(),
                new UI(),
                new AspectRatio(),
                new HitSound(),
                new AutoRespawn(),
                new CustomHitBox(),
                new NameProtect(),
                new ChinaHat(),
                new PvpHelper(),
                new JumpCircle(),
                new ClientSound(),
                new WorldParticles(),
                new DamageParticles(),
                new CustomFog(),
                new SwingAnimation(),
                new TimeChanger(),
                new ItemPhysic(),
                new FriendHelper(),
                new Predictions(),
                new BlockOverlay(),
                new BetterMinecraft(),
                new Zoom(),
                new ShiftTap(),
                new Trails(),
                new SmokeTrails(),
                new DeathAnimation(),
                new HitBubbles(),
                new HitColor(),
                new FlightMotion(),
                new DamageExplosion(),
                new DiscordRPCModule(),
                new BaTIndicator(),
                new BatSwap(),
                new dev.batvisuals.modules.impl.render.SmoothCamera(),
                new GlyphLines(),
                new FakeFPS(),
                new HandShader(),
                new NoGlow(),
                new SkyFX(),
                new Wings(),
                new Halo(),
                new dev.batvisuals.modules.impl.render.Cape(),
                new FakePlayer(),
                new Optimization(),
                new Collector()
        );

        for (Module module : modules) {
            try {
                for (Field field : module.getClass().getDeclaredFields()) {
                    if (!Setting.class.isAssignableFrom(field.getType())) continue;
                    field.setAccessible(true);
                    Setting<?> setting = (Setting<?>) field.get(module);
                    if (setting != null && !module.getSettings().contains(setting)) module.getSettings().add(setting);
                }
            } catch (Exception ignored) {}
            // Capture default binds after module fully constructed
            defaultBinds.put(module, module.getBind());
        }
    }

    private void addModules(Module... module) {
        this.modules.addAll(List.of(module));
        this.modules.sort(java.util.Comparator.comparing(m -> m.getName().toLowerCase(java.util.Locale.ROOT)));
    }

    @EventHandler
    public void onKey(EventKey e) {
        // Do not toggle modules while any GUI screen is open
        if (mc.currentScreen != null) return;
        // Filter invalid key
        if (e.getKey() < 0) return;
        for (Module module : modules) {
            if (module.getBind().isMouse()) continue;
            if (module.getBind().getKey() < 0) continue;
            if (module.getBind().getKey() != e.getKey()) continue;
            switch (e.getAction()) {
                case GLFW.GLFW_PRESS -> {
                    if (module.getBind().getMode() == dev.batvisuals.modules.settings.api.Bind.Mode.HOLD) module.setToggled(true);
                    else module.toggle();
                }
                case GLFW.GLFW_RELEASE -> {
                    if (module.getBind().getMode() == dev.batvisuals.modules.settings.api.Bind.Mode.HOLD) module.setToggled(false);
                }
            }
        }
    }

    @EventHandler
    public void onMouse(EventMouse e) {
        // Do not toggle modules while any GUI screen is open
        if (mc.currentScreen != null) return;
        if (e.getButton() < 0) return;
        for (Module module : modules) {
            if (!module.getBind().isMouse()) continue;
            if (module.getBind().getKey() < 0) continue;
            if (module.getBind().getKey() != e.getButton()) continue;
            switch (e.getAction()) {
                case GLFW.GLFW_PRESS -> {
                    if (module.getBind().getMode() == dev.batvisuals.modules.settings.api.Bind.Mode.HOLD) module.setToggled(true);
                    else module.toggle();
                }
                case GLFW.GLFW_RELEASE -> {
                    if (module.getBind().getMode() == dev.batvisuals.modules.settings.api.Bind.Mode.HOLD) module.setToggled(false);
                }
            }
        }
    }

    public List<Module> getModules(Category category) {
        return modules.stream().filter(m -> m.getCategory() == category).toList();
    }

    public List<Category> getCategories() {
        return Arrays.asList(Category.values());
    }

    public <T extends Module> T getModule(Class<T> clazz) {
        for (Module module : modules) {
            if (!clazz.isInstance(module)) continue;
            return (T) module;
        }
        return null;
    }

    public Module getModuleByName(String name) {
        for (Module module : modules) {
            if (module.getName().equalsIgnoreCase(name)) {
                return module;
            }
        }
        return null;
    }

    public void resetBindsToDefaults() {
        for (Module module : modules) {
            Bind def = defaultBinds.get(module);
            if (def == null) def = new Bind(-1, false);
            module.setBind(def);
        }
    }
}
