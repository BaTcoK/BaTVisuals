package dev.batvisuals.client.managers;

import dev.batvisuals.client.ui.hud.impl.ArmorHUD;
import dev.batvisuals.client.ui.hud.impl.Potions;
import dev.batvisuals.client.util.math.MathUtils;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.client.events.impl.EventMouse;
import dev.batvisuals.client.events.impl.EventRender2D;
import dev.batvisuals.client.ui.hud.HudElement;
import dev.batvisuals.client.ui.hud.impl.TargetHud;
import dev.batvisuals.client.ui.hud.impl.HotbarHUD;
import dev.batvisuals.client.ui.hud.impl.Watermark;
import dev.batvisuals.client.ui.hud.impl.DynamicIsland;
import dev.batvisuals.client.ui.hud.impl.Keystrokes;
import dev.batvisuals.client.ui.hud.impl.MusicPlayerHud;
import dev.batvisuals.modules.impl.utility.TotemCounter;
import dev.batvisuals.client.ui.hud.windows.Window;
import dev.batvisuals.client.util.render.Wrapper;
import dev.batvisuals.modules.settings.Setting;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.ListSetting;
import dev.batvisuals.batvisuals;
import lombok.Getter;
import lombok.Setter;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.ChatScreen;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import static dev.batvisuals.client.util.Wrapper.mc;

@Getter
public class HudManager implements Wrapper {

    @Setter private HudElement currentDragging;
    private final List<HudElement> hudElements = new ArrayList<>();
    protected final ListSetting elements = new ListSetting("setting.layout",
            new BooleanSetting("Watermark", true),
            new BooleanSetting("DynamicIsland", true),
            new BooleanSetting("TargetHud", true),
            new BooleanSetting("Potions", true),
            new BooleanSetting("ArmorHUD", true),
            new BooleanSetting("Hotbar", true),
            new BooleanSetting("TotemCounter", true),
            new BooleanSetting("Keystrokes", true),
            new BooleanSetting("MusicPlayer", true)
    );
    @Setter private Window window;

    public HudManager() {
        batvisuals.getInstance().getEventHandler().subscribe(this);

        addElements(
                new Watermark(),
                new DynamicIsland(),
                new TargetHud(),
                new Potions(),
                new ArmorHUD(),
                new HotbarHUD(),
                new TotemCounter(),
                new Keystrokes(),
                new MusicPlayerHud()
        );

        for (HudElement element : hudElements) {
            try {
                Class<?> cl = element.getClass();
                while (cl != null && cl != Object.class) {
                    for (Field field : cl.getDeclaredFields()) {
                        if (!Setting.class.isAssignableFrom(field.getType())) continue;
                        field.setAccessible(true);
                        Setting<?> setting = (Setting<?>) field.get(element);
                        if (setting != null && !element.getSettings().contains(setting)) element.getSettings().add(setting);
                    }
                    cl = cl.getSuperclass();
                }
            } catch (Exception ignored) {}

            // Subscribe HUD elements to the event bus so they can render and handle input
            try {
                batvisuals.getInstance().getEventHandler().subscribe(element);
            } catch (Throwable ignored) {}
        }
        ensureHudToggles();
    }

    private void ensureHudToggles() {
        try {
            java.util.List<BooleanSetting> list = new java.util.ArrayList<>(elements.getValue());
            java.util.function.Consumer<String> ensure = name -> {
                for (BooleanSetting b : list) {
                    if (name.equalsIgnoreCase(b.getName())) return;
                }
                list.add(new BooleanSetting(name, true));
            };
            ensure.accept("Keystrokes");
            ensure.accept("MusicPlayer");
            elements.setValue(list);
            for (HudElement el : hudElements) {
                if ("Keystrokes".equalsIgnoreCase(el.getName()) || "MusicPlayer".equalsIgnoreCase(el.getName())) {
                    el.setToggled(true);
                    BooleanSetting bs = elements.getName(el.getName());
                    if (bs != null) bs.setValue(true);
                }
            }
        } catch (Throwable ignored) {}
    }

    @EventHandler
    public void onRender2D(EventRender2D e) {
        if (Module.fullNullCheck()) return;

        if (window != null) {
            if (!(mc.currentScreen instanceof ChatScreen)) window.reset();

            if (window.closed()) {
                window = null;
                return;
            }

            window.render(e.getContext(), mouseX(), mouseY());
        }
    }

    @EventHandler
    public void onMouse(EventMouse e) {
        if (!(mc.currentScreen instanceof ChatScreen) || Module.fullNullCheck()) return;

        if (e.getAction() == 1) {
            if (window != null) {
                if (MathUtils.isHovered(window.getX(), window.getY(), window.getWidth(), window.getFinalHeight(), mouseX(), mouseY())) {
                    window.mouseClicked(mouseX(), mouseY(), e.getButton());
                    return;
                } else window.reset();
            }

            if (e.getButton() == 1) {
                // If right-click is over any HUD element area, let the element handle opening its own settings
                for (HudElement element : hudElements) {
                    if (MathUtils.isHovered(element.getX(), element.getY(), element.getWidth(), element.getHeight(), mouseX(), mouseY())) {
                        return;
                    }
                }

                // Otherwise, open the global elements window
                for (HudElement element : hudElements) {
                    if (element.getWindow() == null) continue;
                    if (element.getSettings().size() == 1) return;
                    element.getWindow().reset();
                }

                window = new Window(mouseX() + 3, mouseY() + 3, 100, 12.5f, List.of(elements));
            }
        }
    }

    public int mouseX() {
        return (int) (mc.mouse.getX() / mc.getWindow().getScaleFactor());
    }

    public int mouseY() {
        return (int) (mc.mouse.getY() / mc.getWindow().getScaleFactor());
    }

    private void addElements(HudElement... element) {
        this.hudElements.addAll(List.of(element));
    }
}