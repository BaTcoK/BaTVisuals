package dev.batvisuals.client.managers;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.ChatUtils;
import dev.batvisuals.client.events.impl.EventPacket;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.util.math.Vec3d;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Авто-ивент для FunTime / SpookyTime.
 *
 * Логика детекта сообщений и типов ивентов адаптирована из мода
 * FTAutoEvent / gpsmarkers (MIT) by <b>b1nt1n</b> — с сохранением авторства.
 * Интеграция в BaTVisuals: метки WaypointManager, удаление в 100 м, только FT/Spooky.
 */
public final class AutoEventManager {

    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static final double AUTO_REMOVE_DIST = 100.0;

    // --- patterns from b1nt1n/gpsmarkers (MIT) ---
    private static final Pattern COORDINATES = Pattern.compile(
            "координат[а-яёa-z]*[^-+\\d]*(?:\\[\\s*)?([-+]?\\d+(?:[.,]\\d+)?)[,\\s]+([-+]?\\d+(?:[.,]\\d+)?)[,\\s]+([-+]?\\d+(?:[.,]\\d+)?)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern LOOT_LEVEL = Pattern.compile(
            "уровень\\s+лута\\s*:?\\s*([^\\n\\r\\]║]+)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern SUMMON_PLAYER = Pattern.compile(
            "призван\\s+игроком\\s+([^\\s\\]║]+)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern FORMATTING_CODE = Pattern.compile("(?i)§[0-9A-FK-OR]");
    private static final long PENDING_TTL_MS = 6000L;

    /** Типы ивентов (displayName) — по b1nt1n AutoEventType */
    public enum EventType {
        MYSTIC_BEACON("Загадочный маяк"),
        KILLER_BEACON("Маяк убийца"),
        METEOR_SHOWER("Метеоритный дождь"),
        VOLCANO("Вулкан"),
        UNDEAD_ALTAR("Алтарь нежити"),
        AIRDROP("Аир-дроп"),
        GEYSER("Гейзер"),
        GENERIC("Авто-метка");

        public final String displayName;
        EventType(String d) { this.displayName = d; }
    }

    private static final class PendingEvent {
        final EventType type;
        long updatedAt;
        String lootLevel = "";
        String playerName = "";
        PendingEvent(EventType type, long t) { this.type = type; this.updatedAt = t; }
    }

    private PendingEvent pendingEvent;
    private long deathMessageAt;
    private long lastWaypointMs;

    public AutoEventManager() {
        batvisuals.getInstance().getEventHandler().subscribe(this);
    }

    private static boolean isSupportedBrand() {
        String b = WaypointManager.detectBrand();
        return "funtime".equals(b) || "spookytime".equals(b);
    }

    @EventHandler
    public void onPacket(EventPacket.Receive event) {
        if (!WaypointManager.isAutoEvent()) return;
        if (!isSupportedBrand()) return;
        if (!(event.getPacket() instanceof GameMessageS2CPacket packet)) return;
        String raw;
        try {
            raw = packet.content().getString();
        } catch (Throwable t) {
            return;
        }
        if (raw == null || raw.isBlank()) return;
        onServerMessage(raw);
    }

    public void tick() {
        if (!WaypointManager.isAutoEvent()) return;
        if (mc.player == null) return;
        tryRemoveNearbyMarkers();
        // /event delay не спамим — основной источник = объявления в чате (как у b1nt1n)
    }

    /** Адаптация EventMarkerDetector.onServerMessage (b1nt1n, MIT). */
    public void onServerMessage(String rawMessage) {
        String normalized = normalize(rawMessage);
        for (String rawLine : normalized.split("\\R")) {
            String line = rawLine.trim();
            if (!line.isBlank()) processLine(line);
        }
    }

    private void processLine(String message) {
        long now = System.currentTimeMillis();
        if (isDeathMessage(message)) {
            deathMessageAt = now;
            pendingEvent = null;
            return;
        }

        EventType explicitType = detectType(message);
        if (explicitType != null) {
            pendingEvent = new PendingEvent(explicitType, now);
        }

        PendingEvent current = validPending(now);
        if (current != null) {
            updatePendingDetails(current, message);
        }

        Matcher coordinates = COORDINATES.matcher(message);
        if (!coordinates.find()) return;
        if (shouldIgnoreCoordinates(message, now, explicitType, current)) return;

        EventType type = explicitType;
        current = validPending(now);
        if (type == null) {
            type = current == null ? EventType.GENERIC : current.type;
        }

        int x = parseCoordinate(coordinates.group(1));
        int y = parseCoordinate(coordinates.group(2));
        int z = parseCoordinate(coordinates.group(3));
        String name = buildMarkerName(type, current, message);

        if (now - lastWaypointMs < 1500) return;
        lastWaypointMs = now;

        WaypointManager.refreshContext();
        // одна метка на тип+имя — replace by name
        WaypointManager.add(name, new Vec3d(x + 0.5, y, z + 0.5));
        // также держим Auto-Event как «последний ивент» для быстрого удаления у точки
        WaypointManager.add("Auto-Event", new Vec3d(x + 0.5, y, z + 0.5));
        try {
            ChatUtils.sendMessage("§aAuto-Event §7→ §f" + name + " §e" + x + " " + y + " " + z
                    + " §8(логика FTAutoEvent © b1nt1n, MIT)");
        } catch (Throwable ignored) {}
    }

    private void tryRemoveNearbyMarkers() {
        if (mc.player == null) return;
        WaypointManager.refreshContext();
        double px = mc.player.getX();
        double pz = mc.player.getZ();
        for (WaypointManager.Waypoint wp : new java.util.ArrayList<>(WaypointManager.list())) {
            if (wp == null || wp.name == null) continue;
            // удаляем Auto-Event и метки ивентов при приближении
            boolean isEvent = wp.name.equalsIgnoreCase("Auto-Event")
                    || startsWithEventName(wp.name);
            if (!isEvent) continue;
            double dx = px - wp.pos.x;
            double dz = pz - wp.pos.z;
            if (Math.sqrt(dx * dx + dz * dz) <= AUTO_REMOVE_DIST) {
                WaypointManager.remove(wp.name);
                try {
                    ChatUtils.sendMessage("§7Метка §f" + wp.name + " §cудалена §8(≤100м)");
                } catch (Throwable ignored) {}
            }
        }
    }

    private static boolean startsWithEventName(String name) {
        for (EventType t : EventType.values()) {
            if (name.regionMatches(true, 0, t.displayName, 0, t.displayName.length())) return true;
        }
        return name.regionMatches(true, 0, "Авто-метка", 0, "Авто-метка".length());
    }

    // ---- detect / parse (b1nt1n) ----

    private static EventType detectType(String message) {
        String lower = message.toLowerCase(Locale.ROOT);
        if (lower.contains("загадочный маяк")) return EventType.MYSTIC_BEACON;
        if (lower.contains("маяк убийца")) return EventType.KILLER_BEACON;
        if (lower.contains("метеоритный дождь")) return EventType.METEOR_SHOWER;
        if (lower.contains("вулкан")) return EventType.VOLCANO;
        if (lower.contains("алтарь нежити")) return EventType.UNDEAD_ALTAR;
        if (lower.contains("аир-дроп") || lower.contains("аирдроп") || lower.contains("пандора")
                || lower.contains("air-drop") || lower.contains("airdrop")) return EventType.AIRDROP;
        if (lower.contains("гейзер")) return EventType.GEYSER;
        if (lower.contains("призван игроком")) return EventType.MYSTIC_BEACON;
        return null;
    }

    private static void updatePendingDetails(PendingEvent event, String message) {
        event.updatedAt = System.currentTimeMillis();
        Matcher loot = LOOT_LEVEL.matcher(message);
        if (loot.find()) event.lootLevel = cleanTail(loot.group(1));
        Matcher player = SUMMON_PLAYER.matcher(message);
        if (player.find()) event.playerName = cleanTail(player.group(1));
    }

    private static String buildMarkerName(EventType type, PendingEvent event, String message) {
        String lootLevel = event == null ? extractLoot(message) : event.lootLevel;
        String playerName = event == null ? extractPlayer(message) : event.playerName;
        return switch (type) {
            case MYSTIC_BEACON, AIRDROP ->
                    (playerName != null && !playerName.isBlank())
                            ? type.displayName + ": " + playerName
                            : type.displayName;
            case KILLER_BEACON, METEOR_SHOWER, VOLCANO, GEYSER ->
                    withLoot(type.displayName, lootLevel);
            case UNDEAD_ALTAR -> type.displayName;
            case GENERIC -> "Авто-метка";
        };
    }

    private static String withLoot(String name, String lootLevel) {
        if (lootLevel == null || lootLevel.isBlank()) return name;
        return name + ": " + lootLevel;
    }

    private static String extractLoot(String message) {
        Matcher loot = LOOT_LEVEL.matcher(message);
        return loot.find() ? cleanTail(loot.group(1)) : null;
    }

    private static String extractPlayer(String message) {
        Matcher player = SUMMON_PLAYER.matcher(message);
        return player.find() ? cleanTail(player.group(1)) : null;
    }

    private boolean shouldIgnoreCoordinates(String message, long now, EventType explicitType, PendingEvent event) {
        if (isDeathMessage(message)) return true;
        // Shortly after death: ignore coords unless this line explicitly names an event
        if (now - deathMessageAt <= PENDING_TTL_MS) {
            return explicitType == null && (event == null || event.updatedAt <= deathMessageAt);
        }
        return false;
    }

    private static boolean isDeathMessage(String message) {
        String lower = message.toLowerCase(Locale.ROOT);
        return lower.contains("вы погибли")
                || lower.contains("помянем")
                || lower.contains("вас убил")
                || lower.contains("смерть на координат");
    }

    private PendingEvent validPending(long now) {
        if (pendingEvent == null || now - pendingEvent.updatedAt > PENDING_TTL_MS) {
            pendingEvent = null;
            return null;
        }
        return pendingEvent;
    }

    private static String normalize(String rawMessage) {
        String withoutEscaped = rawMessage.replace("\\n", "\n");
        return FORMATTING_CODE.matcher(withoutEscaped).replaceAll("").replace('\u00a0', ' ');
    }

    private static String cleanTail(String value) {
        if (value == null || value.isBlank()) return "";
        String cleaned = value.replace("[", "").replace("]", "").trim();
        int idx = cleaned.toLowerCase(Locale.ROOT).indexOf("на координат");
        if (idx >= 0) cleaned = cleaned.substring(0, idx).trim();
        return cleaned.length() > 24 ? cleaned.substring(0, 24) : cleaned;
    }

    private static int parseCoordinate(String value) {
        try {
            return (int) Math.round(Double.parseDouble(value.replace(',', '.')));
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
