package dev.batvisuals.client.managers;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Saves custom 5x5 crosshair presets to config/batvisuals/crosshairs.json */
public final class CrosshairPresetManager {
    public static final int SIZE = 5;
    public static final String VANILLA = "Ванильный";

    public static final class Preset {
        public String name;
        /** ARGB pixels row-major 5x5; 0 = empty */
        public int[] pixels = new int[SIZE * SIZE];

        public Preset() {}
        public Preset(String name) {
            this.name = name;
        }
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final List<Preset> PRESETS = new ArrayList<>();
    private static String selected = VANILLA;
    private static File file;

    private CrosshairPresetManager() {}

    public static void init(File globalsDir) {
        file = new File(globalsDir, "crosshairs.json");
        load();
    }

    public static synchronized String getSelected() {
        return selected == null ? VANILLA : selected;
    }

    public static synchronized void setSelected(String name) {
        selected = name == null ? VANILLA : name;
        save();
    }

    public static synchronized boolean isVanilla() {
        return VANILLA.equals(getSelected());
    }

    public static synchronized List<Preset> list() {
        return Collections.unmodifiableList(new ArrayList<>(PRESETS));
    }

    public static synchronized Preset getSelectedPreset() {
        if (isVanilla()) return null;
        for (Preset p : PRESETS) {
            if (p.name != null && p.name.equalsIgnoreCase(selected)) return p;
        }
        return null;
    }

    public static synchronized boolean add(Preset p) {
        if (p == null || p.name == null || p.name.isBlank()) return false;
        if (VANILLA.equalsIgnoreCase(p.name.trim())) return false;
        String n = p.name.trim();
        PRESETS.removeIf(x -> x.name != null && x.name.equalsIgnoreCase(n));
        p.name = n;
        if (p.pixels == null || p.pixels.length != SIZE * SIZE) p.pixels = new int[SIZE * SIZE];
        PRESETS.add(p);
        selected = n;
        save();
        return true;
    }

    public static synchronized boolean rename(String oldName, String newName) {
        if (oldName == null || newName == null) return false;
        if (VANILLA.equalsIgnoreCase(oldName) || VANILLA.equalsIgnoreCase(newName)) return false;
        for (Preset p : PRESETS) {
            if (p.name != null && p.name.equalsIgnoreCase(oldName)) {
                p.name = newName.trim();
                if (selected.equalsIgnoreCase(oldName)) selected = p.name;
                save();
                return true;
            }
        }
        return false;
    }

    public static synchronized boolean remove(String name) {
        if (name == null || VANILLA.equalsIgnoreCase(name)) return false;
        boolean ok = PRESETS.removeIf(p -> p.name != null && p.name.equalsIgnoreCase(name));
        if (ok && selected.equalsIgnoreCase(name)) selected = VANILLA;
        if (ok) save();
        return ok;
    }

    public static synchronized void save() {
        if (file == null) return;
        try {
            File parent = file.getParentFile();
            if (parent != null) parent.mkdirs();
            JsonObject root = new JsonObject();
            root.addProperty("selected", selected);
            JsonArray arr = new JsonArray();
            for (Preset p : PRESETS) {
                JsonObject o = new JsonObject();
                o.addProperty("name", p.name);
                JsonArray pix = new JsonArray();
                if (p.pixels != null) {
                    for (int v : p.pixels) pix.add(v);
                }
                o.add("pixels", pix);
                arr.add(o);
            }
            root.add("presets", arr);
            try (FileWriter w = new FileWriter(file)) {
                GSON.toJson(root, w);
            }
        } catch (Throwable ignored) {}
    }

    public static synchronized void load() {
        PRESETS.clear();
        selected = VANILLA;
        if (file == null || !file.exists()) return;
        try (FileReader r = new FileReader(file)) {
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
            if (root.has("selected")) selected = root.get("selected").getAsString();
            if (root.has("presets")) {
                for (var el : root.getAsJsonArray("presets")) {
                    JsonObject o = el.getAsJsonObject();
                    Preset p = new Preset(o.get("name").getAsString());
                    p.pixels = new int[SIZE * SIZE];
                    if (o.has("pixels")) {
                        JsonArray pix = o.getAsJsonArray("pixels");
                        for (int i = 0; i < Math.min(pix.size(), SIZE * SIZE); i++) {
                            p.pixels[i] = pix.get(i).getAsInt();
                        }
                    }
                    PRESETS.add(p);
                }
            }
        } catch (Throwable ignored) {}
    }

    public static File defaultDir() {
        try {
            return new File(MinecraftClient.getInstance().runDirectory, "config/batvisuals");
        } catch (Throwable t) {
            return new File("config/batvisuals");
        }
    }
}
