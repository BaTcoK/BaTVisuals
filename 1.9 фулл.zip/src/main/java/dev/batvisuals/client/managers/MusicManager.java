package dev.batvisuals.client.managers;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.batvisuals.batvisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import org.lwjgl.openal.AL10;
import org.lwjgl.system.MemoryUtil;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Плеер через OpenAL (движок Minecraft).
 * javax.sound на Android/Termux НЕ работает — поэтому только OpenAL.
 * Форматы: .wav (PCM), .ogg. .mp3 пока не поддерживается без декодера.
 */
public final class MusicManager {

    public static final Identifier DEFAULT_COVER = Identifier.of("batvisuals", "hud/music_avatar.png");

    public static final class Track {
        public final File file;
        public final String title;
        public final String artist;

        public Track(File file, String title, String artist) {
            this.file = file;
            this.title = title;
            this.artist = artist;
        }
    }

    private static File musicDir;
    private static final List<Track> TRACKS = new ArrayList<>();
    private static int index = 0;

    private static volatile boolean playing = false;
    private static volatile boolean paused = false;
    private static float volume = 0.85f;
    private static boolean loopTrack = false;
    private static boolean autoPlayOnSelect = true;
    private static boolean shuffle = false;

    private static int alSource = -1;
    private static int alBuffer = -1;
    private static int playGeneration = 0;
    private static final AtomicBoolean stopFlag = new AtomicBoolean(false);
    private static Thread monitorThread;

    private static final Map<String, Identifier> COVER_CACHE = new HashMap<>();
    private static int coverSeq = 0;

    private MusicManager() {}

    public static void init(File globalsDir) {
        musicDir = new File(globalsDir, "music");
        if (!musicDir.exists()) musicDir.mkdirs();
        try {
            File readme = new File(musicDir, "README.txt");
            if (!readme.exists()) {
                Files.writeString(readme.toPath(),
                        "Положи треки сюда.\n" +
                        "Поддерживается: .wav (PCM 16-bit) и .ogg\n" +
                        ".mp3 на Android НЕ играет — конвертируй в .wav или .ogg\n" +
                        "Имя: Автор - Название.wav\n" +
                        "Обложка: то же имя .png/.jpg или cover.png\n");
            }
        } catch (Throwable ignored) {}
        refresh();
    }

    public static File getMusicDir() { return musicDir; }

    public static synchronized void refresh() {
        TRACKS.clear();
        if (musicDir == null || !musicDir.isDirectory()) return;
        File[] files = musicDir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (!f.isFile()) continue;
            String n = f.getName().toLowerCase(Locale.ROOT);
            if (!(n.endsWith(".wav") || n.endsWith(".ogg") || n.endsWith(".mp3"))) continue;
            String base = f.getName();
            int dot = base.lastIndexOf('.');
            if (dot > 0) base = base.substring(0, dot);
            String artist = "Неизвестен";
            String title = base;
            int sep = base.indexOf(" - ");
            if (sep < 0) sep = base.indexOf(" – ");
            if (sep > 0) {
                artist = base.substring(0, sep).trim();
                title = base.substring(sep + 3).trim();
            }
            TRACKS.add(new Track(f, title.isEmpty() ? f.getName() : title, artist));
        }
        TRACKS.sort((a, b) -> a.title.compareToIgnoreCase(b.title));
        if (index >= TRACKS.size()) index = Math.max(0, TRACKS.size() - 1);
    }

    public static synchronized List<Track> list() {
        return Collections.unmodifiableList(new ArrayList<>(TRACKS));
    }

    public static synchronized Track current() {
        if (TRACKS.isEmpty()) return null;
        if (index < 0 || index >= TRACKS.size()) index = 0;
        return TRACKS.get(index);
    }

    public static synchronized int getIndex() { return index; }
    public static synchronized boolean isPlaying() { return playing && !paused; }
    public static synchronized boolean isPaused() { return paused; }
    public static synchronized boolean hasTracks() { return !TRACKS.isEmpty(); }

    public static synchronized float getVolume() { return volume; }
    public static synchronized void setVolume(float v) {
        volume = Math.max(0f, Math.min(1f, v));
        applyGain();
    }
    public static synchronized boolean isLoopTrack() { return loopTrack; }
    public static synchronized void setLoopTrack(boolean v) { loopTrack = v; }
    public static synchronized boolean isAutoPlayOnSelect() { return autoPlayOnSelect; }
    public static synchronized void setAutoPlayOnSelect(boolean v) { autoPlayOnSelect = v; }
    public static synchronized boolean isShuffle() { return shuffle; }
    public static synchronized void setShuffle(boolean v) { shuffle = v; }

    public static float estimatePanelContentHeight() {
        return 14f + 52f + 12f + 22f + 12f + 14f * 3 + 12f + 18f + 12f + 14f + list().size() * 34f + 24f;
    }

    public static synchronized void select(int i) {
        if (i < 0 || i >= TRACKS.size()) return;
        stopInternal();
        index = i;
    }

    public static synchronized void selectAndPlay(int i) {
        if (i < 0 || i >= TRACKS.size()) return;
        stopInternal();
        index = i;
        playInternal();
    }

    public static synchronized void play() {
        if (TRACKS.isEmpty()) {
            refresh();
            if (TRACKS.isEmpty()) return;
        }
        if (playing && paused) {
            resumeInternal();
            return;
        }
        if (playing && !paused) return;
        playInternal();
    }

    public static synchronized void playPause() {
        if (TRACKS.isEmpty()) {
            refresh();
            if (TRACKS.isEmpty()) return;
        }
        if (playing && !paused) {
            pauseInternal();
        } else if (playing && paused) {
            resumeInternal();
        } else {
            playInternal();
        }
    }

    public static synchronized void next() {
        if (TRACKS.isEmpty()) return;
        boolean was = isPlaying() || paused;
        stopInternal();
        if (shuffle && TRACKS.size() > 1) {
            int n;
            do { n = (int) (Math.random() * TRACKS.size()); } while (n == index && TRACKS.size() > 1);
            index = n;
        } else {
            index = (index + 1) % TRACKS.size();
        }
        if (was || autoPlayOnSelect) playInternal();
    }

    public static synchronized void prev() {
        if (TRACKS.isEmpty()) return;
        boolean was = isPlaying() || paused;
        stopInternal();
        index = (index - 1 + TRACKS.size()) % TRACKS.size();
        if (was || autoPlayOnSelect) playInternal();
    }

    public static synchronized void stop() {
        stopInternal();
    }

    public static synchronized boolean delete(int i) {
        if (i < 0 || i >= TRACKS.size()) return false;
        Track t = TRACKS.get(i);
        boolean wasCurrent = i == index;
        if (wasCurrent) stopInternal();
        boolean ok = false;
        try { ok = t.file.delete(); } catch (Throwable ignored) {}
        refresh();
        if (wasCurrent && !TRACKS.isEmpty()) index = Math.min(i, TRACKS.size() - 1);
        return ok;
    }

    public static Identifier getCover(Track track) {
        if (track == null) return DEFAULT_COVER;
        try {
            File cover = findCoverFile(track);
            if (cover == null || !cover.isFile()) return DEFAULT_COVER;
            String key = cover.getAbsolutePath() + ":" + cover.lastModified();
            Identifier cached = COVER_CACHE.get(key);
            if (cached != null) return cached;
            NativeImage img;
            try (InputStream in = new FileInputStream(cover)) {
                img = NativeImage.read(in);
            }
            NativeImageBackedTexture tex = new NativeImageBackedTexture(img);
            Identifier id = Identifier.of("batvisuals", "dynamic/music_cover_" + (coverSeq++));
            MinecraftClient.getInstance().getTextureManager().registerTexture(id, tex);
            COVER_CACHE.put(key, id);
            return id;
        } catch (Throwable t) {
            return DEFAULT_COVER;
        }
    }

    public static Identifier getCurrentCover() {
        return getCover(current());
    }

    private static File findCoverFile(Track track) {
        if (track == null || track.file == null) return null;
        String name = track.file.getName();
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        File parent = track.file.getParentFile();
        if (parent == null) parent = musicDir;
        for (String e : new String[]{".png", ".jpg", ".jpeg", ".webp"}) {
            File f = new File(parent, base + e);
            if (f.isFile()) return f;
        }
        if (musicDir != null) {
            for (String n : new String[]{"cover.png", "cover.jpg", "folder.png", "folder.jpg", "album.png", "album.jpg"}) {
                File f = new File(musicDir, n);
                if (f.isFile()) return f;
            }
        }
        return null;
    }

    // ---------- OpenAL playback ----------

    private static void playInternal() {
        Track t = current();
        if (t == null) return;
        final File file = t.file;
        stopFlag.set(false);
        paused = false;
        playing = true; // UI сразу показывает play
        final int gen = ++playGeneration;

        // Декод в фоне, OpenAL-объекты создаём на render thread
        new Thread(() -> {
            try {
                PcmData pcm = decodeFile(file);
                if (stopFlag.get() || gen != playGeneration) return;
                MinecraftClient.getInstance().execute(() -> {
                    synchronized (MusicManager.class) {
                        if (stopFlag.get() || gen != playGeneration) return;
                        try {
                            startOpenAl(pcm, gen);
                        } catch (Throwable ex) {
                            playing = false;
                            paused = false;
                            try {
                                batvisuals.LOGGER.warn("[Music] OpenAL play fail: {}", ex.toString());
                            } catch (Throwable ignored) {}
                        }
                    }
                });
            } catch (Throwable ex) {
                synchronized (MusicManager.class) {
                    if (gen == playGeneration) {
                        playing = false;
                        paused = false;
                    }
                }
                try {
                    batvisuals.LOGGER.warn("[Music] decode fail {}: {}", file.getName(), ex.toString());
                } catch (Throwable ignored) {}
            }
        }, "BaTVisuals-Music-Decode").start();
    }

    private static void startOpenAl(PcmData pcm, int gen) {
        destroyAlQuiet();
        int buffer = AL10.alGenBuffers();
        int source = AL10.alGenSources();
        int err = AL10.alGetError();
        if (err != AL10.AL_NO_ERROR) {
            throw new IllegalStateException("alGen error " + err);
        }

        ByteBuffer data = MemoryUtil.memAlloc(pcm.samples.remaining());
        data.put(pcm.samples);
        data.flip();
        AL10.alBufferData(buffer, pcm.alFormat, data, pcm.sampleRate);
        MemoryUtil.memFree(data);

        AL10.alSourcei(source, AL10.AL_BUFFER, buffer);
        AL10.alSourcei(source, AL10.AL_LOOPING, loopTrack ? AL10.AL_TRUE : AL10.AL_FALSE);
        AL10.alSourcef(source, AL10.AL_GAIN, Math.max(0f, Math.min(1f, volume)));
        AL10.alSourcePlay(source);

        alBuffer = buffer;
        alSource = source;
        playing = true;
        paused = false;

        // монитор окончания
        monitorThread = new Thread(() -> {
            try {
                while (!stopFlag.get() && gen == playGeneration) {
                    if (paused) {
                        Thread.sleep(50);
                        continue;
                    }
                    int state = AL10.alGetSourcei(source, AL10.AL_SOURCE_STATE);
                    if (state == AL10.AL_STOPPED) {
                        synchronized (MusicManager.class) {
                            if (gen != playGeneration || stopFlag.get()) return;
                            playing = false;
                            paused = false;
                            destroyAlQuiet();
                            if (loopTrack) {
                                MinecraftClient.getInstance().execute(MusicManager::playInternal);
                            } else if (!TRACKS.isEmpty()) {
                                MinecraftClient.getInstance().execute(() -> {
                                    synchronized (MusicManager.class) {
                                        if (shuffle && TRACKS.size() > 1) {
                                            int n;
                                            do { n = (int) (Math.random() * TRACKS.size()); } while (n == index && TRACKS.size() > 1);
                                            index = n;
                                        } else {
                                            index = (index + 1) % TRACKS.size();
                                        }
                                        playInternal();
                                    }
                                });
                            }
                        }
                        return;
                    }
                    Thread.sleep(80);
                }
            } catch (Throwable ignored) {}
        }, "BaTVisuals-Music-Monitor");
        monitorThread.setDaemon(true);
        monitorThread.start();
    }

    private static void applyGain() {
        try {
            if (alSource > 0) {
                AL10.alSourcef(alSource, AL10.AL_GAIN, Math.max(0f, Math.min(1f, volume)));
            }
        } catch (Throwable ignored) {}
    }

    private static void pauseInternal() {
        paused = true;
        try {
            if (alSource > 0) AL10.alSourcePause(alSource);
        } catch (Throwable ignored) {}
    }

    private static void resumeInternal() {
        paused = false;
        try {
            if (alSource > 0) AL10.alSourcePlay(alSource);
        } catch (Throwable ignored) {}
    }

    private static void stopInternal() {
        stopFlag.set(true);
        playGeneration++;
        paused = false;
        playing = false;
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null) {
                // destroy on render thread if possible
                if (RenderSystem.isOnRenderThread()) {
                    destroyAlQuiet();
                } else {
                    mc.execute(MusicManager::destroyAlQuiet);
                }
            } else {
                destroyAlQuiet();
            }
        } catch (Throwable t) {
            destroyAlQuiet();
        }
        stopFlag.set(false);
    }

    private static void destroyAlQuiet() {
        try {
            if (alSource > 0) {
                AL10.alSourceStop(alSource);
                AL10.alDeleteSources(alSource);
            }
        } catch (Throwable ignored) {}
        try {
            if (alBuffer > 0) AL10.alDeleteBuffers(alBuffer);
        } catch (Throwable ignored) {}
        alSource = -1;
        alBuffer = -1;
    }

    // ---------- decode ----------

    private static final class PcmData {
        final ByteBuffer samples; // direct, 16-bit LE
        final int sampleRate;
        final int alFormat;

        PcmData(ByteBuffer samples, int sampleRate, int channels) {
            this.samples = samples;
            this.sampleRate = sampleRate;
            this.alFormat = channels == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16;
        }
    }

    private static PcmData decodeFile(File file) throws Exception {
        String n = file.getName().toLowerCase(Locale.ROOT);
        if (n.endsWith(".ogg")) return decodeOgg(file);
        if (n.endsWith(".wav")) return decodeWav(file);
        if (n.endsWith(".mp3")) return decodeMp3(file);
        throw new IllegalStateException("Неподдерживаемый формат: " + file.getName());
    }

    /**
     * MP3 → PCM 16-bit через JLayer (javazoom).
     * Результат сразу в OpenAL, без javax.sound.
     */
    private static PcmData decodeMp3(File file) throws Exception {
        java.io.ByteArrayOutputStream raw = new java.io.ByteArrayOutputStream(1024 * 256);
        int channels = 2;
        int sampleRate = 44100;
        try (java.io.InputStream fis = new java.io.BufferedInputStream(new FileInputStream(file))) {
            javazoom.jl.decoder.Bitstream bitstream = new javazoom.jl.decoder.Bitstream(fis);
            javazoom.jl.decoder.Decoder decoder = new javazoom.jl.decoder.Decoder();
            boolean first = true;
            while (true) {
                javazoom.jl.decoder.Header header = bitstream.readFrame();
                if (header == null) break;
                if (first) {
                    sampleRate = header.frequency();
                    // mode: 3 = single channel (mono)
                    int mode = header.mode();
                    channels = (mode == javazoom.jl.decoder.Header.SINGLE_CHANNEL) ? 1 : 2;
                    first = false;
                }
                javazoom.jl.decoder.SampleBuffer output =
                        (javazoom.jl.decoder.SampleBuffer) decoder.decodeFrame(header, bitstream);
                short[] buf = output.getBuffer();
                int len = output.getBufferLength();
                for (int i = 0; i < len; i++) {
                    short s = buf[i];
                    raw.write(s & 0xff);
                    raw.write((s >> 8) & 0xff);
                }
                bitstream.closeFrame();
            }
            try { bitstream.close(); } catch (Throwable ignored) {}
        }
        byte[] bytes = raw.toByteArray();
        if (bytes.length < 64) {
            throw new IllegalStateException("MP3 пустой или не декодировался: " + file.getName());
        }
        ByteBuffer pcm = MemoryUtil.memAlloc(bytes.length);
        pcm.put(bytes);
        pcm.flip();
        return new PcmData(pcm, sampleRate > 0 ? sampleRate : 44100, channels > 0 ? channels : 2);
    }

    private static PcmData decodeOgg(File file) throws Exception {
        // LWJGL STB Vorbis — тот же декодер, что у Minecraft
        org.lwjgl.system.MemoryStack stack = org.lwjgl.system.MemoryStack.stackPush();
        try {
            java.nio.IntBuffer channelsBuf = stack.mallocInt(1);
            java.nio.IntBuffer rateBuf = stack.mallocInt(1);
            ShortBuffer pcm = org.lwjgl.stb.STBVorbis.stb_vorbis_decode_filename(
                    file.getAbsolutePath(), channelsBuf, rateBuf);
            if (pcm == null) {
                throw new IllegalStateException("STB не смог декодировать OGG: " + file.getName());
            }
            int channels = channelsBuf.get(0);
            int rate = rateBuf.get(0);
            ByteBuffer bytes = MemoryUtil.memAlloc(pcm.remaining() * 2);
            // short → little-endian bytes
            while (pcm.hasRemaining()) {
                short s = pcm.get();
                bytes.put((byte) (s & 0xff));
                bytes.put((byte) ((s >> 8) & 0xff));
            }
            bytes.flip();
            return new PcmData(bytes, rate > 0 ? rate : 44100, channels > 0 ? channels : 1);
        } finally {
            stack.close();
        }
    }

    /** Простой PCM WAV reader (16-bit). */
    private static PcmData decodeWav(File file) throws Exception {
        byte[] all = Files.readAllBytes(file.toPath());
        if (all.length < 44) throw new IllegalStateException("WAV слишком короткий");
        ByteBuffer bb = ByteBuffer.wrap(all).order(ByteOrder.LITTLE_ENDIAN);
        if (bb.getInt() != 0x46464952) throw new IllegalStateException("Не RIFF"); // 'RIFF'
        bb.getInt(); // size
        if (bb.getInt() != 0x45564157) throw new IllegalStateException("Не WAVE"); // 'WAVE'

        int channels = 1;
        int rate = 44100;
        int bits = 16;
        int dataOffset = -1;
        int dataSize = 0;

        while (bb.remaining() >= 8) {
            int id = bb.getInt();
            int size = bb.getInt();
            int pos = bb.position();
            if (id == 0x20746d66) { // 'fmt '
                int audioFormat = bb.getShort() & 0xffff;
                channels = bb.getShort() & 0xffff;
                rate = bb.getInt();
                bb.getInt(); // byte rate
                bb.getShort(); // block align
                bits = bb.getShort() & 0xffff;
                if (audioFormat != 1) {
                    throw new IllegalStateException("Нужен PCM WAV (format=1), сейчас " + audioFormat);
                }
            } else if (id == 0x61746164) { // 'data'
                dataOffset = pos;
                dataSize = size;
                break;
            }
            bb.position(pos + size + (size & 1)); // word align
        }
        if (dataOffset < 0) throw new IllegalStateException("Нет data chunk в WAV");
        if (bits != 16) throw new IllegalStateException("Нужен 16-bit WAV, сейчас " + bits);

        ByteBuffer pcm = MemoryUtil.memAlloc(dataSize);
        pcm.put(all, dataOffset, dataSize);
        pcm.flip();
        return new PcmData(pcm, rate, channels);
    }
}
