package dev.batvisuals.client.managers;

import com.google.common.collect.Lists;
import dev.batvisuals.batvisuals;
import dev.batvisuals.client.events.impl.EventRender2D;
import dev.batvisuals.client.ui.clickgui.ClickGui;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.client.util.Wrapper;
import dev.batvisuals.client.util.notify.Notify;
import meteordevelopment.orbit.EventHandler;

import java.util.*;

public class NotifyManager implements Wrapper {

    public NotifyManager() {
        batvisuals.getInstance().getEventHandler().subscribe(this);
    }

    private final List<Notify> notifies = new ArrayList<>();

    public void add(Notify notify) {
        notifies.add(notify);
    }

    @EventHandler
    public void onRender2D(EventRender2D e) {
        if (notifies.isEmpty()) return;
        // Не перекрываем ClickGUI
        if (mc.currentScreen instanceof ClickGui) return;
        float startY = mc.getWindow().getScaledHeight() / 2f + 26;
        if (notifies.size() > 10) notifies.removeFirst();
        notifies.removeIf(Notify::expired);

        for (Notify notify : Lists.newArrayList(notifies)) {
            startY = (startY - 22f);
            notify.render(e, startY + (notifies.size() * 22f));
        }
    }
}