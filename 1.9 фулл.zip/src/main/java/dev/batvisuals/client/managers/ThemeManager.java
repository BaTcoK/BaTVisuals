package dev.batvisuals.client.managers;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * Static colour themes only — no RGB / gradient animation (stable menu + watermark).
 */
public class ThemeManager {
    private static ThemeManager instance;
    private Theme currentTheme;
    private final List<ThemeChangeListener> listeners = new ArrayList<>();

    private ThemeManager() {
        this.currentTheme = new SolidTheme("Синяя", new Color(55, 130, 230));
    }

    public static ThemeManager getInstance() {
        if (instance == null) {
            instance = new ThemeManager();
        }
        return instance;
    }

    public void setTheme(Theme theme) {
        if (theme == null) return;
        this.currentTheme = theme;
        notifyListeners();
    }

    public void addThemeChangeListener(ThemeChangeListener listener) {
        if (listener != null && !listeners.contains(listener)) listeners.add(listener);
    }

    public void removeThemeChangeListener(ThemeChangeListener listener) {
        listeners.remove(listener);
    }

    private void notifyListeners() {
        for (ThemeChangeListener listener : listeners) {
            try {
                listener.onThemeChanged(currentTheme);
            } catch (Throwable ignored) {}
        }
    }

    public Theme getCurrentTheme() {
        return currentTheme;
    }

    /** Accent / brand colour used by HUD and ClickGUI. */
    public Color getThemeColor() {
        return currentTheme != null ? currentTheme.getAccentColor() : new Color(120, 90, 255);
    }

    public Theme[] getAvailableThemes() {
        return new Theme[]{
                new SolidTheme("White", new Color(230, 230, 235)),
                new SolidTheme("Тёмная", new Color(90, 90, 100)),
                new SolidTheme("Синяя", new Color(55, 130, 230)),
                new SolidTheme("Красная", new Color(230, 25, 30)),
                new SolidTheme("Зелёная", new Color(50, 175, 95)),
                new SolidTheme("Оранжевая", new Color(230, 130, 40)),
                new SolidTheme("Фиолетовая", new Color(145, 75, 220)),
                new SolidTheme("Розовая", new Color(230, 90, 160)),
                new SolidTheme("Жёлтая", new Color(230, 200, 55)),
                new SolidTheme("Бирюзовая", new Color(45, 190, 185)),
                // was RGB / gradient — now static
                new SolidTheme("Emerald", new Color(40, 180, 110)),
                new SolidTheme("Amethyst", new Color(155, 90, 220)),
                new SolidTheme("Лайм", new Color(140, 220, 50)),
                new SolidTheme("Золотой", new Color(218, 175, 45)),
                new SolidTheme("Коричневый", new Color(145, 95, 55)),
                new SolidTheme("Голубая", new Color(80, 170, 255)),
                new SolidTheme("Мятная", new Color(70, 210, 160)),
                new SolidTheme("Коралловая", new Color(240, 110, 100)),
                new SolidTheme("Индиго", new Color(75, 70, 200)),
                new SolidTheme("Малиновая", new Color(190, 40, 90)),
                new SolidTheme("Оливковая", new Color(120, 140, 55)),
                new SolidTheme("Серебристая", new Color(170, 180, 195)),
        };
    }

    /** Always false — gradients removed for stable UI. */
    public boolean isGradientTheme(Theme theme) {
        return false;
    }

    public interface Theme {
        Color getBackgroundColor();
        Color getBorderColor();
        Color getTextColor();
        Color getAccentColor();
        Color getSecondaryBackgroundColor();
        String getName();
    }

    public interface ThemeChangeListener {
        void onThemeChanged(Theme theme);
    }

    /**
     * Static theme: dark panels + fixed accent colour (no animation).
     */
    public static class SolidTheme implements Theme {
        private final String name;
        private final Color accent;

        public SolidTheme(String name, Color accent) {
            this.name = name;
            this.accent = accent;
        }

        @Override
        public Color getBackgroundColor() {
            return new Color(22, 22, 28, 230);
        }

        @Override
        public Color getBorderColor() {
            return new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 120);
        }

        @Override
        public Color getTextColor() {
            return Color.WHITE;
        }

        @Override
        public Color getAccentColor() {
            return accent;
        }

        @Override
        public Color getSecondaryBackgroundColor() {
            return new Color(28, 28, 34, 230);
        }

        @Override
        public String getName() {
            return name;
        }
    }

    /** Kept for compatibility with old references. */
    public static class LightTheme extends SolidTheme {
        public LightTheme() {
            super("White", new Color(230, 230, 235));
        }
    }

    public static class DarkTheme extends SolidTheme {
        public DarkTheme() {
            super("Тёмная", new Color(90, 90, 100));
        }
    }
}
