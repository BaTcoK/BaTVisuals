package dev.batvisuals.client.managers;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.util.math.Vec3d;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Метки как в оригинале (единый список + отображение), плюс context при сохранении.
 */
public final class WaypointManager {

    public static final class Waypoint {
        public final String name;
        public final Vec3d pos;
        public final String context; // server key / sp:name / default

        public Waypoint(String name, Vec3d pos) {
            this(name, pos, "default");
        }

        public Waypoint(String name, Vec3d pos, String context) {
            this.name = name;
            this.pos = pos;
            this.context = context == null ? "default" : context;
        }
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final List<Waypoint> WAYPOINTS = new ArrayList<>();
    private static File waypointsFile;
    private static boolean autoEvent = false;

    private WaypointManager() {}

    public static void init(File globalsDir) {
        waypointsFile = new File(globalsDir, "waypoints.json");
        loadAll();
    }

    public static synchronized boolean isAutoEvent() { return false; } // removed

    public static synchronized void setAutoEvent(boolean v) {
        autoEvent = false;
        saveAll();
    }

    public static String getCurrentContext() {
        return detectContextKey();
    }

    public static void refreshContext() {
        // no-op for API compat; context computed on demand
    }

    public static String detectContextKey() {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc == null) return "default";
            ServerInfo info = mc.getCurrentServerEntry();
            if (info != null && info.address != null && !info.address.isBlank()) {
                return normalizeServerKey(info.address);
            }
            if (mc.isInSingleplayer()) {
                try {
                    if (mc.getServer() != null) {
                        String name = mc.getServer().getSaveProperties().getLevelName();
                        if (name != null && !name.isBlank()) return "sp:" + name.trim();
                    }
                } catch (Throwable ignored) {}
                return "sp:singleplayer";
            }
        } catch (Throwable ignored) {}
        return "default";
    }

    public static String normalizeServerKey(String address) {
        if (address == null) return "default";
        String a = address.trim().toLowerCase(Locale.ROOT);
        int colon = a.lastIndexOf(':');
        if (colon > 0 && a.indexOf(']') < 0) {
            try {
                Integer.parseInt(a.substring(colon + 1));
                a = a.substring(0, colon);
            } catch (Exception ignored) {}
        }
        String[] brands = {"funtime", "holyworld", "reallyworld", "spookytime"};
        for (String b : brands) {
            if (a.contains(b)) return a.substring(a.indexOf(b));
        }
        String[] parts = a.split("\\.");
        if (parts.length >= 2) return parts[parts.length - 2] + "." + parts[parts.length - 1];
        return a.isEmpty() ? "default" : a;
    }

    public static String detectBrand() {
        String k = detectContextKey().toLowerCase(Locale.ROOT);
        if (k.contains("funtime")) return "funtime";
        if (k.contains("spookytime") || k.contains("spooky")) return "spookytime";
        if (k.contains("holyworld") || k.contains("holy")) return "holyworld";
        if (k.contains("reallyworld") || k.contains("really")) return "reallyworld";
        return "unknown";
    }

    public static synchronized void add(String name, Vec3d pos) {
        if (name == null || name.isBlank() || pos == null) return;
        String n = name.trim();
        String ctx = detectContextKey();
        WAYPOINTS.removeIf(w -> w.name.equalsIgnoreCase(n) && (w.context.equals(ctx) || "default".equals(w.context)));
        WAYPOINTS.add(new Waypoint(n, pos, ctx));
        saveAll();
    }

    public static synchronized boolean remove(String name) {
        String ctx = detectContextKey();
        boolean ok = WAYPOINTS.removeIf(w -> w.name.equalsIgnoreCase(name)
                && (w.context.equals(ctx) || "default".equals(w.context) || "default".equals(ctx)));
        // if none matched context, remove by name only
        if (!ok) {
            ok = WAYPOINTS.removeIf(w -> w.name.equalsIgnoreCase(name));
        }
        if (ok) saveAll();
        return ok;
    }

    public static synchronized void clear() {
        String ctx = detectContextKey();
        WAYPOINTS.removeIf(w -> w.context.equals(ctx) || "default".equals(w.context));
        saveAll();
    }

    /**
     * Как в оригинале: всегда отдаём видимый список.
     * Фильтр по серверу, но если пусто — все метки (чтобы не «пропали»).
     */
    public static synchronized List<Waypoint> list() {
        String ctx = detectContextKey();
        List<Waypoint> filtered = new ArrayList<>();
        for (Waypoint w : WAYPOINTS) {
            if (w.context == null || w.context.equals(ctx) || "default".equals(w.context)
                    || "default".equals(ctx)) {
                filtered.add(w);
            }
        }
        if (filtered.isEmpty() && !WAYPOINTS.isEmpty()) {
            return Collections.unmodifiableList(new ArrayList<>(WAYPOINTS));
        }
        return Collections.unmodifiableList(filtered);
    }

    public static synchronized void saveAll() {
        if (waypointsFile == null) return;
        try {
            File parent = waypointsFile.getParentFile();
            if (parent != null) parent.mkdirs();
        } catch (Throwable ignored) {}
        JsonObject root = new JsonObject();
        root.addProperty("autoEvent", autoEvent);
        JsonArray arr = new JsonArray();
        for (Waypoint w : WAYPOINTS) {
            JsonObject o = new JsonObject();
            o.addProperty("name", w.name);
            o.addProperty("x", w.pos.x);
            o.addProperty("y", w.pos.y);
            o.addProperty("z", w.pos.z);
            o.addProperty("context", w.context);
            arr.add(o);
        }
        root.add("waypoints", arr);
        try (FileWriter writer = new FileWriter(waypointsFile)) {
            GSON.toJson(root, writer);
        } catch (Exception ignored) {}
    }

    public static synchronized void loadAll() {
        WAYPOINTS.clear();
        autoEvent = false;
        if (waypointsFile == null || !waypointsFile.exists()) return;
        try (FileReader reader = new FileReader(waypointsFile)) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
            if (root.has("autoEvent")) autoEvent = root.get("autoEvent").getAsBoolean();
            // new format
            if (root.has("waypoints")) {
                for (JsonElement el : root.getAsJsonArray("waypoints")) {
                    JsonObject o = el.getAsJsonObject();
                    String name = o.get("name").getAsString();
                    double x = o.get("x").getAsDouble();
                    double y = o.has("y") ? o.get("y").getAsDouble() : 64;
                    double z = o.get("z").getAsDouble();
                    String ctx = o.has("context") ? o.get("context").getAsString() : "default";
                    WAYPOINTS.add(new Waypoint(name, new Vec3d(x, y, z), ctx));
                }
            }
            // migrate contexts{} from previous version
            if (root.has("contexts") && root.get("contexts").isJsonObject()) {
                JsonObject contexts = root.getAsJsonObject("contexts");
                for (var e : contexts.entrySet()) {
                    if (!e.getValue().isJsonArray()) continue;
                    for (JsonElement el : e.getValue().getAsJsonArray()) {
                        JsonObject o = el.getAsJsonObject();
                        String name = o.get("name").getAsString();
                        double x = o.get("x").getAsDouble();
                        double y = o.has("y") ? o.get("y").getAsDouble() : 64;
                        double z = o.get("z").getAsDouble();
                        WAYPOINTS.add(new Waypoint(name, new Vec3d(x, y, z), e.getKey()));
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    public static void save() { saveAll(); }
    public static void load() { loadAll(); }
}
