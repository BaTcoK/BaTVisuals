package dev.batvisuals.client.managers;

import com.google.gson.*;
import dev.batvisuals.batvisuals;
import dev.batvisuals.client.util.notify.Notify;
import dev.batvisuals.client.util.notify.NotifyIcons;
import lombok.Getter;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Друзья хранятся по UUID (ключ Firebase без дефисов) + последний известный ник.
 * Онлайн-статус и смена ника — через {@link FirebaseManager} (players/{uuid}).
 */
public class FriendsManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final List<FriendEntry> friends = new ArrayList<>();
    @Getter private static File friendsFile;

    public static class FriendEntry {
        /** UUID без дефисов (Firebase key), может быть null пока не резолвится */
        public String uuidKey;
        public String nick;

        public FriendEntry(String uuidKey, String nick) {
            this.uuidKey = uuidKey;
            this.nick = nick;
        }
    }

    public static void init(File globalsDir) {
        friendsFile = new File(globalsDir, "friends.json");
        load();
    }

    public static synchronized void addFriend(String name) {
        if (name == null || name.isEmpty()) return;
        String nick = name.trim();
        if (nick.isEmpty()) return;
        if (checkFriend(nick)) return;

        String uuidKey = null;
        try {
            FirebaseManager fb = batvisuals.getInstance().getFirebaseManager();
            if (fb != null) {
                uuidKey = fb.findUuidKeyByNick(nick);
            }
        } catch (Throwable ignored) {}

        // Также пробуем tab-list (если друг на том же сервере)
        if (uuidKey == null) {
            try {
                var mc = net.minecraft.client.MinecraftClient.getInstance();
                if (mc != null && mc.getNetworkHandler() != null) {
                    for (var entry : mc.getNetworkHandler().getPlayerList()) {
                        if (entry == null || entry.getProfile() == null) continue;
                        if (nick.equalsIgnoreCase(entry.getProfile().getName())) {
                            uuidKey = entry.getProfile().getId().toString().replace("-", "");
                            break;
                        }
                    }
                }
            } catch (Throwable ignored) {}
        }

        friends.add(new FriendEntry(uuidKey, nick));
        save();
    }

    public static synchronized void addFriend(String uuidKey, String nick) {
        if (nick == null || nick.isEmpty()) return;
        if (uuidKey != null) {
            for (FriendEntry f : friends) {
                if (uuidKey.equalsIgnoreCase(f.uuidKey)) return;
            }
        }
        if (checkFriend(nick)) return;
        friends.add(new FriendEntry(uuidKey, nick.trim()));
        save();
    }

    public static synchronized void removeFriend(String name) {
        if (name == null) return;
        friends.removeIf(f -> f.nick != null && f.nick.equalsIgnoreCase(name));
        save();
    }

    public static synchronized void removeFriendEntry(FriendEntry entry) {
        friends.remove(entry);
        save();
    }

    public static synchronized boolean checkFriend(String name) {
        if (name == null) return false;
        for (FriendEntry f : friends) {
            if (f.nick != null && f.nick.equalsIgnoreCase(name)) return true;
        }
        return false;
    }

    public static synchronized boolean checkFriendUuid(String uuidKey) {
        if (uuidKey == null) return false;
        String k = uuidKey.replace("-", "");
        for (FriendEntry f : friends) {
            if (f.uuidKey != null && f.uuidKey.equalsIgnoreCase(k)) return true;
        }
        return false;
    }

    public static synchronized void clear() {
        friends.clear();
        save();
    }

    /** Ники друзей (для совместимости со старым UI). */
    public static synchronized List<String> getFriends() {
        List<String> nicks = new ArrayList<>();
        for (FriendEntry f : friends) nicks.add(f.nick);
        return Collections.unmodifiableList(nicks);
    }

    public static synchronized List<FriendEntry> getFriendEntries() {
        return Collections.unmodifiableList(new ArrayList<>(friends));
    }

    public static boolean isFriendOnline(FriendEntry f) {
        if (f == null) return false;
        try {
            FirebaseManager fb = batvisuals.getInstance().getFirebaseManager();
            if (fb == null) return false;
            if (f.uuidKey != null && !f.uuidKey.isEmpty()) {
                return fb.isOnlineKey(f.uuidKey);
            }
            return fb.isNickOnline(f.nick);
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Вызывается после обновления Firebase-кэша.
     * Резолвит UUID по нику и ловит смену ника.
     */
    public static synchronized void onPresenceUpdate(
            Map<String, FirebaseManager.PlayerSnapshot> all,
            Map<String, FirebaseManager.PlayerSnapshot> online
    ) {
        if (all == null) return;
        boolean changed = false;

        for (FriendEntry f : friends) {
            // Resolve UUID by nick if missing
            if ((f.uuidKey == null || f.uuidKey.isEmpty()) && f.nick != null) {
                for (Map.Entry<String, FirebaseManager.PlayerSnapshot> e : all.entrySet()) {
                    if (e.getValue() != null && e.getValue().nick != null
                            && e.getValue().nick.equalsIgnoreCase(f.nick)) {
                        f.uuidKey = e.getKey();
                        changed = true;
                        break;
                    }
                }
            }

            // Nick change detection
            if (f.uuidKey != null && all.containsKey(f.uuidKey)) {
                FirebaseManager.PlayerSnapshot snap = all.get(f.uuidKey);
                if (snap != null && snap.nick != null && !snap.nick.isEmpty()
                        && f.nick != null && !snap.nick.equals(f.nick)) {
                    String oldNick = f.nick;
                    f.nick = snap.nick;
                    changed = true;
                    notifyNickChange(oldNick, snap.nick);
                }
            }
        }

        if (changed) save();
    }

    private static void notifyNickChange(String oldNick, String newNick) {
        try {
            String msg = "Друг сменил ник: " + oldNick + " → " + newNick;
            batvisuals.getInstance().getNotifyManager().add(
                    new Notify(NotifyIcons.successIcon, msg, 4000)
            );
        } catch (Throwable ignored) {}
    }


    /** Игрок-друг? (по нику и UUID) */
    public static boolean isFriendPlayer(net.minecraft.entity.player.PlayerEntity player) {
        if (player == null) return false;
        try {
            String nick = player.getGameProfile().getName();
            if (checkFriend(nick)) return true;
            String uuid = player.getGameProfile().getId().toString().replace("-", "");
            if (checkFriendUuid(uuid)) return true;
        } catch (Throwable ignored) {}
        return false;
    }

    public static boolean isFriendEntity(net.minecraft.entity.Entity entity) {
        if (entity instanceof net.minecraft.entity.player.PlayerEntity pe) {
            return isFriendPlayer(pe);
        }
        return false;
    }

    public static synchronized void save() {
        if (friendsFile == null) return;
        JsonObject root = new JsonObject();
        JsonArray arr = new JsonArray();
        for (FriendEntry f : friends) {
            JsonObject o = new JsonObject();
            o.addProperty("nick", f.nick);
            if (f.uuidKey != null) o.addProperty("uuid", f.uuidKey);
            arr.add(o);
        }
        root.add("friends", arr);
        try (FileWriter writer = new FileWriter(friendsFile)) {
            GSON.toJson(root, writer);
        } catch (IOException ignored) {}
    }

    public static synchronized void load() {
        if (friendsFile == null) return;
        if (!friendsFile.exists()) {
            save();
            return;
        }
        try (FileReader reader = new FileReader(friendsFile)) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
            friends.clear();
            if (root.has("friends")) {
                JsonArray arr = root.getAsJsonArray("friends");
                for (JsonElement e : arr) {
                    if (e.isJsonPrimitive()) {
                        // legacy: plain string nick
                        friends.add(new FriendEntry(null, e.getAsString()));
                    } else if (e.isJsonObject()) {
                        JsonObject o = e.getAsJsonObject();
                        String nick = o.has("nick") ? o.get("nick").getAsString() : null;
                        String uuid = o.has("uuid") ? o.get("uuid").getAsString() : null;
                        if (nick != null && !nick.isEmpty()) {
                            friends.add(new FriendEntry(uuid, nick));
                        }
                    }
                }
            }
        } catch (Exception ignored) {}
    }
}
