package dev.batvisuals.client.managers;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * Клиент для Firebase Realtime Database (BaTVisuals project), реализованный через обычный
 * REST API (Firebase RTDB поддерживает чтение/запись как plain HTTP PUT/GET к *.json путям) —
 * без подключения официального Firebase Admin/Client SDK, который тянет за собой тяжёлые
 * зависимости и не рассчитан на встраивание в Minecraft-мод.
 *
 * Узел в базе: players/{uuid} = { "nick": "...", "online": true, "lastSeen": <epoch millis> }
 * Отдельно от likes/stats, которые использует сайт — свои правила записи не пересекаются.
 */
public final class FirebaseManager {

    private static final Logger LOGGER = LogManager.getLogger(FirebaseManager.class);
    private static final String BASE_URL = "https://batvisuals-e047c-default-rtdb.firebaseio.com";
    private static final Gson GSON = new Gson();
    private static final Type STRING_MAP_TYPE = new TypeToken<Map<String, PlayerRecord>>() {}.getType();

    /** Игрок считается оффлайн, если lastSeen не обновлялся дольше этого времени (мс). */
    private static final long ONLINE_TTL_MS = 90_000L;
    /** Как часто клиент обновляет свой lastSeen, пока играет (сек). */
    private static final long PING_INTERVAL_SEC = 30L;
    /** Как часто клиент подтягивает список играющих для локального кэша (сек). */
    private static final long FETCH_INTERVAL_SEC = 3L;

    private volatile HttpClient httpClient;

    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "BaTVisuals-Firebase");
        t.setDaemon(true);
        return t;
    });

    /** Локальный кэш: UUID (без дефисов, как в Firebase-ключе) -> запись игрока. Обновляется fetch-циклом. */
    private final Map<String, PlayerRecord> onlineCache = new ConcurrentHashMap<>();
    /** Полный снимок players (включая оффлайн) — для резолва UUID/ников друзей. */
    private final Map<String, PlayerRecord> allCache = new ConcurrentHashMap<>();

    private String currentUuidKey = null;
    private volatile boolean active = false;
    private volatile ScheduledFuture<?> pingTask;

    public FirebaseManager() {
        // HttpClient создаётся не в конструкторе (может выполняться на главном потоке при
        // старте игры), а лениво на фоновом демон-потоке планировщика — на некоторых JVM
        // (в частности на Android/Termux) построение java.net.http.HttpClient может подвисать
        // при первой инициализации сетевого стека, и раньше это блокировало старт всего клиента.
        scheduler.execute(this::ensureHttpClient);
        scheduler.scheduleWithFixedDelay(this::fetchOnlinePlayers, 2, FETCH_INTERVAL_SEC, TimeUnit.SECONDS);
    }

    private HttpClient ensureHttpClient() {
        HttpClient local = httpClient;
        if (local == null) {
            synchronized (this) {
                local = httpClient;
                if (local == null) {
                    try {
                        local = HttpClient.newBuilder()
                                .connectTimeout(Duration.ofSeconds(5))
                                .build();
                        httpClient = local;
                    } catch (Throwable t) {
                        LOGGER.warn("[BaTVisuals] Не удалось инициализировать HTTP-клиент Firebase: {}", t.getMessage());
                        return null;
                    }
                }
            }
        }
        return local;
    }

    private static final class PlayerRecord {
        String nick;
        boolean online;
        long lastSeen;
        PetData pet; // optional cosmetic pet for other clients
    }

    public static final class PetData {
        public String type; // BAT, WOLF, CAT, FOX, PARROT, ALLAY
        public boolean sit;
    }

    /** Публичный снимок записи игрока (для Friends UI). */
    public static final class PlayerSnapshot {
        public final String nick;
        public final boolean online;
        public final long lastSeen;
        public final PetData pet;
        public PlayerSnapshot(String nick, boolean online, long lastSeen, PetData pet) {
            this.nick = nick;
            this.online = online;
            this.lastSeen = lastSeen;
            this.pet = pet;
        }
    }

    private static PlayerSnapshot toSnapshot(PlayerRecord r) {
        if (r == null) return null;
        return new PlayerSnapshot(r.nick, r.online, r.lastSeen, r.pet);
    }

    /** Ключ Firebase не должен содержать точки/#/$/[/] — UUID без дефисов уже безопасен. */
    private static String keyFor(java.util.UUID uuid) {
        return uuid.toString().replace("-", "");
    }

    /**
     * Вызывается при входе на любой сервер (или в одиночную игру — не важно, статус глобальный
     * для аккаунта, не привязан к конкретному серверу). Начинает периодический пинг.
     */
    public void markOnline(java.util.UUID uuid, String nick) {
        ScheduledFuture<?> previousPing = pingTask;
        if (previousPing != null) previousPing.cancel(false);

        currentUuidKey = keyFor(uuid);
        active = true;

        // Показываем собственный статус сразу, не дожидаясь первого REST-опроса.
        PlayerRecord local = new PlayerRecord();
        local.nick = nick;
        local.online = true;
        local.lastSeen = System.currentTimeMillis();
        onlineCache.put(currentUuidKey, local);

        scheduler.execute(() -> {
            JsonObject body = new JsonObject();
            body.addProperty("nick", nick);
            body.addProperty("online", true);
            body.addProperty("lastSeen", System.currentTimeMillis());
            putAsync("players/" + currentUuidKey, body.toString());
            fetchOnlinePlayers();
        });

        pingTask = scheduler.scheduleWithFixedDelay(this::pingIfActive, PING_INTERVAL_SEC, PING_INTERVAL_SEC, TimeUnit.SECONDS);
    }

    private void pingIfActive() {
        if (!active || currentUuidKey == null) return;
        JsonObject patch = new JsonObject();
        patch.addProperty("lastSeen", System.currentTimeMillis());
        patch.addProperty("online", true);
        patchAsync("players/" + currentUuidKey, patch.toString());
    }

    /** Вызывается при выходе из мира/дисконнекте. Останавливает пинг и помечает оффлайн. */
    public void markOffline() {
        ScheduledFuture<?> previousPing = pingTask;
        pingTask = null;
        if (previousPing != null) previousPing.cancel(false);
        active = false;
        if (currentUuidKey == null) return;
        String uuidKey = currentUuidKey;
        currentUuidKey = null;
        scheduler.execute(() -> {
            JsonObject patch = new JsonObject();
            patch.addProperty("online", false);
            patchAsync("players/" + uuidKey, patch.toString());
        });
    }

    /** Подтягивает весь узел players и обновляет локальный кэш (только реально "online" и не протухшие по TTL). */
    private void fetchOnlinePlayers() {
        try {
            HttpClient client = ensureHttpClient();
            if (client == null) return;

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL + "/players.json"))
                    .timeout(Duration.ofSeconds(6))
                    .GET()
                    .build();

            client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                    .thenAccept(response -> {
                        if (response.statusCode() != 200) return;
                        String bodyStr = response.body();
                        if (bodyStr == null || bodyStr.equals("null")) {
                            onlineCache.clear();
                            return;
                        }
                        try {
                            Map<String, PlayerRecord> parsed = GSON.fromJson(bodyStr, STRING_MAP_TYPE);
                            if (parsed == null) {
                                onlineCache.clear();
                                return;
                            }
                            long now = System.currentTimeMillis();
                            onlineCache.clear();
                            allCache.clear();
                            for (Map.Entry<String, PlayerRecord> entry : parsed.entrySet()) {
                                PlayerRecord rec = entry.getValue();
                                if (rec == null) continue;
                                allCache.put(entry.getKey(), rec);
                                boolean fresh = rec.online && (now - rec.lastSeen) < ONLINE_TTL_MS;
                                if (fresh) onlineCache.put(entry.getKey(), rec);
                            }
                            try {
                                java.util.Map<String, PlayerSnapshot> allSnap = new java.util.HashMap<>();
                                java.util.Map<String, PlayerSnapshot> onSnap = new java.util.HashMap<>();
                                for (var e : allCache.entrySet()) allSnap.put(e.getKey(), toSnapshot(e.getValue()));
                                for (var e : onlineCache.entrySet()) onSnap.put(e.getKey(), toSnapshot(e.getValue()));
                                FriendsManager.onPresenceUpdate(allSnap, onSnap);
                            } catch (Throwable ignored) {}
                        } catch (Exception parseEx) {
                            LOGGER.warn("[BaTVisuals] Не удалось разобрать ответ players.json: {}", parseEx.getMessage());
                        }
                    })
                    .exceptionally(ex -> {
                        LOGGER.debug("[BaTVisuals] Firebase fetch не удался: {}", ex.getMessage());
                        return null;
                    });
        } catch (Exception e) {
            LOGGER.debug("[BaTVisuals] Firebase fetch ошибка: {}", e.getMessage());
        }
    }

    /** @return true если данный UUID сейчас числится играющим с BaTVisuals (по локальному кэшу). */
    public boolean isOnline(java.util.UUID uuid) {
        return onlineCache.containsKey(keyFor(uuid));
    }

    /**
     * Проверка online-статуса по нику игрока (используется там, где доступен только текст
     * nametag/tab, а не сам Entity/UUID — например, в миксинах на renderLabelIfPresent,
     * где новый PlayerEntityRenderState API 1.21.4 не даёт прямого доступа к Entity).
     * Не так надёжно как UUID (ники не уникальны навечно), но приемлемо для визуального индикатора.
     */
    public boolean isNickOnline(String nick) {
        if (nick == null || nick.isEmpty()) return false;
        for (PlayerRecord rec : onlineCache.values()) {
            if (nick.equals(rec.nick)) return true;
        }
        return false;
    }

    /**
     * То же самое, но для случаев когда полный текст label может содержать префиксы сервера
     * (ранги, донат-теги и т.д.) вокруг ника — проверяет, встречается ли ник любого online-игрока
     * как отдельное слово внутри переданной строки.
     */
    public boolean containsAnyOnlineNick(String labelText) {
        if (labelText == null || labelText.isEmpty()) return false;
        for (PlayerRecord rec : onlineCache.values()) {
            if (rec.nick == null || rec.nick.isEmpty()) continue;
            if (containsWord(labelText, rec.nick)) return true;
        }
        return false;
    }

    private static boolean containsWord(String haystack, String word) {
        int idx = haystack.indexOf(word);
        while (idx != -1) {
            boolean leftOk = idx == 0 || !Character.isLetterOrDigit(haystack.charAt(idx - 1));
            int endIdx = idx + word.length();
            boolean rightOk = endIdx >= haystack.length() || !Character.isLetterOrDigit(haystack.charAt(endIdx));
            if (leftOk && rightOk) return true;
            idx = haystack.indexOf(word, idx + 1);
        }
        return false;
    }

    /** Снимок текущего набора UUID (в форме ключа Firebase, без дефисов), считающихся играющими. */
    public Set<String> onlineKeysSnapshot() {
        return Collections.unmodifiableSet(onlineCache.keySet());
    }

    public int getOnlineCount() {
        return onlineCache.size();
    }

    public boolean isOnlineKey(String uuidKey) {
        if (uuidKey == null) return false;
        return onlineCache.containsKey(uuidKey.replace("-", ""));
    }

    public String findUuidKeyByNick(String nick) {
        if (nick == null || nick.isEmpty()) return null;
        for (Map.Entry<String, PlayerRecord> e : allCache.entrySet()) {
            if (e.getValue() != null && e.getValue().nick != null
                    && e.getValue().nick.equalsIgnoreCase(nick)) {
                return e.getKey();
            }
        }
        for (Map.Entry<String, PlayerRecord> e : onlineCache.entrySet()) {
            if (e.getValue() != null && e.getValue().nick != null
                    && e.getValue().nick.equalsIgnoreCase(nick)) {
                return e.getKey();
            }
        }
        return null;
    }

    public PlayerSnapshot getPlayer(String uuidKey) {
        if (uuidKey == null) return null;
        String k = uuidKey.replace("-", "");
        PlayerRecord r = onlineCache.get(k);
        if (r == null) r = allCache.get(k);
        return toSnapshot(r);
    }

    public String getNick(String uuidKey) {
        PlayerSnapshot s = getPlayer(uuidKey);
        return s == null ? null : s.nick;
    }

    private CompletableFuture<Void> putAsync(String path, String jsonBody) {
        HttpClient client = ensureHttpClient();
        if (client == null) return CompletableFuture.completedFuture(null);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/" + path + ".json"))
                .timeout(Duration.ofSeconds(6))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();
        return client.sendAsync(request, HttpResponse.BodyHandlers.discarding())
                .thenAccept(r -> {})
                .exceptionally(ex -> {
                    LOGGER.debug("[BaTVisuals] Firebase PUT ошибка ({}): {}", path, ex.getMessage());
                    return null;
                });
    }

    private CompletableFuture<Void> patchAsync(String path, String jsonBody) {
        HttpClient client = ensureHttpClient();
        if (client == null) return CompletableFuture.completedFuture(null);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/" + path + ".json"))
                .timeout(Duration.ofSeconds(6))
                .header("Content-Type", "application/json")
                .method("PATCH", HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();
        return client.sendAsync(request, HttpResponse.BodyHandlers.discarding())
                .thenAccept(r -> {})
                .exceptionally(ex -> {
                    LOGGER.debug("[BaTVisuals] Firebase PATCH ошибка ({}): {}", path, ex.getMessage());
                    return null;
                });
    }

    /**
     * Публикует косметического питомца в players/{uuid}/pet.
     * type == null → удаляет pet (модуль выключен).
     */
    public void updatePet(String type, boolean sit) {
        if (currentUuidKey == null) return;
        scheduler.execute(() -> {
            if (type == null || type.isEmpty()) {
                // удалить узел pet
                putAsync("players/" + currentUuidKey + "/pet", "null");
                PlayerRecord rec = allCache.get(currentUuidKey);
                if (rec != null) rec.pet = null;
                return;
            }
            JsonObject pet = new JsonObject();
            pet.addProperty("type", type);
            pet.addProperty("sit", sit);
            putAsync("players/" + currentUuidKey + "/pet", pet.toString());
            PlayerRecord rec = allCache.get(currentUuidKey);
            if (rec == null) {
                rec = new PlayerRecord();
                allCache.put(currentUuidKey, rec);
            }
            PetData pd = new PetData();
            pd.type = type;
            pd.sit = sit;
            rec.pet = pd;
        });
    }

    public PetData getPet(String uuidKey) {
        if (uuidKey == null) return null;
        String k = uuidKey.replace("-", "");
        PlayerRecord r = onlineCache.get(k);
        if (r == null) r = allCache.get(k);
        return r == null ? null : r.pet;
    }

        /** Останавливает фоновый планировщик (вызывать при полном завершении работы клиента, если потребуется). */
    public void shutdown() {
        ScheduledFuture<?> previousPing = pingTask;
        pingTask = null;
        if (previousPing != null) previousPing.cancel(false);
        active = false;
        scheduler.shutdownNow();
    }
}
