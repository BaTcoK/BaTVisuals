package dev.batvisuals.client.managers;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import dev.batvisuals.batvisuals;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Избранные модули — всегда сверху в списке категории. */
public final class FavoritesManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static File file;
    private static final Set<String> FAVORITES = new LinkedHashSet<>();

    private FavoritesManager() {}

    public static void init(File globalsDir) {
        file = new File(globalsDir, "favorites.json");
        load();
    }

    public static synchronized boolean isFavorite(String moduleName) {
        return moduleName != null && FAVORITES.contains(moduleName);
    }

    public static synchronized void toggle(String moduleName) {
        if (moduleName == null || moduleName.isBlank()) return;
        if (FAVORITES.contains(moduleName)) FAVORITES.remove(moduleName);
        else FAVORITES.add(moduleName);
        save();
    }

    public static synchronized void setFavorite(String moduleName, boolean fav) {
        if (moduleName == null) return;
        if (fav) FAVORITES.add(moduleName);
        else FAVORITES.remove(moduleName);
        save();
    }

    public static synchronized List<String> list() {
        return new ArrayList<>(FAVORITES);
    }

    private static synchronized void load() {
        FAVORITES.clear();
        if (file == null || !file.isFile()) return;
        try {
            String json = Files.readString(file.toPath(), StandardCharsets.UTF_8);
            List<String> list = GSON.fromJson(json, new TypeToken<List<String>>(){}.getType());
            if (list != null) FAVORITES.addAll(list);
        } catch (Throwable t) {
            try { batvisuals.LOGGER.warn("[Favorites] load: {}", t.toString()); } catch (Throwable ignored) {}
        }
    }

    private static synchronized void save() {
        if (file == null) return;
        try {
            Files.writeString(file.toPath(), GSON.toJson(new ArrayList<>(FAVORITES)), StandardCharsets.UTF_8);
        } catch (Throwable t) {
            try { batvisuals.LOGGER.warn("[Favorites] save: {}", t.toString()); } catch (Throwable ignored) {}
        }
    }
}
