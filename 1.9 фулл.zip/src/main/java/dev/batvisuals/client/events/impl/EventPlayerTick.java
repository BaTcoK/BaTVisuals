package dev.batvisuals.client.events.impl;

import dev.batvisuals.client.events.Event;

public class EventPlayerTick extends Event {
}