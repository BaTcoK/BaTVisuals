package dev.batvisuals.client.events.impl;

import dev.batvisuals.client.events.Event;

public class EventGameShutdown extends Event {
    // Событие вызывается при выключении игры
} 