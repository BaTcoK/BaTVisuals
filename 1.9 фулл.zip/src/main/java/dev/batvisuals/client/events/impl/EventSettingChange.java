package dev.batvisuals.client.events.impl;

import dev.batvisuals.client.events.Event;
import dev.batvisuals.modules.settings.Setting;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor @Getter
public class EventSettingChange extends Event {
    private final Setting<?> setting;
}