package dev.batvisuals.client.events.impl;

import dev.batvisuals.client.events.Event;

public class EventClientShutdown extends Event {
    // Событие вызывается при выключении клиента
} 