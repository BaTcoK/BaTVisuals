package dev.batvisuals.client.events.impl;

import dev.batvisuals.client.events.Event;
import lombok.Getter;
import net.minecraft.entity.LivingEntity;

@Getter
public class EventEntityDeath extends Event {
    private final LivingEntity entity;

    public EventEntityDeath(LivingEntity entity) {
        this.entity = entity;
    }
}
