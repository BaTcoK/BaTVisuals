package dev.batvisuals.client.events.impl;

import dev.batvisuals.client.events.Event;
import lombok.Getter;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.screen.slot.Slot;

@Getter
public class EventHandledScreen extends Event {
	private final DrawContext drawContext;
	private final Slot slotHover;
	private final int backgroundWidth;
	private final int backgroundHeight;
	private final int guiLeft;
	private final int guiTop;
	private final int mouseX;
	private final int mouseY;

	public EventHandledScreen(DrawContext drawContext, Slot slotHover, int backgroundWidth, int backgroundHeight,
							  int guiLeft, int guiTop, int mouseX, int mouseY) {
		this.drawContext = drawContext;
		this.slotHover = slotHover;
		this.backgroundWidth = backgroundWidth;
		this.backgroundHeight = backgroundHeight;
		this.guiLeft = guiLeft;
		this.guiTop = guiTop;
		this.mouseX = mouseX;
		this.mouseY = mouseY;
	}
}
