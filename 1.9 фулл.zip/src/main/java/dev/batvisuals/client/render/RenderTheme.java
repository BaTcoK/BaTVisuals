package dev.batvisuals.client.render;

import net.minecraft.util.math.MathHelper;

import java.util.function.IntSupplier;

public final class RenderTheme {
    private RenderTheme() {}

    /** Hook: set from client init → ThemeManager accent ARGB. */
    public static volatile IntSupplier primary = () -> 0xFF8A5CFF;

    public static int primary() { return argb(primary.getAsInt()); }

    /** 0x00RRGGBB (alpha=0, rgb!=0) treat as opaque. */
    public static int argb(int c) {
        return ((c >>> 24) == 0 && (c & 0xFFFFFF) != 0) ? (c | 0xFF000000) : c;
    }

    public static int alpha(int c, float mul) {
        int a = (int) (((c >>> 24) & 0xFF) * MathHelper.clamp(mul, 0f, 1f));
        return (a << 24) | (c & 0xFFFFFF);
    }

    public static int mix(int a, int b, float t) {
        t = MathHelper.clamp(t, 0f, 1f);
        int r = 0;
        for (int sh = 0; sh <= 24; sh += 8) {
            int x = (a >>> sh) & 0xFF, y = (b >>> sh) & 0xFF;
            r |= ((int) (x + (y - x) * t) & 0xFF) << sh;
        }
        return r;
    }

    public static float r(int c) { return ((c >> 16) & 0xFF) / 255f; }
    public static float g(int c) { return ((c >> 8) & 0xFF) / 255f; }
    public static float b(int c) { return (c & 0xFF) / 255f; }

    public static float time() { return (System.nanoTime() / 1_000_000L % 3_600_000L) / 1000f; }

    public static int fromAwt(java.awt.Color c) {
        if (c == null) return primary();
        return (c.getAlpha() << 24) | (c.getRed() << 16) | (c.getGreen() << 8) | c.getBlue();
    }
}
