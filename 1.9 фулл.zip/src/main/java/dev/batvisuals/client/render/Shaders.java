package dev.batvisuals.client.render;

import net.minecraft.client.gl.Defines;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

/** Lazy only — nothing in static init. */
public final class Shaders {
    private Shaders() {}
    public static final String MOD_ID = "batvisuals";

    private static ShaderProgramKey skyFx;
    private static ShaderProgramKey handOutline;

    public static ShaderProgramKey skyFx() {
        if (skyFx == null) {
            skyFx = new ShaderProgramKey(Identifier.of(MOD_ID, "core/sky_fx"), VertexFormats.POSITION, Defines.EMPTY);
        }
        return skyFx;
    }

    /** Экранная обводка руки/предметов (дилатация маски глубины). */
    public static ShaderProgramKey handOutline() {
        if (handOutline == null) {
            handOutline = new ShaderProgramKey(Identifier.of(MOD_ID, "core/hand_outline"), VertexFormats.POSITION, Defines.EMPTY);
        }
        return handOutline;
    }
}
