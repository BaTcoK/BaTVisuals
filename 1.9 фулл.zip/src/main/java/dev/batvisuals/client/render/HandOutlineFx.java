package dev.batvisuals.client.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.batvisuals.client.util.render.HandFillProvider;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Экранная обводка руки + предметов + блоков в руке.
 *
 * После отрисовки руки (GameRenderer.renderHand) глубина кадра была очищена перед рукой, значит всё, у чего
 * глубина &lt; 1.0 - это рука/предмет. Копируем глубину в свой FBO и фуллскрин-шейдером рисуем кольцо вокруг этого
 * силуэта (hand_outline.fsh). Работает для ЛЮБОЙ геометрии: плоские предметы, блоки, инструменты, щиты, тотемы,
 * потому что обводка строится по готовому изображению, а не по квадам модели.
 *
 * Если шейдер не загрузился (GLES/MobileGlues, шейдерпак) - ready() вернёт false и HandShader сам включит
 * геометрическую обводку (inverted hull).
 */
public final class HandOutlineFx {
    private HandOutlineFx() {}

    private static final Logger LOG = LoggerFactory.getLogger("BaTVisuals/HandOutline");

    private static SimpleFramebuffer depthCopy;
    private static boolean composed;
    private static boolean broken;
    private static int probes;
    private static int failures;
    private static boolean lastOk = true;
    private static long nextProbe;

    /**
     * Можно ли сейчас полагаться на экранную обводку. Пока она ни разу не отрисовалась, даём ~3 секунды на запуск;
     * если за это время хук так и не сработал (другая сигнатура метода и т.п.) - возвращаем false -> fallback.
     */
    public static boolean ready() {
        if (broken) return false;
        if (!composed && ++probes > 180) return false;
        long now = System.currentTimeMillis();
        if (now >= nextProbe) {
            nextProbe = now + 1000L;
            boolean ok;
            try {
                ok = !RenderCaps.shaderPackActive() && RenderPipeline.program(Shaders.handOutline()) != null;
            } catch (Throwable t) {
                ok = false;
            }
            lastOk = ok;
        }
        return lastOk;
    }

    /** Вызывать сразу после отрисовки руки, пока в основном FBO лежит глубина руки. */
    public static void compose(HandFillProvider.Style st) {
        if (broken || st == null || !lastOk) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        Framebuffer main = mc.getFramebuffer();
        if (main == null) return;
        final int w = main.textureWidth, h = main.textureHeight;
        if (w <= 0 || h <= 0) return;

        try {
            if (depthCopy == null) depthCopy = new SimpleFramebuffer(w, h, true);
            else if (depthCopy.textureWidth != w || depthCopy.textureHeight != h) depthCopy.resize(w, h);

            // копия глубины: сэмплить глубину того же FBO, в который рисуем, нельзя (feedback loop)
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, main.fbo);
            GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, depthCopy.fbo);
            GL30.glBlitFramebuffer(0, 0, w, h, 0, 0, w, h, GL11.GL_DEPTH_BUFFER_BIT, GL11.GL_NEAREST);
            main.beginWrite(false);

            final float widthPx = Math.max(1f, Math.min(14f, st.width * 230f * (h / 1080f)));
            final float time = st.time;
            final float theme = st.theme;
            final float alpha = st.lineAlpha() / 255f;
            final float br = ((st.base >> 16) & 255) / 255f, bg = ((st.base >> 8) & 255) / 255f, bb = (st.base & 255) / 255f;
            final float c1r = ((st.c1 >> 16) & 255) / 255f, c1g = ((st.c1 >> 8) & 255) / 255f, c1b = (st.c1 & 255) / 255f;
            final float c2r = ((st.c2 >> 16) & 255) / 255f, c2g = ((st.c2 >> 8) & 255) / 255f, c2b = (st.c2 & 255) / 255f;

            RenderSystem.setShaderTexture(0, depthCopy.getDepthAttachment());
            try (var batch = RenderPipeline.begin(RenderState.Preset.GUI, VertexFormat.DrawMode.QUADS,
                    VertexFormats.POSITION, Shaders.handOutline(), sp -> {
                        RenderPipeline.set2(sp, "uSize", w, h);
                        RenderPipeline.set1(sp, "uWidth", widthPx);
                        RenderPipeline.set1(sp, "uTime", time);
                        RenderPipeline.set1(sp, "uTheme", theme);
                        RenderPipeline.set1(sp, "uAlpha", alpha);
                        RenderPipeline.set3(sp, "uBase", br, bg, bb);
                        RenderPipeline.set3(sp, "uC1", c1r, c1g, c1b);
                        RenderPipeline.set3(sp, "uC2", c2r, c2g, c2b);
                    })) {
                BufferBuilder b = batch.buf();
                b.vertex(-1f, -1f, 0f);
                b.vertex(1f, -1f, 0f);
                b.vertex(1f, 1f, 0f);
                b.vertex(-1f, 1f, 0f);
            }
            RenderSystem.setShaderTexture(0, 0);
            composed = true;
        } catch (Throwable t) {
            if (++failures <= 3) LOG.warn("hand outline pass failed: {}", t.toString());
            if (failures >= 5) broken = true;
            try { main.beginWrite(false); } catch (Throwable ignored) {}
        }
    }
}
