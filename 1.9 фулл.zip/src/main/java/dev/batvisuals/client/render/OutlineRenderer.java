package dev.batvisuals.client.render;

import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;

public final class OutlineRenderer {
    private OutlineRenderer() {}

    public static final class Style {
        public int color = 0;
        public float widthPx = 2.0f;
        public float fill = 0.10f;
        public float bloom = 1.0f;
        public float bloomPx = 5f;
        public float pulse = 0f;
        public float pulseSpeed = 3f;
        public float throughAlpha = 0.45f;
    }

    public static void entity(MatrixStack ms, Camera cam, Entity e, float tickDelta, Style s) {
        double dx = MathHelper.lerp(tickDelta, e.lastRenderX, e.getX()) - e.getX();
        double dy = MathHelper.lerp(tickDelta, e.lastRenderY, e.getY()) - e.getY();
        double dz = MathHelper.lerp(tickDelta, e.lastRenderZ, e.getZ()) - e.getZ();
        box(ms, cam, e.getBoundingBox().offset(dx, dy, dz).expand(0.002), s);
    }

    public static void box(MatrixStack ms, Camera cam, Box bb, Style s) {
        int col = RenderTheme.argb(s.color == 0 ? RenderTheme.primary() : s.color);
        float k = s.pulse > 0f
                ? 1f - s.pulse * (0.5f + 0.5f * (float) Math.sin(RenderTheme.time() * s.pulseSpeed))
                : 1f;

        if (s.throughAlpha > 0f) {
            try (var g = WorldRenderer3D.colored(ms, cam, RenderState.Preset.ALPHA, true)) {
                g.boxOutline(bb, s.widthPx, RenderTheme.alpha(col, s.throughAlpha * k));
            }
        }
        try (var g = WorldRenderer3D.colored(ms, cam, RenderState.Preset.ALPHA, false)) {
            if (s.fill > 0f) g.box(bb, RenderTheme.alpha(col, s.fill * k));
            g.boxOutline(bb, s.widthPx, RenderTheme.alpha(col, k));
        }
        if (s.bloom > 0f) {
            try (var g = WorldRenderer3D.colored(ms, cam, RenderState.Preset.GLOW, false)) {
                g.boxOutline(bb, s.widthPx + s.bloomPx, RenderTheme.alpha(col, s.bloom * 0.50f * k));
                g.boxOutline(bb, s.widthPx + s.bloomPx * 2.2f, RenderTheme.alpha(col, s.bloom * 0.25f * k));
            }
        }
    }
}
