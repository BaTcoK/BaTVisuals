package dev.batvisuals.client.render.providers;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.batvisuals.batvisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;

public final class ResourceProvider {

	private static final Gson GSON = new Gson();

	private ResourceProvider() {}

	/** Lazy — never cache at class-init (MC ResourceManager may be null early). */
	private static ResourceManager rm() {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc == null) {
			throw new IllegalStateException("MinecraftClient not ready");
		}
		ResourceManager manager = mc.getResourceManager();
		if (manager == null) {
			throw new IllegalStateException("ResourceManager not ready");
		}
		return manager;
	}
	
	public static Identifier getShaderIdentifier(String name) {
		return batvisuals.id("core/" + name);
	}

	public static JsonObject toJson(Identifier identifier) {
		return JsonParser.parseString(toString(identifier)).getAsJsonObject();
	}

	public static <T> T fromJsonToInstance(Identifier identifier, Class<T> clazz) {
		return GSON.fromJson(toString(identifier), clazz);
	}

	public static String toString(Identifier identifier) {
		return toString(identifier, "\n");
	}
	
	public static String toString(Identifier identifier, String delimiter) {
		try (InputStream inputStream = rm().open(identifier);
			 BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
			return reader.lines().collect(Collectors.joining(delimiter));
		} catch (IOException ex) {
			throw new RuntimeException(ex);
		}
	}
}
