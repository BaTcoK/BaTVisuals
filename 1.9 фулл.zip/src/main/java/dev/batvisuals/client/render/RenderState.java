package dev.batvisuals.client.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;

import java.util.ArrayDeque;

public final class RenderState {
    private RenderState() {}

    public enum Blend { NONE, ALPHA, ADDITIVE }

    public record Preset(Blend blend, boolean depthTest, int depthFunc, boolean depthMask, boolean cull) {
        public static final Preset ALPHA    = new Preset(Blend.ALPHA,    true,  GL11.GL_LEQUAL, false, false);
        public static final Preset GLOW     = new Preset(Blend.ADDITIVE, true,  GL11.GL_LEQUAL, false, false);
        public static final Preset OPAQUE   = new Preset(Blend.NONE,     true,  GL11.GL_LEQUAL, true,  false);
        public static final Preset GUI      = new Preset(Blend.ALPHA,    false, GL11.GL_LEQUAL, false, false);
        public static final Preset GUI_GLOW = new Preset(Blend.ADDITIVE, false, GL11.GL_LEQUAL, false, false);
        public static final Preset SKY      = new Preset(Blend.ALPHA,    true,  GL11.GL_LEQUAL, false, false);

        public Preset through(boolean on) {
            return on ? new Preset(blend, false, depthFunc, false, cull) : this;
        }
    }

    private record Snap(boolean blend, int sRgb, int dRgb, int sA, int dA,
                        boolean depth, int func, boolean mask, boolean cull, int tex0) {}

    private static final ArrayDeque<Snap> STACK = new ArrayDeque<>();

    public static void push() {
        try {
            RenderSystem.assertOnRenderThread();
        } catch (Throwable ignored) {}
        int tex0 = 0;
        try { tex0 = RenderSystem.getShaderTexture(0); } catch (Throwable ignored) {}
        STACK.push(new Snap(
            GL11.glIsEnabled(GL11.GL_BLEND),
            GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB), GL11.glGetInteger(GL14.GL_BLEND_DST_RGB),
            GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA), GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA),
            GL11.glIsEnabled(GL11.GL_DEPTH_TEST), GL11.glGetInteger(GL11.GL_DEPTH_FUNC),
            GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK), GL11.glIsEnabled(GL11.GL_CULL_FACE),
            tex0));
    }

    public static void pop() {
        Snap s = STACK.poll();
        if (s == null) return;
        if (s.blend) RenderSystem.enableBlend(); else RenderSystem.disableBlend();
        RenderSystem.blendFuncSeparate(s.sRgb, s.dRgb, s.sA, s.dA);
        if (s.depth) RenderSystem.enableDepthTest(); else RenderSystem.disableDepthTest();
        RenderSystem.depthFunc(s.func);
        RenderSystem.depthMask(s.mask);
        if (s.cull) RenderSystem.enableCull(); else RenderSystem.disableCull();
        try { RenderSystem.setShaderTexture(0, s.tex0); } catch (Throwable ignored) {}
    }

    public static void apply(Preset p) {
        switch (p.blend()) {
            case NONE -> RenderSystem.disableBlend();
            case ALPHA -> { RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc(); }
            case ADDITIVE -> {
                RenderSystem.enableBlend();
                RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
            }
        }
        if (p.depthTest()) { RenderSystem.enableDepthTest(); RenderSystem.depthFunc(p.depthFunc()); }
        else RenderSystem.disableDepthTest();
        RenderSystem.depthMask(p.depthMask());
        if (p.cull()) RenderSystem.enableCull(); else RenderSystem.disableCull();
    }
}
