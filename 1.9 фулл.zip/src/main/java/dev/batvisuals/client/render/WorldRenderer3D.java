package dev.batvisuals.client.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public final class WorldRenderer3D {
    private WorldRenderer3D() {}

    public static Colored colored(MatrixStack ms, Camera cam, RenderState.Preset preset, boolean throughWalls) {
        return new Colored(ms, cam, preset, throughWalls);
    }

    public static Textured textured(MatrixStack ms, Camera cam, Identifier tex, RenderState.Preset preset, boolean throughWalls) {
        return new Textured(ms, cam, tex, preset, throughWalls);
    }

    public static final class Basis {
        public double fx, fy, fz, rx, ry, rz, ux, uy, uz;
        /**
         * World-up locked FPS basis (Minecraft Entity.getRotationVec style).
         * Sky pattern stays fixed in world when you look around — no camera-stuck roll.
         */
        public static Basis of(Camera c) {
            // MC: getRotationVec uses pitch and -yaw in radians
            double pitch = Math.toRadians(c.getPitch());
            double yaw = Math.toRadians(c.getYaw());
            double cosYaw = Math.cos(-yaw);
            double sinYaw = Math.sin(-yaw);
            double cosPitch = Math.cos(pitch);
            double sinPitch = Math.sin(pitch);
            Basis b = new Basis();
            // forward
            b.fx = sinYaw * cosPitch;
            b.fy = -sinPitch;
            b.fz = cosYaw * cosPitch;
            // right = normalize(cross(forward, worldUp)) with worldUp=(0,1,0)
            // cross(f, up) = (fz, 0, -fx) wait: f × (0,1,0) = (fy*0 - fz*1, fz*0 - fx*0, fx*1 - fy*0) = (-fz, 0, fx)
            double rx = -b.fz, ry = 0, rz = b.fx;
            double rl = Math.sqrt(rx * rx + rz * rz);
            if (rl < 1e-6) {
                // looking straight up/down — use yaw-only right
                rx = cosYaw; rz = sinYaw; rl = 1;
            }
            b.rx = rx / rl; b.ry = 0; b.rz = rz / rl;
            // up = right × forward
            b.ux = b.ry * b.fz - b.rz * b.fy;
            b.uy = b.rz * b.fx - b.rx * b.fz;
            b.uz = b.rx * b.fy - b.ry * b.fx;
            double ul = Math.sqrt(b.ux * b.ux + b.uy * b.uy + b.uz * b.uz);
            if (ul > 1e-9) { b.ux /= ul; b.uy /= ul; b.uz /= ul; }
            return b;
        }
    }

    private static final int[][] EDGES = {
        {0,1},{1,3},{3,2},{2,0},
        {4,5},{5,7},{7,6},{6,4},
        {0,4},{1,5},{2,6},{3,7}
    };

    public static final class Colored implements AutoCloseable {
        private final RenderPipeline.Batch batch;
        private final BufferBuilder b;
        private final Matrix4f m;
        private final double cx, cy, cz, pxPerDist;
        private final Basis basis;

        private Colored(MatrixStack ms, Camera cam, RenderState.Preset preset, boolean through) {
            Vec3d p = cam.getPos();
            cx = p.x; cy = p.y; cz = p.z;
            m = ms.peek().getPositionMatrix();
            basis = Basis.of(cam);
            MinecraftClient mc = MinecraftClient.getInstance();
            double fov = 70;
            try { fov = mc.options.getFov().getValue(); } catch (Throwable ignored) {}
            double tanHalf = Math.tan(Math.toRadians(fov) * 0.5);
            pxPerDist = 2.0 * tanHalf / Math.max(1, mc.getWindow().getFramebufferHeight());
            batch = RenderPipeline.beginVanilla(preset.through(through), VertexFormat.DrawMode.QUADS,
                    VertexFormats.POSITION_COLOR, () -> RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR));
            b = batch.buf();
        }

        @Override public void close() { batch.close(); }

        private void vr(double x, double y, double z, int c) {
            b.vertex(m, (float) x, (float) y, (float) z).color(c);
        }

        private void ribbon(double ax, double ay, double az, double bx, double by, double bz, double w, int ca, int cb) {
            double dx = bx - ax, dy = by - ay, dz = bz - az;
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 1e-7 || w <= 0) return;
            dx /= len; dy /= len; dz /= len;
            double h = w * 0.5;
            ax -= dx * h; ay -= dy * h; az -= dz * h;
            bx += dx * h; by += dy * h; bz += dz * h;
            double mx = (ax + bx) * 0.5, my = (ay + by) * 0.5, mz = (az + bz) * 0.5;
            // cross with camera-ish up
            double sx = dy * 1 - dz * 0, sy = dz * 0 - dx * 1, sz = dx * 0 - dy * 0;
            // better: cross with view to mid
            double vx = -mx, vy = -my, vz = -mz;
            sx = dy * vz - dz * vy;
            sy = dz * vx - dx * vz;
            sz = dx * vy - dy * vx;
            double sl = Math.sqrt(sx * sx + sy * sy + sz * sz);
            if (sl < 1e-9) {
                sx = -dz; sy = 0; sz = dx;
                sl = Math.sqrt(sx * sx + sz * sz);
                if (sl < 1e-9) return;
            }
            double k = h / sl;
            sx *= k; sy *= k; sz *= k;
            vr(ax + sx, ay + sy, az + sz, ca);
            vr(ax - sx, ay - sy, az - sz, ca);
            vr(bx - sx, by - sy, bz - sz, cb);
            vr(bx + sx, by + sy, bz + sz, cb);
        }

        public Colored line(Vec3d a, Vec3d c, float widthBlocks, int ca, int cb) {
            ribbon(a.x - cx, a.y - cy, a.z - cz, c.x - cx, c.y - cy, c.z - cz, widthBlocks, ca, cb);
            return this;
        }

        public Colored line(Vec3d a, Vec3d c, float widthBlocks, int col) {
            return line(a, c, widthBlocks, col, col);
        }

        public Colored linePx(Vec3d a, Vec3d c, float px, int ca, int cb) {
            double mx = (a.x + c.x) * 0.5 - cx, my = (a.y + c.y) * 0.5 - cy, mz = (a.z + c.z) * 0.5 - cz;
            double w = px * Math.sqrt(mx * mx + my * my + mz * mz) * pxPerDist;
            ribbon(a.x - cx, a.y - cy, a.z - cz, c.x - cx, c.y - cy, c.z - cz, w, ca, cb);
            return this;
        }

        public Colored linePx(Vec3d a, Vec3d c, float px, int col) {
            return linePx(a, c, px, col, col);
        }

        public Colored boxOutline(Box bb, float widthPx, int col) {
            double x0 = bb.minX - cx, y0 = bb.minY - cy, z0 = bb.minZ - cz;
            double x1 = bb.maxX - cx, y1 = bb.maxY - cy, z1 = bb.maxZ - cz;
            double[][] v = {
                {x0,y0,z0},{x1,y0,z0},{x0,y0,z1},{x1,y0,z1},
                {x0,y1,z0},{x1,y1,z0},{x0,y1,z1},{x1,y1,z1}
            };
            for (int[] e : EDGES) {
                double ax = v[e[0]][0], ay = v[e[0]][1], az = v[e[0]][2];
                double bx = v[e[1]][0], by = v[e[1]][1], bz = v[e[1]][2];
                double mx = (ax + bx) * 0.5, my = (ay + by) * 0.5, mz = (az + bz) * 0.5;
                double w = widthPx * Math.sqrt(mx * mx + my * my + mz * mz) * pxPerDist;
                ribbon(ax, ay, az, bx, by, bz, w, col, col);
            }
            return this;
        }

        public Colored box(Box bb, int col) {
            double x0 = bb.minX - cx, y0 = bb.minY - cy, z0 = bb.minZ - cz;
            double x1 = bb.maxX - cx, y1 = bb.maxY - cy, z1 = bb.maxZ - cz;
            // 6 faces
            face(x0,y0,z0, x1,y0,z0, x1,y0,z1, x0,y0,z1, col);
            face(x0,y1,z0, x0,y1,z1, x1,y1,z1, x1,y1,z0, col);
            face(x0,y0,z0, x0,y1,z0, x1,y1,z0, x1,y0,z0, col);
            face(x0,y0,z1, x1,y0,z1, x1,y1,z1, x0,y1,z1, col);
            face(x0,y0,z0, x0,y0,z1, x0,y1,z1, x0,y1,z0, col);
            face(x1,y0,z0, x1,y1,z0, x1,y1,z1, x1,y0,z1, col);
            return this;
        }

        private void face(double x0, double y0, double z0, double x1, double y1, double z1,
                          double x2, double y2, double z2, double x3, double y3, double z3, int c) {
            vr(x0,y0,z0,c); vr(x1,y1,z1,c); vr(x2,y2,z2,c); vr(x3,y3,z3,c);
        }

        public Colored billboard(Vec3d pos, float size, int col) {
            double x = pos.x - cx, y = pos.y - cy, z = pos.z - cz;
            double hx = basis.rx * size, hy = basis.ry * size, hz = basis.rz * size;
            double vx = basis.ux * size, vy = basis.uy * size, vz = basis.uz * size;
            vr(x - hx - vx, y - hy - vy, z - hz - vz, col);
            vr(x - hx + vx, y - hy + vy, z - hz + vz, col);
            vr(x + hx + vx, y + hy + vy, z + hz + vz, col);
            vr(x + hx - vx, y + hy - vy, z + hz - vz, col);
            return this;
        }

        /** Simple sky dome for fallback. */
        public Colored skyDome(double radius, int segments, int colTop, int colBot) {
            for (int i = 0; i < segments; i++) {
                double a0 = 2 * Math.PI * i / segments;
                double a1 = 2 * Math.PI * (i + 1) / segments;
                double x0 = Math.cos(a0) * radius, z0 = Math.sin(a0) * radius;
                double x1 = Math.cos(a1) * radius, z1 = Math.sin(a1) * radius;
                vr(0, radius * 0.4, 0, colTop);
                vr(x0, 0, z0, colBot);
                vr(x1, 0, z1, colBot);
                vr(0, radius * 0.4, 0, colTop);
            }
            return this;
        }
    }

    public static final class Textured implements AutoCloseable {
        private final RenderPipeline.Batch batch;
        private final BufferBuilder b;
        private final Matrix4f m;
        private final double cx, cy, cz;
        private final Basis basis;

        private Textured(MatrixStack ms, Camera cam, Identifier tex, RenderState.Preset preset, boolean through) {
            Vec3d p = cam.getPos();
            cx = p.x; cy = p.y; cz = p.z;
            m = ms.peek().getPositionMatrix();
            basis = Basis.of(cam);
            batch = RenderPipeline.beginVanilla(preset.through(through), VertexFormat.DrawMode.QUADS,
                    VertexFormats.POSITION_TEXTURE_COLOR, () -> {
                        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
                        RenderSystem.setShaderTexture(0, tex);
                    });
            b = batch.buf();
        }

        @Override public void close() { batch.close(); }

        public Textured billboard(Vec3d pos, float size, int col) {
            double x = pos.x - cx, y = pos.y - cy, z = pos.z - cz;
            double hx = basis.rx * size, hy = basis.ry * size, hz = basis.rz * size;
            double vx = basis.ux * size, vy = basis.uy * size, vz = basis.uz * size;
            b.vertex(m, (float)(x - hx - vx), (float)(y - hy - vy), (float)(z - hz - vz)).texture(0, 1).color(col);
            b.vertex(m, (float)(x - hx + vx), (float)(y - hy + vy), (float)(z - hz + vz)).texture(0, 0).color(col);
            b.vertex(m, (float)(x + hx + vx), (float)(y + hy + vy), (float)(z + hz + vz)).texture(1, 0).color(col);
            b.vertex(m, (float)(x + hx - vx), (float)(y + hy - vy), (float)(z + hz - vz)).texture(1, 1).color(col);
            return this;
        }
    }
}
