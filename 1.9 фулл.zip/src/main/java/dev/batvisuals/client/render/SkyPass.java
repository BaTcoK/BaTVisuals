package dev.batvisuals.client.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;

/**
 * Fullscreen NDC z=1 sky pass. Call after entities. TargetESP untouched.
 */
public final class SkyPass {
    private SkyPass() {}
    private static final long T0 = System.nanoTime();

    public enum Mode { WATER, CAUSTIC }

    public static final class Params {
        public Mode mode = Mode.CAUSTIC;
        public int color = 0;
        public float alpha = 0.55f, speed = 1f, scale = 1.6f, intensity = 1f;
        public float iter = -1f;
    }

    public static void draw(MatrixStack ms, Camera camera, Matrix4f projection, Params p) {
        if (p == null || camera == null) return;
        if (RenderCaps.shaderPackActive()) return;
        if (RenderPipeline.program(Shaders.skyFx()) != null) {
            drawShader(camera, projection, p);
        } else if (ms != null) {
            drawFallback(ms, camera, p);
        }
    }

    private static void drawShader(Camera camera, Matrix4f projection, Params p) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Window win = mc.getWindow();
        int col = RenderTheme.argb(p.color == 0 ? RenderTheme.primary() : p.color);
        WorldRenderer3D.Basis bs = WorldRenderer3D.Basis.of(camera);
        float tanHalf;
        if (projection != null && Math.abs(projection.m11()) > 1e-4f) {
            tanHalf = 1f / projection.m11();
        } else {
            double fov = 70;
            try { fov = mc.options.getFov().getValue(); } catch (Throwable ignored) {}
            tanHalf = (float) Math.tan(Math.toRadians(fov) * 0.5);
        }
        final float fov = (float) (2.0 * Math.atan(tanHalf));
        final float time = ((System.nanoTime() - T0) / 1_000_000L % 3_600_000L) / 1000f;
        final float iter = p.iter >= 0f ? p.iter : RenderCaps.skyIter();
        final float w = win.getFramebufferWidth(), h = win.getFramebufferHeight();
        final float cr = RenderTheme.r(col), cg = RenderTheme.g(col), cb = RenderTheme.b(col);
        final float a = p.alpha * ((col >>> 24) / 255f);
        final float mode = p.mode == Mode.CAUSTIC ? 1f : 0f;
        RenderState.Preset preset = p.mode == Mode.CAUSTIC ? RenderState.Preset.GLOW : RenderState.Preset.SKY;

        try (var batch = RenderPipeline.begin(preset, VertexFormat.DrawMode.QUADS, VertexFormats.POSITION,
                Shaders.skyFx(), sp -> uniforms(sp, time, w, h, cr, cg, cb, a, p, fov, mode, iter, bs))) {
            BufferBuilder b = batch.buf();
            b.vertex(-1f, -1f, 0f);
            b.vertex(1f, -1f, 0f);
            b.vertex(1f, 1f, 0f);
            b.vertex(-1f, 1f, 0f);
        }
    }

    private static void uniforms(ShaderProgram sp, float t, float w, float h, float r, float g, float b, float a,
                                 Params p, float fov, float mode, float iter, WorldRenderer3D.Basis bs) {
        RenderPipeline.set1(sp, "uTime", t);
        RenderPipeline.set2(sp, "uResolution", w, h);
        RenderPipeline.set3(sp, "uColor", r, g, b);
        RenderPipeline.set1(sp, "uAlpha", a);
        RenderPipeline.set1(sp, "uSpeed", p.speed);
        RenderPipeline.set1(sp, "uScale", p.scale);
        RenderPipeline.set1(sp, "uIntensity", p.intensity);
        RenderPipeline.set1(sp, "uFov", fov);
        RenderPipeline.set1(sp, "uMode", mode);
        RenderPipeline.set1(sp, "uIter", iter);
        RenderPipeline.set3(sp, "uCameraDir", (float) bs.fx, (float) bs.fy, (float) bs.fz);
        RenderPipeline.set3(sp, "uCamRight", (float) bs.rx, (float) bs.ry, (float) bs.rz);
        RenderPipeline.set3(sp, "uCamUp", (float) bs.ux, (float) bs.uy, (float) bs.uz);
    }

    private static void drawFallback(MatrixStack ms, Camera camera, Params p) {
        int col = RenderTheme.argb(p.color == 0 ? RenderTheme.primary() : p.color);
        try (var g = WorldRenderer3D.colored(ms, camera, RenderState.Preset.GLOW, false)) {
            g.skyDome(96.0, RenderCaps.mobile() ? 12 : 20,
                    RenderTheme.alpha(col, p.alpha * 0.35f),
                    RenderTheme.alpha(col, p.alpha * 0.08f));
        }
    }
}
