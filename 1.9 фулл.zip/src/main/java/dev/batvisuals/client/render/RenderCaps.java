package dev.batvisuals.client.render;

import org.lwjgl.opengl.GL11;

import java.lang.reflect.Method;
import java.util.Locale;

public final class RenderCaps {
    private RenderCaps() {}

    private static Boolean mobile;
    private static boolean irisProbed;
    private static Object irisApi;
    private static Method irisInUse;

    public static boolean mobile() {
        if (mobile == null) {
            String s = "";
            try {
                s = (GL11.glGetString(GL11.GL_RENDERER) + " " + GL11.glGetString(GL11.GL_VERSION)).toLowerCase(Locale.ROOT);
            } catch (Throwable ignored) {}
            mobile = System.getenv("POJAV_RENDERER") != null
                || s.contains("mobileglues") || s.contains("gl4es") || s.contains("angle")
                || s.contains("mali") || s.contains("adreno") || s.contains("powervr") || s.contains("opengl es");
        }
        return mobile;
    }

    public static float skyIter() { return mobile() ? 3f : 5f; }
    public static int arcSegments() { return mobile() ? 6 : 10; }

    public static boolean shaderPackActive() {
        if (!irisProbed) {
            irisProbed = true;
            try {
                Class<?> c = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
                irisApi = c.getMethod("getInstance").invoke(null);
                irisInUse = c.getMethod("isShaderPackInUse");
            } catch (Throwable ignored) {}
        }
        if (irisInUse == null) return false;
        try { return (boolean) irisInUse.invoke(irisApi); } catch (Throwable t) { return false; }
    }
}
