package dev.batvisuals.client.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.GlUniform;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.render.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

public final class RenderPipeline {
    private RenderPipeline() {}
    private static final Logger LOG = LoggerFactory.getLogger("BaTVisuals/Render");
    private static final long RETRY_MS = 8000;
    private static final Map<ShaderProgramKey, Long> FAILED = new HashMap<>();
    private static boolean open;

    public static void resetFailures() { FAILED.clear(); }

    public static ShaderProgram program(ShaderProgramKey key) {
        Long t = FAILED.get(key);
        if (t != null && System.currentTimeMillis() - t < RETRY_MS) return null;
        try {
            ShaderProgram sp = RenderSystem.setShader(key);
            if (sp == null) throw new IllegalStateException("program is null");
            FAILED.remove(key);
            return sp;
        } catch (Throwable e) {
            if (t == null) LOG.warn("shader {} failed, fallback: {}", key, e.toString());
            FAILED.put(key, System.currentTimeMillis());
            return null;
        }
    }

    public static boolean submit(BufferBuilder b, ShaderProgramKey key, Consumer<ShaderProgram> uniforms) {
        try {
            var built = b.end();
            if (built == null) return false;
            ShaderProgram sp = program(key);
            if (sp == null) {
                try { built.close(); } catch (Throwable ignored) {}
                return false;
            }
            if (uniforms != null) uniforms.accept(sp);
            BufferRenderer.drawWithGlobalProgram(built);
            return true;
        } catch (Throwable t) {
            LOG.debug("submit failed: {}", t.toString());
            return false;
        }
    }

    /** Vanilla shader path (no custom key). */
    public static boolean submitVanilla(BufferBuilder b, Runnable setShader) {
        try {
            var built = b.end();
            if (built == null) return false;
            if (setShader != null) setShader.run();
            BufferRenderer.drawWithGlobalProgram(built);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public static Batch begin(RenderState.Preset preset, VertexFormat.DrawMode mode, VertexFormat fmt,
                              ShaderProgramKey shader, Consumer<ShaderProgram> uniforms) {
        if (open) throw new IllegalStateException("RenderPipeline batch already open");
        return new Batch(preset, mode, fmt, shader, uniforms);
    }

    public static Batch beginVanilla(RenderState.Preset preset, VertexFormat.DrawMode mode, VertexFormat fmt,
                                     Runnable setShader) {
        if (open) throw new IllegalStateException("RenderPipeline batch already open");
        return new Batch(preset, mode, fmt, null, null, setShader);
    }

    public static final class Batch implements AutoCloseable {
        private final BufferBuilder buf;
        private final ShaderProgramKey key;
        private final Consumer<ShaderProgram> uniforms;
        private final Runnable vanillaSet;
        private boolean closed;

        private Batch(RenderState.Preset p, VertexFormat.DrawMode mode, VertexFormat fmt,
                      ShaderProgramKey key, Consumer<ShaderProgram> uniforms) {
            this(p, mode, fmt, key, uniforms, null);
        }

        private Batch(RenderState.Preset p, VertexFormat.DrawMode mode, VertexFormat fmt,
                      ShaderProgramKey key, Consumer<ShaderProgram> uniforms, Runnable vanillaSet) {
            this.key = key;
            this.uniforms = uniforms;
            this.vanillaSet = vanillaSet;
            open = true;
            BufferBuilder created;
            boolean pushed = false;
            try {
                RenderState.push();
                pushed = true;
                RenderState.apply(p);
                created = Tessellator.getInstance().begin(mode, fmt);
            } catch (Throwable t) {
                // иначе флаг open залипнет и каждый следующий begin() будет падать
                open = false;
                if (pushed) { try { RenderState.pop(); } catch (Throwable ignored) {} }
                throw t;
            }
            this.buf = created;
        }

        public BufferBuilder buf() { return buf; }

        @Override
        public void close() {
            if (closed) return;
            closed = true;
            try {
                if (key != null) submit(buf, key, uniforms);
                else submitVanilla(buf, vanillaSet);
            } catch (Throwable t) {
                LOG.error("batch draw failed", t);
            } finally {
                open = false;
                RenderState.pop();
            }
        }
    }

    public static void set1(ShaderProgram p, String n, float a) {
        GlUniform u = p.getUniform(n);
        if (u != null) u.set(a);
    }

    public static void set2(ShaderProgram p, String n, float a, float b) {
        GlUniform u = p.getUniform(n);
        if (u != null) u.set(a, b);
    }

    public static void set3(ShaderProgram p, String n, float a, float b, float c) {
        GlUniform u = p.getUniform(n);
        if (u != null) u.set(a, b, c);
    }
}
