package dev.batvisuals.modules.settings.impl;

import dev.batvisuals.modules.settings.Setting;
import dev.batvisuals.modules.settings.api.EnumConverter;
import dev.batvisuals.modules.settings.api.Nameable;

import java.util.function.Supplier;

public class EnumSetting<Value extends Enum<?>> extends Setting<Value> {

    public EnumSetting(String name, Value defaultValue) {
        super(name, defaultValue);
    }

    public EnumSetting(String name, Value defaultValue, Supplier<Boolean> visible) {
        super(name, defaultValue, visible);
    }

    public void increaseEnum() {
        setValue((Value) EnumConverter.increaseEnum(value));
    }

    public String currentEnumName() {
        return ((Nameable) value).getName();
    }

    /**
     * Accepts both display name (Nameable.getName()) and enum constant name (e.g. BAT).
     * Old configs saved Gson enum names; new configs save display names.
     */
    public void setEnumValue(String value) {
        if (value == null || value.isEmpty()) return;
        Value[] constants = (Value[]) this.value.getClass().getEnumConstants();
        if (constants == null) return;

        // 1) display name (RU/EN label)
        for (Value e : constants) {
            if (e instanceof Nameable && ((Nameable) e).getName().equalsIgnoreCase(value)) {
                setValue(e);
                return;
            }
        }
        // 2) enum constant name (BAT, ALLAY, ...)
        for (Value e : constants) {
            if (e.name().equalsIgnoreCase(value)) {
                setValue(e);
                return;
            }
        }
        // 3) toString fallback
        for (Value e : constants) {
            if (String.valueOf(e).equalsIgnoreCase(value)) {
                setValue(e);
                return;
            }
        }
    }
}
