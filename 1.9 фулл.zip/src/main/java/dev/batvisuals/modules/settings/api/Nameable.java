package dev.batvisuals.modules.settings.api;

public interface Nameable {
    String getName();
}