package dev.batvisuals.modules.impl.utility;

import dev.batvisuals.client.events.impl.EventRender2D;
import dev.batvisuals.client.ui.hud.HudElement;
import dev.batvisuals.client.util.renderer.Render2D;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.text.Text;

import java.awt.Color;

/**
 * Показывает количество тотемов в инвентаре игрока.
 * Является HudElement, поэтому наследует всю систему перетаскивания:
 * при открытом чате элемент можно схватить ЛКМ и перетащить в любое место экрана
 * (включая зону поверх строки ввода чата), а также открыть его настройки ПКМ.
 */
public class TotemCounter extends HudElement {

    private static final float ICON_SIZE = 16.0f;
    private static final Identifier TOTEM_TEXTURE = Identifier.of("minecraft", "textures/item/totem_of_undying.png");

    public TotemCounter() {
        super("TotemCounter");
		// Убрать Scale (больше/меньше) из ПКМ-настроек
		getSettings().removeIf(s -> "Scale".equalsIgnoreCase(s.getName()));
        // Дефолтная позиция примерно там же, где элемент был раньше (чуть правее и выше центра прицела)
        getPosition().getValue().setX(0.52f);
        getPosition().getValue().setY(0.485f);
    }

    @Override
    public void onRender2D(EventRender2D e) {
        if (fullNullCheck() || closed()) return;
        if (mc.player == null) return;

        int totemCount = countTotems();
        String countText = String.valueOf(totemCount);

        float textWidth = mc.textRenderer.getWidth(countText);
        float gap = 4.0f;
        float totalWidth = ICON_SIZE + gap + textWidth;
        float totalHeight = ICON_SIZE;

        float posX = getX();
        float posY = getY();

        // Иконка тотема
        e.getContext().getMatrices().push();
        e.getContext().getMatrices().translate(posX, posY, 0);
        Render2D.drawTexture(
                e.getContext().getMatrices(),
                0, 0, ICON_SIZE, ICON_SIZE,
                0f,
                TOTEM_TEXTURE,
                new Color(255, 255, 255, 255)
        );
        e.getContext().getMatrices().pop();

        // Текст количества
        float textX = posX + ICON_SIZE + gap;
        float textY = posY + (ICON_SIZE / 2.0f) - (mc.textRenderer.fontHeight / 2.0f);

        e.getContext().drawText(
                mc.textRenderer,
                Text.of(countText),
                (int) textX,
                (int) textY,
                new Color(255, 255, 255, 255).getRGB(),
                true
        );

        // Регистрируем текущие размеры/позицию для drag-системы HudElement
        setBounds(posX, posY, totalWidth, totalHeight);
        super.onRender2D(e);
    }

    private int countTotems() {
        if (mc.player == null) return 0;

        int count = 0;
        for (int i = 0; i < mc.player.getInventory().size(); i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.TOTEM_OF_UNDYING) {
                count += mc.player.getInventory().getStack(i).getCount();
            }
        }
        return count;
    }
}
