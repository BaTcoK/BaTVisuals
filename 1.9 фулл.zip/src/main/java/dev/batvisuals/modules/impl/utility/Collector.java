package dev.batvisuals.modules.impl.utility;

import com.google.gson.*;
import dev.batvisuals.batvisuals;
import dev.batvisuals.client.events.impl.EventHandledScreen;
import dev.batvisuals.client.events.impl.EventTick;
import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.renderer.fonts.Fonts;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;

/**
 * Collector — сохраняет раскладку инвентаря и раскладывает предметы по слотам (200мс / шаг).
 * Кнопка справа от инвентаря, оверлей для профилей.
 */
public class Collector extends Module {

    private static final long STEP_MS = 200L;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // UI
    private boolean overlayOpen = false;
    private int selectedIndex = -1;
    private boolean renaming = false;
    private String renameBuffer = "";
    private String statusMsg = "";
    private long statusUntil = 0L;

    // Button bounds (screen space)
    private float btnX, btnY, btnW = 72f, btnH = 18f;

    // Sorting state
    private boolean sorting = false;
    private InventoryProfile activeProfile;
    private long lastStepTime = 0L;
    private int sortSteps = 0;
    private static final int MAX_SORT_STEPS = 80;
    private int lastSrc = -1, lastTgt = -1;
    private int samePairCount = 0;

    private final List<InventoryProfile> profiles = new ArrayList<>();

    public Collector() {
        super("Collector", Category.Utility, "Сбор предметов");
    }

    @Override
    public void onEnable() {
        super.onEnable();
        loadProfiles();
        overlayOpen = false;
        sorting = false;
        renaming = false;
    }

    @Override
    public void onDisable() {
        overlayOpen = false;
        sorting = false;
        renaming = false;
        super.onDisable();
    }

    // ------------------------------------------------------------------
    // Persistence
    // ------------------------------------------------------------------

    private File dir() {
        File d = new File(batvisuals.getInstance().getGlobalsDir(), "collector");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private File profilesFile() {
        return new File(dir(), "profiles.json");
    }

    private void loadProfiles() {
        profiles.clear();
        try {
            File f = profilesFile();
            if (!f.exists()) return;
            String raw = Files.readString(f.toPath(), StandardCharsets.UTF_8);
            JsonArray arr = JsonParser.parseString(raw).getAsJsonArray();
            for (JsonElement el : arr) {
                InventoryProfile p = InventoryProfile.fromJson(el.getAsJsonObject());
                if (p != null) profiles.add(p);
            }
        } catch (Exception e) {
            System.err.println("[Collector] load failed: " + e.getMessage());
        }
    }

    private void saveProfiles() {
        try {
            JsonArray arr = new JsonArray();
            for (InventoryProfile p : profiles) arr.add(p.toJson());
            Files.writeString(profilesFile().toPath(), GSON.toJson(arr), StandardCharsets.UTF_8);
        } catch (Exception e) {
            System.err.println("[Collector] save failed: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------
    // Capture / match / restore
    // ------------------------------------------------------------------

    /** Handler slots we care about: armor 5-8, main 9-35, hotbar 36-44, offhand 45 */
    private static boolean isTrackedSlot(int handlerSlot) {
        return (handlerSlot >= 5 && handlerSlot <= 8)
                || (handlerSlot >= 9 && handlerSlot <= 45);
    }

    private InventoryProfile captureCurrent(String name) {
        InventoryProfile p = new InventoryProfile(name);
        if (mc.player == null) return p;
        PlayerScreenHandler h = mc.player.playerScreenHandler;
        for (int i = 5; i <= 45; i++) {
            ItemStack stack = h.getSlot(i).getStack();
            if (!stack.isEmpty()) {
                p.slots.put(i, SlotSnapshot.from(stack));
            }
        }
        return p;
    }

    private boolean stackMatches(ItemStack stack, SlotSnapshot snap) {
        if (snap == null) return stack.isEmpty();
        if (stack.isEmpty()) return false;
        if (!Registries.ITEM.getId(stack.getItem()).toString().equals(snap.itemId)) return false;
        // Точное совпадение количества — иначе бесконечные свапы
        if (stack.getCount() != snap.count) return false;
        String custom = customNameOf(stack);
        return Objects.equals(custom, snap.customName == null ? "" : snap.customName);
    }

    /** Предмет подходит как источник (можно взять стопку с count >= need). */
    private boolean stackUsableAsSource(ItemStack stack, SlotSnapshot need) {
        if (need == null || stack.isEmpty()) return false;
        if (!Registries.ITEM.getId(stack.getItem()).toString().equals(need.itemId)) return false;
        if (stack.getCount() < need.count) return false;
        String custom = customNameOf(stack);
        return Objects.equals(custom, need.customName == null ? "" : need.customName);
    }

    private static String customNameOf(ItemStack stack) {
        Text t = stack.get(DataComponentTypes.CUSTOM_NAME);
        return t == null ? "" : t.getString();
    }

    private int findSourceSlot(int targetSlot, SlotSnapshot need) {
        if (mc.player == null || need == null) return -1;
        PlayerScreenHandler h = mc.player.playerScreenHandler;

        // 1) Слоты вне профиля
        for (int i = 5; i <= 45; i++) {
            if (i == targetSlot) continue;
            if (activeProfile.slots.containsKey(i)) continue;
            if (stackUsableAsSource(h.getSlot(i).getStack(), need)) return i;
        }
        // 2) Слоты профиля, которые сами заполнены НЕПРАВИЛЬНО (нельзя трогать уже правильные)
        for (int i = 5; i <= 45; i++) {
            if (i == targetSlot) continue;
            if (!activeProfile.slots.containsKey(i)) continue;
            ItemStack at = h.getSlot(i).getStack();
            if (stackMatches(at, activeProfile.slots.get(i))) continue; // already correct — leave it
            if (stackUsableAsSource(at, need)) return i;
        }
        return -1;
    }

    private void swapHandlerSlots(int a, int b) {
        if (mc.player == null || mc.interactionManager == null) return;
        if (a == b) return;
        // Не трогаем крафт (0-4)
        if (a < 5 || b < 5 || a > 45 || b > 45) return;
        int sync = mc.player.playerScreenHandler.syncId;
        // Если на курсоре что-то висит — не сортируем
        if (!mc.player.playerScreenHandler.getCursorStack().isEmpty()) return;
        mc.interactionManager.clickSlot(sync, a, 0, SlotActionType.PICKUP, mc.player);
        mc.interactionManager.clickSlot(sync, b, 0, SlotActionType.PICKUP, mc.player);
        mc.interactionManager.clickSlot(sync, a, 0, SlotActionType.PICKUP, mc.player);
    }

    /** One step. true = ещё есть работа / сделали ход. false = стоп. */
    private boolean sortStep() {
        if (mc.player == null || activeProfile == null) return false;
        PlayerScreenHandler h = mc.player.playerScreenHandler;
        if (!h.getCursorStack().isEmpty()) return true; // ждём пока курсор пуст

        sortSteps++;
        if (sortSteps > MAX_SORT_STEPS) return false;

        for (Map.Entry<Integer, SlotSnapshot> e : activeProfile.slots.entrySet()) {
            int target = e.getKey();
            if (target < 5 || target > 45) continue;
            SlotSnapshot need = e.getValue();
            ItemStack there = h.getSlot(target).getStack();
            if (stackMatches(there, need)) continue;

            int src = findSourceSlot(target, need);
            if (src == -1) continue;
            if (src == target) continue;

            // Защита от бесконечного свапа одной пары
            if ((src == lastSrc && target == lastTgt) || (src == lastTgt && target == lastSrc)) {
                samePairCount++;
                if (samePairCount >= 3) continue; // skip this pair
            } else {
                samePairCount = 0;
            }
            lastSrc = src;
            lastTgt = target;

            swapHandlerSlots(src, target);
            return true;
        }
        return false;
    }

    private boolean isLayoutSatisfied() {
        if (mc.player == null || activeProfile == null) return true;
        PlayerScreenHandler h = mc.player.playerScreenHandler;
        for (Map.Entry<Integer, SlotSnapshot> e : activeProfile.slots.entrySet()) {
            if (!stackMatches(h.getSlot(e.getKey()).getStack(), e.getValue())) return false;
        }
        return true;
    }

    private void startSort(InventoryProfile p) {
        activeProfile = p;
        sorting = true;
        lastStepTime = 0L;
        sortSteps = 0;
        lastSrc = lastTgt = -1;
        samePairCount = 0;
        status("Раскладка: " + p.name);
    }

    private void stopSort(String msg) {
        sorting = false;
        activeProfile = null;
        if (msg != null) status(msg);
    }

    private void status(String s) {
        statusMsg = s;
        statusUntil = System.currentTimeMillis() + 2500;
    }

    // ------------------------------------------------------------------
    // Tick
    // ------------------------------------------------------------------

    @EventHandler
    public void onTick(EventTick e) {
        if (!isToggled() || !sorting) return;
        if (fullNullCheck()) {
            stopSort("Игрок недоступен");
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastStepTime < STEP_MS) return;
        lastStepTime = now;

        if (isLayoutSatisfied()) {
            stopSort("Готово: " + (activeProfile != null ? activeProfile.name : ""));
            return;
        }
        boolean moved = sortStep();
        if (!moved) {
            // Nothing could be moved — missing items
            stopSort("Остановлено (не хватает предметов)");
        }
    }

    // ------------------------------------------------------------------
    // Inventory button + overlay render
    // ------------------------------------------------------------------

    @EventHandler
    public void onHandledScreen(EventHandledScreen e) {
        if (!isToggled()) return;
        // Only survival inventory screen
        if (!(mc.currentScreen instanceof InventoryScreen)) return;

        DrawContext ctx = e.getDrawContext();
        int mouseX = e.getMouseX();
        int mouseY = e.getMouseY();

        // Button to the right of inventory GUI, top area
        btnX = e.getGuiLeft() + e.getBackgroundWidth() + 6f;
        btnY = e.getGuiTop() + 6f;

        drawButton(ctx, mouseX, mouseY);

        if (overlayOpen) {
            drawOverlay(ctx, mouseX, mouseY);
        }

        // Status toast
        if (System.currentTimeMillis() < statusUntil && statusMsg != null && !statusMsg.isEmpty()) {
            float tw = Fonts.REGULAR.getWidth(statusMsg, 7f);
            float tx = (mc.getWindow().getScaledWidth() - tw) / 2f;
            float ty = mc.getWindow().getScaledHeight() - 40f;
            Render2D.drawRoundedRect(ctx.getMatrices(), tx - 6, ty - 3, tw + 12, 14, 4,
                    new Color(20, 20, 28, 200));
            Render2D.drawFont(ctx.getMatrices(), Fonts.REGULAR.getFont(7f), statusMsg, tx, ty, new Color(220, 220, 240));
        }
    }

    private void drawButton(DrawContext ctx, int mouseX, int mouseY) {
        boolean hover = mouseX >= btnX && mouseX <= btnX + btnW && mouseY >= btnY && mouseY <= btnY + btnH;
        Color bg = hover ? new Color(70, 90, 160, 230) : new Color(40, 45, 60, 220);
        Render2D.drawRoundedRect(ctx.getMatrices(), btnX, btnY, btnW, btnH, 5, bg);
        String label = sorting ? "..." : "Collector";
        float tw = Fonts.REGULAR.getWidth(label, 7f);
        float th = Fonts.REGULAR.getHeight(7f);
        Render2D.drawFont(ctx.getMatrices(), Fonts.REGULAR.getFont(7f), label, btnX + (btnW - tw) / 2f, btnY + (btnH - th) / 2f, Color.WHITE);
    }

    private void drawOverlay(DrawContext ctx, int mouseX, int mouseY) {
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        // Dim full screen
        Render2D.drawRoundedRect(ctx.getMatrices(), 0, 0, sw, sh, 0, new Color(0, 0, 0, 160));

        float pw = Math.min(320f, sw - 24f);
        float ph = Math.min(280f, sh - 24f);
        float px = (sw - pw) / 2f;
        float py = (sh - ph) / 2f;

        Render2D.drawRoundedRect(ctx.getMatrices(), px, py, pw, ph, 10, new Color(22, 22, 30, 245));
        Render2D.drawFont(ctx.getMatrices(), Fonts.BOLD.getFont(9f), "Collector", px + 12, py + 10, new Color(220, 225, 255));
        Render2D.drawFont(ctx.getMatrices(), Fonts.REGULAR.getFont(6f), "Профилей: " + profiles.size(), px + 12, py + 26, new Color(160, 160, 180));

        // Close X
        float closeX = px + pw - 22;
        float closeY = py + 10;
        boolean closeHover = mouseX >= closeX && mouseX <= closeX + 14 && mouseY >= closeY && mouseY <= closeY + 14;
        Render2D.drawFont(ctx.getMatrices(), Fonts.BOLD.getFont(8f), "X", closeX, closeY, closeHover ? Color.RED : new Color(200, 200, 200));

        // List area
        float listY = py + 44;
        float rowH = 22f;
        float listH = ph - 100;
        int maxVisible = (int) (listH / rowH);

        if (profiles.isEmpty()) {
            Render2D.drawFont(ctx.getMatrices(), Fonts.REGULAR.getFont(7f), "Нет сохранённых инвентарей", px + 12, listY + 8, new Color(140, 140, 160));
        } else {
            for (int i = 0; i < Math.min(profiles.size(), maxVisible); i++) {
                InventoryProfile p = profiles.get(i);
                float ry = listY + i * rowH;
                boolean sel = i == selectedIndex;
                boolean hover = mouseX >= px + 10 && mouseX <= px + pw - 10 && mouseY >= ry && mouseY <= ry + rowH - 2;
                Color rowBg = sel ? new Color(60, 80, 140, 200) : (hover ? new Color(40, 45, 60, 200) : new Color(30, 32, 42, 180));
                Render2D.drawRoundedRect(ctx.getMatrices(), px + 10, ry, pw - 20, rowH - 3, 4, rowBg);
                String title = p.name + "  (" + p.slots.size() + " сл.)";
                Render2D.drawFont(ctx.getMatrices(), Fonts.REGULAR.getFont(7f), title, px + 16, ry + 5, Color.WHITE);
            }
        }

        // Bottom buttons
        float by = py + ph - 40;
        float bw = (pw - 40) / 4f;
        drawSmallBtn(ctx, px + 10, by, bw, 22, "Сохранить", mouseX, mouseY);
        drawSmallBtn(ctx, px + 16 + bw, by, bw, 22, "Применить", mouseX, mouseY);
        drawSmallBtn(ctx, px + 22 + bw * 2, by, bw, 22, "Имя", mouseX, mouseY);
        drawSmallBtn(ctx, px + 28 + bw * 3, by, bw, 22, "Удалить", mouseX, mouseY);

        if (renaming) {
            float fbY = by - 28;
            Render2D.drawRoundedRect(ctx.getMatrices(), px + 10, fbY, pw - 20, 20, 4, new Color(15, 15, 22, 240));
            String shown = "Имя: " + renameBuffer + "_";
            Render2D.drawFont(ctx.getMatrices(), Fonts.REGULAR.getFont(7f), shown, px + 16, fbY + 5, new Color(255, 220, 120));
        }

        // Preview selected
        if (selectedIndex >= 0 && selectedIndex < profiles.size() && !renaming) {
            InventoryProfile p = profiles.get(selectedIndex);
            float prevY = listY + Math.min(profiles.size(), maxVisible) * rowH + 4;
            if (prevY < by - 36) {
                Render2D.drawFont(ctx.getMatrices(), Fonts.REGULAR.getFont(6f), "Слотов: " + p.slots.size() + " | броня+оффхенд+инв", px + 12, prevY, new Color(150, 150, 170));
            }
        }
    }

    private void drawSmallBtn(DrawContext ctx, float x, float y, float w, float h, String text, int mx, int my) {
        boolean hover = mx >= x && mx <= x + w && my >= y && my <= y + h;
        Render2D.drawRoundedRect(ctx.getMatrices(), x, y, w, h, 4,
                hover ? new Color(70, 95, 170, 230) : new Color(45, 50, 65, 220));
        float tw = Fonts.REGULAR.getWidth(text, 6f);
        Render2D.drawFont(ctx.getMatrices(), Fonts.REGULAR.getFont(6f), text, x + (w - tw) / 2f, y + 6, Color.WHITE);
    }

    // ------------------------------------------------------------------
    // Input from HandledScreen mixin
    // ------------------------------------------------------------------

    public boolean onInventoryMouseClicked(double mouseX, double mouseY, int button, int guiLeft, int guiTop, int bgW, int bgH) {
        if (!(mc.currentScreen instanceof InventoryScreen)) return false;

        // Update button pos
        btnX = guiLeft + bgW + 6f;
        btnY = guiTop + 6f;

        // Оверлей открыт — полностью блокируем клики по инвентарю (любая кнопка мыши)
        if (overlayOpen) {
            if (button == 0) handleOverlayClick(mouseX, mouseY);
            return true;
        }

        if (button != 0) return false;

        // Collector button
        if (mouseX >= btnX && mouseX <= btnX + btnW && mouseY >= btnY && mouseY <= btnY + btnH) {
            overlayOpen = true;
            renaming = false;
            return true;
        }
        return false;
    }

    private boolean handleOverlayClick(double mouseX, double mouseY) {
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        float pw = Math.min(320f, sw - 24f);
        float ph = Math.min(280f, sh - 24f);
        float px = (sw - pw) / 2f;
        float py = (sh - ph) / 2f;

        // Outside panel — close
        if (mouseX < px || mouseX > px + pw || mouseY < py || mouseY > py + ph) {
            if (!renaming) {
                overlayOpen = false;
            }
            return true;
        }

        // Close X
        float closeX = px + pw - 22;
        float closeY = py + 10;
        if (mouseX >= closeX && mouseX <= closeX + 14 && mouseY >= closeY && mouseY <= closeY + 14) {
            overlayOpen = false;
            renaming = false;
            return true;
        }

        // List select
        float listY = py + 44;
        float rowH = 22f;
        float listH = ph - 100;
        int maxVisible = (int) (listH / rowH);
        for (int i = 0; i < Math.min(profiles.size(), maxVisible); i++) {
            float ry = listY + i * rowH;
            if (mouseX >= px + 10 && mouseX <= px + pw - 10 && mouseY >= ry && mouseY <= ry + rowH - 2) {
                selectedIndex = i;
                renaming = false;
                return true;
            }
        }

        // Bottom buttons
        float by = py + ph - 40;
        float bw = (pw - 40) / 4f;
        // Save
        if (hit(mouseX, mouseY, px + 10, by, bw, 22)) {
            String name = "Инвентарь " + (profiles.size() + 1);
            profiles.add(captureCurrent(name));
            selectedIndex = profiles.size() - 1;
            saveProfiles();
            status("Сохранено: " + name);
            return true;
        }
        // Apply
        if (hit(mouseX, mouseY, px + 16 + bw, by, bw, 22)) {
            if (selectedIndex >= 0 && selectedIndex < profiles.size()) {
                overlayOpen = false;
                startSort(profiles.get(selectedIndex));
            } else {
                status("Выбери профиль");
            }
            return true;
        }
        // Rename
        if (hit(mouseX, mouseY, px + 22 + bw * 2, by, bw, 22)) {
            if (selectedIndex >= 0 && selectedIndex < profiles.size()) {
                renaming = true;
                renameBuffer = profiles.get(selectedIndex).name;
            } else {
                status("Выбери профиль");
            }
            return true;
        }
        // Delete
        if (hit(mouseX, mouseY, px + 28 + bw * 3, by, bw, 22)) {
            if (selectedIndex >= 0 && selectedIndex < profiles.size()) {
                String n = profiles.remove(selectedIndex).name;
                selectedIndex = -1;
                saveProfiles();
                status("Удалено: " + n);
            }
            return true;
        }
        return true; // absorb all clicks while overlay open
    }

    private static boolean hit(double mx, double my, float x, float y, float w, float h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    public boolean onInventoryKeyPressed(int keyCode) {
        if (!overlayOpen) return false;
        if (renaming) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                renaming = false;
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                if (selectedIndex >= 0 && selectedIndex < profiles.size() && !renameBuffer.isBlank()) {
                    profiles.get(selectedIndex).name = renameBuffer.trim();
                    saveProfiles();
                    status("Переименовано");
                }
                renaming = false;
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!renameBuffer.isEmpty()) renameBuffer = renameBuffer.substring(0, renameBuffer.length() - 1);
                return true;
            }
            return true; // блокируем клавиши инвентаря пока идёт rename
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            overlayOpen = false;
            return true;
        }
        return false;
    }

    /** Вызывается из ScreenMixin.charTyped — поддерживает RU/EN. */
    public boolean onCharTyped(char chr) {
        if (!overlayOpen || !renaming) return false;
        if (Character.isISOControl(chr)) return true;
        if (renameBuffer.length() < 32) renameBuffer += chr;
        return true;
    }

    public boolean isOverlayOpen() {
        return overlayOpen;
    }

    // ------------------------------------------------------------------
    // Data
    // ------------------------------------------------------------------

    public static class SlotSnapshot {
        public String itemId;
        public int count;
        public String customName; // "" if none

        public static SlotSnapshot from(ItemStack stack) {
            SlotSnapshot s = new SlotSnapshot();
            s.itemId = Registries.ITEM.getId(stack.getItem()).toString();
            s.count = stack.getCount();
            s.customName = customNameOf(stack);
            return s;
        }

        public JsonObject toJson() {
            JsonObject o = new JsonObject();
            o.addProperty("id", itemId);
            o.addProperty("count", count);
            o.addProperty("name", customName == null ? "" : customName);
            return o;
        }

        public static SlotSnapshot fromJson(JsonObject o) {
            SlotSnapshot s = new SlotSnapshot();
            s.itemId = o.get("id").getAsString();
            s.count = o.has("count") ? o.get("count").getAsInt() : 1;
            s.customName = o.has("name") ? o.get("name").getAsString() : "";
            return s;
        }
    }

    public static class InventoryProfile {
        public String name;
        /** handler slot id -> snapshot */
        public final LinkedHashMap<Integer, SlotSnapshot> slots = new LinkedHashMap<>();

        public InventoryProfile(String name) {
            this.name = name;
        }

        public JsonObject toJson() {
            JsonObject o = new JsonObject();
            o.addProperty("name", name);
            JsonObject sl = new JsonObject();
            for (Map.Entry<Integer, SlotSnapshot> e : slots.entrySet()) {
                sl.add(String.valueOf(e.getKey()), e.getValue().toJson());
            }
            o.add("slots", sl);
            return o;
        }

        public static InventoryProfile fromJson(JsonObject o) {
            if (o == null || !o.has("name")) return null;
            InventoryProfile p = new InventoryProfile(o.get("name").getAsString());
            if (o.has("slots") && o.get("slots").isJsonObject()) {
                JsonObject sl = o.getAsJsonObject("slots");
                for (Map.Entry<String, JsonElement> e : sl.entrySet()) {
                    try {
                        int id = Integer.parseInt(e.getKey());
                        p.slots.put(id, SlotSnapshot.fromJson(e.getValue().getAsJsonObject()));
                    } catch (Exception ignored) {}
                }
            }
            return p;
        }
    }
}
