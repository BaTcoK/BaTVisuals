package dev.batvisuals.modules.impl.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.batvisuals.client.events.impl.EventRender3D;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.client.render.RenderState;
import dev.batvisuals.client.util.render.HandFillProvider;
import dev.batvisuals.client.util.render.HandItemOutline;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.api.Nameable;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.EnumSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Arm;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;

import java.awt.Color;
import java.util.Arrays;

/**
 * First-person hand: тема (заливка) + анимированная обводка руки и предметов (обе руки) + дым в мире.
 * Outline = inverted hull, no GL_POLYGON_MODE (works on MobileGlues/GLES).
 */
public class HandShader extends Module implements ThemeManager.ThemeChangeListener {

    public enum Theme implements Nameable {
        NORMAL("Обычный"), WATER("Вода"), CAUSTIC("Каустика"), PLASMA("Плазма"),
        NEON("Неон"), RAINBOW("Радуга"), GALAXY("Галактика"), GLASS("Стекло");
        private final String name;
        Theme(String name) { this.name = name; }
        @Override public String getName() { return name; }
    }

    public final EnumSetting<Theme> theme = new EnumSetting<>("Тема", Theme.NORMAL);
    public final NumberSetting animSpeed = new NumberSetting("Скорость анимации", 1.0f, 0.2f, 3.0f, 0.1f);
    public final NumberSetting glassAlpha = new NumberSetting("Прозрачность стекла", 0.55f, 0.2f, 1.0f, 0.05f,
            () -> theme.getValue() == Theme.GLASS);
    public final BooleanSetting outline = new BooleanSetting("Обводка", true);
    public final NumberSetting outlineWidth = new NumberSetting("Толщина обводки", 0.014f, 0.004f, 0.04f, 0.002f,
            () -> outline.getValue());
    public final BooleanSetting itemOutline = new BooleanSetting("Обводка предметов", true, () -> outline.getValue());
    public final BooleanSetting itemFill = new BooleanSetting("Заливка предметов", true);
    /** 0% = заливка полностью непрозрачная, 100% = заливки нет (чистый предмет). */
    public final NumberSetting itemTransparency = new NumberSetting("Прозрачность предметов, %", 15f, 0f, 100f, 1f,
            () -> itemFill.getValue());

    /** Smoke (world-space). */
    public final BooleanSetting smoke = new BooleanSetting("Дым", false);
    public final BooleanSetting whiteSmoke = new BooleanSetting("Белый дым", true, () -> smoke.getValue());
    public final NumberSetting smokeStrength = new NumberSetting("Сила дыма", 1.0f, 0.3f, 2.0f, 0.1f,
            () -> smoke.getValue());
    public final NumberSetting smokeTime = new NumberSetting("Время дыма", 2.5f, 0.8f, 6.0f, 0.1f,
            () -> smoke.getValue());
    public final BooleanSetting autoSmoke = new BooleanSetting("Авто-дым", false, () -> smoke.getValue());

    private final ThemeManager themeManager;
    private Color currentColor;

    private static final boolean LOW = System.getenv("POJAV_RENDERER") != null;
    private static final int CAP = LOW ? 90 : 180;
    private final double[] sx = new double[CAP], sy = new double[CAP], sz = new double[CAP];
    private final float[] vx = new float[CAP], vy = new float[CAP], vz = new float[CAP];
    private final float[] smokeLife = new float[CAP], smokeSize = new float[CAP];
    private final long[] smokeBorn = new long[CAP];
    private int smokeHead;
    private Vec3d lastHand;
    private long lastMs;
    private float autoAcc;
    private static Identifier softTex;
    private static boolean softInit;

    public HandShader() {
        super("HandShader", Category.Render, "Заливка и обводка руки от 1-го лица");
        this.themeManager = ThemeManager.getInstance();
        this.currentColor = themeManager.getThemeColor();
        themeManager.addThemeChangeListener(this);
    }

    public Color getBaseThemeColor() {
        try {
            Color c = themeManager.getCurrentTheme().getAccentColor();
            if (c != null) {
                currentColor = c;
                return c;
            }
        } catch (Throwable ignored) {}
        if (currentColor == null) currentColor = new Color(55, 130, 230);
        return currentColor;
    }

    /** Цвет для дыма. */
    public Color getLiveColor() {
        return getBaseThemeColor();
    }

    public boolean isOutline() {
        return Boolean.TRUE.equals(outline.getValue());
    }

    public boolean isSmoke() {
        return Boolean.TRUE.equals(smoke.getValue());
    }

    /** Обводка включена и для предметов -> рисуем её экранным проходом по силуэту руки+предмета. */
    public boolean itemsOutline() {
        return isOutline() && Boolean.TRUE.equals(itemOutline.getValue());
    }

    /** Нужна ли вообще обёртка предметов (заливка или обводка). */
    public boolean itemsActive() {
        return itemsOutline() || (Boolean.TRUE.equals(itemFill.getValue()) && itemAlpha() > 0.01f);
    }

    private float itemAlpha() {
        Float v = itemTransparency.getValue();
        return 1f - MathHelper.clamp(v == null ? 40f : v, 0f, 100f) / 100f;
    }

    /** Геометрический путь: не трогает весь framebuffer и не может перекрыть HUD/интерфейс. */
    private HandFillProvider.Style buildStyle(boolean probe) {
        boolean geomArm = isOutline();
        boolean geomItem = itemsOutline();

        Color base = getBaseThemeColor();
        float spd = animSpeed.getValue() == null ? 1f : MathHelper.clamp(animSpeed.getValue(), 0.2f, 3f);
        float t = (System.currentTimeMillis() % 100000L) / 1000f * spd;
        Float w = outlineWidth.getValue();
        HandFillProvider.Style st = new HandFillProvider.Style(theme.getValue().ordinal(), base.getRGB(),
                mix(base, Color.WHITE, 0.30f).getRGB(), mix(base, Color.WHITE, 0.90f).getRGB(),
                geomArm, w == null ? 0.014f : MathHelper.clamp(w, 0.004f, 0.04f), t,
                glassAlpha.getValue() == null ? 0.55f : MathHelper.clamp(glassAlpha.getValue(), 0.2f, 1f));
        st.itemOutline = geomItem;
        st.itemFill = Boolean.TRUE.equals(itemFill.getValue());
        st.itemAlpha = itemAlpha();
        return st;
    }

    /** Рука: заливка темы (+ hull-обводка только в fallback). */
    public VertexConsumerProvider wrapArm(VertexConsumerProvider parent) {
        return new HandFillProvider(parent, buildStyle(true));
    }

    /** Предмет/блок в руке (любой руке): заливка в вершины предмета; после рендера вызвать flush() (fallback-обводка). */
    public HandItemOutline wrapItem(VertexConsumerProvider parent) {
        return new HandItemOutline(parent, buildStyle(true));
    }

    private static Color mix(Color x, Color y, float t) {
        return new Color(
                clamp255(x.getRed() + (y.getRed() - x.getRed()) * t),
                clamp255(x.getGreen() + (y.getGreen() - x.getGreen()) * t),
                clamp255(x.getBlue() + (y.getBlue() - x.getBlue()) * t));
    }

    // ───────────────────────── дым (мировые координаты) ─────────────────────────

    @EventHandler
    public void onRender3D(EventRender3D.Game e) {
        if (fullNullCheck() || !isSmoke()) {
            lastHand = null;
            return;
        }
        long now = System.currentTimeMillis();
        Camera cam = mc.gameRenderer.getCamera();
        if (mc.options.getPerspective().isFirstPerson()) spawn(cam, now);
        else lastHand = null;
        lastMs = now;
        draw(cam, now);
    }

    private void ensureSoft() {
        if (softInit) return;
        softInit = true;
        try {
            softTex = Identifier.of("batvisuals", "dyn/hand_soft");
            int n = 64;
            NativeImage img = new NativeImage(n, n, false);
            for (int y = 0; y < n; y++) for (int x = 0; x < n; x++) {
                float dx = (x + 0.5f) / n * 2 - 1, dy = (y + 0.5f) / n * 2 - 1;
                float a = Math.max(0f, 1f - (float) Math.sqrt(dx * dx + dy * dy));
                a = a * a * (3 - 2 * a);
                img.setColorArgb(x, y, ((int) (a * 255) << 24) | 0xFFFFFF);
            }
            MinecraftClient.getInstance().getTextureManager()
                    .registerTexture(softTex, new NativeImageBackedTexture(img));
        } catch (Throwable t) {
            softTex = Identifier.of("batvisuals", "hud/glow.png");
        }
    }

    private void spawn(Camera cam, long now) {
        Vector3f f = new Vector3f(0, 0, -1).rotate(cam.getRotation());
        Vector3f r = new Vector3f(1, 0, 0).rotate(cam.getRotation());
        Vector3f u = new Vector3f(0, 1, 0).rotate(cam.getRotation());
        float side = mc.options.getMainArm().getValue() == Arm.RIGHT ? 1f : -1f;
        Vec3d hand = cam.getPos().add(
                f.x * 0.55 + r.x * 0.30 * side - u.x * 0.28,
                f.y * 0.55 + r.y * 0.30 * side - u.y * 0.28,
                f.z * 0.55 + r.z * 0.30 * side - u.z * 0.28);
        float str = smokeStrength.getValue() == null ? 1f : smokeStrength.getValue();
        double dt = lastMs > 0 ? MathHelper.clamp((now - lastMs) / 1000.0, 0.001, 0.1) : 0.016;

        if (lastHand != null) {
            double dist = hand.distanceTo(lastHand);
            double speed = dist / dt;
            if (dist < 2.5 && speed > 0.35 * (2.0 - Math.min(str, 1.5)) && dist > 0.004) {
                int n = Math.min(LOW ? 3 : 5, 1 + (int) (dist / 0.02 * str));
                for (int i = 1; i <= n; i++) {
                    double k = i / (double) n;
                    put(lastHand.x + (hand.x - lastHand.x) * k, lastHand.y + (hand.y - lastHand.y) * k,
                            lastHand.z + (hand.z - lastHand.z) * k, now, f, str, 0.02f);
                }
            }
        }
        if (Boolean.TRUE.equals(autoSmoke.getValue())) {
            autoAcc += (float) dt * 16f * str;
            while (autoAcc >= 1f) {
                autoAcc -= 1f;
                put(hand.x, hand.y, hand.z, now, f, str, 0.03f);
            }
        } else {
            autoAcc = 0f;
        }
        lastHand = hand;
    }

    /** Новая частица: чуть шума, медленный дрейф вверх и от руки. */
    private void put(double x, double y, double z, long now, Vector3f fwd, float str, float jitter) {
        int s = smokeHead;
        smokeHead = (smokeHead + 1) % CAP;
        java.util.concurrent.ThreadLocalRandom rnd = java.util.concurrent.ThreadLocalRandom.current();
        sx[s] = x + (rnd.nextDouble() - 0.5) * jitter;
        sy[s] = y + (rnd.nextDouble() - 0.5) * jitter;
        sz[s] = z + (rnd.nextDouble() - 0.5) * jitter;
        vx[s] = (rnd.nextFloat() - 0.5f) * 0.06f + fwd.x * 0.05f;
        vy[s] = 0.04f + rnd.nextFloat() * 0.05f + fwd.y * 0.05f;
        vz[s] = (rnd.nextFloat() - 0.5f) * 0.06f + fwd.z * 0.05f;
        float tm = smokeTime.getValue() == null ? 2.5f : smokeTime.getValue();
        smokeLife[s] = tm * (0.75f + 0.25f * rnd.nextFloat()) * (0.7f + 0.3f * Math.min(str, 1.5f));
        smokeSize[s] = 0.9f + 0.45f * rnd.nextFloat();
        smokeBorn[s] = now;
    }

    private void draw(Camera cam, long now) {
        ensureSoft();
        Vec3d cpos = cam.getPos();
        Vector3f r = new Vector3f(1, 0, 0).rotate(cam.getRotation());
        Vector3f u = new Vector3f(0, 1, 0).rotate(cam.getRotation());
        boolean white = Boolean.TRUE.equals(whiteSmoke.getValue());
        int r0 = 255, g0 = 255, b0 = 255;
        if (!white) {
            Color c = getLiveColor();
            r0 = c.getRed(); g0 = c.getGreen(); b0 = c.getBlue();
        }
        float str = smokeStrength.getValue() == null ? 1f : smokeStrength.getValue();

        RenderState.push();
        try {
            RenderState.apply(white ? RenderState.Preset.ALPHA : RenderState.Preset.GLOW);
            RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
            RenderSystem.setShaderTexture(0, softTex != null ? softTex : Identifier.of("batvisuals", "hud/glow.png"));
            RenderSystem.disableCull();
            BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            boolean any = false;
            for (int i = 0; i < CAP; i++) {
                if (smokeLife[i] <= 0) continue;
                float age = (now - smokeBorn[i]) / 1000f;
                float a = age / smokeLife[i];
                if (a >= 1f || a < 0f) continue;
                any = true;
                float al = Math.min(a / 0.12f, 1f) * (float) Math.pow(1f - a, 1.4) * 0.7f * Math.min(str, 1.5f);
                float half = (0.05f + 0.16f * a) * smokeSize[i];
                int argb = ((int) (MathHelper.clamp(al, 0f, 1f) * 255) << 24) | (r0 << 16) | (g0 << 8) | b0;
                float x = (float) (sx[i] + vx[i] * age - cpos.x);
                float y = (float) (sy[i] + vy[i] * age - cpos.y);
                float z = (float) (sz[i] + vz[i] * age - cpos.z);
                float hx = r.x * half, hy = r.y * half, hz = r.z * half;
                float ux = u.x * half, uy = u.y * half, uz = u.z * half;
                buf.vertex(x - hx - ux, y - hy - uy, z - hz - uz).texture(0f, 1f).color(argb);
                buf.vertex(x - hx + ux, y - hy + uy, z - hz + uz).texture(0f, 0f).color(argb);
                buf.vertex(x + hx + ux, y + hy + uy, z + hz + uz).texture(1f, 0f).color(argb);
                buf.vertex(x + hx - ux, y + hy - uy, z + hz - uz).texture(1f, 1f).color(argb);
            }
            if (any) dev.batvisuals.client.util.render.SafeDraw.draw(buf);
        } catch (Throwable ignored) {
        } finally {
            RenderState.pop();
        }
    }

    private static int clamp255(float v) {
        return MathHelper.clamp((int) v, 0, 255);
    }

    @Override
    public void onThemeChanged(ThemeManager.Theme theme) {
        if (theme != null && theme.getAccentColor() != null) {
            this.currentColor = theme.getAccentColor();
        }
    }

    @Override
    public void onEnable() {
        themeManager.addThemeChangeListener(this);
        try { currentColor = themeManager.getThemeColor(); } catch (Throwable ignored) {}
        super.onEnable();
    }

    @Override
    public void onDisable() {
        themeManager.removeThemeChangeListener(this);
        Arrays.fill(smokeLife, 0f);
        lastHand = null;
        super.onDisable();
    }
}
