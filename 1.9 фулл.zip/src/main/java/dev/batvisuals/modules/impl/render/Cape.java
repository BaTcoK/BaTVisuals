package dev.batvisuals.modules.impl.render;

import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;

/**
 * Кастомный плащ BaTVisuals (текстура textures/newcape.png).
 */
public class Cape extends Module {

    public Cape() {
        super("Cape", Category.Render, "Кастомный плащ BaTVisuals");
    }
}
