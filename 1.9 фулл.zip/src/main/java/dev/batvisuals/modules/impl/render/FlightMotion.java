package dev.batvisuals.modules.impl.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.batvisuals.client.events.impl.EventRender3D;
import dev.batvisuals.client.events.impl.EventTick;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Elytra slipstream + wing trails.
 * Slipstream only when horizontal/3d speed >= threshold (blocks/sec), with smooth fade.
 */
public class FlightMotion extends Module {

    private final NumberSetting lifetime = new NumberSetting("Длительность", 18f, 5f, 50f, 1f);
    private final NumberSetting spacing = new NumberSetting("Ширина следа", 0.22f, 0.05f, 0.8f, 0.01f);
    private final NumberSetting streakCount = new NumberSetting("Линий ветра", 14f, 4f, 40f, 1f);
    private final NumberSetting streakLength = new NumberSetting("Длина ветра", 4.5f, 1.0f, 12f, 0.5f);
    private final NumberSetting lineWidth = new NumberSetting("Толщина", 2.2f, 0.5f, 8f, 0.5f);
    private final NumberSetting alphaMul = new NumberSetting("Прозрачность", 0.9f, 0.1f, 1f, 0.05f);
    /** Min speed in blocks/second to show slipstream (looking down while hovering won't spam). */
    private final NumberSetting minSpeed = new NumberSetting("Мин. скорость", 16f, 8f, 32f, 1f);
    private final NumberSetting fadeSpeed = new NumberSetting("Плавность", 0.12f, 0.03f, 0.4f, 0.01f);
    private final BooleanSetting wingTrail = new BooleanSetting("След крыльев", true);
    private final BooleanSetting slipstream = new BooleanSetting("Слипстрим", true);

    private final ArrayDeque<Seg> segs = new ArrayDeque<>();
    private Vec3d lastPos;
    private float slipAlpha; // 0..1 smoothed gate

    private static final class Seg {
        final Vec3d a, b;
        int age;
        final int life;
        final boolean isSlip;
        Seg(Vec3d a, Vec3d b, int life, boolean isSlip) {
            this.a = a; this.b = b; this.life = life; this.age = 0; this.isSlip = isSlip;
        }
        float alpha() { return 1f - age / (float) Math.max(1, life); }
    }

    public FlightMotion() {
        super("FlightMotion", Category.Render, "Дополнительные эффекты при полёте на элитрах");
    }

    @Override
    public void onDisable() {
        segs.clear();
        lastPos = null;
        slipAlpha = 0f;
        super.onDisable();
    }

    private Color accent() {
        try {
            Color c = ThemeManager.getInstance().getCurrentTheme().getAccentColor();
            if (c != null) return c;
        } catch (Throwable ignored) {}
        return new Color(230, 240, 255);
    }

    private boolean flying() {
        if (mc.player == null) return false;
        try { return mc.player.isGliding(); } catch (Throwable t) { return false; }
    }

    /** Blocks per second from velocity. */
    private double speedBps() {
        if (mc.player == null) return 0;
        Vec3d v = mc.player.getVelocity();
        return v.length() * 20.0; // ticks → seconds
    }

    @EventHandler
    public void onTick(EventTick e) {
        if (fullNullCheck() || !isToggled()) {
            segs.clear();
            lastPos = null;
            slipAlpha = 0f;
            return;
        }

        Iterator<Seg> it = segs.iterator();
        while (it.hasNext()) {
            Seg s = it.next();
            s.age++;
            if (s.age >= s.life) it.remove();
        }

        if (!flying()) {
            lastPos = null;
            slipAlpha += (0f - slipAlpha) * Math.min(1f, fadeSpeed.getValue() * 2f);
            return;
        }

        double spd = speedBps();
        float target = (spd >= minSpeed.getValue() && Boolean.TRUE.equals(slipstream.getValue())) ? 1f : 0f;
        float lerp = MathHelper.clamp(fadeSpeed.getValue(), 0.03f, 0.4f);
        slipAlpha += (target - slipAlpha) * lerp;
        if (slipAlpha < 0.01f) slipAlpha = 0f;
        if (slipAlpha > 0.99f) slipAlpha = 1f;

        Vec3d pos = mc.player.getLerpedPos(1f).add(0, mc.player.getHeight() * 0.45, 0);
        Vec3d vel = lastPos == null ? mc.player.getVelocity() : pos.subtract(lastPos);
        if (vel.lengthSquared() < 1e-6) vel = mc.player.getVelocity();
        Vec3d back = vel.lengthSquared() > 1e-8 ? vel.normalize().multiply(-1) : mc.player.getRotationVector().multiply(-1);
        Vec3d right = back.crossProduct(new Vec3d(0, 1, 0));
        if (right.lengthSquared() < 1e-8) right = new Vec3d(1, 0, 0);
        else right = right.normalize();
        Vec3d up = right.crossProduct(back).normalize();

        int life = Math.max(1, Math.round(lifetime.getValue()));
        ThreadLocalRandom rng = ThreadLocalRandom.current();

        if (Boolean.TRUE.equals(wingTrail.getValue()) && lastPos != null && pos.distanceTo(lastPos) > 0.05) {
            double half = spacing.getValue() * 0.5;
            segs.addLast(new Seg(lastPos.add(right.multiply(half)), pos.add(right.multiply(half)), life, false));
            segs.addLast(new Seg(lastPos.add(right.multiply(-half)), pos.add(right.multiply(-half)), life, false));
        }

        // Slipstream only when speed gate is partially open
        if (slipAlpha > 0.05f) {
            boolean firstPerson = mc.options.getPerspective() == Perspective.FIRST_PERSON;
            int count = Math.max(1, Math.round(streakCount.getValue() * (firstPerson ? 1.0f : 0.85f)));
            double len = streakLength.getValue();
            int spawn = Math.max(1, (int) (count / 4 * slipAlpha));
            for (int i = 0; i < spawn; i++) {
                double side = (rng.nextDouble() - 0.5) * (firstPerson ? 3.2 : 2.4);
                double vert = (rng.nextDouble() - 0.5) * (firstPerson ? 2.0 : 1.5);
                double along = rng.nextDouble() * 0.8;
                Vec3d origin;
                if (firstPerson) {
                    Vec3d cam = mc.gameRenderer.getCamera().getPos();
                    Vec3d look = mc.player.getRotationVector();
                    // further from the screen (2.5–5.5 blocks along look)
                    double dist = 2.5 + rng.nextDouble() * 3.0;
                    origin = cam
                            .add(look.multiply(dist))
                            .add(right.multiply(side * 1.3))
                            .add(up.multiply(vert));
                } else {
                    origin = pos
                            .add(right.multiply(side))
                            .add(up.multiply(vert))
                            .add(back.multiply(along));
                }
                double thisLen = len * (0.55 + rng.nextDouble() * 0.55);
                Vec3d end = origin.add(back.multiply(thisLen));
                int slipLife = Math.max(6, life / 2 + rng.nextInt(6));
                segs.addLast(new Seg(origin, end, slipLife, true));
            }
        }

        lastPos = pos;
        while (segs.size() > 500) segs.removeFirst();
    }

    @EventHandler
    public void onRender3D(EventRender3D.Game e) {
        if (fullNullCheck() || segs.isEmpty()) return;

        Color col = accent();
        float mul = alphaMul.getValue() != null ? alphaMul.getValue() : 0.9f;
        float width = lineWidth.getValue() != null ? lineWidth.getValue() : 2.2f;
        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        MatrixStack matrices = e.getMatrices();

        // Precompute vertices to avoid empty BufferBuilder
        class V { float x,y,z,r,g,b,a; V(float x,float y,float z,float r,float g,float b,float a){this.x=x;this.y=y;this.z=z;this.r=r;this.g=g;this.b=b;this.a=a;} }
        java.util.ArrayList<V> verts = new java.util.ArrayList<>();

        float cr = col.getRed() / 255f, cg = col.getGreen() / 255f, cb = col.getBlue() / 255f;
        if (cr + cg + cb < 1.2f) { cr = 0.92f; cg = 0.95f; cb = 1f; }

        for (Seg s : segs) {
            float a = MathHelper.clamp(s.alpha() * mul, 0f, 1f);
            if (s.isSlip) a *= slipAlpha; // smooth appear/disappear with speed
            if (a < 0.02f) continue;
            verts.add(new V((float) s.a.x, (float) s.a.y, (float) s.a.z, cr, cg, cb, a));
            verts.add(new V((float) s.b.x, (float) s.b.y, (float) s.b.z, cr, cg, cb, a * 0.3f));
        }
        if (verts.isEmpty()) return;

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        boolean fp = mc.options.getPerspective() == Perspective.FIRST_PERSON;
        if (fp) RenderSystem.disableDepthTest();
        else RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glLineWidth(Math.max(0.5f, width));

        matrices.push();
        matrices.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f m = matrices.peek().getPositionMatrix();
        BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        for (V v : verts) {
            buf.vertex(m, v.x, v.y, v.z).color(v.r, v.g, v.b, v.a);
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(buf);
        matrices.pop();

        GL11.glLineWidth(1f);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
    }
}
