package dev.batvisuals.modules.impl.utility;

import dev.batvisuals.batvisuals;
import dev.batvisuals.mixin.accessors.IWorldRenderer;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.impl.render.Zoom;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

/** Client-only visual optimizations; simulation and network behaviour stay untouched. */
public final class Optimization extends Module {
    public final BooleanSetting cullEntities = new BooleanSetting("Скрывать невидимые сущности", true);
    public final NumberSetting entityDistance = new NumberSetting("Дистанция сущностей", 96f, 16f, 256f, 8f,
            () -> cullEntities.getValue());
    public final BooleanSetting zoomQuality = new BooleanSetting("Качество в зуме", true);
    public final BooleanSetting disableBlur = new BooleanSetting("Отключить блюр", true);
    public final BooleanSetting disableParticles = new BooleanSetting("Отключить частицы", false);
    public final BooleanSetting disableWeather = new BooleanSetting("Отключить погоду", false);
    public final BooleanSetting disableClouds = new BooleanSetting("Отключить облака", false);

    public Optimization() {
        super("Optimization", Category.Utility, "Оптимизация рендера, больше FPS");
    }

    public boolean shouldCullEntity(Entity entity) {
        if (!isToggled() || !Boolean.TRUE.equals(cullEntities.getValue()) || entity == null) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (entity == mc.player || mc.worldRenderer == null) return false;
        Zoom zoom = batvisuals.getInstance().getModuleManager().getModule(Zoom.class);
        if (Boolean.TRUE.equals(zoomQuality.getValue()) && zoom != null && (zoom.isToggled() || zoom.isAnimating())) return false;
        float distance = entityDistance.getValue() == null ? 96f : entityDistance.getValue();
        if (!(entity instanceof PlayerEntity) && mc.getEntityRenderDispatcher().getSquaredDistanceToCamera(entity) > distance * distance) return true;
        try {
            var frustum = ((IWorldRenderer) mc.worldRenderer).getFrustum();
            return frustum != null && !frustum.isVisible(entity.getBoundingBox().expand(0.5));
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static Optimization get() {
        try { return batvisuals.getInstance().getModuleManager().getModule(Optimization.class); }
        catch (Throwable ignored) { return null; }
    }
}
