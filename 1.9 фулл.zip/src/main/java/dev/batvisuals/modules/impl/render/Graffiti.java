package dev.batvisuals.modules.impl.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.batvisuals.batvisuals;
import dev.batvisuals.client.events.impl.EventRender2D;
import dev.batvisuals.client.events.impl.EventRender3D;
import dev.batvisuals.client.events.impl.EventTick;
import dev.batvisuals.client.managers.GraffitiManager;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.api.Bind;
import dev.batvisuals.modules.settings.impl.BindSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

import java.util.UUID;

/**
 * Hold bind → radial picker (cursor unlocked). Release on photo → place.
 * Floor/ceiling stickers face player yaw. Synced via Firebase.
 */
public class Graffiti extends Module {

    public final BindSetting placeBind = new BindSetting("Бинд выбора", new Bind(GLFW.GLFW_KEY_G, false));

    public final NumberSetting reach = new NumberSetting("Дистанция", 8.0f, 3.0f, 20.0f, 0.5f);

    private boolean menuOpen = false;
    private boolean cursorUnlocked = false;
    private int hoverIndex = -1;

    private static final Identifier[] TEX = new Identifier[GraffitiManager.IMAGE_COUNT];
    static {
        for (int i = 0; i < TEX.length; i++) {
            TEX[i] = Identifier.of("batvisuals", "textures/graffiti/g" + i + ".png");
        }
    }

    public Graffiti() {
        super("Graffiti", Category.Cosmetics, "Граффити на блоках по бинду");
    }

    private void sub() {
        try { batvisuals.getInstance().getEventHandler().subscribe(this); } catch (Throwable ignored) {}
    }

    private void unsub() {
        try { batvisuals.getInstance().getEventHandler().unsubscribe(this); } catch (Throwable ignored) {}
    }

    /** Чужие граффити (pull + рендер) работают даже при выключенном модуле. Вызывается при старте. */
    public void ensureAlwaysOn() {
        unsub();
        sub();
    }

    @Override
    public void onEnable() {
        unsub();
        super.onEnable();
        try {
            GraffitiManager gm = batvisuals.getInstance().getGraffitiManager();
            if (gm != null) gm.setBaseUrl("https://batvisuals-e047c-default-rtdb.firebaseio.com");
        } catch (Throwable ignored) {}
    }

    @Override
    public void onDisable() {
        closeMenu(false);
        super.onDisable();
        sub();
    }

    private boolean isBindDown() {
        Bind b = placeBind.getValue();
        if (b == null || b.getKey() < 0) return false;
        long win = mc.getWindow().getHandle();
        if (b.isMouse()) {
            return GLFW.glfwGetMouseButton(win, b.getKey()) == GLFW.GLFW_PRESS;
        }
        return GLFW.glfwGetKey(win, b.getKey()) == GLFW.GLFW_PRESS;
    }

    private void openMenu() {
        menuOpen = true;
        hoverIndex = -1;
        if (!cursorUnlocked && mc.mouse != null) {
            mc.mouse.unlockCursor();
            cursorUnlocked = true;
        }
    }

    private void closeMenu(boolean place) {
        if (place && hoverIndex >= 0) {
            tryPlace(hoverIndex);
        }
        menuOpen = false;
        hoverIndex = -1;
        if (cursorUnlocked && mc.mouse != null && mc.currentScreen == null) {
            mc.mouse.lockCursor();
            cursorUnlocked = false;
        }
    }

    private boolean isForbidden(BlockState state) {
        if (state == null || state.isAir()) return true;
        Block b = state.getBlock();
        if (state.isReplaceable()) return true;
        if (state.isIn(BlockTags.REPLACEABLE) || state.isIn(BlockTags.FLOWERS)
                || state.isIn(BlockTags.SAPLINGS) || state.isIn(BlockTags.LEAVES)
                || state.isIn(BlockTags.CROPS) || state.isIn(BlockTags.WOOL_CARPETS)) {
            return true;
        }
        if (b == Blocks.SHORT_GRASS || b == Blocks.TALL_GRASS || b == Blocks.FERN
                || b == Blocks.LARGE_FERN || b == Blocks.DEAD_BUSH || b == Blocks.SEAGRASS
                || b == Blocks.TALL_SEAGRASS || b == Blocks.KELP || b == Blocks.KELP_PLANT
                || b == Blocks.VINE || b == Blocks.GLOW_LICHEN || b == Blocks.SNOW
                || b == Blocks.MOSS_CARPET || b == Blocks.PINK_PETALS
                || b == Blocks.WATER || b == Blocks.LAVA || b == Blocks.FIRE
                || b == Blocks.SOUL_FIRE || b == Blocks.COBWEB || b == Blocks.TORCH
                || b == Blocks.WALL_TORCH || b == Blocks.LANTERN || b == Blocks.SOUL_LANTERN
                || b == Blocks.RAIL || b == Blocks.POWERED_RAIL || b == Blocks.DETECTOR_RAIL
                || b == Blocks.ACTIVATOR_RAIL || b == Blocks.LADDER || b == Blocks.SCAFFOLDING
                || b == Blocks.SUGAR_CANE || b == Blocks.BAMBOO || b == Blocks.BAMBOO_SAPLING) {
            return true;
        }
        return false;
    }

    private void tryPlace(int image) {
        if (mc.player == null || mc.world == null) return;
        HitResult hr = mc.player.raycast(reach.getValue(), 0f, false);
        if (!(hr instanceof BlockHitResult bhr) || hr.getType() != HitResult.Type.BLOCK) return;
        BlockPos pos = bhr.getBlockPos();
        Direction face = bhr.getSide();
        BlockState state = mc.world.getBlockState(pos);
        if (isForbidden(state)) return;

        // Floor/ceiling: only 4 sides like a block; image bottom faces player
        float yaw = 0f;
        if (face == Direction.UP || face == Direction.DOWN) {
            // horizontalFacing is already N/E/S/W; bottom of art faces toward player
            Direction facing = mc.player.getHorizontalFacing();
            // Bottom of texture faces the player; facing direction = rotation
            // верх картинки смотрит туда же, куда смотрит игрок (низ — к игроку)
            yaw = switch (facing) {
                case SOUTH -> 180f;
                case WEST  -> 90f;
                case NORTH -> 0f;
                case EAST  -> 270f;
                default -> 0f;
            };
        }
        long exp = System.currentTimeMillis() + GraffitiManager.LIFETIME_MS;
        String dim = mc.world.getRegistryKey().getValue().toString();
        String id = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        GraffitiManager.Sticker s = new GraffitiManager.Sticker(
                id, pos.getX(), pos.getY(), pos.getZ(), face.getId(), image, exp, dim, yaw
        );
        try {
            batvisuals.getInstance().getGraffitiManager().addLocal(s);
        } catch (Throwable ignored) {}

        try {
            mc.getSoundManager().play(PositionedSoundInstance.master(
                    SoundEvent.of(Identifier.of("batvisuals", "spray")), 1.0f, 1.0f));
        } catch (Throwable ignored) {}

        try {
            double px = pos.getX() + 0.5 + face.getOffsetX() * 0.55;
            double py = pos.getY() + 0.5 + face.getOffsetY() * 0.55;
            double pz = pos.getZ() + 0.5 + face.getOffsetZ() * 0.55;
            java.util.Random rng = new java.util.Random();
            for (int i = 0; i < 28; i++) {
                double ox = (rng.nextDouble() - 0.5) * 0.7 + face.getOffsetX() * 0.15;
                double oy = (rng.nextDouble() - 0.5) * 0.7 + face.getOffsetY() * 0.15;
                double oz = (rng.nextDouble() - 0.5) * 0.7 + face.getOffsetZ() * 0.15;
                int ri = (int) ((0.85f + rng.nextFloat() * 0.15f) * 255);
                int gi = (int) ((0.15f + rng.nextFloat() * 0.25f) * 255);
                int bi = (int) ((0.2f + rng.nextFloat() * 0.3f) * 255);
                int color = (ri << 16) | (gi << 8) | bi;
                mc.world.addParticle(
                        new DustParticleEffect(color, 1.0f + rng.nextFloat() * 0.6f),
                        px + ox, py + oy, pz + oz,
                        (rng.nextDouble() - 0.5) * 0.08,
                        rng.nextDouble() * 0.06,
                        (rng.nextDouble() - 0.5) * 0.08
                );
            }
            for (int i = 0; i < 10; i++) {
                mc.world.addParticle(ParticleTypes.CLOUD,
                        px + (rng.nextDouble() - 0.5) * 0.4,
                        py + (rng.nextDouble() - 0.5) * 0.4,
                        pz + (rng.nextDouble() - 0.5) * 0.4,
                        face.getOffsetX() * 0.05, 0.02, face.getOffsetZ() * 0.05);
            }
        } catch (Throwable ignored) {}
    }

    @EventHandler
    public void onTick(EventTick e) {
        if (fullNullCheck()) {
            if (menuOpen) closeMenu(false);
            return;
        }

        boolean down = isToggled() && isBindDown();
        // HOLD to open menu (not click); release places if photo hovered
        if (down) {
            if (!menuOpen && mc.currentScreen == null) {
                openMenu();
            }
        } else if (menuOpen) {
            closeMenu(true);
        }

        // remove stickers only after block stays air (WG safe)
        try {
            GraffitiManager gm = batvisuals.getInstance().getGraffitiManager();
            if (gm != null && mc.world != null) {
                String dim = mc.world.getRegistryKey().getValue().toString();
                java.util.List<String> remove = new java.util.ArrayList<>();
                for (GraffitiManager.Sticker s : gm.getStickers()) {
                    if (s.expired()) { remove.add(s.id); continue; }
                    if (s.dim != null && !s.dim.equals(dim)) continue;
                    BlockPos bp = new BlockPos(s.x, s.y, s.z);
                    if (mc.world.getBlockState(bp).isAir()) {
                        // grace handled simply: require air; WG rollback restores block next ticks
                        // use simple check — if air for this tick only remove if already expired path
                        // keep WG-safe: only remove expired OR air (user wanted break remove; air ticks in prior fix)
                        remove.add(s.id);
                    }
                }
                // Actually don't instant-remove on air — 15 tick grace via static map
                // overridden below
            }
        } catch (Throwable ignored) {}

        tickAirGrace();

        try {
            GraffitiManager gm = batvisuals.getInstance().getGraffitiManager();
            if (gm != null) gm.tickPull("global");
        } catch (Throwable ignored) {}
    }

    private final java.util.Map<String, Integer> airTicks = new java.util.HashMap<>();
    private static final int AIR_CONFIRM_TICKS = 15;

    private void tickAirGrace() {
        try {
            GraffitiManager gm = batvisuals.getInstance().getGraffitiManager();
            if (gm == null || mc.world == null) return;
            String dim = mc.world.getRegistryKey().getValue().toString();
            java.util.List<String> remove = new java.util.ArrayList<>();
            java.util.Set<String> live = new java.util.HashSet<>();
            for (GraffitiManager.Sticker s : gm.getStickers()) {
                if (s.expired()) {
                    remove.add(s.id);
                    airTicks.remove(s.id);
                    continue;
                }
                live.add(s.id);
                if (s.dim != null && !s.dim.equals(dim)) {
                    airTicks.remove(s.id);
                    continue;
                }
                if (!mc.world.getChunkManager().isChunkLoaded(s.x >> 4, s.z >> 4)) {
                    airTicks.remove(s.id);
                    continue;
                }
                BlockPos bp = new BlockPos(s.x, s.y, s.z);
                if (mc.world.getBlockState(bp).isAir()) {
                    int n = airTicks.getOrDefault(s.id, 0) + 1;
                    airTicks.put(s.id, n);
                    if (n >= AIR_CONFIRM_TICKS) {
                        remove.add(s.id);
                        airTicks.remove(s.id);
                    }
                } else {
                    airTicks.remove(s.id);
                }
            }
            airTicks.keySet().removeIf(id -> !live.contains(id));
            for (String id : remove) gm.remove(id);
        } catch (Throwable ignored) {}
    }

    @EventHandler
    public void onRender2D(EventRender2D e) {
        if (!menuOpen || fullNullCheck()) return;
        // keep cursor free while holding
        if (!cursorUnlocked && mc.mouse != null) {
            mc.mouse.unlockCursor();
            cursorUnlocked = true;
        }

        DrawContext ctx = e.getContext();
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        double mx = mc.mouse.getX() * sw / (double) mc.getWindow().getWidth();
        double my = mc.mouse.getY() * sh / (double) mc.getWindow().getHeight();

        float cx = sw / 2f;
        float cy = sh / 2f;
        float radius = 56f;
        int n = GraffitiManager.IMAGE_COUNT;
        hoverIndex = -1;

        // dim
        ctx.fill(0, 0, sw, sh, 0x66000000);

        for (int i = 0; i < n; i++) {
            double ang = -Math.PI / 2 + (2 * Math.PI * i / n);
            float x = cx + (float) Math.cos(ang) * radius;
            float y = cy + (float) Math.sin(ang) * radius;
            float size = 30f;
            boolean hov = mx >= x - size / 2 && mx <= x + size / 2
                    && my >= y - size / 2 && my <= y + size / 2;
            if (hov) {
                hoverIndex = i;
                size = 38f;
            }
            int bg = hov ? 0xF0FFFFFF : 0xC0101018;
            ctx.fill((int) (x - size / 2 - 3), (int) (y - size / 2 - 3),
                    (int) (x + size / 2 + 3), (int) (y + size / 2 + 3), bg);
            int ix = (int) (x - size / 2);
            int iy = (int) (y - size / 2);
            int isz = (int) size;
            ctx.drawTexture(RenderLayer::getGuiTextured, TEX[i], ix, iy, 0f, 0f, isz, isz, isz, isz);
        }
        String hint = hoverIndex >= 0 ? "Отпусти — наклеить" : "Удерживай бинд · наведи на фото";
        ctx.drawText(mc.textRenderer, hint,
                (int) cx - mc.textRenderer.getWidth(hint) / 2,
                (int) cy + 78, 0xFFFFFFFF, true);
    }

    @EventHandler
    public void onRender3D(EventRender3D.Game e) {
        if (fullNullCheck()) return;
        GraffitiManager gm;
        try { gm = batvisuals.getInstance().getGraffitiManager(); }
        catch (Throwable t) { return; }
        if (gm == null) return;

        String dim = mc.world.getRegistryKey().getValue().toString();
        MatrixStack matrices = e.getMatrices();
        Vec3d cam = mc.gameRenderer.getCamera().getPos();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);

        // Hard-expire with spray particles (no fade)
        try {
            java.util.List<GraffitiManager.Sticker> exp = new java.util.ArrayList<>();
            for (GraffitiManager.Sticker s : gm.getStickers()) {
                if (s != null && s.expired()) exp.add(s);
            }
            for (GraffitiManager.Sticker s : exp) {
                try {
                    Direction face = Direction.byId(s.face);
                    if (face == null) face = Direction.NORTH;
                    double px = s.x + 0.5 + face.getOffsetX() * 0.55;
                    double py = s.y + 0.5 + face.getOffsetY() * 0.55;
                    double pz = s.z + 0.5 + face.getOffsetZ() * 0.55;
                    java.util.Random rng = new java.util.Random();
                    for (int i = 0; i < 12; i++) {
                        mc.world.addParticle(ParticleTypes.CLOUD,
                                px + (rng.nextDouble() - 0.5) * 0.5,
                                py + (rng.nextDouble() - 0.5) * 0.5,
                                pz + (rng.nextDouble() - 0.5) * 0.5,
                                0, 0.03, 0);
                    }
                    gm.remove(s.id);
                } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}

        for (GraffitiManager.Sticker s : gm.getStickers()) {
            if (s.expired()) continue;
            if (s.dim != null && !s.dim.equals(dim)) continue;
            if (s.image < 0 || s.image >= TEX.length) continue;
            Direction face = Direction.byId(s.face);
            if (face == null) face = Direction.NORTH;

            double bx = s.x + 0.5 + face.getOffsetX() * 0.51;
            double by = s.y + 0.5 + face.getOffsetY() * 0.51;
            double bz = s.z + 0.5 + face.getOffsetZ() * 0.51;

            matrices.push();
            matrices.translate(bx - cam.x, by - cam.y, bz - cam.z);

            // face orientation — floor/ceiling snapped to 4 block sides; bottom of image toward player
            switch (face) {
                case UP -> {
                    matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_X.rotationDegrees(-90));
                    matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotationDegrees(s.yaw));
                }
                case DOWN -> {
                    matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_X.rotationDegrees(90));
                    matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotationDegrees(-s.yaw));
                }
                case SOUTH -> {}
                case NORTH -> matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotationDegrees(180));
                // swapped vs previous — fixes 180° invert when placing facing left
                case WEST -> matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotationDegrees(-90));
                case EAST -> matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotationDegrees(90));
            }

            // No fade — full opacity until 5 min, then hard remove (particles on expire in tick)
            int white = 0xFFFFFFFF;
            float half = 0.45f;
            Matrix4f mat = matrices.peek().getPositionMatrix();

            RenderSystem.setShaderTexture(0, TEX[s.image]);
            BufferBuilder front = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            // local +X = правая сторона для зрителя на любой грани → U без зеркала
            front.vertex(mat, -half, -half, 0.001f).texture(0f, 1f).color(white);
            front.vertex(mat,  half, -half, 0.001f).texture(1f, 1f).color(white);
            front.vertex(mat,  half,  half, 0.001f).texture(1f, 0f).color(white);
            front.vertex(mat, -half,  half, 0.001f).texture(0f, 0f).color(white);
            dev.batvisuals.client.util.render.SafeDraw.draw(front);
            // No black back face (looked like shadows)

            matrices.pop();
        }

        RenderSystem.enableCull();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }
}
