package dev.batvisuals.modules.impl.render;

import dev.batvisuals.client.events.impl.EventRender2D;
import dev.batvisuals.client.managers.CrosshairPresetManager;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.client.ui.CrosshairEditorScreen;
import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import meteordevelopment.orbit.EventHandler;

import java.awt.Color;

/**
 * Прицел: размер, стык пикселей, квадрат/скругление. Один редактор без имён.
 */
public class Crosshair extends Module implements ThemeManager.ThemeChangeListener {

    private static Crosshair instance;

    private final NumberSetting size = new NumberSetting("Размер", 1.0f, 0.5f, 2.0f, 0.05f);
    /** Без зазоров между пикселями */
    private final BooleanSetting solid = new BooleanSetting("Соединить пиксели", true);
    /** Квадратные пиксели вместо скруглённых */
    private final BooleanSetting square = new BooleanSetting("Квадратные", true);
    private final BooleanSetting openEditor = new BooleanSetting("Редактор прицела", false);

    private final ThemeManager themeManager;
    private Color accent = new Color(80, 170, 255);
    private boolean latch;

    public Crosshair() {
        super("Crosshair", Category.Render, "Свой прицел");
        instance = this;
        themeManager = ThemeManager.getInstance();
        try { accent = themeManager.getThemeColor(); } catch (Throwable ignored) {}
        themeManager.addThemeChangeListener(this);
    }

    public static Crosshair getInstance() { return instance; }
    public boolean isSolid() { return solid.getValue(); }
    public boolean isSquare() { return square.getValue(); }
    public float getSizeVal() { return size.getValue() != null ? size.getValue() : 1f; }

    @Override
    public void onEnable() {
        super.onEnable();
        try { CrosshairPresetManager.init(CrosshairPresetManager.defaultDir()); } catch (Throwable ignored) {}
    }

    @EventHandler
    public void onRender2D(EventRender2D e) {
        if (mc.player == null || mc.world == null) return;
        if (!mc.options.getPerspective().isFirstPerson()) return;

        if (openEditor.getValue() && !latch) {
            latch = true;
            openEditor.setValue(false);
            try { mc.setScreen(new CrosshairEditorScreen()); } catch (Throwable ignored) {}
        }
        if (!openEditor.getValue()) latch = false;

        if (CrosshairPresetManager.isVanilla()) return;

        CrosshairPresetManager.Preset preset = CrosshairPresetManager.getSelectedPreset();
        if (preset == null || preset.pixels == null) return;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        float cx = sw / 2f, cy = sh / 2f;
        float scale = getSizeVal();
        float gap = solid.getValue() ? 0f : 0.4f * scale;
        float cell = 2.4f * scale;
        float total = CrosshairPresetManager.SIZE * cell + (CrosshairPresetManager.SIZE - 1) * gap;
        float ox = cx - total / 2f, oy = cy - total / 2f;
        var matrices = e.getContext().getMatrices();
        float rad = square.getValue() ? 0f : Math.max(0.5f, cell * 0.25f);

        for (int row = 0; row < CrosshairPresetManager.SIZE; row++) {
            for (int col = 0; col < CrosshairPresetManager.SIZE; col++) {
                int argb = preset.pixels[row * CrosshairPresetManager.SIZE + col];
                if (argb == 0) continue;
                int a = (argb >> 24) & 0xFF;
                if (a == 0) continue;
                Color c = new Color((argb >> 16) & 0xFF, (argb >> 8) & 0xFF, argb & 0xFF, a);
                float x = ox + col * (cell + gap);
                float y = oy + row * (cell + gap);
                if (rad <= 0.01f) Render2D.drawRect(matrices, x, y, cell, cell, c);
                else Render2D.drawRoundedRect(matrices, x, y, cell, cell, rad, c);
            }
        }
    }

    @Override
    public void onThemeChanged(ThemeManager.Theme theme) {
        try { accent = themeManager.getThemeColor(); } catch (Throwable t) { accent = new Color(80, 170, 255); }
    }

    @Override
    public void onDisable() {
        themeManager.removeThemeChangeListener(this);
        super.onDisable();
    }
}
