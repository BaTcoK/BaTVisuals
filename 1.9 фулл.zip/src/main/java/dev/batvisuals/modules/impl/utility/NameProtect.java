package dev.batvisuals.modules.impl.utility;

import dev.batvisuals.client.managers.FriendsManager;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.StringSetting;
import lombok.Getter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.PlainTextContent;
import net.minecraft.text.Text;
import net.minecraft.text.TextContent;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Скрывает свой ник и ники друзей: чат, tab, scoreboard, nametag, HUD.
 * protectText сохраняет стили/цвета сегментов.
 */
public class NameProtect extends Module {

    @Getter
    private static NameProtect instance;

    @Getter
    private final StringSetting customName = new StringSetting("Замена ника", "Protected", false);

    @Getter
    private final BooleanSetting protectFriends = new BooleanSetting("Скрывать ники друзей", true);

    @Getter
    private final StringSetting friendName = new StringSetting("Замена друга", "Friend",
            () -> protectFriends.getValue(), false);

    public NameProtect() {
        super("NameProtect", Category.Utility,
                "Скрывает ники (свой и друзей)");
        instance = this;
        getSettings().add(customName);
        getSettings().add(protectFriends);
        getSettings().add(friendName);
    }

    public List<String> selfNames() {
        List<String> names = new ArrayList<>(2);
        MinecraftClient mc = MinecraftClient.getInstance();
        try {
            if (mc.getSession() != null) {
                String s = mc.getSession().getUsername();
                if (s != null && !s.isBlank()) names.add(s);
            }
        } catch (Throwable ignored) {}
        try {
            if (mc.player != null) {
                String p = mc.player.getGameProfile().getName();
                if (p != null && !p.isBlank() && names.stream().noneMatch(n -> n.equalsIgnoreCase(p))) {
                    names.add(p);
                }
            }
        } catch (Throwable ignored) {}
        return names;
    }

    public String getProtectedName(String name) {
        if (!isToggled() || name == null || name.isEmpty()) return name;
        for (String self : selfNames()) {
            if (name.equalsIgnoreCase(self)) return safeCustom();
        }
        if (protectFriends.getValue() && FriendsManager.checkFriend(name)) {
            return safeFriend();
        }
        return name;
    }

    public String replaceNames(String text) {
        if (!isToggled() || text == null || text.isEmpty()) return text;
        String modified = text;
        for (String self : selfNames()) {
            modified = replaceExactName(modified, self, safeCustom());
        }
        if (protectFriends.getValue()) {
            String rep = safeFriend();
            for (String friend : FriendsManager.getFriends()) {
                if (friend == null || friend.isBlank()) continue;
                modified = replaceExactName(modified, friend, rep);
            }
        }
        return modified;
    }

    /**
     * Подмена ников с сохранением Style (цвет, bold и т.д.) у каждого сегмента.
     */
    public Text protectText(Text text) {
        if (!isToggled() || text == null) return text;
        try {
            String before = text.getString();
            if (before == null || before.isEmpty()) return text;
            String after = replaceNames(before);
            if (before.equals(after)) return text;
            return rewritePreservingStyle(text);
        } catch (Throwable t) {
            String after = replaceNames(text.getString());
            return Text.literal(after);
        }
    }

    private Text rewritePreservingStyle(Text text) {
        TextContent content = text.getContent();
        MutableText node;
        if (content instanceof PlainTextContent.Literal lit) {
            node = Text.literal(replaceNames(lit.string())).setStyle(text.getStyle());
        } else {
            // Non-literal (translatable etc.): if no siblings, replace whole string with same style
            if (text.getSiblings().isEmpty()) {
                node = Text.literal(replaceNames(text.getString())).setStyle(text.getStyle());
            } else {
                node = Text.empty().setStyle(text.getStyle());
            }
        }
        MutableText result = node;
        for (Text sibling : text.getSiblings()) {
            result.append(rewritePreservingStyle(sibling));
        }
        return result;
    }

    private String safeCustom() {
        String v = customName.getValue();
        return (v == null || v.isBlank()) ? "Protected" : v;
    }

    private String safeFriend() {
        String v = friendName.getValue();
        return (v == null || v.isBlank()) ? "Friend" : v;
    }

        private String replaceExactName(String text, String name, String replacement) {
        if (text == null || name == null || name.isEmpty()) return text;
        try {
            Pattern p = Pattern.compile(
                    "(?<![\\p{L}\\p{N}_])" + Pattern.quote(name) + "(?![\\p{L}\\p{N}_])",
                    Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE
            );
            return p.matcher(text).replaceAll(java.util.regex.Matcher.quoteReplacement(replacement));
        } catch (Throwable ignored) {
            try {
                return text.replaceAll("(?i)" + Pattern.quote(name), java.util.regex.Matcher.quoteReplacement(replacement));
            } catch (Throwable ignored2) {
                return text;
            }
        }
    }
}
