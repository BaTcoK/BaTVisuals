package dev.batvisuals.modules.impl.utility;

import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Substitutes FPS shown in F3 / watermark with a realistic fake value.
 */
public class FakeFPS extends Module {

    private static FakeFPS INSTANCE;

    private final @NotNull NumberSetting targetFps = new NumberSetting(
            "Target FPS",
            120f,
            15f,
            1000f,
            1f
    );

    private final @NotNull BooleanSetting freezes = new BooleanSetting(
            "Freezes",
            false
    );

    // simulation state
    private static float smoothed = 120f;
    private static float wander = 0f;
    private static long nextFreezeAt = 0L;
    private static long freezeUntil = 0L;
    private static int freezeBase = 60;
    private static long lastUpdateMs = 0L;

    public FakeFPS() {
        super("FakeFPS", Category.Utility, "Фейковый FPS в F3 и watermark");
        INSTANCE = this;
        getSettings().add(targetFps);
        getSettings().add(freezes);
    }

    public static FakeFPS getInstance() {
        return INSTANCE;
    }

    public static boolean isActive() {
        return INSTANCE != null && INSTANCE.isToggled();
    }

    /** Value used by F3 / watermark when module is on. */
    public static int getDisplayFps(int realFps) {
        if (!isActive()) return realFps;

        long now = System.currentTimeMillis();
        if (lastUpdateMs == 0L) lastUpdateMs = now;
        float dt = Math.min(0.1f, (now - lastUpdateMs) / 1000f);
        lastUpdateMs = now;

        float target = INSTANCE.targetFps.getValue();
        if (target < 15f) target = 15f;
        if (target > 1000f) target = 1000f;

        ThreadLocalRandom rng = ThreadLocalRandom.current();

        // --- freezes: ~once per minute dip to low FPS ---
        if (INSTANCE.freezes.getValue()) {
            if (freezeUntil > now) {
                // during freeze: bounce around freezeBase
                float jitter = (float) (Math.sin(now / 40.0) * 8.0 + rng.nextDouble(-6, 6));
                float v = freezeBase + jitter;
                smoothed = Math.max(1f, v);
                return Math.round(smoothed);
            }
            if (nextFreezeAt == 0L) {
                nextFreezeAt = now + rng.nextLong(45_000, 75_000);
            }
            if (now >= nextFreezeAt) {
                // start freeze: 30–120 FPS for 0.4–1.8s
                freezeBase = rng.nextInt(25, 121);
                // sometimes harder stutter (very low)
                if (rng.nextFloat() < 0.25f) freezeBase = rng.nextInt(15, 45);
                freezeUntil = now + rng.nextLong(400, 1800);
                nextFreezeAt = freezeUntil + rng.nextLong(50_000, 80_000);
                smoothed = freezeBase;
                return Math.round(smoothed);
            }
        } else {
            nextFreezeAt = 0L;
            freezeUntil = 0L;
        }

        // --- normal: stay near target with realistic variance ---
        // slow wander ±~2%
        wander += (float) (rng.nextGaussian() * 0.4f * dt * 60f);
        wander *= (float) Math.exp(-dt * 1.2); // mean-reverting
        if (wander > target * 0.03f) wander = target * 0.03f;
        if (wander < -target * 0.03f) wander = -target * 0.03f;

        // medium sine wave ±~1.5%
        float wave = (float) (Math.sin(now / 700.0) * target * 0.012
                + Math.sin(now / 1700.0) * target * 0.008);

        // tiny frame-to-frame noise
        float micro = (float) (rng.nextGaussian() * Math.max(1.0, target * 0.004));

        float desired = target + wander + wave + micro;
        if (desired < 0f) desired = 0f;

        // smooth toward desired (not instant)
        float lerp = 1f - (float) Math.exp(-dt * 14.0);
        smoothed = smoothed + (desired - smoothed) * lerp;

        // hard clamp to ~±4% of target for stability look
        float min = target * 0.96f;
        float max = target * 1.04f;
        if (target >= 30f) {
            if (smoothed < min) smoothed = min;
            if (smoothed > max) smoothed = max;
        }

        return Math.max(0, Math.round(smoothed));
    }
}
