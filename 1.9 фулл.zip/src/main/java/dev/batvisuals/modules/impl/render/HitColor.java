package dev.batvisuals.modules.impl.render;

import dev.batvisuals.client.events.impl.EventAttackEntity;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import meteordevelopment.orbit.EventHandler;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

/**
 * On hit: fill the entity model (skin) with the current theme accent colour
 * + outline of the hit player (vanilla entity-outline pipeline, so armor is outlined too).
 * No outline on players with Invisibility.
 */
public class HitColor extends Module implements ThemeManager.ThemeChangeListener {

    public final BooleanSetting fill = new BooleanSetting("Заливка", true);
    public final NumberSetting fillAlpha = new NumberSetting("Прозрачность заливки", 0.55f, 0.05f, 1.0f, 0.05f,
            () -> fill.getValue());

    public final BooleanSetting outline = new BooleanSetting("Обводка", true);
    public final NumberSetting outlineTime = new NumberSetting("Время обводки", 0.6f, 0.2f, 2.0f, 0.1f,
            () -> outline.getValue());

    private final ThemeManager themeManager;
    /** entityId -> время (ms), до которого держим обводку. Только render-thread. */
    private final Map<Integer, Long> hits = new HashMap<>();

    public HitColor() {
        super("HitColor", Category.Render, "Подсветка при ударе");
        this.themeManager = ThemeManager.getInstance();
        themeManager.addThemeChangeListener(this);
    }

    public Color getLiveColor() {
        try {
            Color c = themeManager.getCurrentTheme().getAccentColor();
            if (c != null) return c;
        } catch (Throwable ignored) {}
        return new Color(120, 90, 255);
    }

    public boolean shouldTintModel() {
        return isToggled() && Boolean.TRUE.equals(fill.getValue());
    }

    @EventHandler
    public void onAttack(EventAttackEntity event) {
        if (!isToggled() || !Boolean.TRUE.equals(outline.getValue())) return;
        Entity target = event.getTarget();
        if (!(target instanceof PlayerEntity p) || p.isInvisible() || p.hasStatusEffect(StatusEffects.INVISIBILITY)) return;
        long now = System.currentTimeMillis();
        float seconds = outlineTime.getValue() == null ? 0.6f : MathHelper.clamp(outlineTime.getValue(), 0.2f, 2f);
        hits.put(p.getId(), now + (long) (seconds * 1000f));
    }

    /**
     * Обводить ли игрока прямо сейчас. Не обводим: невидимых (зелье/флаг), тех кого не видно (нет прямой видимости —
     * ванильный outline иначе светился бы сквозь стены). Броня в обводку входит, т.к. идёт через тот же провайдер.
     */
    public boolean shouldOutline(Entity e) {
        if (!isToggled() || !Boolean.TRUE.equals(outline.getValue())) return false;
        if (!(e instanceof PlayerEntity p)) return false;
        if (mc.player == null || mc.world == null) return false;
        if (p.isInvisible() || p.hasStatusEffect(StatusEffects.INVISIBILITY)) {
            hits.remove(p.getId());
            return false;
        }
        long now = System.currentTimeMillis();
        Long until = hits.get(p.getId());
        if (until == null) return false;
        if (now > until) {
            hits.remove(p.getId());
            return false;
        }
        if (hits.size() > 64) hits.entrySet().removeIf(en -> en.getValue() < now);
        return p == mc.player || mc.player.canSee(p);
    }

    /** RGB (24 бита) для getTeamColorValue. */
    public int getOutlineRgb() {
        return getLiveColor().getRGB() & 0xFFFFFF;
    }

    public float getFillAlpha() {
        Float v = fillAlpha.getValue();
        return v == null ? 0.55f : MathHelper.clamp(v, 0.05f, 1f);
    }

    @Override
    public void onThemeChanged(ThemeManager.Theme theme) {}

    @Override
    public void onDisable() {
        hits.clear();
        themeManager.removeThemeChangeListener(this);
        super.onDisable();
    }
}
