package dev.batvisuals.modules.impl.render;

import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import lombok.Getter;
import net.minecraft.client.resource.language.I18n;

public class Zoom extends Module {
	@Getter private final NumberSetting zoomStrength = new NumberSetting(
			"setting.zoomStrength", 3.0f, 1.0f, 15.0f, 0.1f);

	@Getter private final BooleanSetting smoothZoom = new BooleanSetting(
			"setting.smoothZoom", true);

	@Getter private final NumberSetting smoothSpeed = new NumberSetting(
			"setting.smoothSpeed", 10.0f, 1.0f, 15.0f, 1.0f,
			() -> smoothZoom.getValue());

	private float currentFov = -1.0f;
	private float originalFov = -1.0f;
	private boolean animating;

	public Zoom() {
		super("Zoom", Category.Render, I18n.translate("module.zoom.description"));
	}

	/** True while FOV is still lerping (including after disable). */
	public boolean isAnimating() {
		return animating && currentFov >= 0.0f && originalFov >= 0.0f;
	}

	@Override
	public void onEnable() {
		super.onEnable();
		currentFov = -1.0f;
		originalFov = -1.0f;
		animating = true;
	}

	@Override
	public void onDisable() {
		super.onDisable();
		// keep animating until FOV returns
		animating = true;
	}

	public float applyZoom(float baseFov, float tickDelta) {
		if (originalFov < 0.0f) originalFov = baseFov;

		boolean active = isToggled();
		float strength = Math.max(1.0f, zoomStrength.getValue());
		float targetFov = active ? (originalFov / strength) : originalFov;

		if (!smoothZoom.getValue()) {
			currentFov = targetFov;
			if (!active) {
				currentFov = -1.0f;
				originalFov = -1.0f;
				animating = false;
				return baseFov;
			}
			animating = true;
			return currentFov;
		}

		if (currentFov < 0.0f) currentFov = baseFov;

		// Frame-stable lerp (works both zoom-in and zoom-out)
		float speed = Math.max(1.0f, smoothSpeed.getValue());
		float t = 1.0f - (float) Math.exp(-speed * 0.12f);
		if (t > 1.0f) t = 1.0f;
		currentFov += (targetFov - currentFov) * t;

		float epsilon = 0.05f;
		if (Math.abs(targetFov - currentFov) <= epsilon) {
			currentFov = targetFov;
		}

		if (!active && Math.abs(currentFov - originalFov) <= epsilon) {
			currentFov = -1.0f;
			originalFov = -1.0f;
			animating = false;
			return baseFov;
		}

		animating = true;
		return currentFov;
	}
}
