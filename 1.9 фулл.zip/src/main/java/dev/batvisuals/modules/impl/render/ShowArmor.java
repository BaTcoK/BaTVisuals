package dev.batvisuals.modules.impl.render;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.util.notify.Notify;
import dev.batvisuals.client.util.notify.NotifyIcons;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

import java.util.EnumMap;
import java.util.Map;

/**
 * ShowArmor — красит броню на модели по прочности + предупреждения.
 */
public class ShowArmor extends Module {

    public static volatile boolean ENABLED = false;
    public static volatile boolean TINT_SELF = false;

    /** Stack currently being rendered by EquipmentRenderer. */
    public static final ThreadLocal<ItemStack> CURRENT_STACK = new ThreadLocal<>();

    private final BooleanSetting tintSelf = new BooleanSetting("Красить себя", false);
    private final BooleanSetting warnLow = new BooleanSetting("Предупреждать о низкой прочности", true);

    private enum WarnTier { NONE, LOW15, LOW5, BROKEN }

    private final Map<EquipmentSlot, WarnTier> lastTier = new EnumMap<>(EquipmentSlot.class);
    private int tickCounter = 0;

    public ShowArmor() {
        super("ShowArmor", Category.Render, "Красит броню на игроке по прочности");
        for (EquipmentSlot s : new EquipmentSlot[]{
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
        }) {
            lastTier.put(s, WarnTier.NONE);
        }
    }

    @Override
    public void onEnable() {
        ENABLED = true;
        TINT_SELF = tintSelf.getValue();
        lastTier.replaceAll((s, v) -> WarnTier.NONE);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        ENABLED = false;
        super.onDisable();
    }

    @EventHandler
    private void onTick(dev.batvisuals.client.events.impl.EventTick e) {
        if (!isToggled()) return;
        TINT_SELF = tintSelf.getValue();

        if (!warnLow.getValue()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        if (++tickCounter % 10 != 0) return;

        checkSlot(EquipmentSlot.HEAD, "шлеме");
        checkSlot(EquipmentSlot.CHEST, "нагруднике");
        checkSlot(EquipmentSlot.LEGS, "поножах");
        checkSlot(EquipmentSlot.FEET, "ботинках");
    }

    private void checkSlot(EquipmentSlot slot, String where) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ItemStack stack = mc.player.getEquippedStack(slot);
        WarnTier tier = tierOf(stack);
        WarnTier prev = lastTier.getOrDefault(slot, WarnTier.NONE);

        if (tier.ordinal() > prev.ordinal()) {
            String msg = switch (tier) {
                case LOW15 -> "На " + where + " меньше 15% прочности!";
                case LOW5 -> "На " + where + " меньше 5% прочности!";
                case BROKEN -> "На " + where + " броня сломалась!";
                default -> null;
            };
            if (msg != null) {
                try {
                    batvisuals.getInstance().getNotifyManager().add(
                            new Notify(NotifyIcons.warnIcon, msg, 2800)
                    );
                } catch (Throwable ignored) {}
            }
            lastTier.put(slot, tier);
        } else if (tier == WarnTier.NONE || stack.isEmpty()) {
            lastTier.put(slot, WarnTier.NONE);
        }
    }

    private static WarnTier tierOf(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isDamageable()) return WarnTier.NONE;
        int max = stack.getMaxDamage();
        if (max <= 0) return WarnTier.NONE;
        int dmg = stack.getDamage();
        if (dmg >= max) return WarnTier.BROKEN;
        float pct = 1f - (float) dmg / (float) max;
        if (pct <= 0.05f) return WarnTier.LOW5;
        if (pct <= 0.15f) return WarnTier.LOW15;
        return WarnTier.NONE;
    }
}
