package dev.batvisuals.modules.impl.render.omnom;

import net.minecraft.client.model.*;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * OmNom cosmetic pet model (64×64 UV). Rendered manually from Pets — no EntityType.
 */
public class OmNomModel {

    public static final Identifier TEXTURE = Identifier.of("batvisuals", "textures/entity/omnom/omnom.png");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart leftEyeWhite;
    private final ModelPart rightEyeWhite;
    private final ModelPart leftPupil;
    private final ModelPart rightPupil;
    private final ModelPart teeth;
    private final ModelPart frontLeftLeg;
    private final ModelPart frontRightLeg;
    private final ModelPart backLeftLeg;
    private final ModelPart backRightLeg;
    private final ModelPart antenna;

    public OmNomModel() {
        this.root = getTexturedModelData().createModel();
        this.body = root.getChild("body");
        this.leftEyeWhite = root.getChild("left_eye_white");
        this.rightEyeWhite = root.getChild("right_eye_white");
        this.leftPupil = root.getChild("left_pupil");
        this.rightPupil = root.getChild("right_pupil");
        this.teeth = root.getChild("teeth");
        this.frontLeftLeg = root.getChild("front_left_leg");
        this.frontRightLeg = root.getChild("front_right_leg");
        this.backLeftLeg = root.getChild("back_left_leg");
        this.backRightLeg = root.getChild("back_right_leg");
        this.antenna = root.getChild("antenna");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData md = new ModelData();
        ModelPartData r = md.getRoot();

        r.addChild("body",
                ModelPartBuilder.create().uv(0, 0).cuboid(-7f, -12f, -6f, 14, 12, 12),
                ModelTransform.pivot(0f, 24f, 0f));

        r.addChild("left_eye_white",
                ModelPartBuilder.create().uv(0, 25).cuboid(-3f, 0f, 0f, 6, 6, 2),
                ModelTransform.pivot(3f, 12f, -8f));

        r.addChild("right_eye_white",
                ModelPartBuilder.create().uv(17, 25).cuboid(-3f, 0f, 0f, 6, 6, 2),
                ModelTransform.pivot(-3f, 12f, -8f));

        r.addChild("left_pupil",
                ModelPartBuilder.create().uv(34, 25).cuboid(-1f, 0f, 0f, 2, 3, 1),
                ModelTransform.pivot(2f, 14f, -10f));

        r.addChild("right_pupil",
                ModelPartBuilder.create().uv(41, 25).cuboid(-1f, 0f, 0f, 2, 3, 1),
                ModelTransform.pivot(-2f, 14f, -10f));

        r.addChild("teeth",
                ModelPartBuilder.create().uv(0, 34).cuboid(-5f, -4f, 0f, 10, 4, 2),
                ModelTransform.pivot(0f, 24f, -8f));

        r.addChild("front_left_leg",
                ModelPartBuilder.create().uv(25, 34).cuboid(-1f, 0f, -1f, 3, 2, 3),
                ModelTransform.pivot(-4f, 24f, -4f));

        r.addChild("front_right_leg",
                ModelPartBuilder.create().uv(37, 34).cuboid(-1f, 0f, -1f, 3, 2, 3),
                ModelTransform.pivot(4f, 24f, -4f));

        r.addChild("back_left_leg",
                ModelPartBuilder.create().uv(25, 41).cuboid(-1f, 0f, -1f, 3, 2, 3),
                ModelTransform.pivot(-4f, 24f, 4f));

        r.addChild("back_right_leg",
                ModelPartBuilder.create().uv(37, 41).cuboid(-1f, 0f, -1f, 3, 2, 3),
                ModelTransform.pivot(4f, 24f, 4f));

        r.addChild("antenna",
                ModelPartBuilder.create().uv(50, 34).cuboid(-1f, -6f, -1f, 2, 6, 2),
                ModelTransform.pivot(0f, 12f, 0f));

        return TexturedModelData.of(md, 64, 64);
    }

    public void animate(float limbAngle, float limbDistance, float animationProgress, float headYawDeg) {
        float swing = MathHelper.cos(limbAngle * 0.6662f) * 0.85f * limbDistance;
        frontLeftLeg.pitch = swing;
        frontRightLeg.pitch = -swing;
        backLeftLeg.pitch = -swing;
        backRightLeg.pitch = swing;

        body.roll = MathHelper.sin(limbAngle * 0.6662f) * 0.045f * limbDistance;

        antenna.roll = MathHelper.sin(animationProgress * 0.085f) * 0.22f;
        antenna.pitch = MathHelper.cos(animationProgress * 0.065f) * 0.11f;

        float cycle = animationProgress % 140f;
        float blink = 0f;
        if (cycle < 4f) blink = cycle / 4f;
        else if (cycle < 8f) blink = 1f - (cycle - 4f) / 4f;

        float eyeOpen = 1f - blink;
        leftEyeWhite.yScale = eyeOpen;
        rightEyeWhite.yScale = eyeOpen;
        leftPupil.yScale = eyeOpen;
        rightPupil.yScale = eyeOpen;

        float yawRad = headYawDeg * ((float) Math.PI / 180f) * 0.25f;
        leftPupil.yaw = yawRad;
        rightPupil.yaw = yawRad;
    }

    public void render(MatrixStack matrices, VertexConsumerProvider consumers, int light, float scale) {
        matrices.push();
        // Vanilla entity model: flip, then 1/16 from pixel space; scale setting multiplies size
        float s = 0.0625f * scale;
        matrices.scale(-s, -s, s);
        matrices.translate(0.0, -24.0, 0.0); // model pivot at y=24 pixels

        VertexConsumer vc = consumers.getBuffer(RenderLayer.getEntityCutoutNoCull(TEXTURE));
        root.render(matrices, vc, light, 0x00F000F0);

        matrices.pop();
    }

    /** World-space helper used by Pets. */
    public void renderAt(MatrixStack matrices, VertexConsumerProvider consumers,
                         double x, double y, double z, float yawDeg, float scale,
                         float limbAngle, float limbDistance, float age, int light) {
        matrices.push();
        matrices.translate(x, y, z);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f - yawDeg));
        animate(limbAngle, limbDistance, age, 0f);
        render(matrices, consumers, light, scale);
        matrices.pop();
    }
}
