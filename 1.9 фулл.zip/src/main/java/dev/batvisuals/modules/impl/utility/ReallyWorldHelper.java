package dev.batvisuals.modules.impl.utility;

import dev.batvisuals.client.ChatUtils;
import dev.batvisuals.client.events.impl.EventPacket;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.packet.c2s.play.ChatMessageC2SPacket;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

public class ReallyWorldHelper extends Module {

    private final Set<Pattern> bannedPatterns = new HashSet<>();

    public ReallyWorldHelper() {
        super("ReallyWorldHelper", Category.Utility, "Хелпер для ReallyWorld");
        String[] words = {
            "акриен(а|у|ом|е|чик)?", "рич(а|у|ом|ей|е)?", "ньюкод(ом|а|у|ами|ик|е)?",
            "экспенсив(ом|а|у|ами|е)?", "импакт(ом|а|у|ами|ик|е)?", "экселлент(ом|а|у|ами|ик|е)?",
            "экселент(ом|а|у|ами|ик)?", "катлаван(ом|а|у|ами|чик)?", "катлован(ом|а|у|ами|чик)?",
            "целестиал(ом|а|у|ами|е)?", "целк(ой|а|у|ами|очка|е)?", "матикс(ом|а|у|ами|е)?",
            "инерти(я|ей|ю|ями|е)?", "эксп(а|ой|ою|у|уличка|е)?", "флюгер(ом|а|у|ами)?",
            "рикер(а|у|ом|очек)?", "фанпе(й|ю|я|ем|е|йчик)?", "вексайд(ом|а|у|ами|ик|е)?",
            "нурсултан(а|у|е|ом|чик)?", "нурик(а|у|ом|е)?", "нурлан(а|у|ом|чик|е)?",
            "векс(ом|у|а|ами|ик|е)?", "релейк(ом|у|а|ами|е)?", "арбуз(ом|а|у|ами|ик|е)?",
            "вилд(ом|у|а|ами|ик|е)?", "фантайм(е|а|у)?", "холик(е|а|у)?", "холиворлд(а|у|е)?",
            "рокстар(ом|а|у|ами|чик|е)?", "рогалик(а|у|ом|е)?", "тандерхак(ом|у|и|ами|а|е)?",
            "ликвидбаунс(а|у|ами|е)?",
            "expensive", "celestial", "newcode", "arbuz", "akrien", "nursultan", "relake",
            "batclient", "wurst", "catlovan", "excellent", "rockstar", "catlavan", "impact",
            "matix", "inertia", "wex", "wexside", "nurik", "nurlan", "rich", "funpay",
            "fluger", "riker", "funtime", "holyworld", "wwe", "hvh", "rogalik", "thunderhack",
            "liquidbounce"
        };
        for (String w : words) {
            bannedPatterns.add(Pattern.compile(".*" + w + ".*", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE));
        }
    }

    @EventHandler
    public void onPacketSend(EventPacket.Send event) {
        if (!(event.getPacket() instanceof ChatMessageC2SPacket chatPacket)) return;

        String message = chatPacket.chatMessage().toLowerCase();
        for (Pattern p : bannedPatterns) {
            if (p.matcher(message).matches()) {
                event.cancel();
                ChatUtils.sendMessage("A forbidden word was found in your message, message sending has been cancelled!");
                return;
            }
        }
    }
}
