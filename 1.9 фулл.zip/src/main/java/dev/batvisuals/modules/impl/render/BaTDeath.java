package dev.batvisuals.modules.impl.render;

import dev.batvisuals.client.events.impl.EventEntityDeath;
import dev.batvisuals.client.events.impl.EventRender3D;
import dev.batvisuals.client.util.renderer.Render3D;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.ColorSetting;
import dev.batvisuals.modules.settings.impl.ListSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.LightningEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * BaTDeath: визуальный эффект на месте смерти игрока.
 */
public class BaTDeath extends Module {

    private final ListSetting deathType = new ListSetting("setting.deathType", true,
            new BooleanSetting("death.lightning", true),
            new BooleanSetting("death.beam", false)
    );

    private final ColorSetting beamColor = new ColorSetting("setting.beamColor", Color.CYAN.getRGB());
    private final BooleanSetting playersOnly = new BooleanSetting("setting.playersOnly", true);

    private record ActiveBeam(Vec3d pos, long startMs) {}

    private static final long BEAM_DURATION_MS = 3000L;
    private static final long FADE_IN_MS = 500L;
    private static final long FADE_OUT_MS = 900L;
    private static final double BEAM_HEIGHT = 60.0;
    private static final double BEAM_WIDTH = 0.35;

    private final List<ActiveBeam> beams = new ArrayList<>();

    public BaTDeath() {
        super("BaTDeath", Category.Render, I18n.translate("module.batdeath.description"));
    }

    @Override
    public void onDisable() {
        beams.clear();
        super.onDisable();
    }

    @EventHandler
    public void onEntityDeath(EventEntityDeath e) {
        if (!isToggled()) return;
        LivingEntity entity = e.getEntity();
        if (entity == null) return;
        if (playersOnly.getValue() && !(entity instanceof PlayerEntity)) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && entity == mc.player) return;

        Vec3d pos = entity.getPos();

        BooleanSetting mode = deathType.getToggled().isEmpty() ? null : deathType.getToggled().get(0);
        String modeName = mode != null ? mode.getName() : "death.lightning";

        if (modeName.equals("death.lightning")) {
            spawnVisualLightning(mc, pos);
            playLightningSound(mc, pos);
        } else {
            beams.add(new ActiveBeam(pos, System.currentTimeMillis()));
            playBeamSound(mc, pos);
        }
    }

    private void playBeamSound(MinecraftClient mc, Vec3d pos) {
        if (mc.world == null) return;
        SoundEvent soundEvent = SoundEvent.of(Identifier.of("batvisuals:lightning"));
        mc.getSoundManager().play(new PositionedSoundInstance(
                soundEvent,
                SoundCategory.PLAYERS,
                1.0f,
                1.0f,
                net.minecraft.util.math.random.Random.create(),
                pos.x, pos.y, pos.z
        ));
    }

    private void playLightningSound(MinecraftClient mc, Vec3d pos) {
        if (mc.world == null) return;
        mc.getSoundManager().play(new PositionedSoundInstance(
                SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER,
                SoundCategory.PLAYERS,
                1.0f,
                1.0f,
                net.minecraft.util.math.random.Random.create(),
                pos.x, pos.y, pos.z
        ));
    }

    private void spawnVisualLightning(MinecraftClient mc, Vec3d pos) {
        if (mc.world == null) return;
        LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(mc.world, SpawnReason.TRIGGERED);
        if (bolt == null) return;
        bolt.setPosition(pos.x, pos.y, pos.z);
        bolt.setCosmetic(true);
        mc.world.addEntity(bolt);
    }

    @EventHandler
    public void onRender3D(EventRender3D.Game e) {
        if (!isToggled() || beams.isEmpty()) return;

        long now = System.currentTimeMillis();
        beams.removeIf(b -> now - b.startMs() > BEAM_DURATION_MS);
        if (beams.isEmpty()) return;

        Color base = beamColor.getColor();
        int r = base.getRed();
        int g = base.getGreen();
        int b = base.getBlue();

        MatrixStack matrices = new MatrixStack();
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        Vec3d cam = MinecraftClient.getInstance().gameRenderer.getCamera().getPos();

        for (ActiveBeam beam : beams) {
            long age = now - beam.startMs();
            float alphaMul;
            if (age < FADE_IN_MS) {
                alphaMul = (float) age / (float) FADE_IN_MS;
            } else if (age > BEAM_DURATION_MS - FADE_OUT_MS) {
                long intoFade = age - (BEAM_DURATION_MS - FADE_OUT_MS);
                alphaMul = 1.0f - ((float) intoFade / (float) FADE_OUT_MS);
            } else {
                alphaMul = 1.0f;
            }
            alphaMul = Math.max(0f, Math.min(1f, alphaMul));
            if (alphaMul <= 0f) continue;

            int alpha = (int) (200 * alphaMul);
            int colorTop = new Color(r, g, b, 0).getRGB(); 
            int colorBottom = new Color(r, g, b, alpha).getRGB();

            double half = BEAM_WIDTH / 2.0;
            Vec3d base1 = beam.pos().add(-half, 0, 0).subtract(cam);
            Vec3d base2 = beam.pos().add(half, 0, 0).subtract(cam);
            Vec3d base3 = beam.pos().add(0, 0, -half).subtract(cam);
            Vec3d base4 = beam.pos().add(0, 0, half).subtract(cam);
            Vec3d top1 = base1.add(0, BEAM_HEIGHT, 0);
            Vec3d top2 = base2.add(0, BEAM_HEIGHT, 0);
            Vec3d top3 = base3.add(0, BEAM_HEIGHT, 0);
            Vec3d top4 = base4.add(0, BEAM_HEIGHT, 0);

            // ФИКС ПРОПАДАНИЯ ЛУЧА: Отрисовываем квады с обеих сторон
            // Плоскость 1 (Лицевая и изнаночная сторона)
            addBeamQuad(matrix, base1, base2, top2, top1, colorBottom, colorTop);
            addBeamQuad(matrix, base2, base1, top1, top2, colorBottom, colorTop); 
            
            // Плоскость 2 (Лицевая и изнаночная сторона)
            addBeamQuad(matrix, base3, base4, top4, top3, colorBottom, colorTop);
            addBeamQuad(matrix, base4, base3, top3, top4, colorBottom, colorTop);
        }
    }

    private void addBeamQuad(Matrix4f matrix, Vec3d bA, Vec3d bB, Vec3d tB, Vec3d tA, int colorBottom, int colorTop) {
        Render3D.Vertex[] vertices = {
                new Render3D.Vertex(matrix, (float) bA.x, (float) bA.y, (float) bA.z, colorBottom),
                new Render3D.Vertex(matrix, (float) bB.x, (float) bB.y, (float) bB.z, colorBottom),
                new Render3D.Vertex(matrix, (float) tB.x, (float) tB.y, (float) tB.z, colorTop),
                new Render3D.Vertex(matrix, (float) tA.x, (float) tA.y, (float) tA.z, colorTop)
        };
        Render3D.QUADS.add(new Render3D.VertexCollection(vertices));
    }
}
