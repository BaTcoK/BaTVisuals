package dev.batvisuals.modules.impl.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.batvisuals.client.events.impl.EventAttackEntity;
import dev.batvisuals.client.events.impl.EventRender3D;
import dev.batvisuals.client.events.impl.EventTick;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.ListSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import org.joml.Matrix4f;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Crit / mace hit → expanding ring of BlockOverlay-style filled blocks under the target.
 */
public class DamageExplosion extends Module {

    private final NumberSetting radius = new NumberSetting("Радиус", 8f, 5f, 20f, 1f);
    private final NumberSetting centerAlpha = new NumberSetting("Заливка центра", 200f, 50f, 255f, 5f);
    private final NumberSetting edgeAlpha = new NumberSetting("Заливка края", 50f, 0f, 200f, 5f);
    private final NumberSetting waveMs = new NumberSetting("Шаг волны мс", 70f, 30f, 200f, 10f);
    private final NumberSetting holdMs = new NumberSetting("Держать мс", 400f, 100f, 2000f, 50f);
    private final NumberSetting fadeMs = new NumberSetting("Затухание мс", 350f, 50f, 1500f, 50f);

    private final ListSetting triggers = new ListSetting("Условие", false,
            new BooleanSetting("Булавой", true),
            new BooleanSetting("Крит", true),
            new BooleanSetting("Прыжок", false)
    );

    private final List<Wave> waves = new ArrayList<>();
    private boolean wasOnGround = true;
    private int jumpCd;
    private int attackCd;
    private int airTicks;
    private float peakFall;

    private static final class Cell {
        final BlockPos pos;
        final Box box;
        final int ring;
        long activateAt;
        boolean active;

        Cell(BlockPos pos, Box box, int ring) {
            this.pos = pos;
            this.box = box;
            this.ring = ring;
            this.activateAt = Long.MAX_VALUE;
        }
    }

    private static final class Wave {
        final long startMs;
        final int maxRing;
        final long stepMs;
        final long holdMs;
        final long fadeMs;
        final List<Cell> cells = new ArrayList<>();
        int releasedRing = -1;

        Wave(long startMs, int maxRing, long stepMs, long holdMs, long fadeMs) {
            this.startMs = startMs;
            this.maxRing = maxRing;
            this.stepMs = stepMs;
            this.holdMs = holdMs;
            this.fadeMs = fadeMs;
        }

        boolean done(long now) {
            return now > startMs + (long) maxRing * stepMs + holdMs + fadeMs + 50;
        }
    }

    public DamageExplosion() {
        super("DamageExplosion", Category.Render, "Волна блоков при сильном ударе");
    }

    @Override
    public void onDisable() {
        waves.clear();
        airTicks = 0;
        peakFall = 0;
        super.onDisable();
    }

    private boolean want(String key) {
        if (triggers.getValue() == null) return false;
        for (BooleanSetting s : triggers.getValue()) {
            if (s == null || s.getName() == null || !Boolean.TRUE.equals(s.getValue())) continue;
            String n = s.getName().toLowerCase();
            if (key.equals("mace") && (n.contains("булав") || n.contains("mace"))) return true;
            if (key.equals("crit") && (n.contains("крит") || n.contains("crit"))) return true;
            if (key.equals("jump") && (n.contains("прыж") || n.contains("jump"))) return true;
        }
        return false;
    }

    private boolean holdingMace() {
        if (mc.player == null) return false;
        try {
            if (mc.player.getMainHandStack().isOf(Items.MACE)) return true;
            if (mc.player.getOffHandStack().isOf(Items.MACE)) return true;
        } catch (Throwable t) {
            try {
                String a = String.valueOf(mc.player.getMainHandStack().getItem()).toLowerCase();
                String b = String.valueOf(mc.player.getOffHandStack().getItem()).toLowerCase();
                return a.contains("mace") || b.contains("mace");
            } catch (Throwable ignored) {}
        }
        return false;
    }

    /** Airborne / falling context for a critical-style hit. */
    private boolean isCritContext() {
        if (mc.player == null) return false;
        if (mc.player.isTouchingWater() || mc.player.isInLava()) return false;
        if (mc.player.isClimbing() || mc.player.hasVehicle()) return false;
        try {
            if (mc.player.isGliding()) return false;
        } catch (Throwable ignored) {}

        if (!mc.player.isOnGround()) return true;
        if (airTicks > 0) return true;
        if (mc.player.fallDistance > 0f || peakFall > 0f) return true;
        return mc.player.getVelocity().y < -0.05;
    }

    private boolean attackMatches() {
        boolean mace = want("mace");
        boolean crit = want("crit");
        // nothing selected for attack types → default crit
        if (!mace && !crit) crit = true;

        boolean hasMace = holdingMace();
        boolean inAir = isCritContext();

        if (mace && crit) {
            // either: mace hit, or airborne crit (any weapon)
            return hasMace || inAir;
        }
        if (mace) return hasMace;          // any hit with mace
        return inAir;                      // crit only
    }

    private void spawnWave(Vec3d entityPos) {
        if (mc.world == null || entityPos == null) return;
        BlockPos feet = BlockPos.ofFloored(entityPos.x, entityPos.y - 0.01, entityPos.z);
        BlockPos ground = feet.down();
        for (int i = 0; i < 6; i++) {
            BlockState st = mc.world.getBlockState(ground);
            if (!st.isAir() && !st.getCollisionShape(mc.world, ground).isEmpty()) break;
            ground = ground.down();
        }

        int r = MathHelper.clamp(Math.round(radius.getValue()), 5, 20);
        long step = Math.max(20L, Math.round(waveMs.getValue()));
        long hold = Math.max(50L, Math.round(holdMs.getValue()));
        long fade = Math.max(50L, Math.round(fadeMs.getValue()));
        long now = System.currentTimeMillis();

        Wave wave = new Wave(now, r, step, hold, fade);
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                int dist = (int) Math.ceil(Math.sqrt(dx * dx + dz * dz));
                if (dist > r) continue;
                for (int dy = 0; dy <= 2; dy++) {
                    BlockPos bp = ground.add(dx, dy, dz);
                    BlockState st = mc.world.getBlockState(bp);
                    VoxelShape shape = st.getOutlineShape(mc.world, bp);
                    if (st.isAir() || shape.isEmpty()) continue;
                    Box box;
                    try {
                        box = shape.getBoundingBox().offset(bp.getX(), bp.getY(), bp.getZ());
                    } catch (Throwable ex) {
                        box = new Box(bp);
                    }
                    wave.cells.add(new Cell(bp, box, dist));
                }
            }
        }

        for (Cell c : wave.cells) {
            if (c.ring == 0) {
                c.active = true;
                c.activateAt = now;
            }
        }
        wave.releasedRing = 0;
        if (wave.cells.isEmpty()) return;
        waves.add(wave);
        while (waves.size() > 6) waves.remove(0);
    }

    @EventHandler
    public void onAttack(EventAttackEntity e) {
        if (!isToggled() || fullNullCheck()) return;
        if (e.getTarget() == mc.player) return;
        if (!(e.getTarget() instanceof LivingEntity living)) return;
        if (!living.isAlive()) return;
        // Same guards as HitBubbles / DamageParticles
        if (!e.isEffectsAllowed()) return;

        // Only local player's attacks
        if (e.getPlayer() != null && e.getPlayer() != mc.player) return;
        if (attackCd > 0) return;
        if (!attackMatches()) return;

        attackCd = 4;
        spawnWave(living.getPos());
    }

    @EventHandler
    public void onTick(EventTick e) {
        if (fullNullCheck()) return;

        if (mc.player.isOnGround()) {
            airTicks = 0;
            peakFall = 0;
        } else {
            airTicks++;
            peakFall = Math.max(peakFall, mc.player.fallDistance);
        }

        if (!isToggled()) {
            wasOnGround = mc.player.isOnGround();
            return;
        }

        if (attackCd > 0) attackCd--;
        if (jumpCd > 0) jumpCd--;

        // Fallback if mixin event was missed: swing + entity under crosshair
        if (attackCd <= 0 && mc.player.handSwinging && mc.player.handSwingTicks == 0) {
            Entity te = mc.targetedEntity;
            if (te instanceof LivingEntity living && living.isAlive() && living != mc.player) {
                if (attackMatches()) {
                    attackCd = 8;
                    spawnWave(living.getPos());
                }
            }
        }

        boolean onGround = mc.player.isOnGround();
        if (want("jump") && wasOnGround && !onGround && jumpCd <= 0) {
            jumpCd = 12;
            spawnWave(mc.player.getPos());
        }
        wasOnGround = onGround;

        long now = System.currentTimeMillis();
        Iterator<Wave> it = waves.iterator();
        while (it.hasNext()) {
            Wave w = it.next();
            if (w.done(now)) {
                it.remove();
                continue;
            }
            int shouldRing = (int) ((now - w.startMs) / w.stepMs);
            if (shouldRing > w.releasedRing) {
                for (int ring = w.releasedRing + 1; ring <= Math.min(shouldRing, w.maxRing); ring++) {
                    for (Cell c : w.cells) {
                        if (c.ring == ring && !c.active) {
                            c.active = true;
                            c.activateAt = now;
                        }
                    }
                }
                w.releasedRing = Math.min(shouldRing, w.maxRing);
            }
        }
    }

    @EventHandler
    public void onRender3D(EventRender3D.Game event) {
        if (fullNullCheck() || waves.isEmpty()) return;

        Color accent;
        try {
            accent = ThemeManager.getInstance().getCurrentTheme().getAccentColor();
            if (accent == null) accent = new Color(100, 180, 255);
        } catch (Throwable t) {
            accent = new Color(100, 180, 255);
        }

        float aCenter = centerAlpha.getValue() != null ? centerAlpha.getValue() : 200f;
        float aEdge = edgeAlpha.getValue() != null ? edgeAlpha.getValue() : 50f;
        long now = System.currentTimeMillis();
        MatrixStack matrices = event.getMatrices();
        Vec3d camera = mc.gameRenderer.getCamera().getPos();

        List<float[]> quads = new ArrayList<>();
        for (Wave w : waves) {
            float invMax = 1f / Math.max(1, w.maxRing);
            for (Cell c : w.cells) {
                if (!c.active) continue;
                long elapsed = now - c.activateAt;
                if (elapsed < 0) continue;

                float life;
                if (elapsed < w.holdMs) life = 1f;
                else {
                    float f = (elapsed - w.holdMs) / (float) Math.max(1L, w.fadeMs);
                    life = 1f - MathHelper.clamp(f, 0f, 1f);
                }
                if (life <= 0.01f) continue;

                float radial = 1f - c.ring * invMax;
                float alphaByte = MathHelper.lerp(1f - radial, aEdge, aCenter) * life;
                int a = MathHelper.clamp((int) alphaByte, 0, 255);
                if (a < 2) continue;

                float r = accent.getRed() / 255f;
                float g = accent.getGreen() / 255f;
                float b = accent.getBlue() / 255f;
                float af = a / 255f;

                float minX = (float) (c.box.minX - camera.x) - 0.002f;
                float minY = (float) (c.box.minY - camera.y) - 0.002f;
                float minZ = (float) (c.box.minZ - camera.z) - 0.002f;
                float maxX = (float) (c.box.maxX - camera.x) + 0.002f;
                float maxY = (float) (c.box.maxY - camera.y) + 0.002f;
                float maxZ = (float) (c.box.maxZ - camera.z) + 0.002f;
                addBox(quads, minX, minY, minZ, maxX, maxY, maxZ, r, g, b, af);
            }
        }

        if (quads.isEmpty()) return;

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);

        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        for (float[] q : quads) {
            for (int i = 0; i < 4; i++) {
                int o = i * 7;
                buffer.vertex(matrix, q[o], q[o + 1], q[o + 2]).color(q[o + 3], q[o + 4], q[o + 5], q[o + 6]);
            }
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(buffer);

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private static void addBox(List<float[]> out,
                               float minX, float minY, float minZ,
                               float maxX, float maxY, float maxZ,
                               float r, float g, float b, float a) {
        out.add(face(minX, minY, minZ, maxX, minY, minZ, maxX, minY, maxZ, minX, minY, maxZ, r, g, b, a));
        out.add(face(minX, maxY, minZ, minX, maxY, maxZ, maxX, maxY, maxZ, maxX, maxY, minZ, r, g, b, a));
        out.add(face(minX, minY, minZ, minX, maxY, minZ, maxX, maxY, minZ, maxX, minY, minZ, r, g, b, a));
        out.add(face(minX, minY, maxZ, maxX, minY, maxZ, maxX, maxY, maxZ, minX, maxY, maxZ, r, g, b, a));
        out.add(face(minX, minY, minZ, minX, minY, maxZ, minX, maxY, maxZ, minX, maxY, minZ, r, g, b, a));
        out.add(face(maxX, minY, minZ, maxX, maxY, minZ, maxX, maxY, maxZ, maxX, minY, maxZ, r, g, b, a));
    }

    private static float[] face(float x1, float y1, float z1,
                                float x2, float y2, float z2,
                                float x3, float y3, float z3,
                                float x4, float y4, float z4,
                                float r, float g, float b, float a) {
        return new float[]{
                x1, y1, z1, r, g, b, a,
                x2, y2, z2, r, g, b, a,
                x3, y3, z3, r, g, b, a,
                x4, y4, z4, r, g, b, a
        };
    }
}
