package dev.batvisuals.modules.impl.render;

import dev.batvisuals.client.events.impl.EventTick;
import dev.batvisuals.client.ui.ViewModelEditorScreen;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import meteordevelopment.orbit.EventHandler;

/** Расположение рук через визуальный редактор. */
public class ViewModel extends Module {

    public NumberSetting mainX = new NumberSetting("mainX", 0f, -2f, 2f, 0.01f, () -> false);
    public NumberSetting mainY = new NumberSetting("mainY", 0f, -2f, 2f, 0.01f, () -> false);
    public NumberSetting mainZ = new NumberSetting("mainZ", 0f, -2f, 2f, 0.01f, () -> false);
    public NumberSetting offX = new NumberSetting("offX", 0f, -2f, 2f, 0.01f, () -> false);
    public NumberSetting offY = new NumberSetting("offY", 0f, -2f, 2f, 0.01f, () -> false);
    public NumberSetting offZ = new NumberSetting("offZ", 0f, -2f, 2f, 0.01f, () -> false);
    public NumberSetting mainScale = new NumberSetting("mainScale", 1f, 0.3f, 2f, 0.01f, () -> false);
    public NumberSetting offScale = new NumberSetting("offScale", 1f, 0.3f, 2f, 0.01f, () -> false);

    public final BooleanSetting openEditor = new BooleanSetting("Открыть редактор", false);
    private boolean latch;

    public ViewModel() {
        super("ViewModel", Category.Render, "Расположение рук — через редактор");
    }

    /** Called every client tick (even if module off) so editor opens reliably. */
    public void pollOpenEditor() {
        if (!openEditor.getValue()) {
            latch = false;
            return;
        }
        if (latch) return;
        latch = true;
        openEditor.setValue(false);
        if (!isToggled()) setToggled(true);
        if (mc != null) {
            try { mc.setScreen(new ViewModelEditorScreen(this)); } catch (Throwable ignored) {}
        }
    }

    @EventHandler
    public void onTick(EventTick e) {
        pollOpenEditor();
    }
}
