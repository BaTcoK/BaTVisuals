package dev.batvisuals.modules.impl.utility;

import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.ListSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.NotNull;

/**
 * Module toggle sounds + ClickGUI UI clicks/sliders.
 * Volume setting 0–5 (default 5). UI plays even if this module is off (uses volume if present).
 */
public class ClientSound extends Module {
    private final @NotNull BooleanSetting pair1 = new BooleanSetting("mode.pair1", true, () -> false);
    private final @NotNull BooleanSetting pair2 = new BooleanSetting("mode.pair2", false, () -> false);
    private final @NotNull BooleanSetting legacy = new BooleanSetting("mode.legacy", false, () -> false);

    private final @NotNull NumberSetting volume = new NumberSetting(
            "setting.volume",
            5.0f,
            0.0f,
            5.0f,
            0.1f
    );

    /** UI click/slider sounds in ClickGUI */
    private final @NotNull BooleanSetting uiSounds = new BooleanSetting("Звуки GUI", true);

    private final @NotNull ListSetting mode = new ListSetting(
            "setting.sound",
            true,
            pair1, pair2, legacy
    );

    private static long lastSliderSoundMs;
    private static ClientSound INSTANCE;

    public ClientSound() {
        super("ClientSound", Category.Utility, I18n.translate("module.clientsound.description"));
        getSettings().add(mode);
        getSettings().add(volume);
        getSettings().add(uiSounds);
        INSTANCE = this;
    }

    public static ClientSound getInstance() {
        return INSTANCE;
    }

    public String getEnableSoundId() {
        if (Boolean.TRUE.equals(pair2.getValue())) return "batvisuals:enable2";
        if (Boolean.TRUE.equals(legacy.getValue())) return "batvisuals:enable";
        return "batvisuals:enable1";
    }

    public String getDisableSoundId() {
        if (Boolean.TRUE.equals(pair2.getValue())) return "batvisuals:disable2";
        if (Boolean.TRUE.equals(legacy.getValue())) return "batvisuals:disable";
        return "batvisuals:disable1";
    }

    public NumberSetting getVolume() {
        return volume;
    }

    public boolean isUiSounds() {
        return uiSounds.getValue() == null || Boolean.TRUE.equals(uiSounds.getValue());
    }

    /** 0–5 → MC volume 0–1 (default 5 = max). */
    public float getPlayVolume() {
        float v = volume.getValue() != null ? volume.getValue() : 5f;
        return Math.max(0f, Math.min(1f, v / 5f));
    }

    public static void playUiClick() {
        playUi("ui_one", 1.0f);
    }

    public static void playUiClickAlt() {
        playUi("ui_two", 1.05f);
    }

    public static void playUiSlider() {
        long now = System.currentTimeMillis();
        if (now - lastSliderSoundMs < 40) return;
        lastSliderSoundMs = now;
        playUi("ui_slider", 1.0f);
    }

    private static void playUi(String path, float pitch) {
        try {
            ClientSound cs = INSTANCE;
            try {
                if (cs == null) {
                    cs = dev.batvisuals.batvisuals.getInstance().getModuleManager().getModule(ClientSound.class);
                }
            } catch (Throwable ignored) {}
            if (cs != null && !cs.isUiSounds()) return;

            float vol = cs != null ? cs.getPlayVolume() : 1f;
            if (vol <= 0.01f) return;
            // boost UI a bit — master was too quiet
            vol = Math.min(1f, vol * 1.0f);

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc == null || mc.getSoundManager() == null) return;

            Identifier id = Identifier.of("batvisuals", path);
            SoundEvent ev = SoundEvent.of(id);
            // master category, full volume
            mc.getSoundManager().play(PositionedSoundInstance.master(ev, pitch, vol));
        } catch (Throwable ignored) {}
    }

    /** Used by Module onEnable/onDisable. */
    public void playToggle(boolean enable) {
        if (!isToggled()) return;
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc == null || mc.getSoundManager() == null) return;
            String full = enable ? getEnableSoundId() : getDisableSoundId();
            String path = full.contains(":") ? full.split(":", 2)[1] : full;
            float vol = getPlayVolume();
            if (vol <= 0.01f) return;
            mc.getSoundManager().play(PositionedSoundInstance.master(
                    SoundEvent.of(Identifier.of("batvisuals", path)),
                    1.0f,
                    vol
            ));
        } catch (Throwable ignored) {}
    }
}
