package dev.batvisuals.modules.impl.render;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.ChatUtils;
import dev.batvisuals.client.events.impl.EventTick;
import dev.batvisuals.client.ui.clickgui.ClickGui;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.api.Bind;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import meteordevelopment.orbit.EventHandler;
import org.lwjgl.glfw.GLFW;
import net.minecraft.client.resource.language.I18n;

public class UI extends Module {

    private final NumberSetting guiScale = new NumberSetting("GUI Scale", 1f, 0.6f, 1.6f, 0.05f);

    /** Applied only after slider release — prevents ClickGUI jitter while dragging. */
    private float appliedScale = 1f;

    public UI() {
        super("UI", Category.Render, I18n.translate("module.ui.description"));
        setBind(new Bind(GLFW.GLFW_KEY_RIGHT_SHIFT, false));
        if (!getSettings().contains(guiScale)) {
            getSettings().add(guiScale);
        }
        // sync applied from default
        commitGuiScale();
    }

    /** Scale used for rendering ClickGUI (stable while dragging the slider). */
    public float getGuiScale() {
        return appliedScale <= 0f ? 1f : appliedScale;
    }

    public NumberSetting getGuiScaleSetting() {
        return guiScale;
    }

    /** Call when user releases the GUI Scale slider. */
    public void commitGuiScale() {
        Float v = guiScale.getValue();
        if (v == null || v <= 0f) appliedScale = 1f;
        else appliedScale = v;
    }

    @EventHandler
    public void onTick(EventTick e) {
        if (!(mc.currentScreen instanceof ClickGui)) {
            if (isToggled()) setToggled(false);
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        // ensure applied matches setting when opening
        commitGuiScale();

        if (mc.player == null || mc.world == null) {
            ChatUtils.sendMessage(I18n.translate("batvisuals.ui.onlyInWorld"));
            setToggled(false);
            return;
        }

        mc.setScreen(batvisuals.getInstance().getClickGui());
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.currentScreen instanceof ClickGui) {
            ((ClickGui) mc.currentScreen).close();
        }
    }
}
