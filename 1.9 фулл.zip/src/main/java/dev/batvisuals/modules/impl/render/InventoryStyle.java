package dev.batvisuals.modules.impl.render;

import dev.batvisuals.client.events.impl.EventHandledScreen;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import meteordevelopment.orbit.EventHandler;

/** A decorative inventory overlay; it never changes slots or container behaviour. */
public final class InventoryStyle extends Module {
    public final NumberSetting intensity = new NumberSetting("Интенсивность", 0.72f, 0.0f, 1.0f, 0.05f);
    public final BooleanSetting mirrorBlocks = new BooleanSetting("Зеркальные блоки", true);
    public final BooleanSetting accentBorder = new BooleanSetting("Акцентная рамка", true);
    public final BooleanSetting hoverHighlight = new BooleanSetting("Подсветка слота", true);

    public InventoryStyle() {
        super("InventoryStyle", Category.Render, "Стиль инвентаря");
    }

    @EventHandler
    public void onHandledScreen(EventHandledScreen event) {
        if (!isToggled() || event == null) return;
        var context = event.getDrawContext();
        int left = event.getGuiLeft();
        int top = event.getGuiTop();
        int right = left + event.getBackgroundWidth();
        int bottom = top + event.getBackgroundHeight();
        int a = Math.max(0, Math.min(120, (int) (intensity.getValue() * 120f)));

        // Glassy edge tint: deliberately thin so vanilla inventory content stays readable.
        context.fill(left, top, right, top + 1, (a << 24) | 0x8EBBFF);
        context.fill(left, bottom - 1, right, bottom, (a << 24) | 0x5478C8);
        context.fill(left, top, left + 1, bottom, (a << 24) | 0x8EBBFF);
        context.fill(right - 1, top, right, bottom, (a << 24) | 0x5478C8);

        if (Boolean.TRUE.equals(mirrorBlocks.getValue())) {
            int shine = Math.max(0, Math.min(75, (int) (intensity.getValue() * 75f)));
            int middle = top + (bottom - top) / 3;
            context.fill(left + 2, middle, right - 2, middle + 1, (shine << 24) | 0xFFFFFF);
            context.fill(left + 2, middle + 2, right - 2, middle + 3, ((shine / 2) << 24) | 0x9FC5FF);
        }

        if (Boolean.TRUE.equals(accentBorder.getValue())) {
            int glow = Math.max(0, Math.min(100, (int) (intensity.getValue() * 100f)));
            context.fill(left - 1, top - 1, right + 1, top, (glow << 24) | 0x6F9BFF);
        }

        if (Boolean.TRUE.equals(hoverHighlight.getValue()) && event.getSlotHover() != null) {
            var slot = event.getSlotHover();
            int highlight = Math.max(0, Math.min(95, (int) (intensity.getValue() * 95f)));
            context.fill(slot.x, slot.y, slot.x + 16, slot.y + 1, (highlight << 24) | 0xBBD7FF);
            context.fill(slot.x, slot.y + 15, slot.x + 16, slot.y + 16, (highlight << 24) | 0x6F9BFF);
        }
    }
}
