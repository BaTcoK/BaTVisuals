package dev.batvisuals.modules.impl.utility;

import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.client.events.impl.EventRender2D;
import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.renderer.fonts.Fonts;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;

import java.awt.Color;

/**
 * Показывает здоровье последней ударенной цели по центру экрана.
 * Без настроек (ПКМ не открывает панель настроек).
 */
public class BaTIndicator extends Module {

    private static LivingEntity target = null;
    private static int timer = 0;

    private static final int DURATION_TICKS = 180;

    static {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClient && entity instanceof LivingEntity living) {
                Module instance = dev.batvisuals.batvisuals.getInstance()
                        .getModuleManager()
                        .getModule(BaTIndicator.class);
                if (instance != null && instance.isToggled()) {
                    target = living;
                    timer = DURATION_TICKS;
                }
            }
            return ActionResult.PASS;
        });
    }

    public BaTIndicator() {
        super("BaTIndicator", Category.Utility, I18n.translate("module.batindicator.description"));
    }

    @Override
    public void onDisable() {
        super.onDisable();
        target = null;
        timer = 0;
    }

    @EventHandler
    public void onRender2D(EventRender2D e) {
        if (!isToggled()) return;
        if (target == null || timer <= 0) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        if (timer > 0) {
            timer--;
            if (timer == 0 || target.isRemoved() || target.isDead()) {
                target = null;
                return;
            }
        }

        float hp = target.getHealth();
        float max = target.getMaxHealth();
        int display = (int) Math.ceil(hp);

        // Текст без стрелок, просто число
        String text = String.valueOf(display);

        float pct = max > 0 ? hp / max : 0f;
        Color color;
        if (pct <= 0.33f) {
            color = new Color(0xFF, 0x55, 0x55);
        } else if (pct <= 0.66f) {
            color = new Color(0xFF, 0xAA, 0x00);
        } else {
            color = new Color(0x55, 0xFF, 0x55);
        }

        int w = client.getWindow().getScaledWidth();
        int h = client.getWindow().getScaledHeight();

        // Всегда ванильный шрифт, в 2 раза больше если HP 0-9
        boolean isSmallHp = display >= 0 && display <= 9;

        var textRenderer = client.textRenderer;
        var drawContext = e.getContext();

        int textWidth = textRenderer.getWidth(text);
        int x = (w - textWidth) / 2;
        int y = (int) ((h / 2f) + 15f);

        int vanillaColor = (0xFF << 24) | (color.getRed() << 16) | (color.getGreen() << 8) | color.getBlue();

        if (isSmallHp) {
            drawContext.getMatrices().push();
            drawContext.getMatrices().scale(2f, 2f, 1f);
            drawContext.drawTextWithShadow(
                textRenderer,
                Text.literal(text),
                (int) (x / 2f),
                (int) (y / 2f),
                vanillaColor
            );
            drawContext.getMatrices().pop();
        } else {
            drawContext.drawTextWithShadow(
                textRenderer,
                Text.literal(text),
                x,
                y,
                vanillaColor
            );
        }
    }
}