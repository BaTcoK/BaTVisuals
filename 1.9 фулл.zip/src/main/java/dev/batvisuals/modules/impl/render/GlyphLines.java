package dev.batvisuals.modules.impl.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.batvisuals.client.events.impl.EventRender3D;
import dev.batvisuals.client.events.impl.EventTick;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Бегущие «глиф»-линии в мире (адаптировано из предоставленного GlyphLines).
 */
public class GlyphLines extends Module {

    public final NumberSetting quantity = new NumberSetting("Quantity", 10f, 3f, 60f, 1f);
    public final BooleanSetting slow = new BooleanSetting("Slow", true);

    private final Random random = new Random(93882L);
    private final List<GlyphVector> glyphs = new ArrayList<>();
    private static final int[][] AXES = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
    private final double[] ptsX = new double[32];
    private final double[] ptsY = new double[32];
    private final double[] ptsZ = new double[32];

    public GlyphLines() {
        super("GlyphLines", Category.Render, "Линии-глифы к сущностям");
    }

    @Override
    public void onDisable() {
        glyphs.clear();
        super.onDisable();
    }

    @EventHandler
    public void onTick(EventTick event) {
        if (mc.player == null) return;

        for (int i = glyphs.size() - 1; i >= 0; --i) {
            GlyphVector g = glyphs.get(i);
            g.update();
            if (g.isExpired()) {
                glyphs.set(i, glyphs.get(glyphs.size() - 1));
                glyphs.remove(glyphs.size() - 1);
            }
        }

        if (glyphs.size() < (int) quantity.getValue().floatValue()) {
            tryAddGlyph();
        }
    }

    @EventHandler
    public void onRender3D(EventRender3D.Game event) {
        if (glyphs.isEmpty() || mc.player == null) return;

        MatrixStack stack = event.getMatrices();
        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        Matrix4f mat = stack.peek().getPositionMatrix();
        Color theme = ThemeManager.getInstance().getThemeColor();
        int tr = theme.getRed(), tg = theme.getGreen(), tb = theme.getBlue();
        long now = System.currentTimeMillis();

        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.enableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.blendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);

        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        int verts = 0;

        for (GlyphVector glyph : glyphs) {
            float alpha = (float) glyph.getFadeOut();
            if (alpha < 0.01f) continue;
            int total = glyph.fillPoints(ptsX, ptsY, ptsZ);
            if (total < 2) continue;

            float pulse = 0.65f + smoothPulse(now, glyph.seed, 3000L) * 0.35f;
            int tm1 = total - 1;
            for (int i = 0; i < tm1; i++) {
                float tA = (float) i / tm1;
                float tB = (float) (i + 1) / tm1;
                float aA = alpha * pulse * tA * tA;
                float aB = alpha * pulse * tB * tB;
                buf.vertex(mat, (float) (ptsX[i] - cam.x), (float) (ptsY[i] - cam.y), (float) (ptsZ[i] - cam.z))
                        .color(tr, tg, tb, clamp(aA));
                buf.vertex(mat, (float) (ptsX[i + 1] - cam.x), (float) (ptsY[i + 1] - cam.y), (float) (ptsZ[i + 1] - cam.z))
                        .color(tr, tg, tb, clamp(aB));
                verts += 2;
            }
        }

        if (verts > 0) {
            dev.batvisuals.client.util.render.SafeDraw.draw(buf);
        }

        // additive core pass
        RenderSystem.blendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ONE, GL11.GL_ZERO);
        buf = tess.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        verts = 0;
        for (GlyphVector glyph : glyphs) {
            float alpha = (float) glyph.getFadeOut();
            if (alpha < 0.01f) continue;
            int total = glyph.fillPoints(ptsX, ptsY, ptsZ);
            if (total < 2) continue;
            float pulse = 0.7f + smoothPulse(now, glyph.seed, 800L) * 0.3f;
            int tm1 = total - 1;
            for (int i = 0; i < tm1; i++) {
                float tA = (float) i / tm1;
                float tB = (float) (i + 1) / tm1;
                buf.vertex(mat, (float) (ptsX[i] - cam.x), (float) (ptsY[i] - cam.y), (float) (ptsZ[i] - cam.z))
                        .color(tr, tg, tb, clamp(alpha * pulse * tA * tA));
                buf.vertex(mat, (float) (ptsX[i + 1] - cam.x), (float) (ptsY[i + 1] - cam.y), (float) (ptsZ[i + 1] - cam.z))
                        .color(tr, tg, tb, clamp(alpha * pulse * tB * tB));
                verts += 2;
            }
        }
        if (verts > 0) {
            dev.batvisuals.client.util.render.SafeDraw.draw(buf);
        }

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.defaultBlendFunc();
    }

    private float smoothPulse(long now, double seed, long periodMs) {
        float t = (float) ((now + (long) (seed * 1000.0)) % periodMs) / (float) periodMs;
        float s = (float) (Math.sin(t * Math.PI * 2.0) * 0.5 + 0.5);
        return s * s * (3.0f - 2.0f * s);
    }

    private int clamp(float a) {
        return Math.max(0, Math.min(255, (int) (a * 255.0f)));
    }

    private void tryAddGlyph() {
        if (mc.player == null) return;
        float fov = (float) (Integer) mc.options.getFov().getValue();
        float baseYaw = mc.player.getYaw();
        int dist = random.nextInt(19) + 6;
        int yaw = random.nextInt((int) (fov * 1.5f) + 1) + (int) (baseYaw - fov * 0.75f);
        double rad = Math.toRadians(yaw);
        Vec3d eye = mc.player.getEyePos();
        double sx = eye.x - Math.sin(rad) * dist;
        double sy = eye.y + random.nextInt(25) - 12.0;
        double sz = eye.z + Math.cos(rad) * dist;
        glyphs.add(new GlyphVector(sx, sy, sz, random.nextInt(6) + 7, random.nextDouble() * Math.PI * 2.0));
    }

    private class GlyphVector {
        private static final int MAX_NODES = 20;
        private final double[] nodeX = new double[MAX_NODES];
        private final double[] nodeY = new double[MAX_NODES];
        private final double[] nodeZ = new double[MAX_NODES];
        private int nodeCount = 0;
        private int drawnNodes = 1;
        private double segProgress = 0;
        private final double segSpeed;
        private byte dirX, dirY, dirZ;
        private boolean fadingOut = false;
        private long fadeStart = -1L;
        private static final long FADE_MS = 700L;
        private int tailNode = 0;
        private double tailProgress = 0;
        private static final int MAX_VISIBLE = 14;
        final double seed;

        GlyphVector(double sx, double sy, double sz, int maxSteps, double seed) {
            this.seed = seed;
            nodeX[0] = sx;
            nodeY[0] = sy;
            nodeZ[0] = sz;
            nodeCount = 1;
            segSpeed = slow.getValue() ? 0.04 : 0.1;
            randomAxisDir();
            buildPath(maxSteps);
        }

        private void buildPath(int steps) {
            for (int s = 0; s < steps && nodeCount < MAX_NODES; s++) {
                nextDir();
                int len = random.nextInt(3) + 1;
                nodeX[nodeCount] = nodeX[nodeCount - 1] + dirX * len;
                nodeY[nodeCount] = nodeY[nodeCount - 1] + dirY * len;
                nodeZ[nodeCount] = nodeZ[nodeCount - 1] + dirZ * len;
                nodeCount++;
            }
        }

        private void randomAxisDir() {
            int idx = random.nextInt(AXES.length);
            dirX = (byte) AXES[idx][0];
            dirY = (byte) AXES[idx][1];
            dirZ = (byte) AXES[idx][2];
        }

        private void nextDir() {
            int count = 0;
            for (int[] axis : AXES) {
                if (axis[0] != -dirX || axis[1] != -dirY || axis[2] != -dirZ) count++;
            }
            int pick = random.nextInt(count);
            for (int[] axis : AXES) {
                if ((axis[0] != -dirX || axis[1] != -dirY || axis[2] != -dirZ) && pick-- == 0) {
                    dirX = (byte) axis[0];
                    dirY = (byte) axis[1];
                    dirZ = (byte) axis[2];
                    return;
                }
            }
        }

        void update() {
            if (fadingOut) return;
            if (drawnNodes < nodeCount) {
                segProgress += segSpeed;
                if (segProgress >= 1.0) {
                    segProgress -= 1.0;
                    drawnNodes++;
                }
            } else {
                fadingOut = true;
                fadeStart = System.currentTimeMillis();
            }
            if (drawnNodes - tailNode > MAX_VISIBLE) {
                tailProgress += segSpeed;
                if (tailProgress >= 1.0) {
                    tailProgress -= 1.0;
                    tailNode++;
                }
            }
        }

        int fillPoints(double[] xs, double[] ys, double[] zs) {
            if (nodeCount < 2) return 0;
            int from = Math.min(tailNode, nodeCount - 1);
            int to = Math.min(drawnNodes, nodeCount - 1);
            int out = 0;
            if (from < nodeCount - 1) {
                double t = tailProgress;
                xs[out] = nodeX[from] + (nodeX[from + 1] - nodeX[from]) * t;
                ys[out] = nodeY[from] + (nodeY[from + 1] - nodeY[from]) * t;
                zs[out] = nodeZ[from] + (nodeZ[from + 1] - nodeZ[from]) * t;
            } else {
                xs[out] = nodeX[from];
                ys[out] = nodeY[from];
                zs[out] = nodeZ[from];
            }
            out++;
            for (int i = from + 1; i <= to && out < xs.length; i++) {
                xs[out] = nodeX[i];
                ys[out] = nodeY[i];
                zs[out] = nodeZ[i];
                out++;
            }
            if (drawnNodes < nodeCount && out > 0) {
                out--;
                double t = segProgress;
                int dn = drawnNodes;
                xs[out] = nodeX[dn - 1] + (nodeX[dn] - nodeX[dn - 1]) * t;
                ys[out] = nodeY[dn - 1] + (nodeY[dn] - nodeY[dn - 1]) * t;
                zs[out] = nodeZ[dn - 1] + (nodeZ[dn] - nodeZ[dn - 1]) * t;
                out++;
            }
            return out;
        }

        double getFadeOut() {
            if (!fadingOut) return 1.0;
            float t = (float) (System.currentTimeMillis() - fadeStart) / FADE_MS;
            return t >= 1.0f ? 0.0 : 1.0 - (t * t * t);
        }

        boolean isExpired() {
            return fadingOut && getFadeOut() <= 0.0;
        }
    }
}
