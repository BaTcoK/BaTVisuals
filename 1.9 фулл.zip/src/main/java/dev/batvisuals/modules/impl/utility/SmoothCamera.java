package dev.batvisuals.modules.impl.utility;

import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import lombok.Getter;

/**
 * Adds first-person camera smoothness.
 * Actual interpolation is applied via MouseMixin when this module is enabled.
 */
public class SmoothCamera extends Module {

    @Getter
    private final NumberSetting delay = new NumberSetting("Delay", 30.0f, 20.0f, 50.0f, 0.5f);

    private float smoothYaw;
    private float smoothPitch;
    private boolean initialized;

    public SmoothCamera() {
        super("SmoothCamera", Category.Utility, "Плавная камера");
    }

    @Override
    public void onEnable() {
        super.onEnable();
        initialized = false;
    }

    @Override
    public void onDisable() {
        initialized = false;
        super.onDisable();
    }

    /**
     * Called from mixin with raw cursor deltas. Returns smoothed deltas [yaw, pitch].
     */
    public float[] applySmooth(float deltaYaw, float deltaPitch, float currentYaw, float currentPitch) {
        if (!initialized) {
            smoothYaw = currentYaw;
            smoothPitch = currentPitch;
            initialized = true;
        }

        // delay 20..50 → factor ~0.12..0.04
        float factor = Math.max(0.03f, Math.min(0.15f, 2.5f / Math.max(1f, delay.getValue())));

        smoothYaw += deltaYaw;
        smoothPitch += deltaPitch;

        float outYaw = (smoothYaw - currentYaw) * factor;
        float outPitch = (smoothPitch - currentPitch) * factor;

        smoothYaw = currentYaw + (smoothYaw - currentYaw) * 0.985f;
        smoothPitch = currentPitch + (smoothPitch - currentPitch) * 0.985f;

        return new float[]{outYaw, outPitch};
    }
}
