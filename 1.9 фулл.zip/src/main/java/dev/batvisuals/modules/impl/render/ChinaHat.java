package dev.batvisuals.modules.impl.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.batvisuals.client.events.impl.EventRender3D;
import dev.batvisuals.client.managers.FriendsManager;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.api.Nameable;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.EnumSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

import dev.batvisuals.client.util.EntityVisibility;

import java.awt.Color;

public class ChinaHat extends Module implements ThemeManager.ThemeChangeListener {

    public enum HatMode implements Nameable {
        DEFAULT("Дефолт"),
        DELTA("Дельта"),
        CLIENT("Клиентский");
        private final String name;
        HatMode(String name) { this.name = name; }
        @Override public String getName() { return name; }
    }

    private final EnumSetting<HatMode> mode = new EnumSetting<>("Режим", HatMode.DEFAULT);
    private final NumberSetting brimRadius = new NumberSetting("setting.brimRadius", 0.7f, 0.3f, 1.4f, 0.05f);
    private final BooleanSetting showFriends = new BooleanSetting("setting.showFriends", true);
    private final NumberSetting opacity = new NumberSetting("setting.opacity", 0.65f, 0.0f, 1.0f, 0.01f);

    private static final int FIXED_SEGMENTS = 96;
    private final ThemeManager themeManager;
    private Color currentColor;

    public ChinaHat() {
        super("ChinaHat", Category.Render, net.minecraft.client.resource.language.I18n.translate("module.chinahat.description"));
        this.themeManager = ThemeManager.getInstance();
        this.currentColor = themeManager.getThemeColor();
        themeManager.addThemeChangeListener(this);
    }

    @Override
    public void onThemeChanged(ThemeManager.Theme theme) {
        this.currentColor = theme.getAccentColor();
    }

    @EventHandler
    public void onThemeChanged(dev.batvisuals.client.events.impl.EventThemeChanged event) {
        this.currentColor = event.getTheme().getAccentColor();
    }

    @Override
    public void onDisable() {
        themeManager.removeThemeChangeListener(this);
        super.onDisable();
    }

    @EventHandler
    public void onRender3D(EventRender3D.Game e) {
        if (fullNullCheck()) return;
        float tickDelta = e.getTickDelta();
        MatrixStack matrices = e.getMatrices();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player && mc.options.getPerspective().isFirstPerson()) continue;
            if (p == mc.player) {
                renderHatForPlayer(matrices, p, tickDelta);
                continue;
            }
            if (FriendsManager.checkFriend(p.getGameProfile().getName()) && showFriends.getValue()) {
                if (!EntityVisibility.canShowCosmetic(p)) continue;
                renderHatForPlayer(matrices, p, tickDelta);
            }
        }
    }

    private Color liveColor() {
        try {
            Color c = ThemeManager.getInstance().getCurrentTheme().getAccentColor();
            if (c != null) return c;
        } catch (Throwable ignored) {}
        return currentColor != null ? currentColor : new Color(120, 90, 255);
    }

    private void renderHatForPlayer(MatrixStack matrices, PlayerEntity player, float tickDelta) {
        Vec3d pos = player.getLerpedPos(tickDelta);
        matrices.push();
        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        float eyeHeight = player.getEyeHeight(player.getPose());
        matrices.translate(pos.x - cam.x, pos.y - cam.y, pos.z - cam.z);

        float bodyYaw = MathHelper.lerp(tickDelta, player.prevBodyYaw, player.bodyYaw);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-bodyYaw));
        float basePivotY = eyeHeight - 0.15f;
        matrices.translate(0.0, basePivotY, 0.0);
        float headYawAbs = MathHelper.lerp(tickDelta, player.prevHeadYaw, player.headYaw);
        float netHeadYaw = headYawAbs - bodyYaw;
        float headPitch = MathHelper.lerp(tickDelta, player.prevPitch, player.getPitch());
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-netHeadYaw));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(headPitch));

        float baseToCrown = player.isInSneakingPose() ? 0.305f : 0.265f;
        float pitchRad = (float) Math.toRadians(MathHelper.clamp(headPitch, -90.0f, 90.0f));
        float cosPitch = MathHelper.clamp((float) Math.cos(pitchRad), 0.0f, 1.0f);
        float tiltFactor = 1.0f - cosPitch;
        float upMul = headPitch < 0.0f ? 1.6f : 1.0f;
        float clearance = 0.03f * cosPitch + (headPitch < 0.0f ? 0.008f * tiltFactor : 0.0f);
        float dynamicOffset = -0.05f + 0.04f + 0.08f * tiltFactor * upMul;
        float forwardOffset = -0.06f * tiltFactor * Math.signum(headPitch) * upMul;
        matrices.translate(0.0, (baseToCrown + clearance) + dynamicOffset, forwardOffset);

        Color color = liveColor();
        float radius = brimRadius.getValue().floatValue();
        if (mode.getValue() == HatMode.DELTA) {
            // Delta style: конус вверх (как обычная шляпа)
            float r = (float) (player.getBoundingBox().maxX - player.getBoundingBox().minX);
            if (r < 0.2f) r = radius;
            else r = r * 0.55f + 0.15f;
            r = MathHelper.clamp(r, 0.35f, 1.2f) * (radius / 0.7f);
            renderDeltaHat(matrices, r, color);
        } else if (mode.getValue() == HatMode.CLIENT) {
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(
                    (float) (System.currentTimeMillis() % 36000L) / 100.0f));
            renderClientHat(matrices, radius * 0.85f, 0.3f, color);
        } else {
            renderConeHatHollow(matrices, radius, 0.35f, color, FIXED_SEGMENTS);
        }
        matrices.pop();
    }

    /** Original BaT cone hat. */
    private void renderConeHatHollow(MatrixStack matrices, float radius, float height, Color color, int segs) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.enableDepthTest();
        RenderSystem.depthFunc(GL11.GL_LEQUAL);
        RenderSystem.depthMask(true);
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        GL11.glDisable(GL11.GL_CULL_FACE);

        Matrix4f m = matrices.peek().getPositionMatrix();
        Tessellator tess = Tessellator.getInstance();
        float r = color.getRed() / 255f;
        float g = color.getGreen() / 255f;
        float b = color.getBlue() / 255f;
        float tipAlpha = MathHelper.clamp(opacity.getValue().floatValue(), 0.0f, 1.0f);
        float baseAlpha = MathHelper.clamp(tipAlpha * 0.7f, 0.0f, 1.0f);
        float tipY = height;

        BufferBuilder coneStrip = tess.begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i <= segs; i++) {
            double a = (i / (double) segs) * Math.PI * 2.0;
            float x = (float) (Math.cos(a) * radius);
            float z = (float) (Math.sin(a) * radius);
            coneStrip.vertex(m, x, 0f, z).color(r, g, b, baseAlpha);
            coneStrip.vertex(m, 0f, tipY, 0f).color(r, g, b, tipAlpha);
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(coneStrip);
        GL11.glEnable(GL11.GL_CULL_FACE);
    }

    /**
     * Delta-style hat: конус остриём вверх, основание внизу
     */
    private void renderDeltaHat(MatrixStack matrices, float radius, Color baseColor) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.enableDepthTest();
        RenderSystem.depthFunc(GL11.GL_LEQUAL);
        RenderSystem.depthMask(true);
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        GL11.glDisable(GL11.GL_CULL_FACE);

        Matrix4f matrix = matrices.peek().getPositionMatrix();
        Tessellator tess = Tessellator.getInstance();
        float alpha = MathHelper.clamp(opacity.getValue().floatValue(), 0.05f, 1.0f);
        int baseR = baseColor.getRed(), baseG = baseColor.getGreen(), baseB = baseColor.getBlue();
        int baseA = MathHelper.clamp((int) (255 * alpha), 0, 255);
        int dimR = Math.max(0, (int) (baseR * 0.5f));
        int dimG = Math.max(0, (int) (baseG * 0.5f));
        int dimB = Math.max(0, (int) (baseB * 0.5f));
        long time = System.currentTimeMillis();
        float tipY = 0.3f; // Кончик ВВЕРХУ

        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < 360; i++) {
            float angle1 = i * 0.017453292f;
            float angle2 = (i + 1) * 0.017453292f;
            float wave = 0.55f + 0.45f * (float) Math.sin((i * 8 + time * 0.08) * 0.017453292f);
            int cr = MathHelper.clamp((int) (dimR + (baseR - dimR) * wave), 0, 255);
            int cg = MathHelper.clamp((int) (dimG + (baseG - dimG) * wave), 0, 255);
            int cb = MathHelper.clamp((int) (dimB + (baseB - dimB) * wave), 0, 255);
            float x1 = MathHelper.sin(angle1) * radius;
            float z1 = MathHelper.cos(angle1) * radius;
            float x2 = MathHelper.sin(angle2) * radius;
            float z2 = MathHelper.cos(angle2) * radius;
            // Основание внизу (y=0), кончик вверху (y=tipY)
            buf.vertex(matrix, x1, 0f, z1).color(cr, cg, cb, baseA);
            buf.vertex(matrix, x2, 0f, z2).color(cr, cg, cb, baseA);
            buf.vertex(matrix, 0f, tipY, 0f).color(baseR, baseG, baseB, baseA);
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(buf);

        // Ободок внизу
        float radiusOuter = radius + 0.01f;
        float radiusInner = Math.max(0.05f, radius - 0.01f);
        float prevOuterX = MathHelper.sin(0f) * radiusOuter;
        float prevOuterZ = MathHelper.cos(0f) * radiusOuter;
        float prevInnerX = MathHelper.sin(0f) * radiusInner;
        float prevInnerZ = MathHelper.cos(0f) * radiusInner;
        BufferBuilder rim = tess.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (int i = 1; i <= 180; i++) {
            float angle = i * (float) (Math.PI * 2.0 / 180.0);
            float wave = 0.55f + 0.45f * (float) Math.sin(((i - 1) * 8 + time * 0.08) * 0.017453292f);
            int cr = MathHelper.clamp((int) (dimR + (baseR - dimR) * wave), 0, 255);
            int cg = MathHelper.clamp((int) (dimG + (baseG - dimG) * wave), 0, 255);
            int cb = MathHelper.clamp((int) (dimB + (baseB - dimB) * wave), 0, 255);
            float outerX = MathHelper.sin(angle) * radiusOuter;
            float outerZ = MathHelper.cos(angle) * radiusOuter;
            float innerX = MathHelper.sin(angle) * radiusInner;
            float innerZ = MathHelper.cos(angle) * radiusInner;
            // Вертикальная стенка ободка
            rim.vertex(matrix, prevOuterX, -0.01f, prevOuterZ).color(cr, cg, cb, baseA);
            rim.vertex(matrix, prevOuterX, 0f, prevOuterZ).color(cr, cg, cb, baseA);
            rim.vertex(matrix, outerX, 0f, outerZ).color(cr, cg, cb, baseA);
            rim.vertex(matrix, outerX, -0.01f, outerZ).color(cr, cg, cb, baseA);
            // Верхняя полоска ободка
            rim.vertex(matrix, prevInnerX, 0f, prevInnerZ).color(cr, cg, cb, baseA);
            rim.vertex(matrix, innerX, 0f, innerZ).color(cr, cg, cb, baseA);
            rim.vertex(matrix, outerX, 0f, outerZ).color(cr, cg, cb, baseA);
            rim.vertex(matrix, prevOuterX, 0f, prevOuterZ).color(cr, cg, cb, baseA);
            prevOuterX = outerX;
            prevOuterZ = outerZ;
            prevInnerX = innerX;
            prevInnerZ = innerZ;
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(rim);
        GL11.glEnable(GL11.GL_CULL_FACE);
    }

    /** Клиентский стиль: TRIANGLE_FAN конус + кольцо-обводка */
    private void renderClientHat(MatrixStack matrices, float radius, float height, Color themeColor) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        RenderSystem.enableDepthTest();
        RenderSystem.depthFunc(GL11.GL_LEQUAL);
        RenderSystem.depthMask(false);
        GL11.glDisable(GL11.GL_CULL_FACE);

        Matrix4f m = matrices.peek().getPositionMatrix();
        Tessellator tess = Tessellator.getInstance();
        float alpha = MathHelper.clamp(opacity.getValue().floatValue(), 0.05f, 1.0f);
        int tipA = MathHelper.clamp((int) (255 * alpha * 0.95f), 0, 255);
        int baseA = MathHelper.clamp((int) (255 * alpha * 0.5f), 0, 255);
        int r = themeColor.getRed(), g = themeColor.getGreen(), b = themeColor.getBlue();
        int steps = 64;
        double angleStep = Math.PI * 2.0 / steps;

        BufferBuilder cone = tess.begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
        cone.vertex(m, 0f, height, 0f).color(r, g, b, tipA);
        for (int i = 0; i <= steps; i++) {
            float x = (float) (Math.cos(i * angleStep) * radius);
            float z = (float) (Math.sin(i * angleStep) * radius);
            cone.vertex(m, x, 0f, z).color(r, g, b, baseA);
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(cone);

        // outline ring
        RenderSystem.lineWidth(2.0f);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        BufferBuilder ring = tess.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < steps; i++) {
            float x1 = (float) (Math.cos(i * angleStep) * radius);
            float z1 = (float) (Math.sin(i * angleStep) * radius);
            float x2 = (float) (Math.cos((i + 1) * angleStep) * radius);
            float z2 = (float) (Math.sin((i + 1) * angleStep) * radius);
            ring.vertex(m, x1, 0f, z1).color(r, g, b, tipA);
            ring.vertex(m, x2, 0f, z2).color(r, g, b, tipA);
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(ring);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        RenderSystem.lineWidth(1.0f);

        RenderSystem.depthMask(true);
        GL11.glEnable(GL11.GL_CULL_FACE);
        RenderSystem.defaultBlendFunc();
    }
}