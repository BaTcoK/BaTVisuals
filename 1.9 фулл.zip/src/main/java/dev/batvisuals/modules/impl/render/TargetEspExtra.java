package dev.batvisuals.modules.impl.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.batvisuals.batvisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.awt.Color;

/**
 * Extra TargetESP modes ported from Rich: Cube, Circle V2, Ghost V2, Garland, Atom.
 */
public final class TargetEspExtra {

    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static final Identifier BLOOM = batvisuals.id("hud/bloom.png");
    private static final Identifier GLOW = batvisuals.id("hud/glow.png");

    private TargetEspExtra() {}

    private static Vec3d lerp(LivingEntity e, float td) {
        return new Vec3d(
                MathHelper.lerp(td, e.lastRenderX, e.getX()),
                MathHelper.lerp(td, e.lastRenderY, e.getY()),
                MathHelper.lerp(td, e.lastRenderZ, e.getZ())
        );
    }

    private static Vec3d cam() {
        return mc.gameRenderer.getCamera().getPos();
    }

    private static int argb(Color c, float a) {
        int aa = MathHelper.clamp((int) (c.getAlpha() * a), 0, 255);
        return (aa << 24) | (c.getRed() << 16) | (c.getGreen() << 8) | c.getBlue();
    }

    private static void setupAdditive() {
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.disableDepthTest();
    }

    private static void restore() {
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    private static void billboard(BufferBuilder bb, MatrixStack ms, float x, float y, float z,
                                  float scale, float yaw, float pitch, int color) {
        ms.push();
        ms.translate(x, y, z);
        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-yaw));
        ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pitch));
        Matrix4f m = ms.peek().getPositionMatrix();
        bb.vertex(m, -scale, -scale, 0).texture(0, 0).color(color);
        bb.vertex(m, -scale, scale, 0).texture(0, 1).color(color);
        bb.vertex(m, scale, scale, 0).texture(1, 1).color(color);
        bb.vertex(m, scale, -scale, 0).texture(1, 0).color(color);
        ms.pop();
    }

    // ─── Cube ───────────────────────────────────────────────
    public static void renderCube(MatrixStack ms, LivingEntity entity, float td, float anim, Color color, float speed) {
        if (entity == null || anim <= 0.01f) return;
        Vec3d pos = lerp(entity, td).subtract(cam());
        float h = entity.getHeight();
        float w = entity.getWidth();
        float t = (System.currentTimeMillis() % 100000L) / 1000f * speed;

        ms.push();
        ms.translate(pos.x, pos.y + h * 0.5, pos.z);
        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(t * 45f));
        ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(t * 20f));
        float s = (0.55f + w * 0.35f) * anim * 0.25f; // 4x smaller than original default

        setupAdditive();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        Matrix4f m = ms.peek().getPositionMatrix();
        BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        int c = argb(color, anim);
        float[][] v = {
                {-s, -s, -s}, {s, -s, -s}, {s, s, -s}, {-s, s, -s},
                {-s, -s, s}, {s, -s, s}, {s, s, s}, {-s, s, s}
        };
        int[][] edges = {
                {0,1},{1,2},{2,3},{3,0},
                {4,5},{5,6},{6,7},{7,4},
                {0,4},{1,5},{2,6},{3,7}
        };
        for (int[] e : edges) {
            bb.vertex(m, v[e[0]][0], v[e[0]][1], v[e[0]][2]).color(c);
            bb.vertex(m, v[e[1]][0], v[e[1]][1], v[e[1]][2]).color(c);
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(bb);

        // face glow quads
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, GLOW);
        BufferBuilder q = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        int soft = argb(color, anim * 0.25f);
        float f = s * 0.92f;
        // +Z / -Z
        q.vertex(m, -f, -f, f).texture(0, 0).color(soft);
        q.vertex(m, -f, f, f).texture(0, 1).color(soft);
        q.vertex(m, f, f, f).texture(1, 1).color(soft);
        q.vertex(m, f, -f, f).texture(1, 0).color(soft);
        q.vertex(m, -f, -f, -f).texture(0, 0).color(soft);
        q.vertex(m, f, -f, -f).texture(1, 0).color(soft);
        q.vertex(m, f, f, -f).texture(1, 1).color(soft);
        q.vertex(m, -f, f, -f).texture(0, 1).color(soft);
        dev.batvisuals.client.util.render.SafeDraw.draw(q);
        restore();
        ms.pop();
    }

    // ─── Circle V2 (kolco with tails) ───────────────────────
    public static void renderCircleV2(MatrixStack ms, LivingEntity entity, float td, float anim, Color color, float speed, double step) {
        if (entity == null || anim <= 0.01f) return;
        Vec3d pos = lerp(entity, td).subtract(cam());
        float w = entity.getWidth() * 0.9f;
        float h = entity.getHeight();
        Camera cam = mc.gameRenderer.getCamera();
        float yaw = cam.getYaw();
        float pitch = cam.getPitch();

        double currentStep = step;
        double headY = Math.abs(Math.sin(currentStep)) * h;
        double tailY = Math.abs(Math.sin(currentStep - 0.4)) * h;

        setupAdditive();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, BLOOM);
        BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        int points = 96;
        int tails = 12;
        for (int i = 0; i < points; i++) {
            double ang = 2 * Math.PI * i / points;
            float xo = (float) (Math.cos(ang) * w);
            float zo = (float) (Math.sin(ang) * w);
            int core = argb(color, anim * 0.9f);
            billboard(bb, ms, (float) pos.x + xo, (float) (pos.y + headY), (float) pos.z + zo, 0.11f, yaw, pitch, core);
            for (int t = 1; t <= tails; t++) {
                float p = (float) t / (tails + 1);
                double ty = headY + (tailY - headY) * p;
                int tc = argb(color, anim * (1f - p) * 0.55f);
                billboard(bb, ms, (float) pos.x + xo, (float) (pos.y + ty), (float) pos.z + zo, 0.07f, yaw, pitch, tc);
            }
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(bb);
        restore();
    }

    // ─── Ghost V2 (double helix) ────────────────────────────
    public static void renderGhostV2(MatrixStack ms, LivingEntity entity, float td, float anim, Color color, float speed) {
        if (entity == null || anim <= 0.01f) return;
        Vec3d pos = lerp(entity, td).subtract(cam());
        float h = entity.getHeight();
        float rad = entity.getWidth() * 0.85f;
        float time = (System.currentTimeMillis() % 100000L) / 1000f * speed;
        Camera cam = mc.gameRenderer.getCamera();

        setupAdditive();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, GLOW);
        BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        int segs = 48;
        for (int strand = 0; strand < 2; strand++) {
            double phase = strand * Math.PI;
            for (int i = 0; i < segs; i++) {
                float p = (float) i / segs;
                double ang = time * 2.2 + p * Math.PI * 4 + phase;
                float x = (float) (Math.cos(ang) * rad);
                float z = (float) (Math.sin(ang) * rad);
                float y = p * h;
                float size = 0.12f * anim * (0.7f + 0.3f * (float) Math.sin(time * 4 + i));
                int c = argb(color, anim * (1f - p * 0.35f));
                billboard(bb, ms, (float) pos.x + x, (float) pos.y + y, (float) pos.z + z, size, cam.getYaw(), cam.getPitch(), c);
            }
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(bb);
        restore();
    }

    // ─── Garland ────────────────────────────────────────────
    public static void renderGarland(MatrixStack ms, LivingEntity entity, float td, float anim, Color color, float speed) {
        if (entity == null || anim <= 0.01f) return;
        Vec3d pos = lerp(entity, td).subtract(cam());
        float h = entity.getHeight();
        float radius = entity.getWidth() * 0.9f + 0.15f;
        float time = (System.currentTimeMillis() % 100000L) / 1000f * speed;
        Camera cam = mc.gameRenderer.getCamera();
        int lights = 36;
        float spirals = 2.2f;
        float offset = time * 90f;

        setupAdditive();
        // wire
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder wire = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
        Matrix4f id = new Matrix4f();
        int wireC = argb(color, anim * 0.45f);
        for (int i = 0; i <= lights; i++) {
            float progress = (float) i / lights;
            float angle = (float) Math.toRadians(offset + progress * 360f * spirals);
            float r = radius * (1.0f - progress * 0.55f);
            float x = (float) (pos.x + Math.cos(angle) * r);
            float z = (float) (pos.z + Math.sin(angle) * r);
            float y = (float) (pos.y + progress * h);
            wire.vertex(id, x, y, z).color(wireC);
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(wire);

        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, BLOOM);
        BufferBuilder bulbs = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        for (int i = 0; i <= lights; i++) {
            float progress = (float) i / lights;
            float angle = (float) Math.toRadians(offset + progress * 360f * spirals);
            float r = radius * (1.0f - progress * 0.55f);
            float x = (float) (pos.x + Math.cos(angle) * r);
            float z = (float) (pos.z + Math.sin(angle) * r);
            float y = (float) (pos.y + progress * h);
            float size = 0.14f * anim;
            float twinkle = (float) Math.sin(time * 8 + i) * 0.2f + 0.8f;
            int c = festive(i, anim * twinkle);
            billboard(bulbs, ms, x, y, z, size, cam.getYaw(), cam.getPitch(), c);
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(bulbs);
        restore();
    }

    private static int festive(int index, float a) {
        int type = index & 3;
        int rgb = switch (type) {
            case 0 -> 0xFF0000;
            case 1 -> 0xFFD700;
            case 2 -> 0x00FF00;
            default -> 0x00BFFF;
        };
        int aa = MathHelper.clamp((int) (255 * a), 0, 255);
        return (aa << 24) | rgb;
    }

    // ─── Atom ───────────────────────────────────────────────
    public static void renderAtom(MatrixStack ms, LivingEntity entity, float td, float anim, Color color, float speed, int particles) {
        if (entity == null || anim <= 0.01f) return;
        Vec3d pos = lerp(entity, td).subtract(cam());
        float h = entity.getHeight();
        float time = (System.currentTimeMillis() % 100000L) / 1000f * speed;
        Camera cam = mc.gameRenderer.getCamera();

        ms.push();
        ms.translate(pos.x, pos.y + h * 0.5, pos.z);
        float scale = 0.7f * anim;
        ms.scale(scale, scale, scale);

        setupAdditive();
        float radius = 1.0f;
        int segments = 120;
        float ringSpin = time * 78f;
        int total = Math.max(3, particles);
        int base = Math.max(1, total / 3);
        int rem = total % 3;

        for (int ring = 0; ring < 3; ring++) {
            ms.push();
            float wobble = (float) Math.sin(time * 1.35f + ring * 0.9f) * 7.5f;
            ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(ring * 60f + wobble));
            ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(ringSpin + ring * 120f));

            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
            Matrix4f matrix = ms.peek().getPositionMatrix();
            for (int i = 0; i <= segments; i++) {
                float ang = (float) (2 * Math.PI * i / segments);
                float x = (float) Math.cos(ang) * radius;
                float z = (float) Math.sin(ang) * radius;
                int segC = argb(color, anim * 0.65f);
                bb.vertex(matrix, x, 0, z).color(segC);
            }
            dev.batvisuals.client.util.render.SafeDraw.draw(bb);

            int eCount = base + (rem > 0 && ring < rem ? 1 : 0);
            float eSpeed = 2.15f + ring * 0.35f;
            for (int p = 0; p < eCount; p++) {
                float baseAng = (float) (2 * Math.PI * p / eCount);
                float theta = time * eSpeed + baseAng + ring * 0.82f;
                float px = (float) Math.cos(theta) * radius;
                float pz = (float) Math.sin(theta) * radius;
                float pulse = 0.92f + 0.08f * (float) Math.sin(time * 6.6f + ring + p);
                float s = 0.08f * anim * pulse;
                int pc = argb(color, anim * 0.9f);

                ms.push();
                ms.translate(px, 0, pz);
                RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
                Matrix4f m = ms.peek().getPositionMatrix();
                BufferBuilder sph = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
                sph.vertex(m, -s, -s, 0).color(pc);
                sph.vertex(m, -s, s, 0).color(pc);
                sph.vertex(m, s, s, 0).color(pc);
                sph.vertex(m, s, -s, 0).color(pc);
                dev.batvisuals.client.util.render.SafeDraw.draw(sph);

                RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
                RenderSystem.setShaderTexture(0, BLOOM);
                BufferBuilder glow = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
                billboard(glow, ms, 0, 0, 0, s * 2.2f, cam.getYaw(), cam.getPitch(), argb(color, anim * 0.35f));
                dev.batvisuals.client.util.render.SafeDraw.draw(glow);
                ms.pop();
            }
            ms.pop();
        }

        // nucleus
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, BLOOM);
        BufferBuilder core = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        billboard(core, ms, 0, 0, 0, 0.18f * anim, cam.getYaw(), cam.getPitch(), argb(color, anim * 0.9f));
        billboard(core, ms, 0, 0, 0, 0.32f * anim, cam.getYaw(), cam.getPitch(), argb(color, anim * 0.35f));
        dev.batvisuals.client.util.render.SafeDraw.draw(core);

        restore();
        ms.pop();
    }


    // ─── GUI-local variants (matrix already at entity center, +Y up, 1=block) ───

    public static void renderCubeLocal(MatrixStack ms, float anim, Color color, float speed, float w, float h) {
        float t = (System.currentTimeMillis() % 100000L) / 1000f * speed;
        ms.push();
        ms.translate(0, 0, 0);
        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(t * 45f));
        ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(t * 20f));
        float s = (0.55f + w * 0.35f) * anim * 0.25f;
        setupAdditive();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        Matrix4f m = ms.peek().getPositionMatrix();
        BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        int c = argb(color, anim);
        float[][] v = {{-s,-s,-s},{s,-s,-s},{s,s,-s},{-s,s,-s},{-s,-s,s},{s,-s,s},{s,s,s},{-s,s,s}};
        int[][] edges = {{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
        for (int[] e : edges) {
            bb.vertex(m, v[e[0]][0], v[e[0]][1], v[e[0]][2]).color(c);
            bb.vertex(m, v[e[1]][0], v[e[1]][1], v[e[1]][2]).color(c);
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(bb);
        restore();
        ms.pop();
    }

    public static void renderCircleV2Local(MatrixStack ms, float anim, Color color, float speed, double step, float w, float h) {
        float radius = w * 0.9f;
        double headY = Math.abs(Math.sin(step)) * h - h * 0.5;
        Camera cam = mc.gameRenderer.getCamera();
        setupAdditive();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, BLOOM);
        BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        int points = 64;
        for (int i = 0; i < points; i++) {
            double ang = 2 * Math.PI * i / points;
            float xo = (float) (Math.cos(ang) * radius);
            float zo = (float) (Math.sin(ang) * radius);
            billboard(bb, ms, xo, (float) headY, zo, 0.1f, cam.getYaw(), cam.getPitch(), argb(color, anim * 0.9f));
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(bb);
        restore();
    }

    public static void renderGhostV2Local(MatrixStack ms, float anim, Color color, float speed, float w, float h) {
        float rad = w * 0.85f;
        float time = (System.currentTimeMillis() % 100000L) / 1000f * speed;
        Camera cam = mc.gameRenderer.getCamera();
        setupAdditive();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, GLOW);
        BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        int segs = 40;
        for (int strand = 0; strand < 2; strand++) {
            double phase = strand * Math.PI;
            for (int i = 0; i < segs; i++) {
                float p = (float) i / segs;
                double ang = time * 2.2 + p * Math.PI * 4 + phase;
                float x = (float) (Math.cos(ang) * rad);
                float z = (float) (Math.sin(ang) * rad);
                float y = p * h - h * 0.5f;
                float size = 0.1f * anim;
                billboard(bb, ms, x, y, z, size, cam.getYaw(), cam.getPitch(), argb(color, anim * (1f - p * 0.3f)));
            }
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(bb);
        restore();
    }

    public static void renderGarlandLocal(MatrixStack ms, float anim, Color color, float speed, float w, float h) {
        float radius = w * 0.9f + 0.15f;
        float time = (System.currentTimeMillis() % 100000L) / 1000f * speed;
        Camera cam = mc.gameRenderer.getCamera();
        int lights = 28;
        float offset = time * 90f;
        setupAdditive();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, BLOOM);
        BufferBuilder bulbs = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        for (int i = 0; i <= lights; i++) {
            float progress = (float) i / lights;
            float angle = (float) Math.toRadians(offset + progress * 360f * 2.2f);
            float r = radius * (1.0f - progress * 0.55f);
            float x = (float) (Math.cos(angle) * r);
            float z = (float) (Math.sin(angle) * r);
            float y = progress * h - h * 0.5f;
            billboard(bulbs, ms, x, y, z, 0.12f * anim, cam.getYaw(), cam.getPitch(), festive(i, anim));
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(bulbs);
        restore();
    }

    public static void renderAtomLocal(MatrixStack ms, float anim, Color color, float speed, int particles, float h) {
        float time = (System.currentTimeMillis() % 100000L) / 1000f * speed;
        ms.push();
        ms.scale(0.7f * anim / 1.3f, 0.7f * anim / 1.3f, 0.7f * anim / 1.3f);
        setupAdditive();
        float radius = 1.0f;
        int segments = 80;
        float ringSpin = time * 78f;
        int total = Math.max(3, particles);
        int base = Math.max(1, total / 3);
        for (int ring = 0; ring < 3; ring++) {
            ms.push();
            ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(ring * 60f));
            ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(ringSpin + ring * 120f));
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
            Matrix4f matrix = ms.peek().getPositionMatrix();
            int segC = argb(color, anim * 0.65f);
            for (int i = 0; i <= segments; i++) {
                float ang = (float) (2 * Math.PI * i / segments);
                bb.vertex(matrix, (float) Math.cos(ang) * radius, 0, (float) Math.sin(ang) * radius).color(segC);
            }
            dev.batvisuals.client.util.render.SafeDraw.draw(bb);
            ms.pop();
        }
        restore();
        ms.pop();
    }

    public static void renderCrystalsLocal(MatrixStack ms, float anim, Color color, float speed, float rad, int count, float size, float h) {
        double time = System.currentTimeMillis() / 1000.0 * speed;
        setupAdditive();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        Matrix4f m = ms.peek().getPositionMatrix();
        BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
        float r = color.getRed() / 255f, g = color.getGreen() / 255f, b = color.getBlue() / 255f, a = anim;
        int n = Math.max(6, count);
        float s = size * anim * 2f;
        for (int i = 0; i < n; i++) {
            double progress = (double) i / n;
            double spiral = progress * Math.PI * 4 + time;
            float x = (float) (Math.cos(spiral) * rad * (0.5 + progress * 0.5));
            float z = (float) (Math.sin(spiral) * rad * (0.5 + progress * 0.5));
            float y = (float) (progress * h - h * 0.5);
            // tiny octahedron
            bb.vertex(m, x, y + s, z).color(r, g, b, a);
            bb.vertex(m, x - s, y, z).color(r, g, b, a * 0.7f);
            bb.vertex(m, x, y, z - s).color(r, g, b, a * 0.7f);
            bb.vertex(m, x, y + s, z).color(r, g, b, a);
            bb.vertex(m, x, y, z - s).color(r, g, b, a * 0.7f);
            bb.vertex(m, x + s, y, z).color(r, g, b, a * 0.7f);
            bb.vertex(m, x, y + s, z).color(r, g, b, a);
            bb.vertex(m, x + s, y, z).color(r, g, b, a * 0.7f);
            bb.vertex(m, x, y, z + s).color(r, g, b, a * 0.7f);
            bb.vertex(m, x, y + s, z).color(r, g, b, a);
            bb.vertex(m, x, y, z + s).color(r, g, b, a * 0.7f);
            bb.vertex(m, x - s, y, z).color(r, g, b, a * 0.7f);
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(bb);
        restore();
    }

    public static void renderChainsLocal(MatrixStack ms, float anim, Color color, float speed, float rad, float heightMul, int segs, float h) {
        float phase = (System.currentTimeMillis() % 100000L) / 1000f * speed;
        float radius = rad * 0.9f;
        float heightGap = Math.max(0.4f, heightMul * h);
        segs = Math.max(8, segs);
        setupAdditive();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, Identifier.of("batvisuals", "textures/chains.png"));
        for (int layer = 0; layer < 2; layer++) {
            float y = -h * 0.2f + heightGap * (layer == 0 ? 0.28f : 0.88f);
            float r = radius * (layer == 0 ? 1f : 1.1f);
            float ph = layer == 0 ? phase : -phase * 1.2f;
            BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            Matrix4f matrix = ms.peek().getPositionMatrix();
            float rr = color.getRed() / 255f, gg = color.getGreen() / 255f, bb = color.getBlue() / 255f, aa = anim * 0.95f;
            float linkH = 0.18f;
            for (int i = 0; i < segs; i++) {
                double a0 = ph + i * (Math.PI * 2.0 / segs);
                double a1 = ph + (i + 1) * (Math.PI * 2.0 / segs);
                float x0 = (float) (Math.cos(a0) * r), z0 = (float) (Math.sin(a0) * r);
                float x1 = (float) (Math.cos(a1) * r), z1 = (float) (Math.sin(a1) * r);
                buffer.vertex(matrix, x0, y - linkH, z0).texture(0, 1).color(rr, gg, bb, aa);
                buffer.vertex(matrix, x1, y - linkH, z1).texture(1, 1).color(rr, gg, bb, aa);
                buffer.vertex(matrix, x1, y + linkH, z1).texture(1, 0).color(rr, gg, bb, aa);
                buffer.vertex(matrix, x0, y + linkH, z0).texture(0, 0).color(rr, gg, bb, aa);
            }
            dev.batvisuals.client.util.render.SafeDraw.draw(buffer);
        }
        restore();
    }

    public static void renderJelloLocal(MatrixStack ms, float anim, Color color, float jelloH, float animSpeed, float h) {
        float phase = (System.currentTimeMillis() % Math.max(1L, (long) animSpeed)) / Math.max(1f, animSpeed);
        float yOff = (float) Math.sin(phase * Math.PI * 2) * 0.15f;
        float height = jelloH * anim;
        float rad = 0.45f;
        setupAdditive();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        Matrix4f m = ms.peek().getPositionMatrix();
        BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
        int c = argb(color, anim * 0.8f);
        int segs = 48;
        for (int i = 0; i <= segs; i++) {
            float ang = (float) (2 * Math.PI * i / segs);
            bb.vertex(m, (float) Math.cos(ang) * rad, yOff - height * 0.3f, (float) Math.sin(ang) * rad).color(c);
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(bb);
        restore();
    }

    public static void renderGhostsLocal(MatrixStack ms, float anim, Color color, float scale, int density, float h) {
        Camera cam = mc.gameRenderer.getCamera();
        setupAdditive();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, GLOW);
        BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        int n = Math.max(5, density);
        float sc = scale * 0.35f * anim;
        long now = System.currentTimeMillis();
        for (int i = 0; i < n; i++) {
            double ang = now / 700.0 + i * (Math.PI * 2.0 / n);
            float x = (float) Math.cos(ang) * 0.55f;
            float z = (float) Math.sin(ang) * 0.55f;
            float y = (float) Math.sin(ang * 1.4 + i) * 0.5f;
            billboard(bb, ms, x, y, z, sc, cam.getYaw(), cam.getPitch(), argb(color, anim * 0.7f));
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(bb);
        restore();
    }

    public static void renderMarkerLocal(MatrixStack ms, float anim, Color color, float scale, float h) {
        Camera cam = mc.gameRenderer.getCamera();
        float size = 0.25f + scale * 0.05f;
        setupAdditive();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, GLOW);
        BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        billboard(bb, ms, 0, 0.2f, 0, size * anim, cam.getYaw(), cam.getPitch(), argb(color, anim));
        dev.batvisuals.client.util.render.SafeDraw.draw(bb);
        restore();
    }

}
