package dev.batvisuals.modules.impl.utility;

import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.util.DiscordRichPresenceUtil;
import net.minecraft.client.resource.language.I18n;

public class DiscordRPCModule extends Module {
    public DiscordRPCModule() {
        super("DiscordRPC", Category.Utility, I18n.translate("module.discordrpc.description"));
    }

    @Override
    public void onEnable() {
        super.onEnable();
        try {
            DiscordRichPresenceUtil.discordrpc();
        } catch (Throwable t) {
            setToggled(false);
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        try {
            DiscordRichPresenceUtil.shutdownDiscord();
        } catch (Throwable ignored) {}
    }
}
