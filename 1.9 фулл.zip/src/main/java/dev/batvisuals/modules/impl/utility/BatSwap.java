package dev.batvisuals.modules.impl.utility;

import dev.batvisuals.client.ChatUtils;
import dev.batvisuals.client.events.impl.EventTick;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.api.Bind;
import dev.batvisuals.modules.settings.impl.BindSetting;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.ListSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

public class BatSwap extends Module {

    private final ListSetting swapFrom = new ListSetting("Свапать что", true,
            new BooleanSetting("Тотем", true),
            new BooleanSetting("Щит", false),
            new BooleanSetting("Сфера", false),
            new BooleanSetting("Гепл", false),
            new BooleanSetting("Чарка", false)
    );

    private final ListSetting swapTo = new ListSetting("На", true,
            new BooleanSetting("Тотем", false),
            new BooleanSetting("Щит", false),
            new BooleanSetting("Сфера", true),
            new BooleanSetting("Гепл", false),
            new BooleanSetting("Чарка", false)
    );

    private final BindSetting swapBind = new BindSetting("Бинд", new Bind(GLFW.GLFW_KEY_R, false));

    // Константа для стопа: 4 тика = 200 мс
    private static final int STOP_TICKS = 4;

    // Состояние
    private int cooldownTicks = 0;
    private int stopTicks = 0;
    private boolean isWaitingToSwap = false;
    private int pendingSlot = -1;
    private String pendingLabel = "";
    private boolean bindLatch = false;
    private boolean movementLocked = false;

    public BatSwap() {
        super("BatSwap", Category.Utility, "Свап предмета в оффхенд");
    }

    @Override
    public void onDisable() {
        resetState();
        super.onDisable();
    }

    @EventHandler
    public void onTick(EventTick e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.interactionManager == null) {
            resetState();
            return;
        }

        if (!isToggled()) {
            resetState();
            return;
        }

        if (cooldownTicks > 0) {
            cooldownTicks--;
        }

        if (isWaitingToSwap) {
            stopMovement(mc);
            
            stopTicks--;
            if (stopTicks <= 0) {
                executeSwap(mc);
            }
            return;
        }

        long window = mc.getWindow().getHandle();
        boolean down = isBindDown(window, swapBind.getValue());

        if (down && !bindLatch) {
            bindLatch = true;
            if (cooldownTicks == 0) {
                startSwapProcess(mc);
            }
        } else if (!down) {
            bindLatch = false;
        }
    }

    private void startSwapProcess(MinecraftClient mc) {
        String fromLabel = getSelectedName(swapFrom);
        String toLabel = getSelectedName(swapTo);
        
        if (fromLabel == null || toLabel == null) return;

        Item offhandItem = mc.player.getOffHandStack().getItem();
        
        Item targetItem = null;
        String displayLabel = "";

        // Если в оффхенде уже предмет из "На", свапаем обратно на "Свапать что"
        if (isItemMatching(offhandItem, toLabel)) {
            targetItem = getItemByName(fromLabel);
            displayLabel = fromLabel;
        } else {
            targetItem = getItemByName(toLabel);
            displayLabel = toLabel;
        }

        if (targetItem == null) return;

        int slot = findSlotInScreenHandler(mc, targetItem);
        if (slot != -1) {
            pendingSlot = slot;
            pendingLabel = displayLabel;
            isWaitingToSwap = true;
            stopTicks = STOP_TICKS;
            
            stopMovement(mc);
            movementLocked = true;
        }
    }

    private void executeSwap(MinecraftClient mc) {
        stopMovement(mc);
        
        int syncId = mc.player.playerScreenHandler.syncId;
        mc.interactionManager.clickSlot(syncId, pendingSlot, 40, SlotActionType.SWAP, mc.player);
        
        String translation = I18n.translate("batswap.swapped");
        ChatUtils.sendMessage(translation + (translation.endsWith(" ") ? "" : " ") + pendingLabel);
        
        resetState();
        cooldownTicks = 40;
    }

    private String getSelectedName(ListSetting list) {
        var toggled = list.getToggled();
        return toggled.isEmpty() ? null : toggled.get(0).getName();
    }

    private boolean isItemMatching(Item item, String label) {
        return switch (label) {
            case "Тотем" -> item == Items.TOTEM_OF_UNDYING;
            case "Щит" -> item == Items.SHIELD;
            case "Сфера" -> item == Items.PLAYER_HEAD;
            case "Гепл" -> item == Items.GOLDEN_APPLE;
            case "Чарка" -> item == Items.ENCHANTED_GOLDEN_APPLE;
            default -> false;
        };
    }

    private Item getItemByName(String label) {
        return switch (label) {
            case "Тотем" -> Items.TOTEM_OF_UNDYING;
            case "Щит" -> Items.SHIELD;
            case "Сфера" -> Items.PLAYER_HEAD;
            case "Гепл" -> Items.GOLDEN_APPLE;
            case "Чарка" -> Items.ENCHANTED_GOLDEN_APPLE;
            default -> null;
        };
    }

    private void stopMovement(MinecraftClient mc) {
        if (mc.player == null || mc.options == null) return;
        
        mc.options.forwardKey.setPressed(false);
        mc.options.backKey.setPressed(false);
        mc.options.leftKey.setPressed(false);
        mc.options.rightKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        mc.options.sneakKey.setPressed(false);
        
        movementLocked = true;
    }

    private int findSlotInScreenHandler(MinecraftClient mc, Item targetItem) {
        ScreenHandler handler = mc.player.playerScreenHandler;
        
        for (int i = 9; i <= 44; i++) {
            ItemStack stack = handler.getSlot(i).getStack();
            if (!stack.isEmpty() && stack.getItem() == targetItem) {
                return i;
            }
        }
        
        return -1;
    }

    private void resetState() {
        if (movementLocked) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.options != null && mc.getWindow() != null) {
                restoreMovement(mc);
            }
            movementLocked = false;
        }
        
        isWaitingToSwap = false;
        stopTicks = 0;
        pendingSlot = -1;
        pendingLabel = "";
        bindLatch = false;
    }

    private void restoreMovement(MinecraftClient mc) {
        long window = mc.getWindow().getHandle();
        
        syncKey(mc, mc.options.forwardKey, window);
        syncKey(mc, mc.options.backKey, window);
        syncKey(mc, mc.options.leftKey, window);
        syncKey(mc, mc.options.rightKey, window);
        syncKey(mc, mc.options.jumpKey, window);
        syncKey(mc, mc.options.sneakKey, window);
    }

    private void syncKey(MinecraftClient mc, KeyBinding key, long window) {
        try {
            String translation = key.getBoundKeyTranslationKey();
            InputUtil.Key boundKey = InputUtil.fromTranslationKey(translation);
            
            if (translation.startsWith("key.keyboard.")) {
                boolean pressed = GLFW.glfwGetKey(window, boundKey.getCode()) == GLFW.GLFW_PRESS;
                key.setPressed(pressed);
            } else if (translation.startsWith("key.mouse.")) {
                boolean pressed = GLFW.glfwGetMouseButton(window, boundKey.getCode()) == GLFW.GLFW_PRESS;
                key.setPressed(pressed);
            }
        } catch (Exception ignored) {
        }
    }

    private static boolean isBindDown(long window, Bind bind) {
        if (bind == null) return false;
        if (bind.isMouse()) {
            return GLFW.glfwGetMouseButton(window, bind.getKey()) == GLFW.GLFW_PRESS;
        }
        return GLFW.glfwGetKey(window, bind.getKey()) == GLFW.GLFW_PRESS;
    }
}