package dev.batvisuals.modules.impl.utility;

import com.mojang.authlib.GameProfile;
import dev.batvisuals.client.events.impl.EventAttackEntity;
import dev.batvisuals.client.events.impl.EventTick;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.ListSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * Client-side fake player for testing (TargetESP, perks, stands, etc.).
 * Does not send packets / not a cheat. Cannot be used to push out of traps.
 */
public class FakePlayer extends Module {

    private final BooleanSetting modeStay = new BooleanSetting("mode.stay", true, () -> false);
    private final BooleanSetting modeMove = new BooleanSetting("mode.move", false, () -> false);
    private final ListSetting mode = new ListSetting(
            "setting.mode", true,
            modeStay, modeMove
    );

    private OtherClientPlayerEntity fake;
    private Vec3d spawnPos;
    private float spawnYaw;
    /** +1 = moving right relative to spawn yaw, -1 = left */
    private int moveDir = 1;
    private static final double MOVE_RANGE = 2.0;
    private static final double WALK_SPEED = 0.12;

    public FakePlayer() {
        super("FakePlayer", Category.Utility, "Фейковый игрок для тренировки");
    }

    @Override
    public void onEnable() {
        super.onEnable();
        spawn();
    }

    @Override
    public void onDisable() {
        removeFake();
        super.onDisable();
    }

    private void spawn() {
        if (fullNullCheck() || mc.world == null || mc.player == null) {
            setToggled(false);
            return;
        }
        removeFake();

        // Скин = игрок Mergouzz (имя профиля), ник над головой = t.me/BaTVisuals
        UUID uuid = UUID.nameUUIDFromBytes(("FakePlayer:t.me/BaTVisuals:Mergouzz").getBytes(StandardCharsets.UTF_8));
        GameProfile profile = new GameProfile(uuid, "Mergouzz");

        ClientWorld world = mc.world;
        fake = new BatFakePlayer(world, profile);
        fake.setCustomName(Text.literal("t.me/BaTVisuals"));
        fake.setCustomNameVisible(true);

        Vec3d pos = mc.player.getPos();
        Direction facing = mc.player.getHorizontalFacing();
        // Spawn 2 blocks in front of player
        double sx = pos.x + facing.getOffsetX() * 2.0;
        double sz = pos.z + facing.getOffsetZ() * 2.0;
        double sy = pos.y;
        spawnPos = new Vec3d(sx, sy, sz);
        spawnYaw = mc.player.getYaw();

        fake.refreshPositionAndAngles(sx, sy, sz, spawnYaw, 0f);
        fake.setPitch(0f);
        fake.setYaw(spawnYaw);

        // Always totem in offhand
        forceTotem();

        // No real health drama — visual only
        try {
            fake.getAttributeInstance(EntityAttributes.MAX_HEALTH).setBaseValue(20.0);
            fake.setHealth(20f);
        } catch (Throwable ignored) {}

        world.addEntity(fake);
        moveDir = 1;
    }

    private void removeFake() {
        if (fake != null) {
            try {
                if (mc.world != null) {
                    mc.world.removeEntity(fake.getId(), Entity.RemovalReason.DISCARDED);
                }
            } catch (Throwable ignored) {}
            fake = null;
        }
        spawnPos = null;
    }

    private void forceTotem() {
        if (fake == null) return;
        ItemStack totem = new ItemStack(Items.TOTEM_OF_UNDYING);
        fake.equipStack(EquipmentSlot.OFFHAND, totem);
        try {
            fake.getInventory().offHand.set(0, totem.copy());
        } catch (Throwable ignored) {}
    }

    @EventHandler
    public void onTick(EventTick e) {
        if (fullNullCheck() || fake == null || mc.world == null || mc.player == null) return;

        if (fake.isRemoved() || fake.getWorld() != mc.world) {
            // Respawn if world changed / entity lost
            spawn();
            return;
        }

        // Keep totem forever in left hand
        ItemStack off = fake.getOffHandStack();
        if (off.isEmpty() || !off.isOf(Items.TOTEM_OF_UNDYING)) {
            forceTotem();
        }

        // Look at real player
        lookAtPlayer();

        // Mode: single-select list (На месте / Движущий)
        BooleanSetting activeMode = mode.getToggled().stream().findFirst().orElse(modeStay);
        boolean moving = activeMode == modeMove;

        if (moving) {
            tickMove();
        } else {
            // Stay at spawn
            if (spawnPos != null) {
                fake.setPosition(spawnPos.x, fake.getY(), spawnPos.z);
                fake.setVelocity(Vec3d.ZERO);
            }
        }

        // Never push the real player (trap safety) — also handled in entity subclass
        fake.velocityModified = false;
    }

    @EventHandler
    public void onAttackEntity(EventAttackEntity e) {
        if (fake == null || e.getTarget() == null) return;
        if (e.getTarget().getId() != fake.getId()) return;
        // Клиентский урон (сервер фейка не знает)
        float dmg = 1.0f;
        try {
            var player = e.getPlayer();
            if (player != null) {
                try {
                    double atk = player.getAttributeValue(EntityAttributes.ATTACK_DAMAGE);
                    dmg = (float) Math.max(1.0, atk);
                } catch (Throwable ignored) {
                    dmg = 1.0f;
                }
            }
        } catch (Throwable ignored) {}

        float hp = Math.max(0f, fake.getHealth() - dmg);
        fake.setHealth(hp);
        fake.hurtTime = 10;
        fake.maxHurtTime = 10;
        // смерть → полный ресет HP (тренировочный манекен)
        if (hp <= 0.01f) {
            fake.setHealth(20f);
            try { fake.deathTime = 0; } catch (Throwable ignored) {}
        }
    }

    private void lookAtPlayer() {
        if (fake == null || mc.player == null) return;
        Vec3d eyes = fake.getEyePos();
        Vec3d target = mc.player.getEyePos();
        double dx = target.x - eyes.x;
        double dy = target.y - eyes.y;
        double dz = target.z - eyes.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90f;
        float pitch = (float) (-(MathHelper.atan2(dy, dist) * (180.0 / Math.PI)));
        fake.setYaw(yaw);
        fake.setBodyYaw(yaw);
        fake.setHeadYaw(yaw);
        fake.setPitch(MathHelper.clamp(pitch, -90f, 90f));
    }

    private void tickMove() {
        if (spawnPos == null || fake == null || mc.world == null) return;

        // Left/right relative to spawn yaw
        float rad = (float) Math.toRadians(spawnYaw);
        // Right vector in MC: yaw 0 = south, so right is...
        double rightX = -MathHelper.cos(rad);
        double rightZ = -MathHelper.sin(rad);

        Vec3d pos = fake.getPos();
        // Projection of (pos - spawn) onto right axis
        double along = (pos.x - spawnPos.x) * rightX + (pos.z - spawnPos.z) * rightZ;

        if (along >= MOVE_RANGE - 0.05) moveDir = -1;
        if (along <= -MOVE_RANGE + 0.05) moveDir = 1;

        double step = WALK_SPEED * moveDir;
        double nx = pos.x + rightX * step;
        double nz = pos.z + rightZ * step;
        // Clamp to range
        double newAlong = (nx - spawnPos.x) * rightX + (nz - spawnPos.z) * rightZ;
        if (Math.abs(newAlong) > MOVE_RANGE) {
            nx = spawnPos.x + rightX * (MOVE_RANGE * moveDir);
            nz = spawnPos.z + rightZ * (MOVE_RANGE * moveDir);
        }

        // Obstacle: 1-block high in movement direction -> jump; 2+ blocks -> stop that step
        BlockPos feet = BlockPos.ofFloored(nx, pos.y, nz);
        BlockPos head = feet.up();
        BlockState atFeet = mc.world.getBlockState(feet);
        BlockState atHead = mc.world.getBlockState(head);
        boolean solidFeet = !atFeet.getCollisionShape(mc.world, feet).isEmpty();
        boolean solidHead = !atHead.getCollisionShape(mc.world, head).isEmpty();

        if (solidFeet && !solidHead) {
            // Jump over 1-block
            if (fake.isOnGround()) {
                fake.jump();
            }
            fake.setPosition(nx, fake.getY(), nz);
        } else if (solidFeet && solidHead) {
            // 2-block wall — reverse
            moveDir = -moveDir;
        } else {
            // Ground follow
            BlockPos below = BlockPos.ofFloored(nx, pos.y - 0.1, nz);
            if (mc.world.getBlockState(below).getCollisionShape(mc.world, below).isEmpty()
                    && mc.world.getBlockState(below.down()).getCollisionShape(mc.world, below.down()).isEmpty()) {
                // hole — reverse instead of falling far
                moveDir = -moveDir;
            } else {
                fake.setPosition(nx, pos.y, nz);
            }
        }

        // Simple walk animation hint
        fake.limbAnimator.setSpeed(0.5f);
        fake.handSwingProgress = 0f;
    }

    /** Public access for other modules (TargetESP etc.) */
    public OtherClientPlayerEntity getFake() {
        return fake;
    }

    public boolean isFake(Entity entity) {
        return fake != null && entity != null && entity.getId() == fake.getId();
    }

    /**
     * Client-only player entity: hittable, visible to TargetESP,
     * not pushable (cannot escape traps by shoving into it).
     */
    public static class BatFakePlayer extends OtherClientPlayerEntity {
        public BatFakePlayer(ClientWorld world, GameProfile profile) {
            super(world, profile);
            this.noClip = false;
        }

        @Override
        public boolean isPushable() {
            return false;
        }

        @Override
        public boolean isCollidable() {
            return true;
        }

        @Override
        public boolean isAttackable() {
            return true;
        }


        @Override
        public boolean isSpectator() {
            return false;
        }

        @Override
        public boolean isInvisible() {
            return false;
        }

        @Override
        public boolean shouldRenderName() {
            return true;
        }

        @Override
        public boolean isInvulnerable() {
            return false;
        }

        @Override
        public net.minecraft.text.Text getName() {
            return net.minecraft.text.Text.literal("t.me/BaTVisuals");
        }

        @Override
        public net.minecraft.text.Text getDisplayName() {
            return net.minecraft.text.Text.literal("t.me/BaTVisuals");
        }
    }
}
