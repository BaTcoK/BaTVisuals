package dev.batvisuals.modules.impl.utility;

import dev.batvisuals.client.events.impl.EventPacket;
import dev.batvisuals.client.events.impl.EventTick;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRemoveS2CPacket;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * ReallyWorld-oriented anti-bot.
 * Detects bots and immediately removes them from the world. No settings.
 */
public class AntiBot extends Module {

    private final Set<UUID> botSet = new HashSet<>();
    private final Set<UUID> suspectSet = new HashSet<>();

    public AntiBot() {
        super("AntiBot", Category.Utility, "Убирает ботов с сервера");
    }

    @EventHandler
    public void onPacketReceive(EventPacket.Receive event) {
        if (event.getPacket() instanceof PlayerListS2CPacket list) {
            list.getPlayerAdditionEntries().forEach(entry -> {
                if (entry.profile() == null) return;
                var profile = entry.profile();
                if (isRealPlayer(entry, profile)) return;
                if (isDuplicateProfile(profile)) {
                    botSet.add(profile.getId());
                } else {
                    suspectSet.add(profile.getId());
                }
            });
        } else if (event.getPacket() instanceof PlayerRemoveS2CPacket remove) {
            remove.profileIds().forEach(uuid -> {
                suspectSet.remove(uuid);
                botSet.remove(uuid);
            });
        }
    }

    @EventHandler
    public void onTick(EventTick event) {
        if (fullNullCheck()) return;

        // Evaluate suspects
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (suspectSet.contains(p.getUuid())) {
                evaluateSuspect(p);
            }
        }

        // ReallyWorld mode: mark offline-UUID players as bots
        for (PlayerEntity entity : mc.world.getPlayers()) {
            if (entity == mc.player) continue;
            String name = entity.getName().getString();
            if (name.contains("NPC") || name.startsWith("[ZNPC]")) continue;
            UUID expected = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes());
            if (!entity.getUuid().equals(expected) && !botSet.contains(entity.getUuid())) {
                botSet.add(entity.getUuid());
            }
        }

        // Always remove bots from world
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p != null && p.getUuid() != null && botSet.contains(p.getUuid())) {
                mc.world.removeEntity(p.getId(), Entity.RemovalReason.DISCARDED);
            }
        }

        // Cleanup
        if (mc.player != null && mc.player.age % 100 == 0) {
            botSet.removeIf(uuid -> mc.world.getPlayerByUuid(uuid) == null);
        }
    }

    private boolean isRealPlayer(PlayerListS2CPacket.Entry entry, com.mojang.authlib.GameProfile profile) {
        return entry.latency() < 2 || (profile.getProperties() != null && !profile.getProperties().isEmpty());
    }

    private boolean isDuplicateProfile(com.mojang.authlib.GameProfile profile) {
        ClientPlayNetworkHandler handler = mc.getNetworkHandler();
        if (handler == null) return false;
        long count = handler.getPlayerList().stream()
                .filter(e -> e.getProfile().getName().equals(profile.getName())
                        && !e.getProfile().getId().equals(profile.getId()))
                .count();
        return count == 1L;
    }

    private void evaluateSuspect(PlayerEntity player) {
        int armorCount = 0;
        for (var stack : player.getArmorItems()) {
            if (!stack.isEmpty()) armorCount++;
        }
        String name = player.getName().getString();
        boolean isNameBot = name.startsWith("CIT-") && !name.contains("NPC") && !name.startsWith("[ZNPC]");
        boolean isFakeUUID = !player.getUuid().equals(UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes()));
        if (armorCount == 4 || isNameBot || isFakeUUID) {
            botSet.add(player.getUuid());
        }
        suspectSet.remove(player.getUuid());
    }

    public boolean isBot(UUID uuid) {
        return botSet.contains(uuid);
    }

    public boolean isBot(Entity entity) {
        if (entity == null || entity.getUuid() == null) return false;
        String name = entity.getName().getString();
        boolean isNameBot = name.startsWith("CIT-") && !name.contains("NPC") && !name.startsWith("[ZNPC]");
        return isNameBot || botSet.contains(entity.getUuid());
    }

    @Override
    public void onDisable() {
        botSet.clear();
        suspectSet.clear();
        super.onDisable();
    }
}
