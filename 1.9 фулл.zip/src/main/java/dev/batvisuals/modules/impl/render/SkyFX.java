package dev.batvisuals.modules.impl.render;

import dev.batvisuals.client.events.impl.EventRender3D;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.client.render.RenderTheme;
import dev.batvisuals.client.render.SkyPass;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.api.Nameable;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.EnumSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import meteordevelopment.orbit.EventHandler;

import java.awt.Color;

/**
 * SkyFX — uses unified SkyPass (Water / Caustic). TargetESP render untouched.
 */
public class SkyFX extends Module {

    public enum Mode implements Nameable {
        Water("Water"),
        Caustic("Caustic");
        private final String name;
        Mode(String name) { this.name = name; }
        @Override public String getName() { return name; }
    }

    private final EnumSetting<Mode> mode = new EnumSetting<>("Режим", Mode.Caustic);
    private final NumberSetting speed = new NumberSetting("Скорость", 1.0f, 0.1f, 5.0f, 0.1f);
    private final NumberSetting scale = new NumberSetting("Размер", 1.6f, 0.5f, 8.0f, 0.1f);
    private final NumberSetting intensity = new NumberSetting("Интенсивность", 1.0f, 0.2f, 3.0f, 0.1f);
    private final NumberSetting alpha = new NumberSetting("Прозрачность", 0.55f, 0.15f, 1.0f, 0.05f);
    private final BooleanSetting colorClouds = new BooleanSetting("Облака", true);

    private final SkyPass.Params params = new SkyPass.Params();

    public SkyFX() {
        super("SkyFX", Category.Render, "Шейдерное небо (Water / Caustic)");
        // theme hook for new pipeline
        try {
            RenderTheme.primary = () -> {
                Color c = ThemeManager.getInstance().getThemeColor();
                return (c.getAlpha() << 24) | (c.getRed() << 16) | (c.getGreen() << 8) | c.getBlue();
            };
        } catch (Throwable ignored) {}
    }

    public Color getSkyColor() {
        try {
            return ThemeManager.getInstance().getThemeColor();
        } catch (Throwable t) {
            return new Color(80, 160, 255);
        }
    }

    public float getSkyBlend() {
        return isToggled() ? 0.85f : 0f;
    }

    public float getFogBlend() {
        return isToggled() ? 0.65f : 0f;
    }

    public boolean colorClouds() {
        return colorClouds.getValue();
    }

    @EventHandler
    public void onRender3D(EventRender3D.Game e) {
        if (!isToggled() || fullNullCheck()) return;
        params.mode = mode.getValue() == Mode.Water ? SkyPass.Mode.WATER : SkyPass.Mode.CAUSTIC;
        params.color = 0; // theme
        params.alpha = alpha.getValue();
        params.speed = speed.getValue();
        params.scale = scale.getValue();
        params.intensity = intensity.getValue();
        try {
            SkyPass.draw(e.getMatrices(), mc.gameRenderer.getCamera(), null, params);
        } catch (Throwable ignored) {}
    }
}
