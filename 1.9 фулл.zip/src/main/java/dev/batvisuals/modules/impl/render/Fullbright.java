package dev.batvisuals.modules.impl.render;

import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import net.minecraft.client.resource.language.I18n;

public class Fullbright extends Module {

    public Fullbright() {
        super("Fullbright", Category.Render, I18n.translate("module.fullbright.description"));
    }
}