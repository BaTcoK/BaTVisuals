package dev.batvisuals.modules.impl.render;

import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.api.Nameable;
import dev.batvisuals.modules.settings.impl.EnumSetting;
import net.minecraft.client.resource.language.I18n;

public class ItemPhysic extends Module {

    public enum PhysicMode implements Nameable {
        MODE_3D("3D"),
        MODE_2D("2D");
        private final String name;
        PhysicMode(String name) { this.name = name; }
        @Override public String getName() { return name; }
    }

    public final EnumSetting<PhysicMode> mode = new EnumSetting<>("Режим", PhysicMode.MODE_3D);

    public ItemPhysic() {
        super("ItemPhysic", Category.Render, I18n.translate("module.itemphysic.description"));
    }

    public boolean is2D() {
        try { return mode.getValue() == PhysicMode.MODE_2D; } catch (Throwable t) { return false; }
    }
}
