package dev.batvisuals.modules.impl.render;

import dev.batvisuals.client.events.impl.EventRender3D;
import dev.batvisuals.client.events.impl.EventTick;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.client.util.render.SmokeTrail;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;

import java.awt.Color;

/**
 * Soft smoke trail under feet while walking on ground.
 */
public class SmokeTrails extends Module {

    private final SmokeTrail trail = new SmokeTrail();

    public final BooleanSetting white = new BooleanSetting("Белый дым", false);
    public final NumberSetting lifetime = new NumberSetting("Время жизни", 2.0f, 0.5f, 5.0f, 0.1f);

    public SmokeTrails() {
        super("SmokeTrails", Category.Render, "Дым под ногами при ходьбе");
    }

    private float life() {
        Float v = lifetime.getValue();
        return v == null ? 2f : v;
    }

    private int themeRgb() {
        try {
            Color c = ThemeManager.getInstance().getThemeColor();
            if (c != null) return (c.getRed() << 16) | (c.getGreen() << 8) | c.getBlue();
        } catch (Throwable ignored) {}
        return 0x8A5CFF;
    }

    @EventHandler
    public void onTick(EventTick e) {
        if (fullNullCheck()) return;
        trail.tick(MinecraftClient.getInstance(), life());
    }

    @EventHandler
    public void onRender3D(EventRender3D.Game e) {
        if (fullNullCheck()) return;
        try {
            trail.render(mc.gameRenderer.getCamera(),
                    Boolean.TRUE.equals(white.getValue()), themeRgb(), life());
        } catch (Throwable t) { t.printStackTrace(); }
    }

    @Override
    public void onDisable() {
        trail.clear();
        super.onDisable();
    }
}
