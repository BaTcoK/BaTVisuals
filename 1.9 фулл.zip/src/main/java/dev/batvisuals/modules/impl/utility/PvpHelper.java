package dev.batvisuals.modules.impl.utility;

import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BindSetting;
import dev.batvisuals.modules.settings.api.Bind;
import dev.batvisuals.client.events.impl.EventTick;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;
import net.minecraft.client.resource.language.I18n;

public class PvpHelper extends Module {

    private final BindSetting pearlBind = new BindSetting("setting.pearlBind", new Bind(GLFW.GLFW_KEY_P, false));

    private boolean pearlWasDown = false;
    private long pearlDownSince = 0L;
    private static final long HOLD_MS = 180L;

    /** True while pearl bind is held long enough — Predictions can show path. */
    public static volatile boolean forcePearlTrajectory = false;

    private int previousSlot = -1;
    private int returnTicks = 0;
    private boolean forcedUseKey = false;

    public PvpHelper() {
        super("PvPHelper", Category.Utility, I18n.translate("module.pvphelper.description"));
    }

    @Override
    public void onDisable() {
        previousSlot = -1;
        returnTicks = 0;
        pearlWasDown = false;
        forcePearlTrajectory = false;
        if (forcedUseKey && MinecraftClient.getInstance().options != null) {
            MinecraftClient.getInstance().options.useKey.setPressed(false);
            forcedUseKey = false;
        }
        super.onDisable();
    }

    @EventHandler
    public void onTick(EventTick e) {
        if (!isToggled()) {
            forcePearlTrajectory = false;
            return;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        if (returnTicks > 0) {
            returnTicks--;
            if (returnTicks == 0 && previousSlot != -1) {
                mc.player.getInventory().selectedSlot = previousSlot;
                previousSlot = -1;
            }
        }

        long window = mc.getWindow().getHandle();
        boolean pearlDown = isBindDown(window, pearlBind.getValue());
        long now = System.currentTimeMillis();

        if (pearlDown) {
            if (!pearlWasDown) {
                pearlWasDown = true;
                pearlDownSince = now;
            }
            forcePearlTrajectory = (now - pearlDownSince) >= HOLD_MS;
        } else {
            if (pearlWasDown) {
                long held = now - pearlDownSince;
                pearlWasDown = false;
                forcePearlTrajectory = false;
                // short click -> throw pearl from hotbar
                if (held < HOLD_MS) {
                    throwPearl(mc);
                }
            }
        }
    }

    private void throwPearl(MinecraftClient mc) {
        int pearlSlot = findInHotbar(mc, Items.ENDER_PEARL);
        if (pearlSlot == -1) return;
        if (previousSlot == -1) previousSlot = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = pearlSlot;
        try {
            mc.options.useKey.setPressed(true);
            forcedUseKey = true;
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        } catch (Throwable ignored) {}
        try {
            mc.options.useKey.setPressed(false);
            forcedUseKey = false;
        } catch (Throwable ignored) {}
        returnTicks = 2;
    }

    private static boolean isBindDown(long window, Bind bind) {
        if (bind == null) return false;
        if (bind.isMouse()) return GLFW.glfwGetMouseButton(window, bind.getKey()) == GLFW.GLFW_PRESS;
        return GLFW.glfwGetKey(window, bind.getKey()) == GLFW.GLFW_PRESS;
    }

    private static int findInHotbar(MinecraftClient mc, Item item) {
        for (int i = 0; i < 9; i++) {
            ItemStack st = mc.player.getInventory().getStack(i);
            if (st != null && st.isOf(item)) return i;
        }
        return -1;
    }
}
