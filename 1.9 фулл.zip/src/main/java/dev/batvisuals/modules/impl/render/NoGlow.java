package dev.batvisuals.modules.impl.render;

import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;

/** Отключает свечение (outline glow) сущностей — больше FPS. */
public class NoGlow extends Module {
    private static NoGlow instance;

    public NoGlow() {
        super("NoGlow", Category.Render, "Отключает свечение сущностей");
        instance = this;
    }

    public static NoGlow getInstance() {
        return instance;
    }

    public static boolean isActive() {
        return instance != null && instance.isToggled();
    }
}
