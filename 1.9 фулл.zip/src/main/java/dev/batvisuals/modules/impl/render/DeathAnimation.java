package dev.batvisuals.modules.impl.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.batvisuals.client.events.impl.EventEntityDeath;
import dev.batvisuals.client.events.impl.EventRender3D;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.ListSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.LightningEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * DeathAnimation: lightning bolt or vertical theme-coloured beam at death position.
 */
public class DeathAnimation extends Module {

    private final ListSetting deathType = new ListSetting("setting.deathType", true,
            new BooleanSetting("death.lightning", true),
            new BooleanSetting("death.beam", false)
    );

    private final BooleanSetting playersOnly = new BooleanSetting("setting.playersOnly", true);

    private record ActiveBeam(Vec3d pos, long startMs) {}

    private static final long BEAM_DURATION_MS = 3000L;
    private static final long FADE_IN_MS = 500L;
    private static final long FADE_OUT_MS = 900L;
    private static final double BEAM_HEIGHT = 60.0;
    private static final double BEAM_WIDTH = 0.45;

    private final List<ActiveBeam> beams = new ArrayList<>();

    public DeathAnimation() {
        super("DeathAnimation", Category.Render, "Анимация смерти игроков");
    }

    @Override
    public void onDisable() {
        beams.clear();
        super.onDisable();
    }

    private boolean isBeamMode() {
        if (deathType.getValue() == null) return false;
        for (BooleanSetting s : deathType.getValue()) {
            if (s == null || !Boolean.TRUE.equals(s.getValue())) continue;
            String n = s.getName() == null ? "" : s.getName().toLowerCase();
            if (n.contains("beam") || n.contains("удар") || n.contains("луч")) return true;
        }
        // fallback: toggled list
        try {
            if (!deathType.getToggled().isEmpty()) {
                String n = deathType.getToggled().get(0).getName().toLowerCase();
                return n.contains("beam") || n.contains("удар") || n.contains("луч");
            }
        } catch (Throwable ignored) {}
        return false;
    }

    @EventHandler
    public void onEntityDeath(EventEntityDeath e) {
        if (!isToggled()) return;
        LivingEntity entity = e.getEntity();
        if (entity == null) return;
        if (Boolean.TRUE.equals(playersOnly.getValue()) && !(entity instanceof PlayerEntity)) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && entity == mc.player) return;

        Vec3d pos = entity.getPos();
        if (isBeamMode()) {
            beams.add(new ActiveBeam(pos, System.currentTimeMillis()));
            playBeamSound(mc, pos);
        } else {
            spawnVisualLightning(mc, pos);
            playLightningSound(mc, pos);
        }
    }

    private void playBeamSound(MinecraftClient mc, Vec3d pos) {
        if (mc.world == null) return;
        try {
            SoundEvent soundEvent = SoundEvent.of(Identifier.of("batvisuals:lightning"));
            mc.getSoundManager().play(new PositionedSoundInstance(
                    soundEvent, SoundCategory.PLAYERS, 1.0f, 1.0f,
                    net.minecraft.util.math.random.Random.create(),
                    pos.x, pos.y, pos.z));
        } catch (Throwable t) {
            playLightningSound(mc, pos);
        }
    }

    private void playLightningSound(MinecraftClient mc, Vec3d pos) {
        if (mc.world == null) return;
        mc.getSoundManager().play(new PositionedSoundInstance(
                SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER,
                SoundCategory.PLAYERS, 1.0f, 1.0f,
                net.minecraft.util.math.random.Random.create(),
                pos.x, pos.y, pos.z));
    }

    private void spawnVisualLightning(MinecraftClient mc, Vec3d pos) {
        if (mc.world == null) return;
        try {
            LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(mc.world, SpawnReason.TRIGGERED);
            if (bolt == null) return;
            bolt.setPosition(pos.x, pos.y, pos.z);
            bolt.setCosmetic(true);
            mc.world.addEntity(bolt);
        } catch (Throwable ignored) {}
    }

    private Color accent() {
        try {
            Color c = ThemeManager.getInstance().getCurrentTheme().getAccentColor();
            if (c != null) return c;
            c = ThemeManager.getInstance().getThemeColor();
            if (c != null) return c;
        } catch (Throwable ignored) {}
        return new Color(120, 200, 255);
    }

    @EventHandler
    public void onRender3D(EventRender3D.Game e) {
        if (!isToggled() || beams.isEmpty()) return;

        long now = System.currentTimeMillis();
        beams.removeIf(b -> now - b.startMs() > BEAM_DURATION_MS);
        if (beams.isEmpty()) return;

        Color base = accent();
        float cr = base.getRed() / 255f;
        float cg = base.getGreen() / 255f;
        float cb = base.getBlue() / 255f;

        Vec3d cam = MinecraftClient.getInstance().gameRenderer.getCamera().getPos();
        MatrixStack matrices = e.getMatrices();

        // Collect verts first — never end empty buffer
        List<float[]> verts = new ArrayList<>();

        for (ActiveBeam beam : beams) {
            long age = now - beam.startMs();
            float alphaMul;
            if (age < FADE_IN_MS) {
                alphaMul = (float) age / (float) FADE_IN_MS;
            } else if (age > BEAM_DURATION_MS - FADE_OUT_MS) {
                long intoFade = age - (BEAM_DURATION_MS - FADE_OUT_MS);
                alphaMul = 1.0f - ((float) intoFade / (float) FADE_OUT_MS);
            } else {
                alphaMul = 1.0f;
            }
            alphaMul = MathHelper.clamp(alphaMul, 0f, 1f);
            if (alphaMul <= 0.01f) continue;

            float aBottom = 0.85f * alphaMul;
            float aTop = 0f;
            double half = BEAM_WIDTH / 2.0;
            double x = beam.pos().x - cam.x;
            double y = beam.pos().y - cam.y;
            double z = beam.pos().z - cam.z;
            double h = BEAM_HEIGHT;

            // Two crossed quads (X and Z planes)
            // Quad 1: along X
            addQuad(verts,
                    x - half, y, z, aBottom,
                    x + half, y, z, aBottom,
                    x + half, y + h, z, aTop,
                    x - half, y + h, z, aTop,
                    cr, cg, cb);
            // Quad 2: along Z
            addQuad(verts,
                    x, y, z - half, aBottom,
                    x, y, z + half, aBottom,
                    x, y + h, z + half, aTop,
                    x, y + h, z - half, aTop,
                    cr, cg, cb);
            // Slightly thicker core
            double half2 = half * 0.45;
            addQuad(verts,
                    x - half2, y, z, aBottom,
                    x + half2, y, z, aBottom,
                    x + half2, y + h, z, aTop,
                    x - half2, y + h, z, aTop,
                    1f, 1f, 1f);
        }

        if (verts.isEmpty()) return;

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);

        matrices.push();
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (float[] v : verts) {
            for (int i = 0; i < 4; i++) {
                int o = i * 7;
                buffer.vertex(matrix, v[o], v[o + 1], v[o + 2])
                        .color(v[o + 3], v[o + 4], v[o + 5], v[o + 6]);
            }
        }
        dev.batvisuals.client.util.render.SafeDraw.draw(buffer);
        matrices.pop();

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private static void addQuad(List<float[]> out,
                                double x1, double y1, double z1, float a1,
                                double x2, double y2, double z2, float a2,
                                double x3, double y3, double z3, float a3,
                                double x4, double y4, double z4, float a4,
                                float r, float g, float b) {
        out.add(new float[]{
                (float) x1, (float) y1, (float) z1, r, g, b, a1,
                (float) x2, (float) y2, (float) z2, r, g, b, a2,
                (float) x3, (float) y3, (float) z3, r, g, b, a3,
                (float) x4, (float) y4, (float) z4, r, g, b, a4
        });
    }
}
