package dev.batvisuals.modules.impl.render;

import dev.batvisuals.client.events.impl.EventAttackEntity;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * HandUP — PvP hands:
 * after you hit a player → their arms up for 5s (refreshed each hit);
 * swing / eat arm poses; optional raise own arms.
 */
public class HandUP extends Module {

    public static volatile boolean ENABLED = false;

    public static final Map<PlayerEntityRenderState, UUID> STATE_UUID = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Long> HANDS_UP_UNTIL = new ConcurrentHashMap<>();
    private static final long HANDS_UP_MS = 5000L;

    /** uuid → last known PlayerEntity for pose checks during model setAngles */
    public static final ConcurrentHashMap<UUID, PlayerEntity> TRACKED = new ConcurrentHashMap<>();

    private final BooleanSetting raiseSelf = new BooleanSetting("Поднять у себя", false);

    public HandUP() {
        super("HandUP", Category.Render, "Руки вверх после удара 5с, удар и еда");
    }

    @Override
    public void onEnable() {
        ENABLED = true;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        ENABLED = false;
        HANDS_UP_UNTIL.clear();
        STATE_UUID.clear();
        TRACKED.clear();
        super.onDisable();
    }

    @EventHandler
    private void onAttack(EventAttackEntity e) {
        if (!isToggled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (e.getPlayer() != mc.player) return;
        Entity target = e.getTarget();
        if (!(target instanceof PlayerEntity victim)) return;
        if (victim == mc.player) return;
        markHandsUp(victim.getUuid());
    }

    public static void markHandsUp(UUID uuid) {
        if (uuid == null) return;
        HANDS_UP_UNTIL.put(uuid, System.currentTimeMillis() + HANDS_UP_MS);
    }

    public static boolean isHandsUp(UUID uuid) {
        if (uuid == null) return false;
        Long until = HANDS_UP_UNTIL.get(uuid);
        if (until == null) return false;
        if (until < System.currentTimeMillis()) {
            HANDS_UP_UNTIL.remove(uuid);
            return false;
        }
        return true;
    }

    public static void trackState(PlayerEntityRenderState state, AbstractClientPlayerEntity player) {
        if (state == null || player == null) return;
        STATE_UUID.put(state, player.getUuid());
        TRACKED.put(player.getUuid(), player);
        if (STATE_UUID.size() > 256) {
            Iterator<Map.Entry<PlayerEntityRenderState, UUID>> it = STATE_UUID.entrySet().iterator();
            int n = 0;
            while (it.hasNext() && n < 64) {
                it.next();
                it.remove();
                n++;
            }
        }
    }

    public static UUID uuidOf(PlayerEntityRenderState state) {
        return state == null ? null : STATE_UUID.get(state);
    }

    public boolean shouldRaiseSelf() {
        return raiseSelf.getValue();
    }

    public static HandUP get() {
        try {
            for (dev.batvisuals.modules.api.Module m : dev.batvisuals.batvisuals.getInstance().getModuleManager().getModules()) {
                if (m instanceof HandUP h) return h;
            }
        } catch (Throwable ignored) {}
        return null;
    }

    public static boolean isEating(PlayerEntity player) {
        if (player == null || !player.isUsingItem()) return false;
        ItemStack stack = player.getActiveItem();
        if (stack.isEmpty()) return false;
        return stack.get(DataComponentTypes.FOOD) != null;
    }

    public static boolean isAttackSwinging(PlayerEntity player) {
        return player != null && player.handSwinging
                && player.handSwingProgress > 0.05f
                && player.handSwingProgress < 0.95f;
    }

    public enum Pose { NONE, EAT, SWING, HANDS_UP }

    public static Pose resolvePose(UUID uuid) {
        if (!ENABLED) return Pose.NONE;
        HandUP mod = get();
        if (mod == null || !mod.isToggled()) return Pose.NONE;
        if (uuid == null) return Pose.NONE;

        MinecraftClient mc = MinecraftClient.getInstance();
        PlayerEntity player = TRACKED.get(uuid);
        if (player == null && mc.world != null) {
            for (PlayerEntity p : mc.world.getPlayers()) {
                if (p.getUuid().equals(uuid)) {
                    player = p;
                    break;
                }
            }
        }

        boolean self = mc.player != null && uuid.equals(mc.player.getUuid());
        boolean marked = isHandsUp(uuid);
        boolean allowSelf = self && mod.shouldRaiseSelf();

        // чужие без метки после удара — не трогаем (и выкл. модуль уже отсёкся выше)
        if (!marked && !allowSelf) {
            return Pose.NONE;
        }

        if (player != null && isEating(player)) return Pose.EAT;
        if (player != null && isAttackSwinging(player)) return Pose.SWING;
        return Pose.HANDS_UP;
    }
}
