package dev.batvisuals.modules.impl.render;

import dev.batvisuals.modules.impl.render.omnom.OmNomModel;

import dev.batvisuals.batvisuals;
import dev.batvisuals.client.events.impl.EventRender3D;
import dev.batvisuals.client.managers.FirebaseManager;
import dev.batvisuals.client.util.animations.Animation;
import dev.batvisuals.client.util.animations.Easing;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.EnumSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import dev.batvisuals.modules.settings.api.Nameable;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.AllayEntity;
import net.minecraft.entity.passive.BatEntity;
import net.minecraft.entity.passive.CatEntity;
import net.minecraft.entity.passive.FoxEntity;
import net.minecraft.entity.passive.ParrotEntity;
import net.minecraft.entity.passive.WolfEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.Hand;

/** Cosmetic vanilla pet. Preview entities are never inserted into the world. */
public final class Pets extends Module {
    public enum PetType implements Nameable {
        BAT("Мышь"), ALLAY("Элей"), WOLF("Волк"), CAT("Кот"), FOX("Лиса"), PARROT("Попугай"), OMNOM("Амням");
        private final String name;
        PetType(String name) { this.name = name; }
        @Override public String getName() { return name; }
    }

    public enum PetPosition implements Nameable {
        TOP_LEFT("Сверху слева"), TOP_RIGHT("Сверху справа");
        private final String name;
        PetPosition(String name) { this.name = name; }
        @Override public String getName() { return name; }
    }

    /** Ground pets walk beside the player and stick to the floor; flying pets hover near the shoulder. */
    private boolean isGroundPet() {
        PetType t = pet.getValue();
        return t == PetType.WOLF || t == PetType.CAT || t == PetType.FOX || t == PetType.OMNOM;
    }

    private final EnumSetting<PetType> pet = new EnumSetting<>("Питомец", PetType.BAT);
    private final EnumSetting<PetPosition> position = new EnumSetting<>("Положение", PetPosition.TOP_RIGHT);
    private final NumberSetting height = new NumberSetting("Высота", 1.35f, 0.5f, 2.5f, 0.05f);
    private final NumberSetting scale = new NumberSetting("Размер", 0.75f, 0.25f, 1.2f, 0.05f);

    private Entity preview;
    private OmNomModel omnomModel;

    private int lastAge = -1;

    // --- Ground pet state (Wolf/Cat/Fox) ---
    private Vec3d groundPos = Vec3d.ZERO;
    private Vec3d groundPrevPos = Vec3d.ZERO;
    private float groundYaw = 0f;
    private float groundPrevYaw = 0f;
    private float groundPitch = 0f;
    private float groundPrevPitch = 0f;
    private float limbSpeed = 0f;
    private float limbDistance = 0f;
    private int afkTicks = 0;
    private Vec3d lastPlayerPos = Vec3d.ZERO;
    private LivingEntity pvpTarget = null;
    private int pvpTicks = 0;
    private boolean wasFlying = false;
    // Grace period after the player starts flying/gliding before we snap the
    // pet down, so short hops/jumps don't cause a jittery teleport.
    private int highUpTicks = 0;
    private static final int HIGH_UP_GRACE_TICKS = 6; // ~0.3s at 20tps

    // --- Flying pet state (Bat/Allay/Parrot) ---
    private final Animation hover = new Animation(1400, 1.0, true, Easing.BOTH_SINE);
    private final Animation wingFlap = new Animation(260, 1.0, true, Easing.BOTH_SINE);
    private boolean hoverForward = true;
    private boolean wingForward = true;
    private Vec3d flyPos = Vec3d.ZERO;
    private boolean localSitting = false;
    private int firebaseSyncAge = -100;
    private final java.util.Map<String, Entity> remotePreviews = new java.util.HashMap<>();
    private Vec3d flyPrevPos = Vec3d.ZERO;

    public Pets() {
        super("Pets", Category.Cosmetics, "Питомец рядом с тобой");
        position.setVisible(() -> !isGroundPet());
        height.setVisible(() -> !isGroundPet());
    }

    @EventHandler
    public void onRender3D(EventRender3D.Game event) {
        if (fullNullCheck()) return;
        float tickDelta = event.getTickDelta();
        // Custom 3D OmNom (ground pet) — no vanilla entity
        if (pet.getValue() == PetType.OMNOM) {
            renderOmNomLocal(event, tickDelta);
            renderRemotePets(event, tickDelta);
            return;
        }

        Entity petEntity = getPreview();
        LivingEntity livingPet = (LivingEntity) petEntity;

        if (mc.player.age != lastAge) {
            lastAge = mc.player.age;
            if (isGroundPet()) {
                tickGroundLogic(livingPet);
            } else {
                tickFlyingLogic();
            }
        }

        Vec3d target;
        float renderYaw, renderPitch;

        if (isGroundPet()) {
            target = groundPrevPos.lerp(groundPos, tickDelta);
            renderYaw = MathHelper.lerp(tickDelta, groundPrevYaw, groundYaw);
            renderPitch = MathHelper.lerp(tickDelta, groundPrevPitch, groundPitch);
        } else {
            target = flyPrevPos.lerp(flyPos, tickDelta);
            renderYaw = mc.player.getYaw();
            renderPitch = mc.player.getPitch();
        }

        petEntity.setPos(target.x, target.y, target.z);
        petEntity.setYaw(renderYaw);
        petEntity.prevYaw = renderYaw;
        livingPet.setHeadYaw(renderYaw);
        livingPet.prevHeadYaw = renderYaw;
        livingPet.setBodyYaw(renderYaw);
        livingPet.prevBodyYaw = renderYaw;
        petEntity.setPitch(renderPitch);
        petEntity.prevPitch = renderPitch;
        petEntity.age = mc.player.age;

        // Walk-cycle limb animation for ground pets, driven by real per-tick
        // travel distance rather than a fixed placeholder value.
        if (isGroundPet()) {
            applyLimbAnimation(livingPet, tickDelta);
        } else {
            applyWingFlap(livingPet);
        }

        MatrixStack matrices = event.getMatrices();
        Vec3d camera = mc.gameRenderer.getCamera().getPos();
        
        matrices.push();
        matrices.translate(target.x - camera.x, target.y - camera.y, target.z - camera.z);
        matrices.scale(scale.getValue(), scale.getValue(), scale.getValue());
        
        VertexConsumerProvider.Immediate immediate = mc.getBufferBuilders().getEntityVertexConsumers();
        mc.getEntityRenderDispatcher().render(petEntity, 0.0, 0.0, 0.0, tickDelta, matrices, immediate, 15728880);
        immediate.draw(); 
        
        matrices.pop();

        // Питомец других игроков с BaTVisuals (Firebase)
        renderRemotePets(event, tickDelta);

        // Синхронизация своего пета в Firebase раз в ~2 сек
        if (mc.player.age - firebaseSyncAge >= 40) {
            firebaseSyncAge = mc.player.age;
            syncPetToFirebase();
        }
    }

    private void syncPetToFirebase() {
        try {
            FirebaseManager fb = batvisuals.getInstance().getFirebaseManager();
            if (fb == null) return;
            fb.updatePet(pet.getValue().name(), localSitting);
        } catch (Throwable ignored) {}
    }

    private void renderRemotePets(EventRender3D.Game event, float tickDelta) {
        try {
            FirebaseManager fb = batvisuals.getInstance().getFirebaseManager();
            if (fb == null || mc.world == null) return;
            MatrixStack matrices = event.getMatrices();
            Vec3d camera = mc.gameRenderer.getCamera().getPos();
            VertexConsumerProvider.Immediate immediate = mc.getBufferBuilders().getEntityVertexConsumers();

            for (PlayerEntity other : mc.world.getPlayers()) {
                if (other == mc.player) continue;
                String key = other.getGameProfile().getId().toString().replace("-", "");
                FirebaseManager.PetData data = fb.getPet(key);
                if (data == null || data.type == null || data.type.isEmpty()) continue;

                PetType type;
                try {
                    type = PetType.valueOf(data.type);
                } catch (Exception ex) {
                    continue;
                }

                float yaw = other.getYaw();
                double rad = Math.toRadians(yaw);
                boolean ground = type == PetType.WOLF || type == PetType.CAT || type == PetType.FOX || type == PetType.OMNOM;
                double ox = -Math.sin(rad) * (ground ? 0.9 : 0.45);
                double oz = Math.cos(rad) * (ground ? 0.9 : 0.45);
                double oy = ground ? 0.0 : 1.2;
                Vec3d pos = other.getPos().add(ox, oy, oz);
                if (ground) {
                    pos = new Vec3d(pos.x, snapToGround(pos), pos.z);
                }

                if (type == PetType.OMNOM) {
                    matrices.push();
                    matrices.translate(pos.x - camera.x, pos.y - camera.y, pos.z - camera.z);
                    renderOmNomRemote(matrices, immediate, 0, 0, 0, yaw, data.sit, tickDelta);
                    matrices.pop();
                    continue;
                }

                Entity remote = getRemotePreview(key, type);
                if (!(remote instanceof LivingEntity living)) continue;

                remote.setPos(pos.x, pos.y, pos.z);
                remote.setYaw(yaw);
                remote.prevYaw = yaw;
                living.setHeadYaw(yaw);
                living.setBodyYaw(yaw);
                remote.setPitch(0);
                remote.age = other.age;
                setSitting(living, data.sit);

                // лёгкая анимация ходьбы если игрок двигается
                double spd = other.getVelocity().horizontalLength();
                if (ground && spd > 0.01 && !data.sit) {
                    applyLimbAnimationRemote(living, (float) spd);
                }

                matrices.push();
                matrices.translate(pos.x - camera.x, pos.y - camera.y, pos.z - camera.z);
                matrices.scale(scale.getValue(), scale.getValue(), scale.getValue());
                mc.getEntityRenderDispatcher().render(remote, 0.0, 0.0, 0.0, tickDelta, matrices, immediate, 15728880);
                immediate.draw();
                matrices.pop();
            }
        } catch (Throwable ignored) {}
    }

    private void applyLimbAnimationRemote(LivingEntity entity, float speed) {
        try {
            Object limbAnimator = LivingEntity.class.getField("limbAnimator").get(entity);
            float s = MathHelper.clamp(speed * 6f, 0f, 1.2f);
            limbAnimator.getClass().getMethod("setSpeed", float.class).invoke(limbAnimator, s);
        } catch (Throwable ignored) {}
    }

    private Entity getRemotePreview(String key, PetType type) {
        Entity existing = remotePreviews.get(key);
        if (existing != null && existing.getWorld() == mc.world && matchesType(existing, type)) {
            return existing;
        }
        Entity created = switch (type) {
            case ALLAY -> new AllayEntity(EntityType.ALLAY, mc.world);
            case BAT -> new BatEntity(EntityType.BAT, mc.world);
            case WOLF -> new WolfEntity(EntityType.WOLF, mc.world);
            case CAT -> new CatEntity(EntityType.CAT, mc.world);
            case FOX -> new FoxEntity(EntityType.FOX, mc.world);
            case PARROT -> new ParrotEntity(EntityType.PARROT, mc.world);
            case OMNOM -> new WolfEntity(EntityType.WOLF, mc.world); // unused
        };
        remotePreviews.put(key, created);
        return created;
    }

    private boolean matchesType(Entity entity, PetType type) {
        return (type == PetType.ALLAY && entity instanceof AllayEntity)
                || (type == PetType.BAT && entity instanceof BatEntity)
                || (type == PetType.WOLF && entity instanceof WolfEntity)
                || (type == PetType.CAT && entity instanceof CatEntity)
                || (type == PetType.FOX && entity instanceof FoxEntity)
                || (type == PetType.PARROT && entity instanceof ParrotEntity);
    }

    /** Sets limb swing speed/amount from actual per-tick horizontal movement, smoothed. */
    private void applyLimbAnimation(LivingEntity entity, float tickDelta) {
        double dx = groundPos.x - groundPrevPos.x;
        double dz = groundPos.z - groundPrevPos.z;
        float dist = (float) Math.sqrt(dx * dx + dz * dz);

        // Smooth the raw per-tick distance so the walk cycle doesn't stutter
        // when the ground AI snaps or lerps unevenly between ticks.
        limbDistance = MathHelper.lerp(0.35f, limbDistance, dist);
        float speed = MathHelper.clamp(limbDistance * 6f, 0f, 1.2f);
        limbSpeed = MathHelper.lerp(0.3f, limbSpeed, speed);

        try {
            Object limbAnimator = LivingEntity.class.getField("limbAnimator").get(entity);
            try { limbAnimator.getClass().getMethod("setSpeed", float.class).invoke(limbAnimator, limbSpeed); } catch (Exception ignored) {}
            try { limbAnimator.getClass().getMethod("updateMeasure", float.class, float.class).invoke(limbAnimator, limbSpeed, tickDelta); } catch (Exception ignored) {}
        } catch (Exception ignored) {}
    }

    /** Drives a simple wing-flap limb cycle for flying pets so they don't render static-limbed. */
    private void applyWingFlap(LivingEntity entity) {
        try {
            Object limbAnimator = LivingEntity.class.getField("limbAnimator").get(entity);
            float flapSpeed = 1.0f;
            try { limbAnimator.getClass().getMethod("setSpeed", float.class).invoke(limbAnimator, flapSpeed); } catch (Exception ignored) {}
            try { limbAnimator.getClass().getMethod("updateMeasure", float.class, float.class).invoke(limbAnimator, flapSpeed, 0.6f); } catch (Exception ignored) {}
        } catch (Exception ignored) {}
    }

    /** Smooth idle hover + shoulder-follow motion for Bat/Allay/Parrot. */
    private void tickFlyingLogic() {
        if (hover.finished(hoverForward)) {
            hoverForward = !hoverForward;
            hover.update(hoverForward);
            hover.reset();
        } else {
            hover.update(hoverForward);
        }
        if (wingFlap.finished(wingForward)) {
            wingForward = !wingForward;
            wingFlap.update(wingForward);
            wingFlap.reset();
        } else {
            wingFlap.update(wingForward);
        }

        flyPrevPos = flyPos;

        float yaw = mc.player.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        Vec3d forward = new Vec3d(-MathHelper.sin(yaw), 0.0, MathHelper.cos(yaw));
        Vec3d right = new Vec3d(-forward.z, 0.0, forward.x);
        double side = position.getValue() == PetPosition.TOP_RIGHT ? 1.0 : -1.0;
        double back = -0.45;

        // Gentle vertical bob so flying pets don't sit perfectly frozen in place.
        float bob = (hover.getValue() - 0.5f) * 0.12f;

        Vec3d basePos = mc.player.getPos()
                .add(right.multiply(side * 1.05))
                .add(forward.multiply(back))
                .add(0.0, height.getValue() + bob, 0.0);

        if (flyPos.equals(Vec3d.ZERO)) {
            flyPos = basePos;
            flyPrevPos = basePos;
        } else {
            // Smoothly follow the shoulder anchor instead of snapping every
            // tick, so quick turns/strafes don't look jittery.
            flyPos = flyPos.lerp(basePos, 0.35);
        }
    }

    private void tickGroundLogic(LivingEntity petEntity) {
        if (petEntity instanceof WolfEntity wolf) {
            wolf.setTamed(true, true);
            if (mc.player.getUuid() != null) {
                wolf.setOwnerUuid(mc.player.getUuid());
            }
        }

        groundPrevPos = groundPos;
        groundPrevYaw = groundYaw;
        groundPrevPitch = groundPitch;

        if (groundPos.equals(Vec3d.ZERO)) {
            groundPos = mc.player.getPos();
            groundPrevPos = groundPos;
            lastPlayerPos = mc.player.getPos();
            groundYaw = mc.player.getYaw();
            groundPrevYaw = groundYaw;
        }

        // Проверяем высоту над землёй
        double heightAboveGround = getHeightAboveGround(mc.player.getPos());

        // Small grace window before we consider the player "high up", so a
        // regular jump doesn't trigger a snap-to-ground teleport.
        boolean aboveThreshold = heightAboveGround > 4.5;
        if (aboveThreshold) {
            highUpTicks = Math.min(highUpTicks + 1, HIGH_UP_GRACE_TICKS + 1);
        } else {
            highUpTicks = 0;
        }
        boolean isHighUp = highUpTicks > HIGH_UP_GRACE_TICKS;
        boolean isGliding = mc.player.isGliding() || mc.player.isSpectator();
        boolean isFlying = isGliding || isHighUp;

        if (isFlying && !wasFlying) {
            // Игрок начал лететь - телепортируем питомца на землю под игроком
            Vec3d groundBelow = findGroundBelow(mc.player.getPos());
            if (groundBelow != null) {
                groundPos = groundBelow;
                groundPrevPos = groundBelow;
            }
        }
        wasFlying = isFlying;

        // Если игрок летит или высоко - питомец остаётся на месте (на земле)
        if (isFlying) {
            setSitting(petEntity, true);

            Vec3d diff = mc.player.getEyePos().subtract(groundPos);
            groundYaw = (float) Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90f;
            groundPitch = (float) Math.toDegrees(-Math.atan2(diff.y, Math.sqrt(diff.x * diff.x + diff.z * diff.z)));

            return;
        }

        if (mc.player.getPos().squaredDistanceTo(lastPlayerPos) < 0.0001) {
            afkTicks++;
        } else {
            afkTicks = 0;
        }
        lastPlayerPos = mc.player.getPos();

        if (mc.crosshairTarget instanceof EntityHitResult ehr && ehr.getEntity() instanceof LivingEntity le) {
            if (mc.player.handSwinging) {
                pvpTarget = le;
                pvpTicks = 60;
            }
        }
        if (pvpTicks > 0) pvpTicks--;
        else pvpTarget = null;

        boolean isAfk = afkTicks >= 100;
        setSitting(petEntity, isAfk);

        Vec3d targetPos;

        if (isAfk) {
            targetPos = groundPos;
            Vec3d diff = mc.player.getEyePos().subtract(groundPos);
            groundYaw = (float) Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90f;
            groundPitch = (float) Math.toDegrees(-Math.atan2(diff.y, Math.sqrt(diff.x * diff.x + diff.z * diff.z)));
        } 
        else if (pvpTarget != null) {
            float pYaw = mc.player.getYaw() * MathHelper.RADIANS_PER_DEGREE;
            Vec3d right = new Vec3d(-MathHelper.cos(pYaw), 0, -MathHelper.sin(pYaw));
            double side = 0.55;
            targetPos = mc.player.getPos().add(right.multiply(side)).add(0, 0, 0);
            Vec3d diff = pvpTarget.getEyePos().subtract(groundPos);
            groundYaw = (float) Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90f;
            groundPitch = (float) Math.toDegrees(-Math.atan2(diff.y, Math.sqrt(diff.x * diff.x + diff.z * diff.z)));

            if (groundPos.distanceTo(pvpTarget.getPos()) < 2.5 && mc.player.age % 10 == 0 && petEntity instanceof WolfEntity wolf) {
                wolf.swingHand(Hand.MAIN_HAND);
            }
        } 
        else {
            float pYaw = mc.player.getYaw() * MathHelper.RADIANS_PER_DEGREE;
            Vec3d right = new Vec3d(-MathHelper.cos(pYaw), 0, -MathHelper.sin(pYaw));
            Vec3d back = new Vec3d(MathHelper.sin(pYaw), 0, -MathHelper.cos(pYaw));
            targetPos = mc.player.getPos().add(right.multiply(0.65)).add(back.multiply(0.35));
            targetPos = new Vec3d(targetPos.x, mc.player.getY(), targetPos.z);

            if (groundPos.squaredDistanceTo(targetPos) > 0.05) {
                Vec3d diff = targetPos.subtract(groundPos);
                groundYaw = (float) Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90f;
                groundPitch = 0f;
            }
        }

        // Snap to actual ground height every tick (not just on state changes)
        // so the pet never sinks into or floats above terrain as it moves.
        double snappedY = snapToGround(targetPos);
        targetPos = new Vec3d(targetPos.x, snappedY, targetPos.z);

        if (groundPos.squaredDistanceTo(targetPos) > 100) {
            groundPos = targetPos;
        } else {
            // Slightly faster follow speed than before (was 0.15) so the pet
            // keeps up better with quick player movement without teleporting.
            groundPos = groundPos.lerp(targetPos, 0.25);
        }
    }

    private void setSitting(LivingEntity pet, boolean sitting) {
        localSitting = sitting;
        if (pet instanceof WolfEntity wolf) {
            wolf.setSitting(sitting);
            wolf.setInSittingPose(sitting);
        } else if (pet instanceof CatEntity cat) {
            cat.setSitting(sitting);
            cat.setInSittingPose(sitting);
        }
        // Fox has no vanilla sitting pose; it just stays still via position lerp.
    }

    /** Finds the ground height directly under a target column, keeping the pet on the surface. */
    private double snapToGround(Vec3d pos) {
        if (mc.world == null) return pos.y;
        for (int i = 0; i < 6; i++) {
            double y = pos.y - i;
            if (y < mc.world.getBottomY()) break;
            if (!mc.world.getBlockState(new BlockPos((int) pos.x, (int) (y - 1), (int) pos.z)).isAir()) {
                return y;
            }
        }
        // No solid ground found within range below - keep current height
        // rather than snapping into a hole/void.
        return pos.y;
    }

    private double getHeightAboveGround(Vec3d pos) {
        if (mc.world == null) return 0;
        
        for (int i = 0; i < 64; i++) {
            double y = pos.y - i;
            if (y < mc.world.getBottomY()) return i;
            
            if (!mc.world.getBlockState(new BlockPos((int) pos.x, (int) y, (int) pos.z)).isAir()) {
                return i;
            }
        }
        return 64;
    }

    private Vec3d findGroundBelow(Vec3d pos) {
        if (mc.world == null) return null;
        
        for (int i = 0; i < 64; i++) {
            double y = pos.y - i;
            if (y < mc.world.getBottomY()) break;
            
            if (!mc.world.getBlockState(new BlockPos((int) pos.x, (int) y, (int) pos.z)).isAir()) {
                return new Vec3d(pos.x, y + 1, pos.z);
            }
        }
        return null;
    }

    private Entity getPreview() {
        if (preview == null || preview.getWorld() != mc.world || !matches(preview)) {
            preview = switch (pet.getValue()) {
                case ALLAY -> new AllayEntity(EntityType.ALLAY, mc.world);
                case BAT -> new BatEntity(EntityType.BAT, mc.world);
                case WOLF -> new WolfEntity(EntityType.WOLF, mc.world);
                case CAT -> new CatEntity(EntityType.CAT, mc.world);
                case FOX -> new FoxEntity(EntityType.FOX, mc.world);
                case PARROT -> new ParrotEntity(EntityType.PARROT, mc.world);
                case OMNOM -> new WolfEntity(EntityType.WOLF, mc.world); // unused; custom model path
            };
        }
        return preview;
    }

    private boolean matches(Entity entity) {
        return (pet.getValue() == PetType.ALLAY && entity instanceof AllayEntity)
                || (pet.getValue() == PetType.BAT && entity instanceof BatEntity)
                || (pet.getValue() == PetType.WOLF && entity instanceof WolfEntity)
                || (pet.getValue() == PetType.CAT && entity instanceof CatEntity)
                || (pet.getValue() == PetType.FOX && entity instanceof FoxEntity)
                || (pet.getValue() == PetType.PARROT && entity instanceof ParrotEntity);
    }


    private OmNomModel getOmnomModel() {
        if (omnomModel == null) omnomModel = new OmNomModel();
        return omnomModel;
    }

    private void renderOmNomLocal(EventRender3D.Game event, float tickDelta) {
        if (mc.player == null || mc.world == null) return;

        if (groundPos.equals(Vec3d.ZERO)) {
            groundPos = mc.player.getPos();
            groundPrevPos = groundPos;
            groundYaw = mc.player.getYaw();
            groundPrevYaw = groundYaw;
            lastPlayerPos = mc.player.getPos();
        }

        if (mc.player.age != lastAge) {
            lastAge = mc.player.age;
            tickOmNomGround();
            try {
                FirebaseManager fb = batvisuals.getInstance().getFirebaseManager();
                if (fb != null && mc.player.age - firebaseSyncAge > 40) {
                    firebaseSyncAge = mc.player.age;
                    fb.updatePet(pet.getValue().name(), localSitting);
                }
            } catch (Throwable ignored) {}
        }

        Vec3d target = groundPrevPos.lerp(groundPos, tickDelta);
        float renderYaw = MathHelper.lerp(tickDelta, groundPrevYaw, groundYaw);

        double dx = groundPos.x - groundPrevPos.x;
        double dz = groundPos.z - groundPrevPos.z;
        float spd = (float) Math.sqrt(dx * dx + dz * dz);
        if (spd > 0.001f && !localSitting) {
            limbSpeed += spd * 2.5f;
            limbDistance = Math.min(1f, limbDistance + 0.15f);
        } else {
            limbDistance = Math.max(0f, limbDistance - 0.08f);
        }

        MatrixStack matrices = event.getMatrices();
        Vec3d camera = mc.gameRenderer.getCamera().getPos();
        VertexConsumerProvider.Immediate immediate = mc.getBufferBuilders().getEntityVertexConsumers();
        // ~1 block tall; model cuboids are in 1/16 units
        float s = scale.getValue() * 1.55f;
        float age = mc.player.age + tickDelta;
        matrices.push();
        matrices.translate(target.x - camera.x, target.y - camera.y, target.z - camera.z);
        getOmnomModel().renderAt(matrices, immediate, 0, 0, 0,
                renderYaw, s, limbSpeed, limbDistance, age, 15728880);
        immediate.draw();
        matrices.pop();
    }

    private void tickOmNomGround() {
        groundPrevPos = groundPos;
        groundPrevYaw = groundYaw;
        groundPrevPitch = groundPitch;

        double heightAboveGround = getHeightAboveGround(mc.player.getPos());
        boolean aboveThreshold = heightAboveGround > 4.5;
        if (aboveThreshold) highUpTicks = Math.min(highUpTicks + 1, HIGH_UP_GRACE_TICKS + 1);
        else highUpTicks = 0;
        boolean isHighUp = highUpTicks > HIGH_UP_GRACE_TICKS;
        boolean isGliding = mc.player.isGliding() || mc.player.isSpectator();
        boolean isFlying = isGliding || isHighUp;
        if (isFlying && !wasFlying) {
            Vec3d groundBelow = findGroundBelow(mc.player.getPos());
            if (groundBelow != null) {
                groundPos = groundBelow;
                groundPrevPos = groundBelow;
            }
        }
        wasFlying = isFlying;

        if (isFlying) {
            localSitting = true;
            Vec3d diff = mc.player.getEyePos().subtract(groundPos);
            groundYaw = (float) Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90f;
            return;
        }

        if (mc.player.getPos().squaredDistanceTo(lastPlayerPos) < 0.0001) afkTicks++;
        else afkTicks = 0;
        lastPlayerPos = mc.player.getPos();
        localSitting = afkTicks >= 100;

        float pYaw = mc.player.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        Vec3d right = new Vec3d(-MathHelper.cos(pYaw), 0, -MathHelper.sin(pYaw));
        Vec3d back = new Vec3d(MathHelper.sin(pYaw), 0, -MathHelper.cos(pYaw));
        Vec3d targetPos = mc.player.getPos().add(right.multiply(0.65)).add(back.multiply(0.35));
        targetPos = new Vec3d(targetPos.x, mc.player.getY(), targetPos.z);

        if (localSitting) {
            Vec3d diff = mc.player.getEyePos().subtract(groundPos);
            groundYaw = (float) Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90f;
        } else if (groundPos.squaredDistanceTo(targetPos) > 0.05) {
            Vec3d diff = targetPos.subtract(groundPos);
            groundYaw = (float) Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90f;
            groundPitch = 0f;
        }

        Vec3d snap = findGroundBelow(new Vec3d(targetPos.x, mc.player.getY() + 0.5, targetPos.z));
        if (snap != null) targetPos = new Vec3d(targetPos.x, snap.y, targetPos.z);
        groundPos = groundPos.lerp(targetPos, localSitting ? 0.15 : 0.35);
    }

    private void renderOmNomRemote(MatrixStack matrices, VertexConsumerProvider.Immediate immediate,
                                   double x, double y, double z, float yaw, boolean sit, float tickDelta) {
        float s = scale.getValue() * 1.0f;
        float age = (mc.player != null ? mc.player.age : 0) + tickDelta;
        float limb = sit ? 0f : age * 0.4f;
        float dist = sit ? 0f : 0.6f;
        getOmnomModel().renderAt(matrices, immediate, x, y, z, yaw, s, limb, dist, age, 15728880);
    }

    @Override
    public void onDisable() {
        preview = null;
        remotePreviews.clear();
        groundPos = Vec3d.ZERO;
        flyPos = Vec3d.ZERO;
        lastAge = -1;
        wasFlying = false;
        highUpTicks = 0;
        limbSpeed = 0f;
        limbDistance = 0f;
        try {
            FirebaseManager fb = batvisuals.getInstance().getFirebaseManager();
            if (fb != null) fb.updatePet(null, false);
        } catch (Throwable ignored) {}
        super.onDisable();
    }
}