package dev.batvisuals.modules.impl.render;

import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.NumberSetting;

/**
 * First-person look smoothing via MouseMixin (cursor delta exponential filter).
 */
public final class SmoothCamera extends Module {
    public final NumberSetting delay = new NumberSetting("Плавность", 30.0F, 5.0F, 50.0F, 0.5F);

    public SmoothCamera() {
        super("SmoothCamera", Category.Render, "Плавная камера");
    }
}
