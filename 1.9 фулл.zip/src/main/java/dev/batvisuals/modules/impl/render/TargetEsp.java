package dev.batvisuals.modules.impl.render;

import dev.batvisuals.client.managers.FriendsManager;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.batvisuals;
import dev.batvisuals.client.events.impl.EventRender2D;
import dev.batvisuals.client.events.impl.EventRender3D;
import dev.batvisuals.client.events.impl.EventAttackEntity;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.ListSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import dev.batvisuals.client.util.animations.Animation;
import dev.batvisuals.client.util.animations.Easing;
import dev.batvisuals.client.util.renderer.Render2D;
import dev.batvisuals.client.util.world.WorldUtils;
import dev.batvisuals.client.util.async.Async;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import meteordevelopment.orbit.EventHandler;
import java.awt.*;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.platform.GlStateManager;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
// imports for renderer delegates only
import dev.batvisuals.client.render.renderers.JelloRenderer;
import dev.batvisuals.client.util.render.StormFx;
import dev.batvisuals.client.render.renderers.SoulRenderer;
// no local MatrixStack usage after refactor

public class TargetEsp extends Module implements ThemeManager.ThemeChangeListener {

    private static final float BASE_SIZE = 5.0f;

    private static final String markerType = "";

    // Modes
    private final BooleanSetting modeMarker = new BooleanSetting("mode.marker", true, () -> false);
    private final BooleanSetting modeGhosts = new BooleanSetting("mode.soul", false, () -> false);
    private final BooleanSetting modeJello = new BooleanSetting("mode.circle", false, () -> false);
    private final BooleanSetting modeCrystals = new BooleanSetting("Кристалы", false, () -> false);
    private final BooleanSetting modeChains = new BooleanSetting("Цепи", false, () -> false);
    private final BooleanSetting modeCube = new BooleanSetting("Cube", false, () -> false);
    private final BooleanSetting modeCircleV2 = new BooleanSetting("Circle V2", false, () -> false);
    private final BooleanSetting modeGhostV2 = new BooleanSetting("Ghost V2", false, () -> false);
    private final BooleanSetting modeGarland = new BooleanSetting("Garland", false, () -> false);
    private final BooleanSetting modeAtom = new BooleanSetting("Atom", false, () -> false);
    private final BooleanSetting modeLightning = new BooleanSetting("Молнии", false, () -> false);
    private final BooleanSetting modeElectro = new BooleanSetting("Электро", false, () -> false);

    private final BooleanSetting modeMarkerOld = new BooleanSetting("old", false, () -> false);
    private final BooleanSetting modeMarkerNew = new BooleanSetting("new", true, () -> false);


    private final ListSetting mode = new ListSetting(
            I18n.translate("setting.animationMode"),
            true,
            modeMarker, modeGhosts, modeJello, modeCrystals, modeChains, modeCube, modeCircleV2, modeGhostV2, modeGarland, modeAtom,
            modeLightning, modeElectro
    );

    // Marker settings
    private final NumberSetting markerScale = new NumberSetting("setting.markerSize", 3.0f, 0.5f, 8.0f, 0.1f);
    private final BooleanSetting markerGlow = new BooleanSetting("setting.markerGlow", true, () -> modeMarker.getValue());
    private final NumberSetting markerGlowIntensity = new NumberSetting("setting.glowIntensity", 0.8f, 0.1f, 2.0f, 0.1f);
    private final BooleanSetting markerHitFlash = new BooleanSetting("Краснеть при ударе", true);
    private ListSetting markerMode = new ListSetting("setting.markerMode", true, modeMarkerOld, modeMarkerNew);

    // Ghosts settings
    private final NumberSetting ghostsScale = new NumberSetting("setting.ghostsScale", 0.3f, 0.1f, 1.0f, 0.05f);
    private final NumberSetting ghostsParticleDensity = new NumberSetting("setting.particleDensity", 14, 5, 20, 1);
    private final BooleanSetting ghostsGlow = new BooleanSetting("setting.markerGlow", true, () -> modeGhosts.getValue());
    private final NumberSetting ghostsGlowIntensity = new NumberSetting("setting.glowIntensity", 0.5f, 0.1f, 1.5f, 0.1f);
    private final NumberSetting ghostsAlpha = new NumberSetting("setting.alpha", 1.0f, 0.1f, 1.0f, 0.1f);

    // Jello settings
    private final NumberSetting jelloHeight = new NumberSetting("setting.jelloHeight", 1.5f, 0.5f, 3.0f, 0.1f);
    private final NumberSetting jelloAnimationSpeed = new NumberSetting("setting.animationSpeed", 2500.0f, 1000.0f, 5000.0f, 100.0f);
    private final BooleanSetting jelloGlow = new BooleanSetting("setting.markerGlow", true, () -> modeJello.getValue());
    private final NumberSetting jelloGlowIntensity = new NumberSetting("setting.glowIntensity", 0.5f, 0.1f, 1.5f, 0.1f);
    private final NumberSetting jelloAlpha = new NumberSetting("setting.alpha", 1.0f, 0.1f, 1.0f, 0.1f);

    private final NumberSetting crystalSpeed = new NumberSetting("Crystal Speed", 1.2f, 0.2f, 5.0f, 0.1f);
    private final NumberSetting crystalRadius = new NumberSetting("Crystal Radius", 0.85f, 0.3f, 2.5f, 0.05f);
    private final NumberSetting crystalCount = new NumberSetting("Crystal Count", 24f, 8f, 48f, 1f);
    private final NumberSetting crystalSize = new NumberSetting("Crystal Size", 0.13f, 0.05f, 0.4f, 0.01f);

    // Chains settings
    private final NumberSetting chainsRadius = new NumberSetting("Chains Radius", 0.95f, 0.4f, 2.5f, 0.05f);
    private final NumberSetting chainsSpeed = new NumberSetting("Chains Speed", 1.0f, 0.2f, 4.0f, 0.1f);
    private final NumberSetting chainsHeight = new NumberSetting("Chains Height", 0.55f, 0.2f, 1.5f, 0.05f);
    private final NumberSetting chainsSegments = new NumberSetting("Chains Segments", 12f, 6f, 24f, 1f);

    private final NumberSetting cubeSpeed = new NumberSetting("Cube Speed", 1.0f, 0.5f, 3.0f, 0.1f);
    private final NumberSetting circleV2Speed = new NumberSetting("Circle V2 Speed", 1.0f, 0.5f, 3.0f, 0.1f);
    private final NumberSetting ghostV2Speed = new NumberSetting("Ghost V2 Speed", 1.0f, 0.5f, 3.0f, 0.1f);
    private final NumberSetting garlandSpeed = new NumberSetting("Garland Speed", 1.0f, 0.5f, 3.0f, 0.1f);
    private final NumberSetting atomSpeed = new NumberSetting("Atom Speed", 1.0f, 0.5f, 3.0f, 0.1f);
    private final NumberSetting atomParticles = new NumberSetting("Atom Particles", 4f, 3f, 12f, 1f);

    // Молнии / Электро
    private final BooleanSetting lightOnHit = new BooleanSetting("Бить при ударе", false);
    private final NumberSetting lightMin = new NumberSetting("Интервал от (с)", 1.0f, 0.3f, 5.0f, 0.1f);
    private final NumberSetting lightMax = new NumberSetting("Интервал до (с)", 3.0f, 0.5f, 8.0f, 0.1f);
    private final NumberSetting lightHeight = new NumberSetting("Высота молнии", 6.0f, 2.0f, 15.0f, 0.5f);
    private final NumberSetting lightThick = new NumberSetting("Толщина молнии", 1.0f, 0.4f, 3.0f, 0.1f);
    private final BooleanSetting lightBranches = new BooleanSetting("Ветвление", true);
    private final NumberSetting electroDensity = new NumberSetting("Плотность тока", 45.0f, 10.0f, 140.0f, 5.0f);
    private final NumberSetting electroSize = new NumberSetting("Размер разрядов", 1.0f, 0.5f, 2.5f, 0.1f);
    private final BooleanSetting electroWhite = new BooleanSetting("Белый ток", true);
    private final StormFx storm = new StormFx();

    private double circleV2Step = 0.0;
    private long crystalStartTime = System.currentTimeMillis();


    private final ThemeManager themeManager;
    private Color currentColor;
    private final SoulRenderer soulRenderer;
    private final JelloRenderer jelloRenderer;

    public TargetEsp() {
        super("TargetEsp", Category.Render, I18n.translate("module.targetesp.description"));

        // Marker visibility
        markerScale.setVisible(() -> modeMarker.getValue());
        markerGlow.setVisible(() -> modeMarker.getValue());
        markerGlowIntensity.setVisible(() -> modeMarker.getValue() && markerGlow.getValue());
        markerHitFlash.setVisible(() -> true);
        markerMode.setVisible(() -> modeMarker.getValue());

        // Ghosts visibility
        ghostsScale.setVisible(() -> modeGhosts.getValue());
        ghostsParticleDensity.setVisible(() -> modeGhosts.getValue());
        ghostsGlow.setVisible(() -> modeGhosts.getValue());
        ghostsGlowIntensity.setVisible(() -> modeGhosts.getValue() && ghostsGlow.getValue());
        markerHitFlash.setVisible(() -> true);
        ghostsAlpha.setVisible(() -> modeGhosts.getValue());

        // Jello visibility
        jelloHeight.setVisible(() -> modeJello.getValue());
        jelloAnimationSpeed.setVisible(() -> modeJello.getValue());
        jelloGlow.setVisible(() -> modeJello.getValue());
        jelloGlowIntensity.setVisible(() -> modeJello.getValue() && jelloGlow.getValue());
        markerHitFlash.setVisible(() -> true);
        jelloAlpha.setVisible(() -> modeJello.getValue());

        crystalSpeed.setVisible(() -> modeCrystals.getValue());
        crystalRadius.setVisible(() -> modeCrystals.getValue());
        crystalCount.setVisible(() -> modeCrystals.getValue());
        crystalSize.setVisible(() -> modeCrystals.getValue());
        chainsRadius.setVisible(() -> modeChains.getValue());
        chainsSpeed.setVisible(() -> modeChains.getValue());
        chainsHeight.setVisible(() -> modeChains.getValue());
        chainsSegments.setVisible(() -> modeChains.getValue());
        cubeSpeed.setVisible(() -> modeCube.getValue());
        circleV2Speed.setVisible(() -> modeCircleV2.getValue());
        ghostV2Speed.setVisible(() -> modeGhostV2.getValue());
        garlandSpeed.setVisible(() -> modeGarland.getValue());
        atomSpeed.setVisible(() -> modeAtom.getValue());
        atomParticles.setVisible(() -> modeAtom.getValue());
        lightOnHit.setVisible(() -> modeLightning.getValue());
        lightMin.setVisible(() -> modeLightning.getValue() && !lightOnHit.getValue());
        lightMax.setVisible(() -> modeLightning.getValue() && !lightOnHit.getValue());
        lightHeight.setVisible(() -> modeLightning.getValue());
        lightThick.setVisible(() -> modeLightning.getValue());
        lightBranches.setVisible(() -> modeLightning.getValue());
        electroDensity.setVisible(() -> modeElectro.getValue());
        electroSize.setVisible(() -> modeElectro.getValue());
        electroWhite.setVisible(() -> modeElectro.getValue());

        this.themeManager = ThemeManager.getInstance();
        this.currentColor = themeManager.getThemeColor();
        themeManager.addThemeChangeListener(this);
        this.soulRenderer = new SoulRenderer(themeManager);
        this.jelloRenderer = new JelloRenderer(themeManager);
    }

    @Override
    public void onThemeChanged(ThemeManager.Theme theme) {
        this.currentColor = theme.getAccentColor();
    }

    private final Animation animation = new Animation(300, 1f, true, Easing.BOTH_SINE);
    private final Animation soulAnimation = new Animation(500, 1f, true, Easing.BOTH_SINE);
    private final Animation jelloAnimation = new Animation(500, 1f, true, Easing.BOTH_SINE);

    private LivingEntity lastTarget = null;
    private LivingEntity fadingTarget = null; // Таргет который исчезает
    private long lastSeenTime = 0L;
    private static final long ESP_DURATION = 2500;
    private long lastHitTime = 0L;
    private static final long HIT_FLASH_DURATION = 300;

    private Vec3d lastKnownCenter = null;
    private float lastKnownHeight = 1.8f;
    private float lastKnownWidth = 0.6f;

    private boolean forceFade = false;
    private Vec3d fadeOrigin = null;

    // Occlusion check throttling
    private long lastOcclusionAt = 0L;
    private boolean lastOcclusion = false;

    // Precompute storage (math-only), updated in background
    private volatile float cachedFinalSize = -1f;
    private volatile int cachedColorRGBA = 0xFFFFFFFF;
    private volatile float cachedRotation = 0f;

    private static int rgb(Color c) {
        if (c == null) return 0xFFFFFF;
        return (c.getRed() << 16) | (c.getGreen() << 8) | c.getBlue();
    }

    private static int clamp255(double v) {
        if (v < 0) return 0;
        if (v > 255) return 255;
        return (int) Math.round(v);
    }

    private Color getTargetColor(LivingEntity target) {
        if (target == null) return Color.WHITE;
        float healthPercent = target.getHealth() / target.getMaxHealth();
        if (healthPercent > 0.7f) return Color.GREEN;
        else if (healthPercent > 0.3f) return Color.YELLOW;
        else return Color.RED;
    }

    private Color getMarkerColor() {
        // Check if target was hit recently - flash red for HIT_FLASH_DURATION
        long now = System.currentTimeMillis();
        if (markerHitFlash.getValue() && now - lastHitTime < HIT_FLASH_DURATION) {
            return Color.RED;
        }
        
        // Use theme color by default
        return currentColor;
    }

    private Vec3d entityCenter(LivingEntity ent, EventRender2D e) {
        Vec3d lp = ent.getLerpedPos(e.getTickDelta());
        return lp.add(0, ent.getHeight() * 0.5, 0);
    }

    // 3D entity center method kept for potential future use
    // private Vec3d entityCenter(LivingEntity ent, EventRender3D.Game e) {
    //     Vec3d lp = ent.getLerpedPos(e.getTickDelta());
    //     return lp.add(0, ent.getHeight() * 0.5, 0);
    // }

    // hasAnyArmor is unused after refactor but kept for potential future logic
    // private static boolean hasAnyArmor(LivingEntity e) {
    //     for (ItemStack s : e.getArmorItems()) {
    //         if (!s.isEmpty()) return true;
    //     }
    //     return false;
    // }

    private static boolean isInvisibleAndUnrevealed(LivingEntity e) {
        return e.hasStatusEffect(StatusEffects.INVISIBILITY) || e.isInvisible();
    }

    private boolean isOccluded(Vec3d from, Vec3d to) {
        long now = System.currentTimeMillis();
        if (now - lastOcclusionAt < 50L) {
            return lastOcclusion;
        }
        HitResult hr = mc.world.raycast(new RaycastContext(
                from, to,
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                mc.player
        ));
        lastOcclusion = hr.getType() != HitResult.Type.MISS;
        lastOcclusionAt = now;
        return lastOcclusion;
    }

    @EventHandler
    public void onAttackEntity(EventAttackEntity e) {
        if (modeLightning.getValue() && lightOnHit.getValue() && e.isEffectsAllowed()
                && e.getPlayer() == mc.player && e.getTarget() instanceof LivingEntity) {
            storm.strike(e.getTarget(), lightHeight.getValue(), lightBranches.getValue());
        }
        if (lastTarget != null && e.getTarget() == lastTarget) {
            lastHitTime = System.currentTimeMillis();
        }
    }

    @EventHandler
    public void onRender2D(EventRender2D e) {
        if (fullNullCheck()) return;

        long now = System.currentTimeMillis();
        // Track previous target if needed in future logic
        // LivingEntity previousTarget = lastTarget;

        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            EntityHitResult hit = (EntityHitResult) mc.crosshairTarget;
            if (hit.getEntity() instanceof LivingEntity) {
                LivingEntity living = (LivingEntity) hit.getEntity();
                if (living.isAlive() && !FriendsManager.isFriendEntity(living)) {
                    Vec3d center = entityCenter(living, e);

                    if (isInvisibleAndUnrevealed(living)) {
                        lastTarget = null;
                        fadeOrigin = center;
                        forceFade = true;
                        fadingTarget = null; // Очищаем fadingTarget
                    } else {
                        Vec3d eyes = mc.player.getCameraPosVec(e.getTickDelta());
                        if (isOccluded(eyes, center)) {
                            lastTarget = null;
                            fadeOrigin = center;
                            forceFade = true;
                            fadingTarget = null; // Очищаем fadingTarget
                        } else {
                            lastTarget = living;
                            lastSeenTime = now;
                            forceFade = false;
                            fadeOrigin = null;
                            fadingTarget = null; // Очищаем fadingTarget при новом таргете

                            lastKnownCenter = center;
                            lastKnownHeight = living.getHeight();
                            lastKnownWidth = living.getWidth();
                        }
                    }
                }
            }
        }

        if (lastTarget != null) {
            boolean killed = !lastTarget.isAlive();
            boolean expired = (now - lastSeenTime) > ESP_DURATION;

            if (killed || expired) {
                Vec3d centerForFade;
                try {
                    centerForFade = entityCenter(lastTarget, e);
                } catch (Throwable t) {
                    centerForFade = lastKnownCenter;
                }
                if (centerForFade != null) fadeOrigin = centerForFade;

                lastKnownHeight = lastTarget.getHeight();
                lastKnownWidth = lastTarget.getWidth();

                fadingTarget = lastTarget; // Сохраняем для анимации
                lastTarget = null;
                forceFade = true;
            } else {
                if (isInvisibleAndUnrevealed(lastTarget)) {
                    fadeOrigin = entityCenter(lastTarget, e);
                    fadingTarget = lastTarget; // Сохраняем для анимации
                    lastTarget = null;
                    forceFade = true;
                } else {
                    Vec3d eyes = mc.player.getCameraPosVec(e.getTickDelta());
                    Vec3d center = entityCenter(lastTarget, e);
                    if (isOccluded(eyes, center)) {
                        fadeOrigin = center;
                        fadingTarget = lastTarget; // Сохраняем для анимации
                        lastTarget = null;
                        forceFade = true;
                    } else {
                        lastKnownCenter = center;
                        lastKnownHeight = lastTarget.getHeight();
                        lastKnownWidth = lastTarget.getWidth();
                    }
                }
            }
        }

        boolean grow = (lastTarget != null) && !forceFade;
        animation.update(grow);
        
        // Управление анимацией soul эффекта
        boolean soulGrow = (lastTarget != null) && !forceFade;
        soulAnimation.update(soulGrow);
        
        // Управление анимацией jello эффекта
        boolean jelloGrow = (lastTarget != null) && !forceFade;
        jelloAnimation.update(jelloGrow);

        // Ensure one mode at a time
        BooleanSetting[] allModes = {modeMarker, modeGhosts, modeJello, modeCrystals, modeChains, modeCube, modeCircleV2, modeGhostV2, modeGarland, modeAtom, modeLightning, modeElectro};
        BooleanSetting active = null;
        // last in list wins so newly selected modes override Marker
        for (int i = allModes.length - 1; i >= 0; i--) {
            if (allModes[i].getValue()) {
                if (active == null) active = allModes[i];
                else allModes[i].setValue(false);
            }
        }
        if (active == null) modeMarker.setValue(true);


        if (modeMarker.getValue()) {
            renderMarker(e);
        }

        if (animation.getValue() <= 0 && forceFade) {
            forceFade = false;
            fadeOrigin = null;
        }
        
        // Очищаем fadeOrigin и fadingTarget когда soul анимация завершена
        if (soulAnimation.getValue() <= 0 && forceFade && modeGhosts.getValue()) {
            fadeOrigin = null;
            fadingTarget = null;
        }
        
        // Очищаем fadeOrigin и fadingTarget когда jello анимация завершена
        if (jelloAnimation.getValue() <= 0 && forceFade && modeJello.getValue()) {
            fadeOrigin = null;
            fadingTarget = null;
        }

        // Async precompute now scheduled inside renderMarker() to keep MC/GL calls on main thread
    }

    @EventHandler
    public void onRender3D(EventRender3D.Game e) {
        if (fullNullCheck()) return;

        if (modeLightning.getValue()) {
            if (!lightOnHit.getValue()) {
                storm.tickAuto(lastTarget != null && animation.getValue() > 0.01f ? lastTarget : null,
                        lightMin.getValue(), lightMax.getValue(), lightHeight.getValue(), lightBranches.getValue());
            }
            storm.renderBolts(mc.gameRenderer.getCamera(), rgb(currentColor), lightThick.getValue());
            return;
        }
        if (modeElectro.getValue()) {
            LivingEntity et = fadingTarget != null ? fadingTarget : lastTarget;
            storm.tickElectro(et != null && animation.getValue() > 0.05f ? et : null,
                    electroDensity.getValue(), electroSize.getValue());
            storm.renderElectro(mc.gameRenderer.getCamera(), e.getTickDelta(),
                    electroWhite.getValue() ? 0xFFFFFF : rgb(currentColor), electroSize.getValue());
            return;
        }

        if (modeGhosts.getValue()) {
            // Рендерим soul эффект если есть таргет или есть fadingTarget для плавного исчезания
            if (lastTarget != null || (fadingTarget != null && soulAnimation.getValue() > 0)) {
                // Используем fadingTarget если есть, иначе lastTarget
                LivingEntity targetToRender = fadingTarget != null ? fadingTarget : lastTarget;
                soulRenderer.render(
                        e,
                        targetToRender,
                        ghostsParticleDensity.getValue().intValue(),
                        ghostsScale.getValue().floatValue(),
                        ghostsGlow.getValue().booleanValue(),
                        ghostsGlowIntensity.getValue().doubleValue(),
                        soulAnimation.getValue(),
                        fadeOrigin,
                        lastKnownHeight,
                        lastKnownWidth,
                        ghostsAlpha.getValue().floatValue(),
                        getMarkerColor()
                );
            }
        } else if (modeJello.getValue()) {
            // Рендерим jello эффект с анимацией появления/исчезания
            if (lastTarget != null || (fadingTarget != null && jelloAnimation.getValue() > 0)) {
                // Используем fadingTarget если есть, иначе lastTarget
                LivingEntity targetToRender = fadingTarget != null ? fadingTarget : lastTarget;
                jelloRenderer.render(
                        e,
                        targetToRender,
                        fadeOrigin,
                        lastKnownWidth,
                        lastKnownHeight,
                        jelloHeight.getValue().doubleValue(),
                        jelloAnimationSpeed.getValue().doubleValue(),
                        jelloGlow.getValue().booleanValue(),
                        jelloGlowIntensity.getValue().doubleValue(),
                        jelloAnimation.getValue(),
                        getMarkerColor()
                );
            }
        } else if (modeCrystals.getValue()) {
            if (lastTarget != null || (fadingTarget != null && animation.getValue() > 0.01f)) {
                LivingEntity targetToRender = fadingTarget != null ? fadingTarget : lastTarget;
                if (targetToRender != null) {
                    renderCrystals(targetToRender, e.getMatrices(), e.getTickDelta(), animation.getValue());
                }
            }
        } else if (modeChains.getValue()) {
            if (lastTarget != null || (fadingTarget != null && animation.getValue() > 0.01f)) {
                LivingEntity targetToRender = fadingTarget != null ? fadingTarget : lastTarget;
                if (targetToRender != null) {
                    renderChains(targetToRender, e.getMatrices(), e.getTickDelta(), animation.getValue());
                }
            }
        } else if (modeCube.getValue()) {
            LivingEntity t = fadingTarget != null ? fadingTarget : lastTarget;
            if (t != null && animation.getValue() > 0.01f)
                TargetEspExtra.renderCube(e.getMatrices(), t, e.getTickDelta(), animation.getValue(), getMarkerColor(), cubeSpeed.getValue());
        } else if (modeCircleV2.getValue()) {
            LivingEntity t = fadingTarget != null ? fadingTarget : lastTarget;
            if (t != null && animation.getValue() > 0.01f) {
                circleV2Step += 0.035 * circleV2Speed.getValue();
                TargetEspExtra.renderCircleV2(e.getMatrices(), t, e.getTickDelta(), animation.getValue(), getMarkerColor(), circleV2Speed.getValue(), circleV2Step);
            }
        } else if (modeGhostV2.getValue()) {
            LivingEntity t = fadingTarget != null ? fadingTarget : lastTarget;
            if (t != null && animation.getValue() > 0.01f)
                TargetEspExtra.renderGhostV2(e.getMatrices(), t, e.getTickDelta(), animation.getValue(), getMarkerColor(), ghostV2Speed.getValue());
        } else if (modeGarland.getValue()) {
            LivingEntity t = fadingTarget != null ? fadingTarget : lastTarget;
            if (t != null && animation.getValue() > 0.01f)
                TargetEspExtra.renderGarland(e.getMatrices(), t, e.getTickDelta(), animation.getValue(), getMarkerColor(), garlandSpeed.getValue());
        } else if (modeAtom.getValue()) {
            LivingEntity t = fadingTarget != null ? fadingTarget : lastTarget;
            if (t != null && animation.getValue() > 0.01f)
                TargetEspExtra.renderAtom(e.getMatrices(), t, e.getTickDelta(), animation.getValue(), getMarkerColor(), atomSpeed.getValue(), Math.round(atomParticles.getValue()));
        }
    }

    private void renderMarker(EventRender2D e) {
        Vec3d centerWorld = lastTarget != null ? entityCenter(lastTarget, e) : fadeOrigin;
        if (centerWorld == null) return;

        float animVal = animation.getValue();
        if (animVal <= 0 && !markerGlow.getValue()) return;

        Vec3d pos = WorldUtils.getPosition(centerWorld);
        if (!(pos.z > 0) || !(pos.z < 1)) return;

        e.getContext().getMatrices().push();
        e.getContext().getMatrices().translate(pos.getX(), pos.getY(), 0);

        // Schedule math-only precompute for marker visuals (size, rotation, color) using snapshot data
        if (animVal > 0) {
            // compute maxSize using main-thread scale (MC camera dependent)
            float maxSize = (float) WorldUtils.getScale(centerWorld, BASE_SIZE * markerScale.getValue() * animVal);

            double px = mc.player.getX();
            double pz = mc.player.getZ();
            double tx = (lastTarget != null) ? lastTarget.getX() : (lastKnownCenter != null ? lastKnownCenter.x : px);
            double tz = (lastTarget != null) ? lastTarget.getZ() : (lastKnownCenter != null ? lastKnownCenter.z : pz);
            float markerScaleVal = markerScale.getValue().floatValue();
            boolean hasTarget = lastTarget != null;
            int baseR, baseG, baseB;
            {
                Color baseCol = getMarkerColor();
                baseR = baseCol.getRed();
                baseG = baseCol.getGreen();
                baseB = baseCol.getBlue();
            }
            long lastHitSnapshot = lastHitTime;
            boolean hitFlashEnabled = markerHitFlash.getValue();

            Async.run(() -> {
                double dx = tx - px;
                double dz = tz - pz;
                double distance = Math.sqrt(dx * dx + dz * dz);
                float finalSize = Math.max(maxSize - (float) distance, markerScaleVal);
                double sin = Math.sin(System.currentTimeMillis() / 1000.0);
                float rotationAngle = (float) (sin * 360);

                long now = System.currentTimeMillis();
                float hitPhase = (hitFlashEnabled && now - lastHitSnapshot < HIT_FLASH_DURATION) ? 1f : 0f;
                int fr = clamp255(baseR + (255 - baseR) * hitPhase);
                int fg = clamp255(baseG + (0 - baseG) * hitPhase);
                int fb = clamp255(baseB + (0 - baseB) * hitPhase);
                int fa = clamp255(255 * animVal);
                int rgba = (fa & 0xFF) << 24 | (fr & 0xFF) << 16 | (fg & 0xFF) << 8 | (fb & 0xFF);

                cachedFinalSize = finalSize;
                cachedRotation = rotationAngle;
                cachedColorRGBA = rgba;
            });
        }

        // Draw glow effect if enabled
        if (markerGlow.getValue()) {
            renderMarkerGlow(e, centerWorld);
        }

        // Draw main marker
        renderMarkerMain(e, centerWorld, animVal, cachedColorRGBA);

        e.getContext().getMatrices().pop();
    }

    private void renderMarkerGlow(EventRender2D e, Vec3d centerWorld) {
        float animVal = animation.getValue();
        if (animVal <= 0) return;
        Color base = (lastTarget != null) ? getTargetColor(lastTarget) : currentColor;
        float glowSize = (float) WorldUtils.getScale(centerWorld, BASE_SIZE * markerScale.getValue() * (1.0f + markerGlowIntensity.getValue() * 0.5f) * animVal);
        int glowAlpha = clamp255(180 * animVal);
        Color glowColor = new Color(base.getRed(), base.getGreen(), base.getBlue(), glowAlpha);

        Render2D.drawTexture(
                e.getContext().getMatrices(),
                -glowSize / 2f, -glowSize / 2f, glowSize, glowSize,
                0f,
                batvisuals.id("hud/glow.png"),
                currentColor
        );
    }

    private void renderMarkerMain(EventRender2D e, Vec3d centerWorld, float animVal, int colorRGBA) {
        if (animVal <= 0) return;

        // Use precomputed values if available, else fallback to inline computation
        float finalSize = this.cachedFinalSize > 0 ? this.cachedFinalSize : (float) WorldUtils.getScale(centerWorld, BASE_SIZE * markerScale.getValue() * animVal);
        float rotationAngle = this.cachedRotation;

        Color finalColor = new Color(colorRGBA, true);

        e.getContext().getMatrices().push();
        e.getContext().getMatrices().multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rotationAngle));

        Render2D.drawTexture(
                e.getContext().getMatrices(),
                -finalSize / 2f, -finalSize / 2f, finalSize, finalSize,
                0f,
                batvisuals.id(modeMarkerNew.getValue() ? "hud/alt_marker.png" : "hud/marker.png"),
                finalColor
        );

        e.getContext().getMatrices().pop();
    }

    private void renderCrystals(LivingEntity target, MatrixStack matrices, float tickDelta, float anim) {
        if (anim <= 0.01f) return;
        Vec3d camPos = mc.gameRenderer.getCamera().getPos();
        double x = MathHelper.lerp(tickDelta, target.prevX, target.getX()) - camPos.x;
        double y = MathHelper.lerp(tickDelta, target.prevY, target.getY()) - camPos.y;
        double z = MathHelper.lerp(tickDelta, target.prevZ, target.getZ()) - camPos.z;

        float speed = crystalSpeed.getValue();
        float radius = crystalRadius.getValue();
        double time = (System.currentTimeMillis() - crystalStartTime) / 1000.0 * speed;

        Color col = getMarkerColor();
        float r = col.getRed() / 255f;
        float g = col.getGreen() / 255f;
        float b = col.getBlue() / 255f;
        float alphaMul = Math.min(1f, anim);

        int crystals = Math.max(4, crystalCount.getValue().intValue());
        float height = target.getHeight();
        float size = crystalSize.getValue() * anim;

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        Matrix4f matrix = matrices.peek().getPositionMatrix();
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);

        for (int i = 0; i < crystals; i++) {
            float progress = (float) i / crystals;
            double spiralOffset = progress * Math.PI * 4;
            double angle1 = spiralOffset + time;
            double angle2 = spiralOffset + time + Math.PI;
            double yPos = y + progress * height;

            double x1 = x + Math.cos(angle1) * radius * anim;
            double z1 = z + Math.sin(angle1) * radius * anim;
            double x2 = x + Math.cos(angle2) * radius * anim;
            double z2 = z + Math.sin(angle2) * radius * anim;

            drawCrystal(buffer, matrix, x1, yPos, z1, size, r, g, b, alphaMul);
            drawCrystal(buffer, matrix, x2, yPos, z2, size, r, g, b, alphaMul);
        }

        dev.batvisuals.client.util.render.SafeDraw.draw(buffer);

        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }



    private static final net.minecraft.util.Identifier CHAINS_TEX =
            net.minecraft.util.Identifier.of("batvisuals", "textures/chains.png");

    private void renderChains(LivingEntity target, MatrixStack matrices, float tickDelta, float anim) {
        if (anim <= 0.01f || target == null || mc == null || mc.player == null) return;
        Vec3d camera = mc.gameRenderer.getCamera().getPos();
        double x = MathHelper.lerp(tickDelta, target.lastRenderX, target.getX()) - camera.x;
        double y = MathHelper.lerp(tickDelta, target.lastRenderY, target.getY()) - camera.y;
        double z = MathHelper.lerp(tickDelta, target.lastRenderZ, target.getZ()) - camera.z;

        float radius = chainsRadius.getValue() * (0.6f + target.getWidth() * 0.5f);
        float speed = chainsSpeed.getValue();
        float heightGap = Math.max(0.35f, chainsHeight.getValue() * target.getHeight());
        int segments = Math.max(8, Math.round(chainsSegments.getValue()));
        Color base = getMarkerColor() != null ? getMarkerColor() : Color.WHITE;
        float alpha = Math.max(0f, Math.min(1f, anim));

        float phase = (System.currentTimeMillis() % 100000L) / 1000f * speed;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, CHAINS_TEX);

        // Layer 1 (lower) + Layer 2 (upper), opposite spin
        drawChainRingVerts(matrices, x, y + heightGap * 0.30f, z, radius, segments, phase, base, alpha, true);
        drawChainRingVerts(matrices, x, y + heightGap * 0.92f, z, radius * 1.12f, segments, -phase * 1.25f, base, alpha, false);

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private void drawChainRingVerts(MatrixStack matrices, double cx, double cy, double cz,
                                    float radius, int segments, float phase, Color base, float alpha, boolean layerA) {
        float r = base.getRed() / 255f;
        float g = base.getGreen() / 255f;
        float b = base.getBlue() / 255f;
        float a = alpha * 0.95f;
        float linkH = 0.22f;

        Matrix4f matrix = matrices.peek().getPositionMatrix();
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        for (int i = 0; i < segments; i++) {
            double a0 = phase + (i) * (Math.PI * 2.0 / segments);
            double a1 = phase + (i + 1) * (Math.PI * 2.0 / segments);
            // slightly expand so links overlap
            double pad = 0.08;
            double aa0 = a0 - pad / radius;
            double aa1 = a1 + pad / radius;

            float x0 = (float) (cx + Math.cos(aa0) * radius);
            float z0 = (float) (cz + Math.sin(aa0) * radius);
            float x1 = (float) (cx + Math.cos(aa1) * radius);
            float z1 = (float) (cz + Math.sin(aa1) * radius);
            float y0 = (float) (cy - linkH);
            float y1 = (float) (cy + linkH);

            // outer face
            buffer.vertex(matrix, x0, y0, z0).texture(0f, 1f).color(r, g, b, a);
            buffer.vertex(matrix, x1, y0, z1).texture(1f, 1f).color(r, g, b, a);
            buffer.vertex(matrix, x1, y1, z1).texture(1f, 0f).color(r, g, b, a);
            buffer.vertex(matrix, x0, y1, z0).texture(0f, 0f).color(r, g, b, a);
            // back face (no cull already, but double for visibility)
            buffer.vertex(matrix, x0, y1, z0).texture(0f, 0f).color(r, g, b, a * 0.85f);
            buffer.vertex(matrix, x1, y1, z1).texture(1f, 0f).color(r, g, b, a * 0.85f);
            buffer.vertex(matrix, x1, y0, z1).texture(1f, 1f).color(r, g, b, a * 0.85f);
            buffer.vertex(matrix, x0, y0, z0).texture(0f, 1f).color(r, g, b, a * 0.85f);
        }

        dev.batvisuals.client.util.render.SafeDraw.draw(buffer);
    }

    /**
     * Real TargetESP effects drawn into the ClickGUI left preview panel (screen space).
     * Uses the same modes, textures and settings as in-world.
     */
    public void renderGuiPreview(net.minecraft.client.gui.DrawContext context, float cx, float cy, float alpha) {
        if (alpha < 0.02f) return;
        Color col = getMarkerColor() != null ? getMarkerColor() : (currentColor != null ? currentColor : Color.WHITE);
        Color c = new Color(col.getRed(), col.getGreen(), col.getBlue(), (int) (255 * alpha));
        var matrices = context.getMatrices();
        long now = System.currentTimeMillis();

        if (modeMarker.getValue()) {
            float size = 28f + markerScale.getValue() * 6f;
            float rot = (now % 4000L) / 4000f * 360f;
            matrices.push();
            matrices.translate(cx, cy - 8f, 0);
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rot));
            Render2D.drawTexture(matrices, -size / 2f, -size / 2f, size, size, 0f,
                    batvisuals.id(modeMarkerNew.getValue() ? "hud/alt_marker.png" : "hud/marker.png"), c);
            if (markerGlow.getValue()) {
                float gs = size * (1.4f + markerGlowIntensity.getValue() * 0.3f);
                Color gc = new Color(c.getRed(), c.getGreen(), c.getBlue(), (int) (90 * alpha));
                Render2D.drawTexture(matrices, -gs / 2f, -gs / 2f, gs, gs, 0f,
                        batvisuals.id("hud/glow.png"), gc);
            }
            matrices.pop();
        } else if (modeJello.getValue()) {
            float h = 36f + jelloHeight.getValue() * 18f;
            float phase = (now % Math.max(1L, (long) jelloAnimationSpeed.getValue().floatValue()))
                    / Math.max(1f, jelloAnimationSpeed.getValue());
            float yOff = (float) Math.sin(phase * Math.PI * 2) * 10f;
            float w = 40f;
            Color soft = new Color(c.getRed(), c.getGreen(), c.getBlue(), (int) (70 * alpha));
            Color edge = new Color(c.getRed(), c.getGreen(), c.getBlue(), (int) (180 * alpha));
            Render2D.drawRoundedRect(matrices, cx - w / 2f, cy - h / 2f + yOff, w, h, 12f, soft);
            Render2D.drawBorder(matrices, cx - w / 2f, cy - h / 2f + yOff, w, h, 12f, 0.6f, 1.2f, edge);
        } else if (modeGhosts.getValue()) {
            int n = Math.max(5, Math.round(ghostsParticleDensity.getValue()));
            float sc = ghostsScale.getValue() * 14f;
            for (int i = 0; i < n; i++) {
                double ang = now / 700.0 + i * (Math.PI * 2.0 / n);
                float px = cx + (float) Math.cos(ang) * (22f + (i % 3) * 4f);
                float py = cy - 12f + (float) Math.sin(ang * 1.4 + i) * 22f;
                Color pc = new Color(c.getRed(), c.getGreen(), c.getBlue(),
                        (int) (ghostsAlpha.getValue() * 200 * alpha));
                Render2D.drawTexture(matrices, px - sc / 2f, py - sc / 2f, sc, sc, sc / 2f,
                        batvisuals.id("hud/glow.png"), pc);
            }
        } else if (modeCrystals.getValue()) {
            int n = Math.max(6, Math.round(crystalCount.getValue()));
            float rad = 20f + crystalRadius.getValue() * 18f;
            float size = 6f + crystalSize.getValue() * 30f;
            double time = now / 1000.0 * crystalSpeed.getValue();
            for (int i = 0; i < n; i++) {
                double progress = (double) i / n;
                double spiral = progress * Math.PI * 4 + time;
                float px = cx + (float) Math.cos(spiral) * rad * (0.5f + (float) progress * 0.5f);
                float py = cy - 30f + (float) progress * 50f;
                Render2D.drawRoundedRect(matrices, px - size / 2f, py - size, size, size * 2f, 1.5f, c);
            }
        } else if (modeChains.getValue()) {
            float rad = 22f + chainsRadius.getValue() * 16f;
            int segs = Math.max(8, Math.round(chainsSegments.getValue()));
            float phase = (now / 1000f) * chainsSpeed.getValue();
            float linkW = (float) (2 * Math.PI * rad / segs) * 1.1f;
            float linkH = 10f;
            for (int layer = 0; layer < 2; layer++) {
                float r = rad + layer * 10f;
                float yBase = cy - 8f + layer * 22f;
                double dir = layer == 0 ? 1 : -1;
                for (int i = 0; i < segs; i++) {
                    double a0 = phase * dir + i * (Math.PI * 2.0 / segs);
                    double a1 = phase * dir + (i + 1) * (Math.PI * 2.0 / segs);
                    float mx = (float) ((Math.cos(a0) + Math.cos(a1)) * 0.5 * r);
                    float my = (float) ((Math.sin(a0) + Math.sin(a1)) * 0.25 * r);
                    matrices.push();
                    matrices.translate(cx + mx, yBase + my, 0);
                    float yaw = (float) Math.toDegrees(Math.atan2(Math.sin(a0) + Math.sin(a1), Math.cos(a0) + Math.cos(a1)));
                    matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(yaw + 90f));
                    Render2D.drawTexture(matrices, -linkW / 2f, -linkH / 2f, linkW, linkH, 0f, CHAINS_TEX, c);
                    matrices.pop();
                }
            }
        } else if (modeCube.getValue() || modeCircleV2.getValue() || modeGhostV2.getValue() || modeGarland.getValue() || modeAtom.getValue()) {
            // simplified ring preview for new modes
            float rad = 28f;
            for (int i = 0; i < 24; i++) {
                double ang = (now / 800.0) + i * (Math.PI * 2 / 24);
                float px = cx + (float) Math.cos(ang) * rad;
                float py = cy + (float) Math.sin(ang) * rad * 0.4f;
                Render2D.drawRoundedRect(matrices, px - 3f, py - 3f, 6f, 6f, 2f, c);
            }
        }
    }

    private void drawCrystal(BufferBuilder buffer, Matrix4f matrix,
                             double x, double y, double z,
                             float size, float r, float g, float b, float a) {
        float cx = (float) x;
        float cy = (float) y;
        float cz = (float) z;
        float top = cy + size;
        float bottom = cy - size;
        float px = cx + size;
        float nx = cx - size;
        float pz = cz + size;
        float nz = cz - size;

        tri(buffer, matrix, cx, top, cz, nx, cy, cz, cx, cy, nz, r, g, b, a);
        tri(buffer, matrix, cx, top, cz, cx, cy, nz, px, cy, cz, r, g, b, a);
        tri(buffer, matrix, cx, top, cz, px, cy, cz, cx, cy, pz, r, g, b, a);
        tri(buffer, matrix, cx, top, cz, cx, cy, pz, nx, cy, cz, r, g, b, a);

        tri(buffer, matrix, cx, bottom, cz, cx, cy, nz, nx, cy, cz, r, g, b, a * 0.7f);
        tri(buffer, matrix, cx, bottom, cz, px, cy, cz, cx, cy, nz, r, g, b, a * 0.7f);
        tri(buffer, matrix, cx, bottom, cz, cx, cy, pz, px, cy, cz, r, g, b, a * 0.7f);
        tri(buffer, matrix, cx, bottom, cz, nx, cy, cz, cx, cy, pz, r, g, b, a * 0.7f);
    }

    private void tri(BufferBuilder buffer, Matrix4f matrix,
                     float x1, float y1, float z1,
                     float x2, float y2, float z2,
                     float x3, float y3, float z3,
                     float r, float g, float b, float a) {
        buffer.vertex(matrix, x1, y1, z1).color(r, g, b, a);
        buffer.vertex(matrix, x2, y2, z2).color(r, g, b, a * 0.7f);
        buffer.vertex(matrix, x3, y3, z3).color(r, g, b, a * 0.7f);
    }


    
    /**
     * Preview effects in matrix space already centered on a 1.8-tall humanoid (GUI).
     * Matrix: +Y up, 1 unit = 1 block.
     */
    public void renderGuiPreview3D(net.minecraft.client.util.math.MatrixStack ms, float anim, float alpha) {
        Color col = getMarkerColor() != null ? getMarkerColor() : (currentColor != null ? currentColor : Color.WHITE);
        Color c = new Color(col.getRed(), col.getGreen(), col.getBlue(), (int) (255 * Math.min(1f, alpha)));
        float w = 0.6f;
        float h = 1.8f;
        float pa = anim * Math.min(1f, alpha);
        if (modeLightning.getValue()) {
            storm.previewBolt(ms, pa, rgb(c), h);
            return;
        }
        if (modeElectro.getValue()) {
            storm.previewElectro(ms, pa, electroWhite.getValue() ? 0xFFFFFF : rgb(c), h);
            return;
        }
        if (modeCube.getValue()) {
            TargetEspExtra.renderCubeLocal(ms, anim, c, cubeSpeed.getValue(), w, h);
        } else if (modeCircleV2.getValue()) {
            circleV2Step += 0.035 * circleV2Speed.getValue();
            TargetEspExtra.renderCircleV2Local(ms, anim, c, circleV2Speed.getValue(), circleV2Step, w, h);
        } else if (modeGhostV2.getValue()) {
            TargetEspExtra.renderGhostV2Local(ms, anim, c, ghostV2Speed.getValue(), w, h);
        } else if (modeGarland.getValue()) {
            TargetEspExtra.renderGarlandLocal(ms, anim, c, garlandSpeed.getValue(), w, h);
        } else if (modeAtom.getValue()) {
            TargetEspExtra.renderAtomLocal(ms, anim, c, atomSpeed.getValue(), Math.round(atomParticles.getValue()), h);
        } else if (modeCrystals.getValue()) {
            TargetEspExtra.renderCrystalsLocal(ms, anim, c, crystalSpeed.getValue(), crystalRadius.getValue(),
                    Math.round(crystalCount.getValue()), crystalSize.getValue(), h);
        } else if (modeChains.getValue()) {
            TargetEspExtra.renderChainsLocal(ms, anim, c, chainsSpeed.getValue(), chainsRadius.getValue(),
                    chainsHeight.getValue(), Math.round(chainsSegments.getValue()), h);
        } else if (modeJello.getValue()) {
            TargetEspExtra.renderJelloLocal(ms, anim, c, jelloHeight.getValue(), jelloAnimationSpeed.getValue(), h);
        } else if (modeGhosts.getValue()) {
            TargetEspExtra.renderGhostsLocal(ms, anim, c, ghostsScale.getValue(), Math.round(ghostsParticleDensity.getValue()), h);
        } else {
            // marker: simple rotating diamond in local space
            TargetEspExtra.renderMarkerLocal(ms, anim, c, markerScale.getValue(), h);
        }
    }

    // --- ClickGUI live preview helpers ---
    public boolean previewMarker() { return modeMarker.getValue(); }
    public boolean previewGhosts() { return modeGhosts.getValue(); }
    public boolean previewJello() { return modeJello.getValue(); }
    public boolean previewCrystals() { return modeCrystals.getValue(); }
    public boolean previewChains() { return modeChains.getValue(); }
    public boolean previewCube() { return modeCube.getValue(); }
    public boolean previewCircleV2() { return modeCircleV2.getValue(); }
    public boolean previewGhostV2() { return modeGhostV2.getValue(); }
    public boolean previewGarland() { return modeGarland.getValue(); }
    public boolean previewAtom() { return modeAtom.getValue(); }
    public float previewChainsRadius() { return chainsRadius.getValue(); }
    public float previewMarkerScale() { return markerScale.getValue(); }
    public float previewJelloHeight() { return jelloHeight.getValue(); }
    public float previewCrystalRadius() { return crystalRadius.getValue(); }
    public int previewCrystalCount() { return Math.round(crystalCount.getValue()); }
    public Color previewColor() {
        return currentColor != null ? currentColor : themeManager.getThemeColor();
    }
    public String previewModeName() {
        if (modeElectro.getValue()) return "Электро";
        if (modeLightning.getValue()) return "Молнии";
        if (modeAtom.getValue()) return "Atom";
        if (modeGarland.getValue()) return "Garland";
        if (modeGhostV2.getValue()) return "Ghost V2";
        if (modeCircleV2.getValue()) return "Circle V2";
        if (modeCube.getValue()) return "Cube";
        if (modeChains.getValue()) return "Цепи";
        if (modeCrystals.getValue()) return "Кристалы";
        if (modeJello.getValue()) return "Круг";
        if (modeGhosts.getValue()) return "Души";
        return "Маркер";
    }

}
