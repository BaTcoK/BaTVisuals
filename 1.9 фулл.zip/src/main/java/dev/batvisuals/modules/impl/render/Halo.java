package dev.batvisuals.modules.impl.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.batvisuals.client.events.impl.EventRender3D;
import dev.batvisuals.client.managers.FriendsManager;
import dev.batvisuals.client.managers.ThemeManager;
import dev.batvisuals.client.util.EntityVisibility;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.awt.Color;

/**
 * 3D torus halo above the head (cosmetics).
 */
public class Halo extends Module implements ThemeManager.ThemeChangeListener {

    private final NumberSetting radius = new NumberSetting("Радиус", 0.32f, 0.15f, 0.7f, 0.01f);
    private final NumberSetting tube = new NumberSetting("Толщина 3D", 0.045f, 0.02f, 0.12f, 0.005f);
    private final NumberSetting height = new NumberSetting("Высота", 0.52f, 0.2f, 1.2f, 0.01f);
    private final NumberSetting opacity = new NumberSetting("Прозрачность", 0.9f, 0.2f, 1.0f, 0.05f);
    private final NumberSetting spinSpeed = new NumberSetting("Вращение", 0.5f, 0f, 3.0f, 0.05f);
    private final BooleanSetting self = new BooleanSetting("На себе", true);
    private final BooleanSetting friends = new BooleanSetting("На друзьях", true);
    private final BooleanSetting others = new BooleanSetting("На игроках", false);
    private final BooleanSetting themeColor = new BooleanSetting("Цвет темы", true);

    private final ThemeManager themeManager;
    private Color currentColor;
    private static final int RING_SEGS = 40;
    private static final int TUBE_SEGS = 10;

    public Halo() {
        super("Halo", Category.Cosmetics, "3D нимб над головой");
        this.themeManager = ThemeManager.getInstance();
        this.currentColor = themeManager.getThemeColor();
        themeManager.addThemeChangeListener(this);
    }

    @Override
    public void onThemeChanged(ThemeManager.Theme theme) {
        if (theme != null && theme.getAccentColor() != null) this.currentColor = theme.getAccentColor();
    }

    @Override
    public void onDisable() {
        themeManager.removeThemeChangeListener(this);
        super.onDisable();
    }

    private Color liveColor() {
        if (Boolean.TRUE.equals(themeColor.getValue())) {
            try {
                Color c = themeManager.getThemeColor();
                if (c != null) currentColor = c;
            } catch (Throwable ignored) {}
        }
        if (currentColor == null) currentColor = new Color(255, 220, 100);
        float a = opacity.getValue() == null ? 0.9f : opacity.getValue();
        return new Color(currentColor.getRed(), currentColor.getGreen(), currentColor.getBlue(),
                MathHelper.clamp((int) (a * 255), 30, 255));
    }

    private boolean shouldShow(PlayerEntity p) {
        if (p == null || !p.isAlive()) return false;
        try {
            if (!EntityVisibility.canShowCosmetic(p)) return false;
        } catch (Throwable ignored) {}
        if (mc.player != null && p == mc.player) {
            if (mc.options.getPerspective().isFirstPerson()) return false;
            return Boolean.TRUE.equals(self.getValue());
        }
        try {
            if (FriendsManager.checkFriend(p.getGameProfile().getName())) {
                return Boolean.TRUE.equals(friends.getValue());
            }
        } catch (Throwable ignored) {}
        return Boolean.TRUE.equals(others.getValue());
    }

    @EventHandler
    public void onRender3D(EventRender3D.Game e) {
        if (fullNullCheck()) return;
        float tickDelta = e.getTickDelta();
        MatrixStack matrices = e.getMatrices();
        Color col = liveColor();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (!shouldShow(p)) continue;
            renderHalo3D(matrices, p, tickDelta, col);
        }
    }

    private void renderHalo3D(MatrixStack matrices, PlayerEntity player, float tickDelta, Color color) {
        Vec3d pos = player.getLerpedPos(tickDelta);
        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        float eye = player.getEyeHeight(player.getPose());
        float h = height.getValue() == null ? 0.52f : height.getValue();
        float R = radius.getValue() == null ? 0.32f : radius.getValue();
        float r = tube.getValue() == null ? 0.045f : tube.getValue();
        float spin = spinSpeed.getValue() == null ? 0.5f : spinSpeed.getValue();

        matrices.push();
        matrices.translate(pos.x - cam.x, pos.y - cam.y + eye + h, pos.z - cam.z);

        float bodyYaw = MathHelper.lerp(tickDelta, player.prevBodyYaw, player.bodyYaw);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-bodyYaw));
        if (spin > 0.001f) {
            float ang = (System.currentTimeMillis() % 360000L) / 1000f * spin * 55f;
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(ang));
        }

        Matrix4f mat = matrices.peek().getPositionMatrix();
        int argb = (color.getAlpha() << 24) | (color.getRed() << 16) | (color.getGreen() << 8) | color.getBlue();
        int dim = ((Math.max(40, color.getAlpha() / 2)) << 24)
                | ((color.getRed() * 2 / 3) << 16) | ((color.getGreen() * 2 / 3) << 8) | (color.getBlue() * 2 / 3);

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);

        BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);

        // Torus: major circle R in XZ, tube radius r
        for (int i = 0; i < RING_SEGS; i++) {
            float a0 = (float) (i * Math.PI * 2 / RING_SEGS);
            float a1 = (float) ((i + 1) * Math.PI * 2 / RING_SEGS);
            float ca0 = MathHelper.cos(a0), sa0 = MathHelper.sin(a0);
            float ca1 = MathHelper.cos(a1), sa1 = MathHelper.sin(a1);

            for (int j = 0; j < TUBE_SEGS; j++) {
                float b0 = (float) (j * Math.PI * 2 / TUBE_SEGS);
                float b1 = (float) ((j + 1) * Math.PI * 2 / TUBE_SEGS);
                float cb0 = MathHelper.cos(b0), sb0 = MathHelper.sin(b0);
                float cb1 = MathHelper.cos(b1), sb1 = MathHelper.sin(b1);

                // point on torus: (R + r*cos b) on ring, y = r*sin b
                float x00 = (R + r * cb0) * ca0, y00 = r * sb0, z00 = (R + r * cb0) * sa0;
                float x01 = (R + r * cb1) * ca0, y01 = r * sb1, z01 = (R + r * cb1) * sa0;
                float x10 = (R + r * cb0) * ca1, y10 = r * sb0, z10 = (R + r * cb0) * sa1;
                float x11 = (R + r * cb1) * ca1, y11 = r * sb1, z11 = (R + r * cb1) * sa1;

                int cA = sb0 > 0.2f ? argb : dim;
                int cB = sb1 > 0.2f ? argb : dim;

                buf.vertex(mat, x00, y00, z00).color(cA);
                buf.vertex(mat, x10, y10, z10).color(cA);
                buf.vertex(mat, x11, y11, z11).color(cB);

                buf.vertex(mat, x00, y00, z00).color(cA);
                buf.vertex(mat, x11, y11, z11).color(cB);
                buf.vertex(mat, x01, y01, z01).color(cB);
            }
        }

        dev.batvisuals.client.util.render.SafeDraw.draw(buf);

        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        matrices.pop();
    }
}
