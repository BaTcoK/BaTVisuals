package dev.batvisuals.modules.impl.utility;

import dev.batvisuals.client.events.impl.EventPacket;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.text.Text;

public class BetterChat extends Module {

    public final BooleanSetting antiSpam = new BooleanSetting("AntiSpam", false);

    private String lastMessage = null;
    private int spamCount = 0;

    public BetterChat() {
        super("BetterChat", Category.Utility, "Улучшенный чат");
    }

    @EventHandler
    public void onPacketReceive(EventPacket.Receive event) {
        if (!(event.getPacket() instanceof GameMessageS2CPacket packet)) return;
        if (!antiSpam.getValue()) return;

        String content = packet.content().getString();
        if (content.equals(lastMessage)) {
            event.cancel();
            spamCount++;
            if (mc.inGameHud != null && mc.inGameHud.getChatHud() != null) {
                mc.inGameHud.getChatHud().addMessage(Text.literal(content + " §7[x" + spamCount + "]"));
            }
        } else {
            lastMessage = content;
            spamCount = 1;
        }
    }
}
