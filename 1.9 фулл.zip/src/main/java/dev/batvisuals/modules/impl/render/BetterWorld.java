package dev.batvisuals.modules.impl.render;

import dev.batvisuals.client.events.impl.EventPacket;
import dev.batvisuals.client.events.impl.EventTick;
import dev.batvisuals.modules.api.Category;
import dev.batvisuals.modules.api.Module;
import dev.batvisuals.modules.settings.api.Nameable;
import dev.batvisuals.modules.settings.impl.BooleanSetting;
import dev.batvisuals.modules.settings.impl.EnumSetting;
import dev.batvisuals.modules.settings.impl.NumberSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;

public class BetterWorld extends Module {

    public enum WeatherMode implements Nameable {
        CLEAR("Clear"),
        RAIN("Rain"),
        STORM("Storm");
        private final String name;
        WeatherMode(String name) { this.name = name; }
        @Override public String getName() { return name; }
    }

    public final BooleanSetting changeTime = new BooleanSetting("Time Changer", false);
    public final NumberSetting time = new NumberSetting("Time", 12f, 1f, 40f, 1f, () -> changeTime.getValue());

    public final BooleanSetting fullBright = new BooleanSetting("FullBright", false);
    public final BooleanSetting fog = new BooleanSetting("Fog", false);
    public final NumberSetting startFog = new NumberSetting("StartFog", 3f, 0f, 20f, 1f, () -> fog.getValue());
    public final NumberSetting endFog = new NumberSetting("EndFog", 50f, 0f, 80f, 1f, () -> fog.getValue());
    public final NumberSetting alphaFog = new NumberSetting("AlphaFog", 90f, 30f, 100f, 5f, () -> fog.getValue());

    public final BooleanSetting skyShader = new BooleanSetting("SkyShader", false);
    public final BooleanSetting weather = new BooleanSetting("Weather", false);
    public final EnumSetting<WeatherMode> weatherMode = new EnumSetting<>("WeatherMode", WeatherMode.CLEAR, () -> weather.getValue());

    public BetterWorld() {
        super("BetterWorld", Category.Render, "Меняет вид мира и небо");
    }

    @EventHandler
    public void onPacketReceive(EventPacket.Receive event) {
        if (!changeTime.getValue()) return;
        if (event.getPacket() instanceof WorldTimeUpdateS2CPacket) {
            event.cancel();
        }
    }

    @EventHandler
    public void onTick(EventTick event) {
        if (fullNullCheck()) return;

        // Time is forced by ClientWorldPropertiesMixin when changeTime is active.
        // WorldTimeUpdateS2CPacket is cancelled in onPacketReceive.

        if (fullBright.getValue()) {
            StatusEffectInstance s = new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 2, false, false, false);
            mc.player.addStatusEffect(s);
        }

        if (skyShader.getValue()) {
            mc.options.getBobView().setValue(false);
        }

        if (weather.getValue()) {
            switch (weatherMode.getValue()) {
                case CLEAR -> {
                    mc.world.getLevelProperties().setRaining(false);
                    mc.world.setRainGradient(0.0f);
                    mc.world.setThunderGradient(0.0f);
                }
                case RAIN -> {
                    mc.world.getLevelProperties().setRaining(true);
                    mc.world.setRainGradient(1.0f);
                    mc.world.setThunderGradient(0.0f);
                }
                case STORM -> {
                    mc.world.getLevelProperties().setRaining(true);
                    mc.world.setRainGradient(1.0f);
                    mc.world.setThunderGradient(1.0f);
                }
            }
        }
    }

    @Override
    public void onDisable() {
        if (mc.player != null && fullBright.getValue()) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
        super.onDisable();
    }

    /** Used by ClientWorldPropertiesMixin instead of old TimeChanger */
    public boolean isTimeChangerActive() {
        return isToggled() && changeTime.getValue();
    }

    public long getForcedTimeOfDay() {
        return (long) (time.getValue() * 1000L);
    }
}
