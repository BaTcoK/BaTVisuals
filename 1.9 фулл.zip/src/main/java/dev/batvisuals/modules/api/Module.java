package dev.batvisuals.modules.api;

import dev.batvisuals.batvisuals;
import dev.batvisuals.modules.settings.Setting;
import dev.batvisuals.modules.settings.api.Bind;
import dev.batvisuals.client.util.Wrapper;
import dev.batvisuals.client.util.notify.Notify;
import dev.batvisuals.client.util.notify.NotifyIcons;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import dev.batvisuals.modules.impl.utility.ClientSound;

import java.util.ArrayList;
import java.util.List;

@Getter
public abstract class Module implements Wrapper {
    private final String name, description;
    private final Category category;
    protected boolean toggled;
    @Setter private Bind bind = new Bind(-1, false);
    private final List<Setting<?>> settings = new ArrayList<>();

    public Module(String name, Category category, String description) {
        this.name = name;
        this.category = category;
        this.description = description;
    }

    // Temporary backward compatibility; prefer using the 3-arg ctor with explicit description
    public Module(String name, Category category) {
        this(name, category, name);
    }

    public void onEnable() {
        toggled = true;
        batvisuals.getInstance().getEventHandler().subscribe(this);
        playClientSound(true);
        if (!fullNullCheck() && !name.equals("UI")) {
            String translatedName = I18n.translate(name);
            String msg = I18n.translate("notify.featureEnabled", translatedName);
            batvisuals.getInstance().getNotifyManager().add(new Notify(NotifyIcons.successIcon, msg, 1000));
        }
    }

    public void onDisable() {
        toggled = false;
        batvisuals.getInstance().getEventHandler().unsubscribe(this);
        playClientSound(false);
        if (!fullNullCheck() && !name.equals("UI")) {
            String translatedName = I18n.translate(name);
            String msg = I18n.translate("notify.featureDisabled", translatedName);
            batvisuals.getInstance().getNotifyManager().add(new Notify(NotifyIcons.failIcon, msg, 1000));
        }
    }

    private void playClientSound(boolean enable) {
        try {
            if (this instanceof ClientSound) return; // don't recurse
            ClientSound cs = batvisuals.getInstance().getModuleManager().getModule(ClientSound.class);
            if (cs == null || !cs.isToggled()) return;
            String id = enable ? cs.getEnableSoundId() : cs.getDisableSoundId();
            float vol = cs.getPlayVolume();
            mc.getSoundManager().play(PositionedSoundInstance.master(
                    SoundEvent.of(Identifier.of(id.contains(":") ? id.split(":", 2)[0] : "batvisuals",
                            id.contains(":") ? id.split(":", 2)[1] : id)),
                    1.0f, Math.max(0f, Math.min(1f, vol))));
        } catch (Throwable ignored) {}
    }

    public void setToggled(boolean toggled) {
        if (toggled) onEnable();
        else onDisable();
        // Планируем автосохранение после изменения состояния модуля
        try {
            dev.batvisuals.client.managers.AutoSaveManager asm = batvisuals.getInstance().getAutoSaveManager();
            if (asm != null) asm.scheduleAutoSave();
        } catch (Throwable ignored) {}
    }

    public void toggle() {
        setToggled(!toggled);
    }

    public static boolean fullNullCheck() {
        return mc.player == null || mc.world == null;
    }
}