package dev.batvisuals.modules.api;

public enum Category {
    Friends("F"),
    Gps("G"),
    Theme("I"),
    Render("H"),
    Utility("U"),
    Games("J"),
    Music("M"),
    Config("C"),
    Hud("L"),
    AI("A"),
    Cosmetics("K"),
    Profile("P");

    private final String icon;

    Category(String icon) {
        this.icon = icon;
    }

    public String getIcon() {
        return icon;
    }
}
